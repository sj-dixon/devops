#!/bin/sh

NAMESPACE="services-local"
ROOT_DIR=$(git rev-parse --show-toplevel)
INGRESS="kong"
cd "$ROOT_DIR" || exit 1

RELEASE_NAME="$1"
CHART_NAME="$2"

docker build -f "./microservices/${CHART_NAME}/Dockerfile" -t "alcumus/${CHART_NAME}" .

# for some reason, this prints out the exact needed command
# but removing echo doesn't make the command run with expected arguments.
helm upgrade "${RELEASE_NAME}" "./charts/${CHART_NAME}" --install --create-namespace --namespace "$NAMESPACE" \
  --set image.pullPolicy=IfNotPresent --set image.repository="alcumus/${CHART_NAME}" --set image.tag=latest \
  --set network.ingress="${INGRESS}" --set network.host="services.internal" --set container.GIT_COMMIT_SHA="$(git rev-parse HEAD)"