#!/bin/sh

ROOT_DIR=$(git rev-parse --show-toplevel)
CURRENT_DATE=$(date)

SERVICE_NAME=$1
BUILD_VERSION=${2:-$CURRENT_DATE}

COMMIT_SHA=$(git rev-parse HEAD)

cd "$ROOT_DIR" || exit 1

echo "Building ${SERVICE_NAME} using build \"${BUILD_VERSION}\" and commit ${COMMIT_SHA}"
docker build -f "./microservices/${SERVICE_NAME}/Dockerfile" -t "alcumus/${SERVICE_NAME}" --build-arg "buildVersion=${BUILD_VERSION}" --build-arg "commit=${COMMIT_SHA}"  .
