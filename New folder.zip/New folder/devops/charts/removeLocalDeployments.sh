#!/bin/sh

ROOT_DIR=$(git rev-parse --show-toplevel)
NAMESPACE=${1:-services-local}
cd "$ROOT_DIR" || exit 1

echo "----------------------------------------------------"
echo "Removing Local Helm Releases For A Clean Slate."
echo " - this should be unnecessary 99% of the time."
echo " - does not uninstall Kong."
echo "Namespace is ${NAMESPACE}"
echo "----------------------------------------------------"

helm uninstall dependencies --namespace "${NAMESPACE}"
helm uninstall tenants --namespace "${NAMESPACE}"
helm uninstall auth --namespace "${NAMESPACE}"
helm uninstall users --namespace "${NAMESPACE}"
helm uninstall si-mapping --namespace "${NAMESPACE}"
helm uninstall billing --namespace "${NAMESPACE}"
helm uninstall admin --namespace "${NAMESPACE}"
