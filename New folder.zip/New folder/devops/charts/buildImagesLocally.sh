#!/bin/sh

ROOT_DIR=$(git rev-parse --show-toplevel)
BUILD_VERSION=$(date)
cd "$ROOT_DIR" || exit 1

echo "----------------------------------------------------"
echo "Building Docker Images for Local Deployment"
echo "----------------------------------------------------"

buildDockerImage(){
  ./charts/buildDockerImage.sh "$1" "${BUILD_VERSION}"
}


buildDockerImage auth-service
buildDockerImage billing-service
buildDockerImage tenant-service
buildDockerImage users-service
buildDockerImage si-mapping-service
buildDockerImage admin-service
