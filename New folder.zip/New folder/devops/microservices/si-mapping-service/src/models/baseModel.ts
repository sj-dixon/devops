import { getMySqlCurrentTimestamp } from '@alcumus/objection-lib';
import { Model } from 'objection';

export default class BaseModel extends Model {
  id!: number;
  createdAt!: string;
  modifiedAt!: string;
  createdBy?: number;
  modifiedBy?: number;

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeInsert() {
    const now = getMySqlCurrentTimestamp();
    this.createdAt = now;
    this.modifiedAt = now;
  }

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeUpdate() {
    this.modifiedAt = getMySqlCurrentTimestamp();
  }
}
