import {
  JsonSchemaBuilder,
  getMySqlCurrentTimestamp,
} from '@alcumus/objection-lib';
import BaseModel from './baseModel';
import { User } from '../types';

export class UserMappingEntity extends BaseModel implements User {
  deletedAt?: string;
  deletedBy?: number;
  tenantId!: number;
  userId!: number;
  ecmsId?: string | null;
  fidId?: string | null;

  static tableName = 'user_mapping';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withCreatedByAtFields(true)
    .withModifiedByAtFields(true)
    .withStringField('deletedAt')
    .withIntegerField('deletedBy')
    .withIntegerField('tenantId', true)
    .withIntegerField('userId', true)
    .withStringField('ecmsId')
    .withStringField('fidId')
    .build();

  static async createUser(userMapping: User): Promise<UserMappingEntity> {
    return UserMappingEntity.query().insert(userMapping);
  }

  static async findByUserIdAndTenantId(
    userId: number,
    tenantId: number
  ): Promise<UserMappingEntity> {
    return UserMappingEntity.query().findOne({
      tenantId,
      userId,
      deletedAt: null,
    });
  }

  static async findByUserId(userId: number): Promise<Array<UserMappingEntity>> {
    return UserMappingEntity.query().where({
      userId,
      deletedAt: null,
    });
  }

  static async updateUser(
    mutation: UserMappingEntity
  ): Promise<UserMappingEntity> {
    return UserMappingEntity.query().patchAndFetchById(mutation.id, mutation);
  }

  static async delete(userId: number, tenantId: number): Promise<void | Error> {
    const result: UserMappingEntity = await UserMappingEntity.query().findOne({
      userId,
      tenantId,
      deletedAt: null,
    });

    if (!result) {
      throw new Error('Entity is already deleted');
    }

    await UserMappingEntity.query()
      .where({ userId, tenantId, deletedAt: null })
      .patch({
        deletedAt: getMySqlCurrentTimestamp(),
      });
  }

  static async hardDelete(userId: number): Promise<void | Error> {
    const result = await UserMappingEntity.query().where({
      userId,
    });

    if (!result.length) {
      throw new Error('No record found!');
    }

    result.forEach(async (userEntry) => {
      await UserMappingEntity.query()
        .delete()
        .where({ userId: userEntry.userId, createdBy: 1, modifiedBy: 1 });
    });
  }
}
