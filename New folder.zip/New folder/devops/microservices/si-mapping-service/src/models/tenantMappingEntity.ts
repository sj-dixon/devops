import {
  getMySqlCurrentTimestamp,
  JsonSchemaBuilder,
} from '@alcumus/objection-lib';
import { Tenant } from '../types';
import BaseModel from './baseModel';

export class TenantMappingEntity extends BaseModel {
  deletedAt?: string;
  deletedBy?: number;
  fidId?: string | null;
  ecmsId?: string | null;
  tenantId?: number;

  static tableName = 'tenant_mapping';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withCreatedByAtFields(true)
    .withModifiedByAtFields(true)
    .withStringField('deletedAt')
    .withIntegerField('deletedBy')
    .withIntegerField('tenantId', true)
    .withStringField('ecmsId')
    .withStringField('fidId')
    .build();

  static async create(tenantMapping: Tenant): Promise<TenantMappingEntity> {
    return TenantMappingEntity.query().insert(tenantMapping);
  }

  static async findByTenantId(tenantId: number): Promise<TenantMappingEntity> {
    return TenantMappingEntity.query().findOne({
      tenantId,
      deletedAt: null,
    });
  }

  static async patchAndGetById(
    tenantMappingEntity: TenantMappingEntity
  ): Promise<TenantMappingEntity> {
    return TenantMappingEntity.query().patchAndFetchById(
      tenantMappingEntity.id,
      tenantMappingEntity
    );
  }

  static async createOrUpdateTenant(
    tenantId: number,
    createTenantRequest: Tenant
  ): Promise<TenantMappingEntity> {
    const tenant = await TenantMappingEntity.findByTenantId(tenantId);

    if (tenant) {
      const existingTenant = tenant;
      if (createTenantRequest.fidId || createTenantRequest.fidId === null) {
        existingTenant.fidId = createTenantRequest?.fidId;
      }
      if (createTenantRequest.ecmsId || createTenantRequest.ecmsId == null) {
        existingTenant.ecmsId = createTenantRequest?.ecmsId;
      }
      return await this.patchAndGetById(existingTenant);
    }

    return await TenantMappingEntity.create({
      ...createTenantRequest,
      tenantId,
    });
  }

  static async deleteTenant(tenantId: number): Promise<void | Error> {
    await TenantMappingEntity.query().where({ tenantId }).patch({
      deletedAt: getMySqlCurrentTimestamp(),
    });
  }

  static async hardDelete(tenantId: number): Promise<void> {
    const result = await TenantMappingEntity.query().where({
      tenantId,
    });

    if (result.length === 0) {
      throw new Error('No record found!');
    }
    result.forEach(async (tenantEntry) => {
      await TenantMappingEntity.query()
        .delete()
        .where({ tenantId: tenantEntry.tenantId, createdBy: 1, modifiedBy: 1 });
    });
  }
}
