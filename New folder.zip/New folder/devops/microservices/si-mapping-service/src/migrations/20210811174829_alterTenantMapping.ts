import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'tenant_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
    }
  );
  await knex.schema.alterTable(
    'tenant_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.integer('created_by').nullable().defaultTo(null).unsigned();
      tableBuilder.integer('modified_by').nullable().defaultTo(null).unsigned();
    }
  );

  await knex.schema.alterTable(
    'user_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
    }
  );
  await knex.schema.alterTable(
    'user_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.integer('created_by').nullable().defaultTo(null).unsigned();
      tableBuilder.integer('modified_by').nullable().defaultTo(null).unsigned();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'tenant_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
    }
  );
  await knex.schema.alterTable(
    'tenant_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.string('created_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('modified_by', 50).notNullable().defaultTo('@SYSTEM');
    }
  );
  await knex.schema.alterTable(
    'user_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
    }
  );
  await knex.schema.alterTable(
    'user_mapping',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.string('created_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('modified_by', 50).notNullable().defaultTo('@SYSTEM');
    }
  );
}
