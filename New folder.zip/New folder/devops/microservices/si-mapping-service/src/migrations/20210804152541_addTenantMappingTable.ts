import { Knex } from 'knex';

const TABLE_NAME = 'tenant_mapping';
const COLUMN_LENGTH = 50;

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.increments('id').primary();
      tableBuilder
        .string('created_by', COLUMN_LENGTH)
        .nullable()
        .defaultTo(null); // this needn't be there
      tableBuilder
        .string('modified_by', COLUMN_LENGTH)
        .nullable()
        .defaultTo(null); // this needn't be there
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      tableBuilder.timestamp('deleted_at').nullable();
      tableBuilder.string('deleted_by', COLUMN_LENGTH).nullable();

      tableBuilder.integer('tenant_id').unsigned().notNullable();
      tableBuilder.string('ecmsId', COLUMN_LENGTH).nullable();
      tableBuilder.string('fidId', COLUMN_LENGTH).nullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
