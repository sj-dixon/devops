import { expressValidator } from '@alcumus/express-app';

export const requireUserId = expressValidator
  .param('userId', 'users.get.requireUserId')
  .exists();
