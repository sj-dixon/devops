import { expressValidator } from '@alcumus/express-app';

export const requireFidOrEcms = expressValidator.oneOf(
  [
    expressValidator.body('ecmsId').exists(),
    expressValidator.body('fidId').exists(),
  ],
  'fidID or ecmsID is needed'
);
