import path from 'path';
import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import { tenantsRouterV1 } from './routes/tenantsV1';
import { usersRouterV1 } from './routes/usersV1';
const apiSpec = './api-spec.yaml';

const app = configureApp({
  serviceName: 'Safety Intelligence Entity Mapping Service',
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
    validateResponse: true,
  },
  setup: (theApp) => {
    theApp.use(ENDPOINTS.TENANTS, tenantsRouterV1);
    theApp.use(ENDPOINTS.USERS, usersRouterV1);
  },
});

export default app;
