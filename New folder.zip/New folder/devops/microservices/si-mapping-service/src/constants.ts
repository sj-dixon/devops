import { Utilities } from '@alcumus/globals';

export const SI_MAPPING_SERVICE_PORT =
  Number(Utilities.ProcessEnv.getValue('SI_MAPPING_SERVICE_PORT')) || 8017;

export const BASE_PATH = '/api';
export const BASE_PATH_V1 = `${BASE_PATH}/v1`;
export const ENDPOINTS = {
  USERS: `${BASE_PATH_V1}/users`,
  TENANTS: `${BASE_PATH_V1}/tenants`,
};
