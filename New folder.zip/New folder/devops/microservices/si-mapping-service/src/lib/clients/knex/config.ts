import { Knex } from 'knex';
import { Utilities } from '@alcumus/globals';
import { getKnexConfig } from '@alcumus/objection-lib';

const databaseName = Utilities.ProcessEnv.getValueOrDefault(
  'SI_MAPPING_SERVICE_DATABASE_NAME',
  'si_mapping_db'
);

const config: Knex.Config = getKnexConfig(databaseName);

export default config;
