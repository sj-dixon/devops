import { User } from '../types';
import { UserMappingEntity } from '../models/userMappingEntity';
import { TenantMappingEntity } from '../models/tenantMappingEntity';

export async function createOrUpdateUserByOrgId(
  createUserRequest: User,
  userId: number,
  tenantId: number
): Promise<UserMappingEntity> {
  const tenant: TenantMappingEntity = await TenantMappingEntity.findByTenantId(
    tenantId
  );

  if (!tenant) {
    throw new Error('Tenant does not exist, please create the tenant first');
  }

  const user: UserMappingEntity =
    await UserMappingEntity.findByUserIdAndTenantId(userId, tenantId);

  if (user) {
    const existingUser = user;
    if (createUserRequest?.fidId || createUserRequest?.fidId === null) {
      existingUser.fidId = createUserRequest.fidId;
    }
    if (createUserRequest?.ecmsId || createUserRequest?.ecmsId === null) {
      existingUser.ecmsId = createUserRequest.ecmsId;
    }
    return patchUser(existingUser);
  }

  const result: UserMappingEntity = await UserMappingEntity.createUser({
    ...createUserRequest,
    tenantId,
    userId,
  });
  if (!result) throw new Error('Unable to create user');
  return result;
}

async function patchUser(
  patchUserRequest: UserMappingEntity
): Promise<UserMappingEntity> {
  const result: UserMappingEntity = await UserMappingEntity.updateUser(
    patchUserRequest
  );
  if (!result) {
    throw new Error('Unable to update tenant');
  }
  return result;
}
