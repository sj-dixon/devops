export interface User {
  userId: number;
  tenantId: number;
  ecmsId?: string | null;
  fidId?: string | null;
}
export interface Tenant {
  tenantId: number;
  fidId?: string | null;
  ecmsId?: string | null;
}
