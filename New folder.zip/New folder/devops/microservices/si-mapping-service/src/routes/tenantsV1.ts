import express, { Router, Response } from 'express';
import { Types, Middlewares } from '@alcumus/globals';
import { Tenant } from '../types';
import { validationHandler } from '@alcumus/express-app';
import { requireFidOrEcms } from '../middleware/createTenantBody';
import { TenantMappingEntity } from '../models/tenantMappingEntity';

const tenantsRouterV1: Router = express.Router();

tenantsRouterV1.get(
  '/:tenantId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const tenant = await TenantMappingEntity.findByTenantId(
      Number(request.params.tenantId)
    );
    if (!tenant) {
      response.status(404).json({ message: 'Tenant not found' });
      return;
    }
    response.json(tenant);
  }
);

tenantsRouterV1.put(
  '/:tenantId',
  requireFidOrEcms,
  validationHandler(),
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const createTenantRequest: Tenant = request.body;
    const { tenantId } = request.params;
    const result = await TenantMappingEntity.createOrUpdateTenant(
      Number(tenantId),
      createTenantRequest
    );
    response.json(result);
  }
);

tenantsRouterV1.delete(
  '/nuke/:tenantId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const { tenantId } = request.params;
    await TenantMappingEntity.hardDelete(Number(tenantId));

    response.sendStatus(204);
  }
);

tenantsRouterV1.delete(
  '/:tenantId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const tenant = await TenantMappingEntity.findByTenantId(
      Number(request.params.tenantId)
    );
    if (!tenant) {
      response.status(404).json({ message: 'Tenant not found' });
      return;
    }

    await TenantMappingEntity.deleteTenant(Number(request.params.tenantId));
    response.sendStatus(204);
  }
);

export { tenantsRouterV1 };
