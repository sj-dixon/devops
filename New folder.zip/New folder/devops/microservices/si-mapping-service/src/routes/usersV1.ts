import express, { Router, Response } from 'express';
import { Types, Middlewares } from '@alcumus/globals';
import { validationHandler } from '@alcumus/express-app';
import { requireFidOrEcms } from '../middleware/createTenantBody';
import { User } from '../types';
import { createOrUpdateUserByOrgId } from '../controllers/UserController';
import { UserMappingEntity } from '../models/userMappingEntity';

const usersRouterV1: Router = express.Router();

usersRouterV1.get(
  '/:userId/tenant/:tenantId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const { userId, tenantId } = request.params;
    const user = await UserMappingEntity.findByUserIdAndTenantId(
      Number(userId),
      Number(tenantId)
    );

    if (!user) {
      response.status(404).json({
        message: `User with id ${userId} not found for tenant with id ${tenantId}`,
      });
      return;
    }

    response.json(user);
  }
);

usersRouterV1.get(
  '/:userId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const { userId } = request.params;
    const userEntries = await UserMappingEntity.findByUserId(Number(userId));

    if (!userEntries.length) {
      response
        .status(404)
        .json({ message: `User records with id ${userId} not found` });
      return;
    }

    response.json(userEntries);
  }
);

usersRouterV1.put(
  '/:userId/tenant/:tenantId',
  requireFidOrEcms,
  validationHandler(),
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const createUserRequest: User = request.body;
    const { userId, tenantId } = request.params;
    await createOrUpdateUserByOrgId(
      createUserRequest,
      Number(userId),
      Number(tenantId)
    )
      .then((res) => {
        response.json(res);
      })
      .catch((err: Error) => {
        response.status(400).send({ message: err.message });
      });
  }
);

usersRouterV1.delete(
  '/:userId/tenant/:tenantId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const { userId, tenantId } = request.params;
    await UserMappingEntity.delete(Number(userId), Number(tenantId));

    response.sendStatus(204);
  }
);

usersRouterV1.delete(
  '/nuke/:userId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const { userId } = request.params;
    await UserMappingEntity.hardDelete(Number(userId));

    response.sendStatus(204);
  }
);

export { usersRouterV1 };
