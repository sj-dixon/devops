# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.3.0](https://github.com/Alcumus/services/compare/si-mapping-service@0.2.0...si-mapping-service@0.3.0) (2021-11-11)

**Note:** Version bump only for package si-mapping-service





# [0.2.0](https://github.com/Alcumus/services/compare/si-mapping-service@0.1.0...si-mapping-service@0.2.0) (2021-11-02)


### Bug Fixes

* Run syncpack:fix to resolve dependency issues ([3dbedf9](https://github.com/Alcumus/services/commit/3dbedf9696f6fb46febb311ec3856347f4c8a8c1))





# 0.1.0 (2021-10-21)


### Bug Fixes

* address pr comments ([9bacd7d](https://github.com/Alcumus/services/commit/9bacd7d2afd0964db05502e3d7582986160a9b4b))
* addressed pr comments ([461c0d3](https://github.com/Alcumus/services/commit/461c0d3bc2413b9c8de846d81d2ca65c2f2d608d))
* create check field exist in body ([d1ed116](https://github.com/Alcumus/services/commit/d1ed116faaed4b9bb4ae846da910c5c0878957a5))
* Made dockerfiles consistent and removed npm run bootstrap since its a postinstall step and ran anyways. ([9bd3f40](https://github.com/Alcumus/services/commit/9bd3f4011bc5250623a5d0c8bea5ee01c41b9563))
* now using lowercase header name in all contracts. ([1e0afa6](https://github.com/Alcumus/services/commit/1e0afa6618236359a7fe91f90ef449e65aa7ea12))
* remove extra method ([bef9ad9](https://github.com/Alcumus/services/commit/bef9ad9449c70d1d538bc848cebde1d491b7b096))
* remove validator on tenantId ([c5d3d27](https://github.com/Alcumus/services/commit/c5d3d2789f76fcdbe5ae45e258163eb359b409f8))
* removed check ([f97bf91](https://github.com/Alcumus/services/commit/f97bf9135e2c655b728f18496a36630995c06316))
* removed tenantId from put body ([5128754](https://github.com/Alcumus/services/commit/51287541503e6b98f29e804f8cff0ffca4a84e17))
* removed x-userinfo from remaining api contracts. ([c23ef4c](https://github.com/Alcumus/services/commit/c23ef4c5c4d33a25d1bcc62664ff5b7f4d4e493a))
* SI2-100 alter table script ([89481d8](https://github.com/Alcumus/services/commit/89481d86e81ff1e6c58553214de88b72e385903b))
* update put tests ([ba629da](https://github.com/Alcumus/services/commit/ba629dab995775baaf081bbdedfdcadff87b939d))
* update schema to have security tokens ([f9a776d](https://github.com/Alcumus/services/commit/f9a776d4e859a3348179d3bb88a338b104a1ef42))
* update validation middleware si2-98 si2-100 ([40bb3c0](https://github.com/Alcumus/services/commit/40bb3c07f47d86322a55567e4f0e9adc4f5d7e01))
* updated package reference ([2f4d702](https://github.com/Alcumus/services/commit/2f4d70223953d1fbe7587ea369688c071b558e00))
* **si-mapping-service:** Fix database setup ([8ad0bb4](https://github.com/Alcumus/services/commit/8ad0bb4315b9a59be6f461749663adb6a643699f))


### Features

* get and post tests ([babd113](https://github.com/Alcumus/services/commit/babd11397a3c125dffe7af4599b9d97cef730fb1))
* SI2-102 delete endpoint ([c4d266e](https://github.com/Alcumus/services/commit/c4d266e1e7e0fc24fea860cef1d5413c9883cdc6))
* **export-api:** add upload api ([c6be9fc](https://github.com/Alcumus/services/commit/c6be9fc6f25c8b9ba017e14f28733cf5a41adca2))
* **user-apis:** add CRU api's for user's ([6cf4f8f](https://github.com/Alcumus/services/commit/6cf4f8f0f4fd512a1303824073de0bef61a4a6c5))
* add middleware SI-98 ([e075a30](https://github.com/Alcumus/services/commit/e075a301a0ddbb4ced4f70fbffc4dcfdb51499bc))
* update conditional logic to check for array SI2-98 ([901a7dd](https://github.com/Alcumus/services/commit/901a7dd8e3298067aa8a82f1399f113e706405ff))
