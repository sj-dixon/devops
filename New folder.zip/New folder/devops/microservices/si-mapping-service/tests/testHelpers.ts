export function generateRandomNumber(): number {
  return Math.floor(Math.random() * 1000000);
}

export function getAuthToken(info: object): string {
  return `fakeHeader.${Buffer.from(JSON.stringify(info)).toString(
    'base64'
  )}.fakeSignature`;
}

export const ENVIRONMENT = {
  SERVICE_MESH_API_KEY: 'service mesh key',
};
