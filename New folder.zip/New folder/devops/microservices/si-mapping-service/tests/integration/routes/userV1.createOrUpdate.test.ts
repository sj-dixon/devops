import app from '../../../src/app';
import supertest from 'supertest';
import connect, { Knex } from 'knex';
import config from '../../../src/knexfile';
import { Model } from 'objection';
import { ENDPOINTS } from '../../../src/constants';
import { ENVIRONMENT, getAuthToken } from '../../testHelpers';
import { Utilities } from '@alcumus/globals';

describe('Integration Test: Tenant Create or Update', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;
  let tenantIds: Array<number> = [10];
  let userIds: Array<number> = [15];
  let encodedUserInfo: string;

  const createTenantRequest = {
    tenantId: 10,
    ecmsId: '111',
    fidId: '222',
    createdBy: 1,
    modifiedBy: 1,
  };

  beforeAll(async () => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connect(config);
    Model.knex(knex);
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => 1487076708000);
    await createTenant(createTenantRequest, createTenantRequest.tenantId);
    tenantIds.push(createTenantRequest.tenantId);
    encodedUserInfo = getAuthToken({
      userId: '1',
    });
  });

  afterAll(async () => {
    await deleteUser(15);
    await deleteTenant(10);
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  function createTenant(createTenantRequest: object, tenantId: number) {
    return supertest(app)
      .put(`${ENDPOINTS.TENANTS}/${tenantId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send(createTenantRequest);
  }

  function deleteTenant(tenantId: number) {
    return supertest(app)
      .delete(`${ENDPOINTS.TENANTS}/nuke/${tenantId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send();
  }

  function createOrUpdateUser(
    createOrUpdateUserRequest: object,
    tenantId: number,
    userId: number
  ) {
    return supertest(app)
      .put(`${ENDPOINTS.USERS}/${userId}/tenant/${tenantId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send(createOrUpdateUserRequest);
  }

  function getUserByTenantId(tenantId: number, userId: number) {
    return supertest(app)
      .get(`${ENDPOINTS.USERS}/${userId}/tenant/${tenantId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send();
  }

  function getUser(userId: number) {
    return supertest(app)
      .get(`${ENDPOINTS.USERS}/${userId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send();
  }

  function deleteUser(userId: number) {
    return supertest(app)
      .delete(`${ENDPOINTS.USERS}/nuke/${userId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send();
  }

  function deleteUserById(tenantId: number, userId: number) {
    return supertest(app)
      .delete(`${ENDPOINTS.USERS}/${userId}/tenant/${tenantId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send();
  }

  describe(`PUT ${ENDPOINTS.USERS}`, () => {
    it('creates a user', (done) => {
      const createOrUpdateUserRequest = {
        createdBy: 1,
        modifiedBy: 1,
        tenantId: createTenantRequest.tenantId,
        userId: 15,
        ecmsId: '111',
        fidId: '222',
      };

      const expectedUserObject = {
        ...createOrUpdateUserRequest,
        createdAt: expect.any(String),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        id: expect.any(Number),
      };

      createOrUpdateUser(
        createOrUpdateUserRequest,
        createOrUpdateUserRequest.tenantId,
        createOrUpdateUserRequest.userId
      ).then((res) => {
        userIds.push(createOrUpdateUserRequest.userId);
        expect(res.status).toEqual(200);
        expect(res.body).toEqual(expectedUserObject);
        done();
      });
    });

    it('updates a user', (done) => {
      const updateUserRequest = {
        fidId: null,
      };

      const expectedUserObject = {
        ...updateUserRequest,
        createdAt: expect.any(String),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        id: expect.any(Number),
        tenantId: 10,
        userId: 15,
        ecmsId: '111',
        createdBy: 1,
        modifiedBy: 1,
      };

      createOrUpdateUser(updateUserRequest, 10, 15).then((res) => {
        expect(res.status).toEqual(200);
        expect(res.body).toEqual(expectedUserObject);
        done();
      });
    });

    it('get a user by tenant id', (done) => {
      const expectedUserObject = {
        fidId: null,
        createdAt: expect.any(String),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        id: expect.any(Number),
        tenantId: 10,
        userId: 15,
        ecmsId: '111',
        createdBy: 1,
        modifiedBy: 1,
      };

      getUserByTenantId(10, 15).then((res) => {
        expect(res.status).toEqual(200);
        expect(res.body).toEqual(expectedUserObject);
        done();
      });
    });

    it('get a user by id', (done) => {
      const expectedUserObject = {
        fidId: null,
        createdAt: expect.any(String),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        id: expect.any(Number),
        tenantId: 10,
        userId: 15,
        ecmsId: '111',
        createdBy: 1,
        modifiedBy: 1,
      };

      getUser(15).then((res) => {
        expect(res.status).toEqual(200);
        expect(res.body).toEqual([expectedUserObject]);
        done();
      });
    });

    it('Soft Delete a user by id', (done) => {
      deleteUserById(10, 15).then((res) => {
        expect(res.status).toEqual(204);
        done();
      });
    });
  });
});
