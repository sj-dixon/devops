import app from '../../../src/app';
import request from 'supertest';
import connect, { Knex } from 'knex';
import config from '../../../src/knexfile';
import { Model } from 'objection';
import { TenantMappingEntity } from '../../../src/models/tenantMappingEntity';
import { ENDPOINTS } from '../../../src/constants';
import {
  ENVIRONMENT,
  generateRandomNumber,
  getAuthToken,
} from '../../testHelpers';
import { Utilities } from '@alcumus/globals';

describe('Integration Test: GET Tenants', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;
  let encodedUserInfo: string;

  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connect(config);
    Model.knex(knex);
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => 1487076708000);
    encodedUserInfo = getAuthToken({
      userId: '1',
    });
  });
  afterAll(async () => {
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  describe(`GET ${ENDPOINTS.TENANTS}/:tenantId`, () => {
    it('returns a single tenant', async (done) => {
      const tenant = await TenantMappingEntity.query().insert({
        tenantId: generateRandomNumber(),
        ecmsId: '111',
        fidId: '222',
        createdBy: 1,
        modifiedBy: 1,
        deletedAt: null,
      });
      request(app)
        .get(`${ENDPOINTS.TENANTS}/${tenant.tenantId}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .then((res) => {
          expect(res.status).toEqual(200);
          expect(res.body).toEqual(tenant);
          done();
        });
    });

    it('returns not found response', async (done) => {
      request(app)
        .get(`${ENDPOINTS.TENANTS}/${generateRandomNumber()}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .then((res) => {
          expect(res.status).toEqual(404);
          done();
        });
    });
    it('returns not found response if tenant is deleted', async (done) => {
      const tenant = await TenantMappingEntity.query().insert({
        tenantId: generateRandomNumber(),
        ecmsId: '111',
        fidId: '222',
        createdBy: 1,
        modifiedBy: 1,
        deletedAt: '2017-02-14 12:51:48',
      });
      request(app)
        .get(`${ENDPOINTS.TENANTS}/${tenant.tenantId}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .then((res) => {
          expect(res.status).toEqual(404);
          done();
        });
    });
  });
});
