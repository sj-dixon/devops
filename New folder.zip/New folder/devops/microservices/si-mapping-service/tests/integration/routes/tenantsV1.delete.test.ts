import request from 'supertest';
import connect, { Knex } from 'knex';
import app from '../../../src/app';
import config from '../../../src/knexfile';
import { Model } from 'objection';
import { TenantMappingEntity } from '../../../src/models/tenantMappingEntity';
import { ENDPOINTS } from '../../../src/constants';
import {
  ENVIRONMENT,
  generateRandomNumber,
  getAuthToken,
} from '../../testHelpers';
import { Utilities } from '@alcumus/globals';

describe('Integration Test: SI Mapping Service', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;
  let encodedUserInfo: string;

  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connect(config);
    Model.knex(knex);
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => 1487076708000);
    encodedUserInfo = getAuthToken({
      userId: 1,
    });
  });
  afterAll(async () => {
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  describe(`DELETE ${ENDPOINTS.TENANTS}/:tenantId`, () => {
    it('soft deletes a tenant', async (done) => {
      const tenant = await TenantMappingEntity.query().insert({
        tenantId: generateRandomNumber(),
        ecmsId: '111',
        fidId: '222',
      });
      request(app)
        .delete(`${ENDPOINTS.TENANTS}/${tenant.tenantId}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .then((res) => {
          expect(res.status).toEqual(204);
          done();
        });
    });

    it('returns error if tenant doesnt exist', async (done) => {
      request(app)
        .delete(`${ENDPOINTS.TENANTS}/${generateRandomNumber()}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .then((res) => {
          expect(res.status).toEqual(404);
          expect(res.body.message).toEqual('Tenant not found');
          done();
        });
    });

    it('returns error if tenant already deleted', async (done) => {
      const tenant = await TenantMappingEntity.query().insert({
        tenantId: generateRandomNumber(),
        ecmsId: '111',
        fidId: '222',
        deletedAt: '2017-02-14 12:51:48',
      });
      request(app)
        .delete(`${ENDPOINTS.TENANTS}/${tenant.tenantId}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .then((res) => {
          expect(res.status).toEqual(404);
          expect(res.body.message).toEqual('Tenant not found');
          done();
        });
    });
  });
});
