import supertest, { Test } from 'supertest';
import connect, { Knex } from 'knex';
import { Model } from 'objection';
import app from '../../../src/app';
import config from '../../../src/knexfile';
import { ENDPOINTS } from '../../../src/constants';
import {
  generateRandomNumber,
  getAuthToken,
  ENVIRONMENT,
} from '../../testHelpers';
import { TenantMappingEntity } from '../../../src/models/tenantMappingEntity';
import { Utilities } from '@alcumus/globals';

describe('Integration Test: Create and Update Tenants', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;
  let encodedUserInfo: string;

  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connect(config);
    Model.knex(knex);
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => 1487076708000);
    encodedUserInfo = getAuthToken({
      userId: '1',
    });
  });
  afterAll(async () => {
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  function createTenant(
    tenantId: number | null,
    createTenantRequest: any
  ): Test {
    return supertest(app)
      .put(`${ENDPOINTS.TENANTS}/${tenantId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send(createTenantRequest);
  }

  function getTenant(tenantId: number | undefined): Test {
    return supertest(app)
      .get(`${ENDPOINTS.TENANTS}/${tenantId}`)
      .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
      .send();
  }

  describe(`PUT ${ENDPOINTS.TENANTS}`, () => {
    it('creates a tenant', async (done) => {
      const tenantId = generateRandomNumber();
      const createTenantRequest = {
        ecmsId: '111',
        fidId: '222',
      };
      const expected = {
        ...createTenantRequest,
        tenantId,
        createdAt: expect.any(String),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        id: expect.any(Number),
      };
      createTenant(Number(tenantId), createTenantRequest).then((res) => {
        expect(res.status).toEqual(200);
        expect(res.body).toEqual(expected);
        done();
      });
    });

    it('updates existing tenant', async (done) => {
      const existingTenant = await TenantMappingEntity.query().insert({
        tenantId: generateRandomNumber(),
        ecmsId: '111',
        fidId: '222',
        createdBy: 1,
        modifiedBy: 1,
      });
      const updateTenantRequest = {
        ecmsId: '123',
      };
      const expected = {
        ...updateTenantRequest,
        tenantId: existingTenant.tenantId,
        fidId: existingTenant.fidId,
        createdAt: expect.any(String),
        createdBy: expect.any(Number),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        modifiedBy: expect.any(Number),
        id: expect.any(Number),
      };
      createTenant(Number(existingTenant.tenantId), updateTenantRequest).then(
        () => {
          getTenant(existingTenant.tenantId).then((res) => {
            expect(res.status).toEqual(200);
            expect(res.body).toEqual(expected);
            done();
          });
        }
      );
    });

    it('returns an error if missing ecmsId and fidId', async (done) => {
      createTenant(Number(generateRandomNumber()), {}).then((res) => {
        expect(res.status).toEqual(400);
        expect(res.body.errors).toEqual({
          _error: {
            key: 'fidID or ecmsID is needed',
            message: 'fidID or ecmsID is needed',
          },
        });
        done();
      });
    });

    it('creates a tenant with fidId only', async (done) => {
      const tenantId = generateRandomNumber();
      const createTenantRequest = {
        fidId: '222',
      };
      const expected = {
        ...createTenantRequest,
        tenantId,
        createdAt: expect.any(String),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        id: expect.any(Number),
        ecmsId: null,
      };
      createTenant(Number(tenantId), createTenantRequest).then((res) => {
        expect(res.status).toEqual(200);
        expect(res.body).toEqual(expected);
        done();
      });
    });

    it('creates a tenant with ecmsId only', async (done) => {
      const tenantId = generateRandomNumber();
      const createTenantRequest = {
        ecmsId: '222',
      };
      const expected = {
        ...createTenantRequest,
        tenantId,
        createdAt: expect.any(String),
        deletedAt: null,
        deletedBy: null,
        modifiedAt: expect.any(String),
        id: expect.any(Number),
        fidId: null,
      };
      createTenant(Number(tenantId), createTenantRequest).then((res) => {
        expect(res.status).toEqual(200);
        expect(res.body).toEqual(expected);
        done();
      });
    });
  });
});
