# si-mappingservice

This microservice will contain api's to store and retrieve entries for tenants and users from existing Alcumus applications like ECMS, FiD and so on

### Steps to start the microservice 

- Run `npm ci && npm run clean && npm run bootstrap && npm run build`
- Run `npm run start-dev`
- Run this command in your terminal to see service health endpoint responding: `curl -i http://localhost:8017/api/health`
