import { Model, Transaction } from 'objection';
import { CreateUserRequest, User } from '../types';
import { extractUserFromRequest } from '../lib/utils';
import { UserAccountEntity } from '../models/userAccountEntity';
import { UserEntity } from '../models/userEntity';
import {
  AdminKeycloakClient,
  getAdminKeycloakClient,
} from '../lib/clients/keycloak';
import { getAuthProvider } from '../lib/tenants';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
} from '../lib/tenants/types';
import { UserAccount, UserAccountType } from '../types/userAccount';
import { Utilities } from '@alcumus/globals';
import { AxiosInstance } from 'axios';

type UserWithCredentials = User & {
  credentials?: UserAccountEntity;
  id: number;
};

export async function createUser(
  createUserRequest: CreateUserRequest,
  userAccountType: UserAccountType,
  tenantsClient: AxiosInstance,
  organizationId?: number
): Promise<UserWithCredentials> {
  const userToCreate: User = extractUserFromRequest(createUserRequest);

  const result: UserWithCredentials = await Model.transaction(
    async (trx: Transaction) => {
      const userEntity = await UserEntity.create(userToCreate, trx);

      if (!createUserRequest.createAccount) {
        return {
          ...userEntity,
          credentials: undefined,
        };
      }

      const targetProviderType = Utilities.ProcessEnv.isEnabled(
        'FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD'
      )
        ? OrganizationAuthProviderType.AZURE_AD
        : OrganizationAuthProviderType.KEYCLOAK;

      let authProvider: OrganizationAuthProvider | undefined | null;
      if (organizationId) {
        authProvider = await getAuthProvider({
          authProviderName: targetProviderType,
          organizationId,
          axiosInstance: tenantsClient,
        });
      }
      let internalAccountId: string | null | undefined;
      if (createUserRequest.password) {
        const keycloakClient: AdminKeycloakClient = getAdminKeycloakClient();
        await keycloakClient.authenticateAsAdmin();
        internalAccountId = await keycloakClient.createUserWithUserIdAttribute(
          userEntity.id,
          createUserRequest,
          authProvider
        );
      }

      const requiresPasswordReset =
        Boolean(createUserRequest.password) &&
        userAccountType === UserAccountType.PERSONAL_ACCOUNT;

      const userAccountRequest: UserAccount = {
        username: createUserRequest.username,
        email: createUserRequest.email,
        userAccountType,
        internalAccountId,
        scopedToOrganizationId: organizationId,
        authProviderName: targetProviderType,
        userId: userEntity.id,
        requiresPasswordReset,
        dataImportRowId: null,
        dataImportFileId: null,
        isEnabled: true,
        phoneNumber: createUserRequest.phoneNumber,
      };
      const credentials = await UserAccountEntity.create(
        trx,
        userAccountRequest
      );
      return {
        ...userEntity,
        credentials: credentials,
      };
    }
  );

  return result;
}
