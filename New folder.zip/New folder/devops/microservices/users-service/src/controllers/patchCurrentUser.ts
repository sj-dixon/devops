import { UpdateUserRequest } from '../types';
import { UserEntity } from '../models/userEntity';

export async function patchUser({
  userId,
  ...userProperties
}: UpdateUserRequest): Promise<UserEntity> {
  await UserEntity.patch(userId, userProperties);
  return await UserEntity.query().findById(userId);
}
