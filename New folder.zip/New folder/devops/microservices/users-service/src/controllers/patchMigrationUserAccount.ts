import { Types, Utilities } from '@alcumus/globals';
import { Response } from 'express';
import { UserMigrationResult } from '../types/userMigration';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
} from '../lib/tenants/types';
import { UserOrganizationEntity } from '../models/userOrganizationEntity';
import {
  createUserWithUserIdAttribute,
  getTargetAuthProviderType,
  syncUsernameEmailAndPassword,
} from '../lib/utils/authClientWrapper';
import { UserEntity } from '../models/userEntity';
import { UserAccountEntity } from '../models/userAccountEntity';
import {
  getAuthProvider,
  getAuthProviderByOrganizationId,
} from '../lib/tenants';
import { UpdateAccountRequest } from '../types';
import { CreateInternalAccountRequest } from '../lib/clients/keycloak/types';
import { UserAccountType } from '../types/userAccount';
import { AxiosInstance } from 'axios';

export async function patchMigrationUserAccount(
  request: Types.Request,
  response: Response,
  migrationAccount: UserMigrationResult
): Promise<void> {
  const updateAccountRequest: UpdateAccountRequest = {
    newPassword: request.body.password,
    username: request.body.username,
    email: request.body.email,
    isEnabled: request.body.isEnabled,
  };
  const { organizationId } = migrationAccount;
  const targetAuthProviderType = getTargetAuthProviderType();
  const axiosInstance = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'tenants'
  );
  const [targetAuthProvider, authProvider] = await getAuthProviders(
    organizationId,
    targetAuthProviderType,
    migrationAccount.authProviderName,
    migrationAccount.userAccountType,
    axiosInstance
  );

  if (
    (migrationAccount.authProviderName !== targetAuthProviderType ||
      !migrationAccount.internalAccountId) &&
    updateAccountRequest.newPassword
  ) {
    // in this case, we are forced to do an immediate user migration.
    const userProfile = await UserEntity.findByUserId(migrationAccount.userId);

    const accountDetails: CreateInternalAccountRequest = {
      username:
        updateAccountRequest.username || migrationAccount.username || undefined,
      email: updateAccountRequest.email || migrationAccount.email || undefined,
      firstName: userProfile.firstName,
      lastName: userProfile.lastName,
      password: updateAccountRequest.newPassword,
    };

    let internalAccountId: string | undefined;
    if (updateAccountRequest.newPassword) {
      internalAccountId = await createUserWithUserIdAttribute(
        migrationAccount.userId,
        organizationId,
        targetAuthProvider,
        accountDetails
      );
    }

    // persist whatever is changing, but also update the auth provider account and type.
    const accountUpdatePromise = UserAccountEntity.patch(
      migrationAccount.userOrganizationAccountId,
      {
        authProviderName: targetAuthProviderType,
        internalAccountId,
        username: updateAccountRequest.username,
        email: updateAccountRequest.email,
        isEnabled: updateAccountRequest.isEnabled,
      }
    );

    // enable account on user organization, since we do not require decoupling between
    // enabled user accounts and enabled user organizations.
    const userOrganizationPromise =
      UserOrganizationEntity.setEnabledByAlcumusUserId(
        migrationAccount.alcumusUserId,
        updateAccountRequest.isEnabled
      );
    await Promise.all([accountUpdatePromise, userOrganizationPromise]);
    return;
  }

  const account = (await UserAccountEntity.findByUserAndAccountId(
    migrationAccount.userId,
    migrationAccount.userOrganizationAccountId
  )) as UserAccountEntity;
  await Promise.all([
    UserOrganizationEntity.setEnabledByAlcumusUserId(
      migrationAccount.alcumusUserId,
      updateAccountRequest.isEnabled
    ),
    syncUsernameEmailAndPassword(account, authProvider, updateAccountRequest),
  ]);
}

async function getAuthProviders(
  organizationId: number,
  targetAuthProviderType: OrganizationAuthProviderType,
  currentProviderName: string,
  userAccountType: UserAccountType,
  axiosInstance: AxiosInstance
): Promise<[OrganizationAuthProvider, OrganizationAuthProvider]> {
  if (currentProviderName === targetAuthProviderType) {
    const provider = await getAuthProvider({
      organizationId,
      authProviderName: targetAuthProviderType,
      axiosInstance,
    });

    if (!provider) {
      throw new Error(
        `Could not find auth provider of type ${targetAuthProviderType} for organization ${organizationId}`
      );
    }

    return [provider, provider];
  }

  const result = await Promise.all([
    getAuthProvider({
      organizationId,
      authProviderName: targetAuthProviderType,
      axiosInstance,
    }),
    getAuthProvider({
      organizationId:
        userAccountType === UserAccountType.ORGANIZATION_ACCOUNT
          ? organizationId
          : 0,
      axiosInstance,
      authProviderName: currentProviderName,
    }),
  ]);

  if (!result[0] || !result[1]) {
    throw new Error(
      `Could not find required providers for organization ${organizationId}: ${
        result[0] ? targetAuthProviderType : ' '
      }${result[1] ? currentProviderName : ''}.`
    );
  }
  return result as [OrganizationAuthProvider, OrganizationAuthProvider];
}
