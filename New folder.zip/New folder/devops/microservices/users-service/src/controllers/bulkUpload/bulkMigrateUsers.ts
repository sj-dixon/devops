import {
  UserDataImportFileDetails,
  UserMigrationRequest,
} from '../../types/userMigration';
import { UserDataImportFileEntity } from '../../models/userDataImportFileEntity';
import { UserDataImportRowEntity } from '../../models/UserDataImportRowEntity';
import { UserDataImportRowStatus } from '../../models/types';
import { v4 as uuidV4 } from 'uuid';
import { toMySqlDateTimeString } from '@alcumus/objection-lib';
import { BatchResult } from '../../lib/bulkUpload/types';
import { getImportedUsersAndEmployees } from '../../models/dataImportQuerier';
import { EmployeeDataImportResult } from '../../types/importIntermediates';

export async function bulkMigrateUsers(
  usersToCreate: UserMigrationRequest[],
  fileDetails: UserDataImportFileDetails,
  needVerboseResponse = false,
  maxRecords = 100
): Promise<BatchResult> {
  const organizationId = fileDetails.organizationId as number;
  const dataImportFile = await UserDataImportFileEntity.create(
    fileDetails,
    usersToCreate.length
  );
  const { id: dataImportFileId } = dataImportFile;
  const createdAt = toMySqlDateTimeString(new Date());
  const rowsToLoad = usersToCreate.map((toCreate) => ({
    firstName: toCreate.firstName,
    lastName: toCreate.lastName,
    rowStatus: UserDataImportRowStatus.COMPLETE,
    email: toCreate.email,
    username: toCreate.username,
    dataImportFileId: dataImportFileId,
    userNumber: toCreate.userNumber || uuidV4(),
    createdAt,
  }));

  await UserDataImportRowEntity.importRows(rowsToLoad);

  // create the users, user accounts, and user organizations
  // we do NOT create keycloak accounts due to a lack of a bulk import API
  await UserDataImportRowEntity.importUsers(dataImportFileId);
  await UserDataImportRowEntity.importUserAccounts(
    dataImportFileId,
    organizationId,
    fileDetails.userAccountType
  );
  await UserDataImportRowEntity.importUserOrganizations(
    dataImportFileId,
    organizationId
  );

  return getBatchSummary({
    dataImportFileId,
    maxRecords,
    needVerboseResponse,
  });
}

export async function getBatchSummary({
  dataImportFileId,
  maxRecords,
  needVerboseResponse,
}: {
  dataImportFileId: number;
  maxRecords: number;
  needVerboseResponse: boolean;
}): Promise<BatchResult> {
  // todo if doing a big upload, we do not need to retrieve the actual records, just a count.
  const result: EmployeeDataImportResult[] = await getImportedUsersAndEmployees(
    dataImportFileId
  );

  const exceedsMaxRecords = result.length > maxRecords;
  return {
    migrated: needVerboseResponse && !exceedsMaxRecords ? result : [],
    rowsAffected: result.length,
    errors: 0,
    dataImportFileId: dataImportFileId,
  };
}
