import { Types } from '@alcumus/globals';
import { UserDataImportFileEntity } from '../../models/userDataImportFileEntity';
import { UserAccountType } from '../../types/userAccount';
import { UserDataImportRowEntity } from '../../models/UserDataImportRowEntity';
import { getBatchSummary } from './bulkMigrateUsers';
import {
  BatchResult,
  UserOrganizationProductRowIntermediate,
} from '../../lib/bulkUpload/types';
import {
  getOrganizationProductMappingsByEmail,
  transformIntermediatesToDataRows,
} from '../../lib/bulkUpload/aggregators';

export async function bulkMigrateIntermediatesMultipleCompanies({
  filename,
  authProviderName,
  intermediates,
  userNumbersByEmail,
  cache,
  needVerboseResponse = false,
  maxRecords = 100,
}: {
  filename: string;
  authProviderName: string;
  intermediates: UserOrganizationProductRowIntermediate[];
  userNumbersByEmail: Types.StringDictionary;
  cache: Types.LookupCache<string, number | null>;
  needVerboseResponse?: boolean;
  maxRecords?: number;
}): Promise<BatchResult> {
  const dataImportFile = await UserDataImportFileEntity.create(
    {
      organizationId: null,
      filename,
      authProviderName,
      userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    },
    intermediates.length
  );

  const { id: dataImportFileId } = dataImportFile;

  const rowMappingsByUserNumber = await getOrganizationProductMappingsByEmail({
    cache,
    userNumbersByEmail,
    intermediates,
    dataImportFileId,
  });

  const now = new Date();
  const rows = transformIntermediatesToDataRows({
    dataImportFileId,
    intermediates,
    now,
    rowMappingsByUserNumber,
  });

  await UserDataImportRowEntity.importRowsWithMappings(rows, dataImportFileId);

  await UserDataImportRowEntity.importUsers(dataImportFileId);

  await Promise.all([
    UserDataImportRowEntity.importUserAccounts(
      dataImportFileId,
      null,
      dataImportFile.userAccountType
    ),
    UserDataImportRowEntity.importUserOrganizations(dataImportFileId),
  ]);

  return getBatchSummary({
    dataImportFileId,
    needVerboseResponse,
    maxRecords,
  });
}
