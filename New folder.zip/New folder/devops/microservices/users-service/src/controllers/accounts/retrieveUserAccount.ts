import { Types, Utilities } from '@alcumus/globals';
import { Response } from 'express';
import { getOrganizationIdByIdentifier } from '../../lib/tenants';
import { UserAccountEntity } from '../../models/userAccountEntity';
import { UserEntity } from '../../models/userEntity';

export async function retrieveUserAccount(
  request: Types.Request,
  response: Response
) {
  const account = await getUserAccountOrRespondWithError(request, response);
  if (!account) {
    return;
  }
  const user = await UserEntity.findByUserId(account?.userId);
  return response.status(200).json({
    ...account,
    firstName: user.firstName,
    lastName: user.lastName,
  });
}

export async function getUserAccountOrRespondWithError(
  request: Types.Request,
  response: Response
): Promise<UserAccountEntity | null> {
  const organizationIdentifier = request.query.organizationIdentifier as string;
  const alcumusUserIdentifier = request.params.loginIdentifier;

  const tenantServiceClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    Types.ServiceEndpoints.TENANTS
  );

  let organizationId;
  if (organizationIdentifier) {
    organizationId = await getOrganizationIdByIdentifier(
      tenantServiceClient,
      organizationIdentifier
    );
    if (!organizationId) {
      response.status(404).json({
        message: `No organization found with identifier ${organizationIdentifier}.`,
      });
      return null;
    }
  }

  const account = await UserAccountEntity.findByLoginIdentifiers(
    alcumusUserIdentifier,
    organizationId
  );
  if (!account) {
    const message = organizationIdentifier
      ? `No user account was found for login ${alcumusUserIdentifier} and organization identifier ${organizationIdentifier}`
      : `No user account was found for login ${alcumusUserIdentifier}`;

    response.status(404).json({
      message,
    });
    return null;
  }
  return account;
}
