import { Types } from '@alcumus/globals';
import { Response } from 'express';
import {
  AzureAdAccountRequestBody,
  AzureAdAccountResponseBody,
} from '../../lib/clients/azureAd/types';
import { UserAccountEntity } from '../../models/userAccountEntity';
import { UserEntity } from '../../models/userEntity';
import { UserAccountType } from '../../types/userAccount';
import { OrganizationAuthProviderType } from '../../lib/tenants/types';
import { transaction, Transaction } from 'objection';

export async function propagateAzureAdAccount(
  request: Types.Request,
  response: Response
) {
  const body: AzureAdAccountRequestBody = request.body;
  try {
    const existingAccount = await UserAccountEntity.findByLoginIdentifiers(
      body.email
    );
    if (existingAccount) {
      response.status(409).json({
        message: `Email ${body.email} is already taken.`,
      });
    }

    const userToCreate = {
      firstName: body.givenName,
      lastName: body.surname,
    };

    const userAccount: UserAccountEntity = await transaction(
      UserEntity,
      UserAccountEntity,
      async (BoundUserEntity, BoundUserAccountEntity, trx: Transaction) => {
        const user = await BoundUserEntity.create(userToCreate, trx);

        return BoundUserAccountEntity.create(trx, {
          userAccountType: UserAccountType.PERSONAL_ACCOUNT,
          authProviderName: OrganizationAuthProviderType.AZURE_AD,
          userId: user.id,
          internalAccountId: body.objectId,
          email: body.email,
          username: null,
          scopedToOrganizationId: null,
          isEnabled: true,
          requiresPasswordReset: false,
        });
      }
    );
    console.info(
      `Associated Azure AD account ${body.objectId} with user id ${userAccount.userId} and account id ${userAccount.id}`
    );

    const propagatedAccount: AzureAdAccountResponseBody = {
      ...userAccount,
      ...userToCreate,
      userAccountId: userAccount.id,
    };
    response.status(200).json(propagatedAccount);
  } catch (error) {
    console.error(`Creating user with objectId ${body.objectId} failed`);
    throw error;
  }
}
