import { Types, Utilities } from '@alcumus/globals';
import { Response } from 'express';
import { UserAccountEntity } from '../../models/userAccountEntity';
import { OrganizationAuthProviderType } from '../../lib/tenants/types';
import { getAdminKeycloakClient } from '../../lib/clients/keycloak';
import { UserEntity } from '../../models/userEntity';
import { getAuthProvider } from '../../lib/tenants';

export async function migrateUserAccount(
  request: Types.Request,
  response: Response
) {
  const { authProviderType: targetProviderType, password } = request.body;
  const accountId = Number(request.params.userAccountId);

  let userAccount = await UserAccountEntity.find(accountId);
  if (!userAccount) {
    return response.status(404).json({
      message: `Could not find user account ${accountId}`,
    });
  }

  const authProvider = await getAuthProvider({
    axiosInstance: Utilities.AxiosClient.getServiceMeshAxiosClient(
      request,
      Types.ServiceEndpoints.TENANTS
    ),
    authProviderName: targetProviderType,
    organizationId: userAccount.scopedToOrganizationId,
  });

  const userPromise = UserEntity.findByUserId(userAccount.userId);
  if (targetProviderType === OrganizationAuthProviderType.KEYCLOAK) {
    // need to update password ourselves because we are not using a managed service
    const client = getAdminKeycloakClient();
    const [user] = await Promise.all([
      userPromise,
      client.authenticateAsAdmin(),
    ]);
    const internalAccountId = await client.createUserWithUserIdAttribute(
      userAccount.userId,
      {
        ...user,
        email: userAccount.email || undefined,
        username: userAccount.username || undefined,
        password,
      },
      authProvider
    );
    userAccount = await UserAccountEntity.patch(userAccount.id, {
      authProviderName: targetProviderType,
      internalAccountId,
    });

    response.status(200).json({
      ...userAccount,
      firstName: user.firstName,
      lastName: user.lastName,
    });
  } else if (targetProviderType === OrganizationAuthProviderType.AZURE_AD) {
    // no need to update password because Azure AD flows differently.

    userAccount = await UserAccountEntity.patch(userAccount.id, {
      authProviderName: targetProviderType,
    });

    const user = await userPromise;
    response.status(200).json({
      ...userAccount,
      firstName: user.firstName,
      lastName: user.lastName,
    });
  } else {
    throw new Error(
      `Cannot migrate account ${accountId} to ${targetProviderType}`
    );
  }
}
