import { Types } from '@alcumus/globals';
import { Response } from 'express';
import { UserAccountEntity } from '../../models/userAccountEntity';
import { getUserAccountOrRespondWithError } from './retrieveUserAccount';

export async function updateUserAccountLinks(
  request: Types.Request,
  response: Response
) {
  const userAccount = await getUserAccountOrRespondWithError(request, response);
  if (!userAccount) {
    return;
  }

  const { objectId, authProviderType } = request.body;
  const result = await UserAccountEntity.patch(userAccount.id, {
    internalAccountId: objectId,
    authProviderName: authProviderType,
    requiresPasswordReset: false,
  });
  return response.status(200).json(result);
}
