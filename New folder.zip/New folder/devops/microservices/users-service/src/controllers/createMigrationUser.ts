import { CreateUserRequest } from '../types';
import { createUser } from './createUser';
import { UserOrganizationEntity } from '../models/userOrganizationEntity';
import {
  UserMigrationRequest,
  UserMigrationResult,
} from '../types/userMigration';
import { UserAccountType } from '../types/userAccount';
import { OrganizationAuthProviderType } from '../lib/tenants/types';
import { Utilities } from '@alcumus/globals';
import { AxiosInstance } from 'axios';

function getCreationRequest(
  migrationRequest: UserMigrationRequest
): CreateUserRequest {
  return {
    firstName: migrationRequest.firstName,
    lastName: migrationRequest.lastName,
    email: migrationRequest.email || undefined,
    username: migrationRequest.username || migrationRequest.email || undefined,
    createAccount: true,
    password: migrationRequest.password,
  };
}

export async function createMigrationUser(
  migrationRequest: UserMigrationRequest,
  tenantsClient: AxiosInstance
): Promise<UserMigrationResult> {
  const userAccountType = UserAccountType.ORGANIZATION_ACCOUNT;
  const createUserRequest = getCreationRequest(migrationRequest);
  const userWithCredentials = await createUser(
    createUserRequest,
    userAccountType,
    tenantsClient,
    migrationRequest.organizationId
  );
  const userOrganization = await UserOrganizationEntity.create({
    userId: userWithCredentials.id,
    organizationId: migrationRequest.organizationId as number,
    isEnabled: migrationRequest.isEnabled,
  });

  const targetProviderName = Utilities.ProcessEnv.isEnabled(
    'FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD'
  )
    ? OrganizationAuthProviderType.AZURE_AD
    : OrganizationAuthProviderType.KEYCLOAK;

  return {
    userId: userOrganization.userId,
    organizationId: userOrganization.organizationId,
    userOrganizationId: userOrganization.id,
    alcumusUserId: userOrganization.id,
    userOrganizationAccountId: userWithCredentials.credentials?.id as number,
    authProviderName:
      userWithCredentials.credentials?.authProviderName || targetProviderName,
    email: createUserRequest.email || null,
    username: createUserRequest.username || null,
    isEnabled: migrationRequest.isEnabled,
    internalAccountId:
      userWithCredentials.credentials?.internalAccountId || null,
    firstName: migrationRequest.firstName,
    lastName: migrationRequest.lastName,
    userAccountType,
  };
}
