import { UserEntity } from '../models/userEntity';
import { UserAccountEntity } from '../models/userAccountEntity';
import { UpdateAccountRequest, UpdateUserRequest } from '../types';
import {
  AdminKeycloakClient,
  getAdminKeycloakClient,
} from '../lib/clients/keycloak';
import { getAuthProviderByOrganizationId } from '../lib/tenants';
import { UserAccountType } from '../types/userAccount';
import { OrganizationAuthProviderType } from '../lib/tenants/types';
import { getTargetAuthProviderType } from '../lib/utils/authClientWrapper';

export async function patchUser({
  userId,
  ...userProperties
}: UpdateUserRequest): Promise<UserEntity> {
  await UserEntity.patch(userId, userProperties);
  return await UserEntity.query().findById(userId);
}

export async function updateKeycloakCredentials(
  userId: number,
  userAccountId: number,
  request: UpdateAccountRequest
): Promise<void> {
  if (
    !request.newPassword &&
    !request.email &&
    !request.username &&
    request.isEnabled === undefined
  ) {
    return;
  }

  const account = (await UserAccountEntity.findByUserAndAccountId(
    userId,
    userAccountId
  )) as UserAccountEntity;

  await updateKeycloakAndUserAccounts(userId, account, request);
}

export async function updateKeycloakAndUserAccounts(
  userId: number,
  account: UserAccountEntity,
  request: UpdateAccountRequest
): Promise<void> {
  if (!account) {
    return;
  }

  const hasCurrentLoginIdentifier = account.username || account.email;
  if (!hasCurrentLoginIdentifier) {
    throw new Error('User does not have a keycloak login');
  }

  const client: AdminKeycloakClient = getAdminKeycloakClient();
  await client.authenticateAsAdmin();

  const targetProviderType = getTargetAuthProviderType();

  // todo too much of this logic is coupled to the keycloak client to safely transition
  if (targetProviderType === OrganizationAuthProviderType.AZURE_AD) {
    throw new Error('Azure AD password and account updates not supported yet');
  }

  if (
    !account.internalAccountId &&
    account.userAccountType === UserAccountType.ORGANIZATION_ACCOUNT
  ) {
    const userProfile = await UserEntity.query().findById(userId);
    if (request.newPassword) {
      const authProvider = await getAuthProviderByOrganizationId(
        account.scopedToOrganizationId || undefined,
        targetProviderType
      );
      request.internalAccountId = await client.createUserWithUserIdAttribute(
        userId,
        {
          username: request.username || account.username || undefined,
          email: request.email || account.email || undefined,
          firstName: userProfile.firstName,
          lastName: userProfile.lastName,
          password: request.newPassword,
        },
        authProvider
      );
    }
    await UserAccountEntity.updateLoginIdentifier(account, request);
  } else if (account.internalAccountId) {
    const authProvider = await getAuthProviderByOrganizationId(
      account.scopedToOrganizationId || undefined,
      targetProviderType
    );

    await Promise.all([
      client.changeLoginIdentifiersAndPassword(
        account.internalAccountId,
        account,
        request,
        authProvider
      ),
      UserAccountEntity.updateLoginIdentifier(account, request),
    ]);
  } else {
    throw new Error(
      `Server does not know how to update ${account.userAccountType} account with username ${account.username} with internal id ${account.internalAccountId} and scopedToOrganizationId = ${account.scopedToOrganizationId}`
    );
  }
}
