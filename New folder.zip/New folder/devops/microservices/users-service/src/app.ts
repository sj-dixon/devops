import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import usersRouterV1 from './routes/usersV1';
import { myProfileRouterV1 } from './routes/meV1';
import path from 'path';
import { authenticationMiddlewares } from '@alcumus/auth-plugin';
import { migrateUsersV1 } from './routes/migrateUsersV1';
import { migrateTenantV1 } from './routes/migrateTenantV1';
import { myOrganizationRouterV1 } from './routes/myOrganizationsV1';
import { migrateAuthV1 } from './routes/migrateAuthV1';
import { accountsV1 } from './routes/accountsV1';
import { employeesRouterV1 } from './routes/employeesV1';
import { migrateUsersBatchV1 } from './routes/migrateUsersBatchV1';
import { importsV1 } from './routes/importsV1';

const apiSpec = './api-spec.yaml';

const usersServiceApp = configureApp({
  serviceName: 'Users Service',
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
    validateResponse: true,
  },
  setup: (app) => {
    app.use(authenticationMiddlewares());
    app.use(ENDPOINTS.USERS, usersRouterV1);
    app.use(ENDPOINTS.ME, myProfileRouterV1);
    app.use(ENDPOINTS.MY_ORGANIZATIONS, myOrganizationRouterV1);
    app.use(ENDPOINTS.MIGRATE_AUTH, migrateAuthV1);
    app.use(ENDPOINTS.MIGRATE_TENANT, migrateTenantV1);
    app.use(ENDPOINTS.MIGRATE_USERS_BATCH, migrateUsersBatchV1);
    app.use(ENDPOINTS.MIGRATE_USER, migrateUsersV1);
    app.use(ENDPOINTS.ACCOUNTS, accountsV1);
    app.use(ENDPOINTS.EMPLOYEES, employeesRouterV1);
    app.use(ENDPOINTS.IMPORTS, importsV1);
  },
});

export default usersServiceApp;
