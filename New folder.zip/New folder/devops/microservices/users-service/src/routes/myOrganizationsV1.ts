import express, { Response, Router } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { requireAuthentication } from '@alcumus/auth-plugin';
import { UserOrganizationEntity } from '../models/userOrganizationEntity';

const myOrganizationRouterV1: Router = express.Router();

myOrganizationRouterV1.get(
  '/',
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  async (request: Types.Request, response: Response) => {
    const internalAccountId = request.userInfo?.internalAccountId as string;

    const organizations = await UserOrganizationEntity.findByInternalAccountId(
      internalAccountId
    );
    const result = organizations.map((mapping) => ({
      ...mapping,
      alcumusUserId: mapping.id,
    }));
    response.send(result);
  }
);

myOrganizationRouterV1.get(
  '/:organizationId',
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  async (request: Types.Request, response: Response) => {
    const internalAccountId = request.userInfo?.internalAccountId as string;
    const organizationId = Number(request.params.organizationId);
    const organizations = await UserOrganizationEntity.findByInternalAccountId(
      internalAccountId
    );
    const organization = organizations
      .map((mapping) => ({
        ...mapping,
        alcumusUserId: mapping.id,
      }))
      .find((mapping) => mapping.organizationId === organizationId);
    if (organization) {
      response.send(organization);
    } else {
      response.status(404).send({
        message: `This user account does not have access to organization ${organizationId}`,
      });
    }
  }
);

export { myOrganizationRouterV1 };
