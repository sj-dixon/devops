import express, { Router, Response } from 'express';
import { Middlewares, Types, Utilities } from '@alcumus/globals';
import { requireExcelFile } from '../middleware/requireExcelFile';
import parseXlsx from '../lib/utils/parseXlsx';
import { bulkMigrateIntermediatesMultipleCompanies } from '../controllers/bulkUpload/bulkMigrateUsersMultipleCompanies';
import { getOrganizationIdByIdentifier } from '../lib/tenants';
import { RawUserDataRowWithOrganization } from '../lib/bulkUpload/types';
import { parseRawRowsDoNotDeduplicate } from '../lib/bulkUpload/parsers';
import { getOrGenerateUserNumbersByEmail } from '../lib/bulkUpload/aggregators';
import { validateIntermediates } from '../lib/bulkUpload/validators';

const migrateUsersBatchV1: Router = express.Router();

async function handleBatchUpload(
  request: Types.Request,
  response: Response,
  needVerboseResponse: boolean
) {
  const [excel] = request.files as Types.File[];
  const axiosInstance = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'tenants'
  );
  const filename = request.file?.filename || 'untitled.xlsx';
  const authProviderName = request.requestedBy
    ?.requestedByApplication as string;
  const rawRows = parseXlsx<RawUserDataRowWithOrganization>(excel.buffer);

  const cache = new Types.LookupCache(
    async (organizationIdentifier: string) => {
      return getOrganizationIdByIdentifier(
        axiosInstance,
        organizationIdentifier
      );
    }
  );

  const intermediates = parseRawRowsDoNotDeduplicate(rawRows);

  const userNumbersByEmail: Types.StringDictionary =
    getOrGenerateUserNumbersByEmail(intermediates);

  const errors = validateIntermediates({
    intermediates,
  });

  if (errors && errors.length > 0) {
    // todo consider returning a maximum number of errors
    response.status(422).json(errors);
    return;
  }

  const batchResult = await bulkMigrateIntermediatesMultipleCompanies({
    filename,
    authProviderName,
    intermediates,
    userNumbersByEmail,
    cache,
    needVerboseResponse,
  });
  if (batchResult.errors === 0) {
    response.status(201).json(batchResult);
  } else {
    // todo this is suspect based on contract definition.
    response.status(422).json(batchResult);
  }
}

migrateUsersBatchV1.post(
  '/large',
  Middlewares.requireApiKeyHeader,
  Middlewares.decodeRequestedBy,
  requireExcelFile,
  async (request: Types.Request, response: Response) => {
    await handleBatchUpload(request, response, false);
  }
);

migrateUsersBatchV1.post(
  '/',
  Middlewares.requireApiKeyHeader,
  Middlewares.decodeRequestedBy,
  requireExcelFile,
  async (request: Types.Request, response: Response) => {
    await handleBatchUpload(request, response, true);
  }
);

export { migrateUsersBatchV1 };
