import express, { Response, Router } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import {
  getImportedAccounts,
  getImportedEmployees,
} from '../models/dataImportQuerier';

const importsV1: Router = express.Router();

importsV1.get(
  '/:dataImportFileId/accounts',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const dataImportFileId = Number(request.params.dataImportFileId);
    const results = await getImportedAccounts(dataImportFileId);
    response.status(200).json(results);
  }
);

importsV1.get(
  '/:dataImportFileId/employees',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const dataImportFileId = Number(request.params.dataImportFileId);
    const results = await getImportedEmployees(dataImportFileId);
    response.status(200).json(results);
  }
);

export { importsV1 };
