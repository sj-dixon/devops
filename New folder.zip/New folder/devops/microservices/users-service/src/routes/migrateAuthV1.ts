import express, { Response, Router } from 'express';
import { Types, Middlewares } from '@alcumus/globals';
import { getMigrationAccountByIdentifiers } from '../models/migrationAccounts';
import { getAuthProvidersByOrganizationIdentifier } from '../lib/tenants';

const migrateAuthV1: Router = express.Router({ mergeParams: true });

migrateAuthV1.get(
  '/:organizationIdentifier/logins/:loginIdentifier',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationIdentifier = request.params.organizationIdentifier;
    const alcumusUserIdentifier = request.params.loginIdentifier;

    // todo can just query organization instead
    const authProviders = await getAuthProvidersByOrganizationIdentifier(
      organizationIdentifier
    );

    if (!authProviders) {
      response.status(404).send({
        message: `No organization found with identifier ${organizationIdentifier}.`,
      });
      return;
    }
    const organizationId = authProviders[0].organizationId;

    const migrationRecord = await getMigrationAccountByIdentifiers(
      organizationId,
      alcumusUserIdentifier
    );
    if (!migrationRecord) {
      response.status(404).send({
        message: `No user found with identifier ${alcumusUserIdentifier}.`,
      });
      return;
    }
    response.json(migrationRecord);
  }
);

export { migrateAuthV1 };
