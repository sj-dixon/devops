import express, { Router, Response } from 'express';
import { requireAuthentication } from '@alcumus/auth-plugin';
import { UserEntity } from '../models/userEntity';
import { patchUser } from '../controllers/patchCurrentUser';
import { UpdateUserRequest } from '../types';
import { Types, Middlewares } from '@alcumus/globals';
import { UserAccountEntity } from '../models/userAccountEntity';
import { UserAccountImportIntermediate } from '../types/importIntermediates';

const myProfileRouterV1: Router = express.Router();

myProfileRouterV1.get(
  '/',
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  async (request: Types.Request, response: Response) => {
    const user = await UserEntity.findByInternalAccountId(
      request.userInfo?.internalAccountId
    );

    if (!user) {
      response.sendStatus(404);
    } else {
      response.json(user);
    }
  }
);

myProfileRouterV1.patch(
  '/',
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  async (request: Types.Request, response: Response) => {
    const user = await UserEntity.findByInternalAccountId(
      request.userInfo?.internalAccountId
    );
    if (!user) {
      response.sendStatus(404);
      return;
    }
    const { id: userId } = user;
    const updateUserRequest: UpdateUserRequest = request.body;
    const result = await patchUser({
      ...updateUserRequest,
      userId,
    });
    response.json(result);
  }
);

myProfileRouterV1.get(
  '/account',
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  async (request: Types.Request, response: Response) => {
    const internalAccountId = request.userInfo?.internalAccountId as string;
    const [userAccount, user] = await Promise.all([
      UserAccountEntity.findByInternalAccountId(internalAccountId),
      UserEntity.findByInternalAccountId(internalAccountId),
    ]);
    if (!userAccount || !user) {
      response.sendStatus(404);
      return;
    }
    const intermediate: UserAccountImportIntermediate = {
      userId: userAccount.userId,
      userAccountId: userAccount.id,
      username: userAccount.username || null,
      email: userAccount.email || null,
      firstName: user.firstName,
      lastName: user.lastName,
      isEnabled: userAccount.isEnabled,
      userAccountType: userAccount.userAccountType,
      authProviderName: userAccount.authProviderName,
    };
    response.status(200).send(intermediate);
  }
);

export { myProfileRouterV1 };
