import express, { Router, Response } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { UserOrganizationEntity } from '../models/userOrganizationEntity';

const userOrganizationsRouterV1: Router = express.Router({ mergeParams: true });

userOrganizationsRouterV1.get(
  '/',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    const userId = Number(req.params.userId);
    const mappings = await UserOrganizationEntity.findByUserId(userId, false);
    const result = mappings.map((mapping) => ({
      ...mapping,
      alcumusUserId: mapping.id,
    }));
    res.json(result);
  }
);

userOrganizationsRouterV1.get(
  '/:organizationId',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    const userId = Number(req.params.userId);
    const organizationId = Number(req.params.organizationId);
    const mapping = await UserOrganizationEntity.findByUserIdAndOrganizationId(
      userId,
      organizationId
    );
    if (!mapping) {
      res.sendStatus(404);
      return;
    }
    const result = {
      ...mapping,
      alcumusUserId: mapping.id,
    };
    res.json(result);
  }
);

userOrganizationsRouterV1.post(
  '/',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    const userId = Number(req.params.userId);
    const { organizationId, isEnabled, invitationCode } = req.body;
    const result = await UserOrganizationEntity.create({
      organizationId,
      userId,
      isEnabled,
      invitationCode,
    });
    res.status(201).json({
      ...result,
      alcumusUserId: result.id,
    });
  }
);

export default userOrganizationsRouterV1;
