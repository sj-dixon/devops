import express, { Router } from 'express';
import { Middlewares } from '@alcumus/globals';
import { propagateAzureAdAccount } from '../controllers/accounts/propagateAzureAdAccount';
import { retrieveUserAccount } from '../controllers/accounts/retrieveUserAccount';
import { migrateUserAccount } from '../controllers/accounts/migrateUserAccount';
import { updateUserAccountLinks } from '../controllers/accounts/updateUserAccountLinks';

const accountsV1: Router = express.Router();

accountsV1.post(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    'x-azure-api-key',
    'AZURE_AD_CALLBACK_API_KEY'
  ),
  propagateAzureAdAccount
);

accountsV1.get(
  '/usernames/:loginIdentifier',
  Middlewares.requireApiKeyHeader,
  retrieveUserAccount
);

accountsV1.patch(
  '/usernames/:loginIdentifier',
  Middlewares.requireApiKeyHeader,
  updateUserAccountLinks
);

accountsV1.patch(
  '/migrate/:userAccountId',
  Middlewares.requireApiKeyHeader,
  migrateUserAccount
);

export { accountsV1 };
