import express, { Response, Router } from 'express';
import { UserAccountEntity } from '../models/userAccountEntity';
import { requireStrongPasswordIfChanging } from '../middleware/requirePasswordIfNeeded';
import { validationHandler } from '@alcumus/express-app';
import { Types, Middlewares } from '@alcumus/globals';
import { UpdateAccountRequest } from '../types';
import {
  updateKeycloakAndUserAccounts,
  updateKeycloakCredentials,
} from '../controllers/patchUser';
import { requireUserAccessRights } from '../middleware/requireUserAccessRights';
import { requireAuthentication } from '@alcumus/auth-plugin';

const userAccountRouter: Router = express.Router({ mergeParams: true });

userAccountRouter.get(
  '/',
  Middlewares.requireApiKeyHeader,
  Middlewares.decodeUserInfo,
  async (request: Types.Request, response: Response) => {
    // todo implement authorization logic.
    const userId: number = parseInt(request.params.userId);
    const account = await UserAccountEntity.findAllByUserId(userId);
    if (!account) {
      response.sendStatus(404);
    } else {
      response.json(account);
    }
  }
);

userAccountRouter.get(
  '/:accountId',
  Middlewares.requireApiKeyHeader,
  Middlewares.decodeUserInfo,
  async (request: Types.Request, response: Response) => {
    const accountId: number = parseInt(request.params.accountId);
    const userId: number = parseInt(request.params.userId);
    const account = await UserAccountEntity.findByUserAndAccountId(
      userId,
      accountId
    );

    if (!account) {
      response.sendStatus(404);
    } else {
      response.json(account);
    }
  }
);

userAccountRouter.patch(
  '/',
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  requireUserAccessRights,
  requireStrongPasswordIfChanging,
  validationHandler(),
  async (request: Types.Request, response: Response) => {
    const userId = Number(request.params.userId);
    const updateAccountRequest: UpdateAccountRequest = request.body;
    const initial = await UserAccountEntity.findAllByUserId(userId);

    if (!initial || initial.length === 0) {
      response.sendStatus(404);
      return;
    } else if (initial.length > 1) {
      response.status(422).send({
        message:
          'Ambiguous account being updated - please specify an account id',
      });
      return;
    }

    await updateKeycloakAndUserAccounts(
      userId,
      initial[0],
      updateAccountRequest
    );
    const result = await UserAccountEntity.findOneByUserId(userId);

    if (!initial) {
      response.sendStatus(404);
    } else {
      response.json(result);
    }
  }
);

userAccountRouter.patch(
  '/:accountId',
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  requireUserAccessRights,
  requireStrongPasswordIfChanging,
  validationHandler(),
  async (request: Types.Request, response: Response) => {
    const userId = Number(request.params.userId);
    const accountId = Number(request.params.accountId);
    const updateAccountRequest: UpdateAccountRequest = request.body;
    await updateKeycloakCredentials(userId, accountId, updateAccountRequest);
    const result = await UserAccountEntity.findByUserAndAccountId(
      userId,
      accountId
    );

    if (!result) {
      response.sendStatus(404);
    } else {
      response.json(result);
    }
  }
);

export default userAccountRouter;
