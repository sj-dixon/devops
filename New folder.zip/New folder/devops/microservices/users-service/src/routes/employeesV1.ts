import express, { Router, Response } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { UserEntity } from '../models/userEntity';
import { UserOrganizationEntity } from '../models/userOrganizationEntity';

const employeesRouterV1: Router = express.Router();

employeesRouterV1.get(
  '/:alcumusUserId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const alcumusUserId = Number(request.params.alcumusUserId);
    const user = await UserEntity.findByAlcumusUserId(alcumusUserId);
    if (!user) {
      response.sendStatus(404);
    } else {
      response.json(user);
    }
  }
);

employeesRouterV1.get(
  '/:alcumusUserId/organization',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const alcumusUserId = Number(request.params.alcumusUserId);
    const userOrganization = await UserOrganizationEntity.findByAlcumusUserId(
      alcumusUserId
    );
    if (!userOrganization) {
      response.sendStatus(404);
    } else {
      response.json({ ...userOrganization, alcumusUserId });
    }
  }
);

export { employeesRouterV1 };
