import express, { Response, Router } from 'express';
import { Middlewares, Types, Utilities } from '@alcumus/globals';
import { requireAuthentication } from '@alcumus/auth-plugin';
import { requireUserAccessRights } from '../middleware/requireUserAccessRights';
import { validationHandler } from '@alcumus/express-app';
import { UserEntity } from '../models/userEntity';
import { requireLoginIdentifierIfNeeded } from '../middleware/requireLoginIdentifierIfNeeded';
import {
  requirePasswordIfNeeded,
  requireStrongPasswordIfNeeded,
} from '../middleware/requirePasswordIfNeeded';
import { createUser } from '../controllers/createUser';
import { CreateUserRequest, UpdateUserRequest } from '../types';
import { patchUser } from '../controllers/patchUser';
import userAccountRouterV1 from './userAccountsV1';
import userOrganizationsRouterV1 from './userOrganizationsV1';
import { UserAccountType } from '../types/userAccount';

const usersRouterV1: Router = express.Router();

usersRouterV1.use('/:userId/accounts', userAccountRouterV1);
usersRouterV1.use('/:userId/organizations', userOrganizationsRouterV1);

usersRouterV1.get(
  '/:userId/',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const userId = Number(request.params.userId);
    const user = await UserEntity.findByUserId(userId);
    if (!user) {
      response.sendStatus(404);
    } else {
      response.json(user);
    }
  }
);

usersRouterV1.post(
  '/',
  Middlewares.requireApiKeyHeader,
  requireLoginIdentifierIfNeeded,
  requirePasswordIfNeeded,
  requireStrongPasswordIfNeeded,
  Middlewares.requireApiKeyHeader,
  validationHandler(),
  async (request: Types.Request, response: Response) => {
    const createUserRequest: CreateUserRequest = request.body;
    const tenantClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
      request,
      Types.ServiceEndpoints.TENANTS
    );
    const userWithAccounts = await createUser(
      createUserRequest,
      UserAccountType.PERSONAL_ACCOUNT,
      tenantClient
    );
    response.status(201).json(userWithAccounts);
  }
);

usersRouterV1.patch(
  '/:userId',
  validationHandler(),
  Middlewares.requireAuthorizationHeader,
  requireAuthentication(),
  Middlewares.decodeUserInfo,
  requireUserAccessRights,
  async (request: Types.Request, response: Response) => {
    const userId = Number(request.params.userId);
    const updateUserRequest: UpdateUserRequest = {
      ...request.body,
      userId,
    };

    const result = await patchUser(updateUserRequest);
    response.json(result);
  }
);

export default usersRouterV1;
