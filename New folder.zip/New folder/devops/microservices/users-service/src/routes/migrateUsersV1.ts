import express, { Router, Response } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { getMigrationAccount } from '../models/migrationAccounts';
import { requireAtLeastOneFieldUpdate } from '../middleware/requireAtLeastOneFieldUpdate';
import { UserEntity } from '../models/userEntity';
import { patchMigrationUserAccount } from '../controllers/patchMigrationUserAccount';

const migrateUsersV1: Router = express.Router();

migrateUsersV1.get(
  '/:alcumusUserId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const alcumusUserId = Number(request.params.alcumusUserId);
    const record = await getMigrationAccount(alcumusUserId);
    if (!record) {
      response.sendStatus(404);
    } else {
      response.json(record);
    }
  }
);

migrateUsersV1.patch(
  '/:alcumusUserId',
  Middlewares.requireApiKeyHeader,
  requireAtLeastOneFieldUpdate,
  async (request: Types.Request, response: Response) => {
    const alcumusUserId = Number(request.params.alcumusUserId);
    const originalRecord = await getMigrationAccount(alcumusUserId);
    if (!originalRecord) {
      response.status(404).send({ message: 'User Not Found' });
      return;
    }

    const userId = originalRecord.userId;
    await UserEntity.patch(userId, request.body);
    const result = await UserEntity.query().findById(userId);
    response.json(result);
  }
);

migrateUsersV1.patch(
  '/:alcumusUserId/credentials',
  Middlewares.requireApiKeyHeader,
  requireAtLeastOneFieldUpdate,
  async (request: Types.Request, response: Response) => {
    const alcumusUserId = Number(request.params.alcumusUserId);
    const originalRecord = await getMigrationAccount(alcumusUserId);
    if (!originalRecord) {
      response.sendStatus(404);
      return;
    }

    await patchMigrationUserAccount(request, response, originalRecord);

    const result = await getMigrationAccount(alcumusUserId);
    response.json(result);
  }
);

export { migrateUsersV1 };
