import express, { Response, Router } from 'express';
import { Types, Middlewares, Utilities } from '@alcumus/globals';
import { createMigrationUser } from '../controllers/createMigrationUser';
import parseXlsx from '../lib/utils/parseXlsx';
import { requireExcelFile } from '../middleware/requireExcelFile';
import { getNonUniqueUserIdentifierErrors } from '../lib/validators/requireUniqueUserIdentifiers';
import { getMigrationAccounts } from '../models/migrationAccounts';
import { bulkMigrateUsers } from '../controllers/bulkUpload/bulkMigrateUsers';
import { requireRealOrganizationId } from '../middleware/requireRealOrganizationId';
import { requireApiClientAppHasAuthProvider } from '../middleware/requireApiClientAppHasAuthProvider';
import { getAccountType } from '../lib/utils/getAccountTypeFromQuery';

import { RawUserDataRow } from '../lib/bulkUpload/types';
import { transformRawUser } from '../lib/bulkUpload/parsers';

const migrateTenantV1: Router = express.Router();

async function processBulkMigration(
  request: Types.Request,
  response: Response,
  isLargeExport = false
) {
  const [excel] = request.files as Types.File[];
  const organizationId = Number(request.params.organizationId);
  const userAccountType = getAccountType(
    request.query.userAccountType as string | undefined
  );
  const users = parseXlsx<RawUserDataRow>(excel.buffer);
  const usersToCreate = users.map(transformRawUser(organizationId));
  const errors = getNonUniqueUserIdentifierErrors(usersToCreate);
  if (!errors || errors.length > 0) {
    response.status(422).send(errors);
    return;
  }

  const needVerboseResponse = !isLargeExport;
  const maxRecordsForVerboseResponse = 100;

  const batchResult = await bulkMigrateUsers(
    usersToCreate,
    {
      filename: excel.filename || excel.originalname,
      organizationId,
      authProviderName: request.requestedBy?.requestedByApplication as string,
      userAccountType,
    },
    needVerboseResponse,
    maxRecordsForVerboseResponse
  );
  console.info(
    `Created ${batchResult.rowsAffected} rows for organization ${organizationId} with ${batchResult.errors} errors`
  );
  response.status(201).json(batchResult);
}

migrateTenantV1.post(
  '/:organizationId/users/batch',
  Middlewares.requireApiKeyHeader,
  requireRealOrganizationId,
  Middlewares.decodeRequestedBy,
  Middlewares.requireApiClientAppHeader,
  requireApiClientAppHasAuthProvider,
  requireExcelFile,
  async (request: Types.Request, response: Response) =>
    processBulkMigration(request, response, false)
);

migrateTenantV1.post(
  '/:organizationId/users/batch/large',
  Middlewares.requireApiKeyHeader,
  requireRealOrganizationId,
  Middlewares.decodeRequestedBy,
  Middlewares.requireApiClientAppHeader,
  requireApiClientAppHasAuthProvider,
  requireExcelFile,
  async (request: Types.Request, response: Response) =>
    processBulkMigration(request, response, true)
);

migrateTenantV1.post(
  '/:organizationId/users/register',
  Middlewares.requireApiKeyHeader,
  requireRealOrganizationId,
  async (request: Types.Request, response: Response) => {
    const organizationId = Number(request.params.organizationId);
    const migrationRequest = {
      ...request.body,
      organizationId,
    };
    const tenantsClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
      request,
      Types.ServiceEndpoints.TENANTS
    );
    const result = await createMigrationUser(migrationRequest, tenantsClient);
    response.status(201).json(result);
  }
);

migrateTenantV1.get(
  '/:organizationId/users',
  Middlewares.requireApiKeyHeader,
  requireRealOrganizationId,
  async (request: Types.Request, response: Response) => {
    const organizationId = Number(request.params.organizationId);
    const migrationAccounts = await getMigrationAccounts(organizationId);
    response.json(migrationAccounts);
  }
);

export { migrateTenantV1 };
