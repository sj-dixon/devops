import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
      tableBuilder.dropColumn('deleted_by');
      tableBuilder.dropColumn('primary_tenant_id');
    }
  );
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.integer('created_by').nullable().defaultTo(null).unsigned();
      tableBuilder.integer('modified_by').nullable().defaultTo(null).unsigned();
      tableBuilder.integer('deleted_by').nullable().defaultTo(null).unsigned();
      tableBuilder.integer('primary_tenant_id').notNullable().unsigned();
    }
  );
  await knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
      tableBuilder.dropColumn('deleted_by');
    }
  );
  await knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.integer('created_by').notNullable().unsigned();
      tableBuilder.integer('modified_by').notNullable().unsigned();
      tableBuilder.integer('deleted_by').nullable().defaultTo(null).unsigned();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
      tableBuilder.dropColumn('deleted_by');
      tableBuilder.dropColumn('primary_tenant_id');
    }
  );
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.string('created_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('modified_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('deleted_by', 50).nullable().defaultTo(null);
      tableBuilder
        .string('primary_tenant_id', 50)
        .notNullable()
        .defaultTo('Unknown');
    }
  );
  await knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
      tableBuilder.dropColumn('deleted_by');
    }
  );
  await knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.string('created_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('modified_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('deleted_by', 50).nullable().defaultTo(null);
    }
  );
}
