import { Knex } from 'knex';

const TABLE = 'user_accounts';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.datetime('created_at').alter();
      tableBuilder.datetime('modified_at').alter();
      tableBuilder.datetime('deleted_at').alter();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.timestamp('created_at').alter();
      tableBuilder.timestamp('modified_at').alter();
      tableBuilder.timestamp('deleted_at').alter();
    }
  );
}
