import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    'user_data_import_files',
    (table: Knex.CreateTableBuilder) => {
      table.increments('id').primary().unsigned();
      table
        .string('filename')
        .notNullable()
        .index('IDX_user_data_import_file_name');
      table.integer('number_of_rows').notNullable().unsigned();
      table
        .integer('organization_id')
        .notNullable()
        .unsigned()
        .index('IDX_user_data_import_file_org_id');

      table.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
      table.timestamp('modified_at').notNullable().defaultTo(knex.fn.now());
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('user_data_import_files');
}
