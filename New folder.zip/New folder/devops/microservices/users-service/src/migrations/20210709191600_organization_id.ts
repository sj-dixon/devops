import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'users',
    (alterTableBuilder: Knex.AlterTableBuilder) => {
      alterTableBuilder.renameColumn('primary_tenant_id', 'organization_id');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'users',
    (alterTableBuilder: Knex.AlterTableBuilder) => {
      alterTableBuilder.renameColumn('organization_id', 'primary_tenant_id');
    }
  );
}
