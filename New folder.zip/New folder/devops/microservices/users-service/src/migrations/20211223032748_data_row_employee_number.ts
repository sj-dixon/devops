import { Knex } from 'knex';

const dataImportRowTable = 'user_data_import_rows';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    dataImportRowTable,
    (builder: Knex.AlterTableBuilder) => {
      builder.string('employee_number', 50).nullable();
    }
  );

  // based on https://stackoverflow.com/questions/6280789/generate-guid-in-mysql-for-existing-data
  // this will generate a random guid for every row, although they do look similar
  await knex.raw(`
    UPDATE ${dataImportRowTable} 
    SET employee_number = (SELECT UUID()) 
    WHERE employee_number IS NULL 
  `);

  await knex.schema.alterTable(
    dataImportRowTable,
    (builder: Knex.AlterTableBuilder) => {
      builder.dropNullable('employee_number');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    dataImportRowTable,
    (builder: Knex.AlterTableBuilder) => {
      builder.dropColumn('employee_number');
    }
  );
}
