import { Knex } from 'knex';

// this migration is the reverse of
// 20210916211638_adjust-email-and-username-unique-constraints-across-tenants.ts

export async function up(knex: Knex): Promise<void> {
  // QA, DEV, and Staging have all been verified to not have any conflicting records
  await knex('user_accounts')
    .where({
      scopedToOrganizationId: null,
    })
    .update({
      scopedToOrganizationId: 0,
    });
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.dropNullable('scoped_to_organization_id');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.setNullable('scoped_to_organization_id');
    }
  );

  await knex('user_accounts')
    .where({
      scopedToOrganizationId: 0,
    })
    .update({
      scopedToOrganizationId: null,
    });
}
