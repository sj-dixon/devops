import { Knex } from 'knex';

const mappingsTableName = 'user_data_import_row_mappings';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    mappingsTableName,
    (table: Knex.CreateTableBuilder) => {
      table.increments('id').notNullable().primary();
      table.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
      table.timestamp('modified_at').notNullable().defaultTo(knex.fn.now());
      table.string('organization_identifier', 50).nullable();
      table.string('employee_number', 50).nullable();
      table.integer('organization_id').nullable();
      table.string('product_type', 50).nullable();
      table
        .integer('data_import_row_id')
        .unsigned()
        .nullable()
        .index('IDX_data_import_row_mapping_row_id');
      table
        .integer('data_import_file_id')
        .unsigned()
        .nullable()
        .index('IDX_data_import_row_mapping_file_id');

      table
        .foreign(
          'data_import_row_id',
          'fk_user_data_import_row_mappings_row_id'
        )
        .references('id')
        .inTable('user_data_import_rows')
        .onDelete('CASCADE');
      table
        .foreign(
          'data_import_file_id',
          'FK_user_data_import_row_mapping_file_id'
        )
        .references('id')
        .inTable('user_data_import_files')
        .onDelete('CASCADE');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable(mappingsTableName);
}
