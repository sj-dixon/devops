import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.CreateTableBuilder) => {
      table.unique(
        ['scoped_to_organization_id', 'username'],
        'UNIQ_username_scoped_to_organization_id'
      );
      table.unique(
        ['scoped_to_organization_id', 'email'],
        'UNIQ_email_scoped_to_organization_id'
      );
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.CreateTableBuilder) => {
      table.dropUnique(
        ['scoped_to_organization_id', 'username'],
        'UNIQ_username_scoped_to_organization_id'
      );
      table.dropUnique(
        ['scoped_to_organization_id', 'email'],
        'UNIQ_email_scoped_to_organization_id'
      );
    }
  );
}
