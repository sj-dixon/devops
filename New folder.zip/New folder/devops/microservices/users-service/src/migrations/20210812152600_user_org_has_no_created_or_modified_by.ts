import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_organizations',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
      tableBuilder.dropColumn('deleted_by');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_organizations',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.string('created_by', 50).nullable();
      tableBuilder.string('modified_by', 50).nullable();
      tableBuilder.string('deleted_by', 50).nullable();
    }
  );
}
