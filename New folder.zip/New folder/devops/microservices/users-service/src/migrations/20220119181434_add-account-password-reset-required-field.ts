import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.boolean('requires_password_reset').notNullable().defaultTo(false);
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.dropColumn('requires_password_reset');
    }
  );
}
