import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    'user_data_import_rows',
    (table: Knex.CreateTableBuilder) => {
      table.increments('id').primary().unsigned();
      table
        .integer('user_data_import_file_id')
        .unsigned()
        .notNullable()
        .index('IDX_user_data_import_row_file_id');
      table
        .foreign('user_data_import_file_id', 'FK_user_data_import_row_file_id')
        .references('id')
        .inTable('user_data_import_files')
        .onDelete('CASCADE');
      table.string('email', 50).nullable();
      table.string('username', 50).nullable();
      table.string('first_name', 50).nullable();
      table.string('last_name', 50).nullable();
      table.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
      table.timestamp('modified_at').notNullable().defaultTo(knex.fn.now());
      table.enum('row_status', ['LOADED', 'COMPLETE', 'ERROR']).notNullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('user_data_import_rows');
}
