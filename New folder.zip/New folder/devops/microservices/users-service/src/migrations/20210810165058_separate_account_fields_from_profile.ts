import { Knex } from 'knex';

const PHONE_COLUMN_LENGTH = 20;

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.dropColumn('work_email');
      tableBuilder.dropColumn('work_phone_number');
      tableBuilder.dropColumn('personal_phone_number');
      tableBuilder.dropColumn('personal_email');
    }
  );

  // no need to migrate data since we don't have data to keep yet.
  await knex.schema.alterTable(
    'user_accounts',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.string('phone_number', PHONE_COLUMN_LENGTH).nullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.dropColumn('phone_number');
    }
  );
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.string('personal_phone_number', PHONE_COLUMN_LENGTH);
      tableBuilder.string('work_phone_number', PHONE_COLUMN_LENGTH).nullable();
      tableBuilder.string('work_email', 50).nullable();
      tableBuilder.string('personal_email', 50);
    }
  );
}
