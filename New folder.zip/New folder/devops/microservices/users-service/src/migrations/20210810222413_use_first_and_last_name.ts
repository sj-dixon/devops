import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.renameColumn('given_names', 'first_name');
      tableBuilder.renameColumn('family_name', 'last_name');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'users',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.renameColumn('first_name', 'given_names');
      tableBuilder.renameColumn('last_name', 'family_name');
    }
  );
}
