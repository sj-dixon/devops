import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_rows',
    (table: Knex.AlterTableBuilder) => {
      table.renameColumn('employee_number', 'user_number');
    }
  );
  await knex.schema.alterTable(
    'user_data_import_row_mappings',
    (table: Knex.AlterTableBuilder) => {
      table.renameColumn('employee_number', 'user_number');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_rows',
    (table: Knex.AlterTableBuilder) => {
      table.renameColumn('user_number', 'employee_number');
    }
  );
  await knex.schema.alterTable(
    'user_data_import_row_mappings',
    (table: Knex.AlterTableBuilder) => {
      table.renameColumn('user_number', 'employee_number');
    }
  );
}
