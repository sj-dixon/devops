import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_files',
    (builder: Knex.AlterTableBuilder) => {
      builder.setNullable('organization_id');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_files',
    (builder: Knex.AlterTableBuilder) => {
      builder.dropNullable('organization_id');
    }
  );
}
