import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.AlterTableBuilder) => {
      table.dropColumn('account_provider_type');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.AlterTableBuilder) => {
      table
        .enum('account_provider_type', ['KEYCLOAK'])
        .notNullable()
        .defaultTo('KEYCLOAK');
    }
  );
}
