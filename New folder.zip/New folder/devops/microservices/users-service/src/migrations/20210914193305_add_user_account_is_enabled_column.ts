import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.CreateTableBuilder) => {
      table.boolean('is_enabled').notNullable().defaultTo(true);
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.CreateTableBuilder) => {
      table.dropColumn('is_enabled');
    }
  );
}
