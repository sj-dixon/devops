import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_files',
    (builder: Knex.AlterTableBuilder) => {
      builder
        .string('user_account_type', 50)
        .notNullable()
        .defaultTo('ORGANIZATION_ACCOUNT');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_files',
    (builder: Knex.AlterTableBuilder) => {
      builder.dropColumn('user_account_type');
    }
  );
}
