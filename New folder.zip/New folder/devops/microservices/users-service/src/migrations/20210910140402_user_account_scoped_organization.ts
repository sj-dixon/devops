import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.integer('scoped_to_organization_id').unsigned().nullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.dropColumn('scoped_to_organization_id');
    }
  );
}
