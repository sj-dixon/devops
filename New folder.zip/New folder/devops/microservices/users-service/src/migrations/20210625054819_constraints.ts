import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.unique(['username', 'email']);
      tableBuilder.unique(['keycloak_id']);
      tableBuilder.unique(['user_id']);
      tableBuilder.dropColumn('credential_type');
      tableBuilder.enum('credential_type', ['keycloak']).notNullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropUnique(['username', 'email']);
      tableBuilder.dropUnique(['keycloak_id']);
      tableBuilder.dropUnique(['user_id']);
      tableBuilder.dropColumn('credential_type');
      tableBuilder.string('credential_type').notNullable();
    }
  );
}
