import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.dropColumn('credential_type');
    }
  );

  await knex.schema.alterTable(
    'user_credentials',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder
        .enum('user_account_type', [
          'PERSONAL_ACCOUNT',
          'ORGANIZATION_ACCOUNT',
          'EXTERNAL_ACCOUNT',
        ])
        .defaultTo('PERSONAL_ACCOUNT')
        .notNullable();
    }
  );

  await knex.schema.renameTable('user_credentials', 'user_accounts');
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.dropColumn('user_account_type');
    }
  );
  await knex.schema.alterTable(
    'user_accounts',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder
        .enum('credential_type', ['keycloak'])
        .defaultTo('keycloak')
        .notNullable();
    }
  );
  await knex.schema.renameTable('user_accounts', 'user_credentials');
}
