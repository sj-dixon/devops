import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_files',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.string('auth_provider_name', 50).nullable().defaultTo(null);
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_data_import_files',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('auth_provider_name');
    }
  );
}
