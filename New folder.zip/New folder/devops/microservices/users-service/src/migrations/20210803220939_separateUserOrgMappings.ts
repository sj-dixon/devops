import { Knex } from 'knex';

const TABLE_NAME = 'user_organizations';

export async function up(knex: Knex): Promise<void> {
  // Create separate table to store user - organization_id mappings
  await knex.schema.createTable(TABLE_NAME, (t: Knex.AlterTableBuilder) => {
    t.increments('id').primary();
    t.integer('organization_id').unsigned().notNullable();
    t.integer('user_id').unsigned().notNullable();
    t.boolean('is_enabled').notNullable().defaultTo(true);
    t.string('created_by', 50).nullable();
    t.string('modified_by', 50).nullable();
    t.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
    t.timestamp('modified_at').notNullable().defaultTo(knex.fn.now());
    t.timestamp('deleted_at').nullable();
    t.string('deleted_by', 50).nullable();
    t.foreign('user_id', 'FK_users_organizations_user_id')
      .references('id')
      .inTable('users')
      .onDelete('CASCADE');
    t.unique(['user_id', 'organization_id']);
  });

  // Copy user-organization mappings to user_organizations table
  await knex
    .select('u.*')
    .from('users AS u')
    .join('user_credentials AS uc', 'u.id', 'uc.user_id')
    .then((rows) =>
      Promise.all(
        rows.map((row) =>
          knex
            .insert({
              userId: row.id,
              organizationId: row.organizationId || 1,
              createdAt: row.createdAt,
              modifiedAt: row.modifiedAt,
              deletedAt: row.deletedAt,
              isEnabled: row.isEnabled,
            })
            .into(TABLE_NAME)
        )
      )
    );

  // Drop organization_id column from users table
  await knex.schema.alterTable('users', (t: Knex.AlterTableBuilder) => {
    t.dropColumn('organization_id');
  });

  // Drop organization_id and is_enabled columns from user_credentials table
  await knex.schema.alterTable(
    'user_credentials',
    (t: Knex.AlterTableBuilder) => {
      t.dropColumn('organization_id');
      t.dropColumn('is_enabled');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  // Restore is_enabled column on user_credentials table
  await knex.schema.alterTable(
    'user_credentials',
    (t: Knex.AlterTableBuilder) => {
      t.integer('organization_id').unsigned().nullable();
      t.boolean('is_enabled').notNullable().defaultTo(true);
    }
  );

  // Restore organization_id column on users table
  await knex.schema.alterTable('users', (t: Knex.AlterTableBuilder) => {
    t.integer('organization_id').unsigned().nullable();
  });

  // Copy data back to old table columns
  await knex
    .select('uo.*')
    .from(`${TABLE_NAME} AS uo`)
    .join('users AS u', 'uo.user_id', 'u.id')
    .then((rows) =>
      Promise.all([
        ...rows.map(({ userId, organizationId }) =>
          knex('users').where({ id: userId }).update({
            organizationId,
          })
        ),
        ...rows.map(async ({ userId, organizationId, isEnabled }) =>
          knex('user_credentials').where({ userId }).update({
            isEnabled,
            organizationId,
          })
        ),
      ])
    );

  // Drop the user_organizations table
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
