import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.string('email', 100).alter();
      builder.string('username', 100).alter();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (builder: Knex.AlterTableBuilder) => {
      builder.string('email', 50).alter();
      builder.string('username', 50).alter();
    }
  );
}
