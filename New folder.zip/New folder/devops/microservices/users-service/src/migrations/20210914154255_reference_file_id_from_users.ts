import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('user_data_import_rows', (table) => {
    table.renameColumn('user_data_import_file_id', 'data_import_file_id');
  });

  await knex.schema.alterTable('users', (table) => {
    table.integer('data_import_file_id').nullable().unsigned();
    table
      .foreign('data_import_file_id', 'FK_users_data_import_file_id')
      .references('id')
      .inTable('user_data_import_files')
      .onDelete('SET NULL');
  });

  await knex.schema.alterTable('user_accounts', (table) => {
    table.integer('data_import_file_id').nullable().unsigned();
    table
      .foreign('data_import_file_id', 'FK_user_accounts_data_import_file_id')
      .references('id')
      .inTable('user_data_import_files')
      .onDelete('SET NULL');
  });

  await knex.schema.alterTable('user_organizations', (table) => {
    table.integer('data_import_file_id').nullable().unsigned();
    table
      .foreign(
        'data_import_file_id',
        'FK_users_organizations_data_import_file_id'
      )
      .references('id')
      .inTable('user_data_import_files')
      .onDelete('SET NULL');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('users', (table) => {
    table.dropForeign('FK_users_data_import_file_id');
    table.dropColumn('data_import_file_id');
  });

  await knex.schema.alterTable('user_accounts', (table) => {
    table.dropForeign('FK_user_accounts_data_import_file_id');
    table.dropColumn('data_import_file_id');
  });

  await knex.schema.alterTable('user_organizations', (table) => {
    table.dropForeign('FK_users_organizations_data_import_file_id');
    table.dropColumn('data_import_file_id');
  });
}
