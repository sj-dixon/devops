import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_organizations',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder
        .enum('role_type', ['ADMIN_ROLE', 'USER_ROLE'])
        .defaultTo('USER_ROLE')
        .notNullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_organizations',
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.dropColumn('role_type');
    }
  );
}
