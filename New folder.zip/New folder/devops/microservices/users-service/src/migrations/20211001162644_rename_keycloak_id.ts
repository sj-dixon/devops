import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.AlterTableBuilder) => {
      table.renameColumn('keycloak_id', 'internal_account_id');
      table
        .enum('account_provider_type', ['KEYCLOAK'])
        .notNullable()
        .defaultTo('KEYCLOAK');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.AlterTableBuilder) => {
      table.dropColumn('account_provider_type');
      table.renameColumn('internal_account_id', 'keycloak_id');
    }
  );
}
