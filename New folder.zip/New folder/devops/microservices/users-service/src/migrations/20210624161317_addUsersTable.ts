import { Knex } from 'knex';

const TABLE_NAME = 'users';
const COLUMN_LENGTH = 50;
const PHONE_COLUMN_LENGTH = 20;

export async function up(knex: Knex): Promise<void> {
  // noinspection DuplicatedCode
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // common metadata
      tableBuilder.increments('id').primary();
      tableBuilder.string('created_by', COLUMN_LENGTH).notNullable();
      tableBuilder.string('modified_by', COLUMN_LENGTH).notNullable();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      // common soft deletion metadata
      tableBuilder.timestamp('deleted_at').nullable();
      tableBuilder.string('deleted_by', COLUMN_LENGTH).nullable();

      // user properties
      tableBuilder.string('given_names', COLUMN_LENGTH).notNullable();
      tableBuilder.string('family_name', COLUMN_LENGTH).notNullable();
      tableBuilder.string('primary_tenant_id').notNullable();
      tableBuilder.string('work_email', COLUMN_LENGTH).nullable();
      tableBuilder.string('work_phone_number', PHONE_COLUMN_LENGTH).nullable();
      tableBuilder.string('personal_email', COLUMN_LENGTH).nullable();
      tableBuilder
        .string('personal_phone_number', PHONE_COLUMN_LENGTH)
        .nullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
