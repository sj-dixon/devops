import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_credentials',
    (alterTableBuilder: Knex.AlterTableBuilder) => {
      alterTableBuilder.renameColumn('tenant_id', 'organization_id');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_credentials',
    (alterTableBuilder: Knex.AlterTableBuilder) => {
      alterTableBuilder.renameColumn('organization_id', 'tenant_id');
    }
  );
}
