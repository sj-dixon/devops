import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_organizations',
    (t: Knex.CreateTableBuilder) => {
      t.string('invitation_code', 36).nullable().defaultTo(null);
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_organizations',
    (t: Knex.CreateTableBuilder) => {
      t.dropColumn('invitation_code');
    }
  );
}
