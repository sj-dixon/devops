import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.AlterTableBuilder) => {
      table
        .string('auth_provider_name', 50)
        .notNullable()
        .defaultTo('KEYCLOAK');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'user_accounts',
    (table: Knex.AlterTableBuilder) => {
      table.dropColumn('auth_provider_name');
    }
  );
}
