import { Knex } from 'knex';

const TABLE_NAME = 'user_credentials';
const COLUMN_LENGTH = 50;

export async function up(knex: Knex): Promise<void> {
  // noinspection DuplicatedCode
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // common metadata
      tableBuilder.increments('id').primary();
      tableBuilder.string('created_by', COLUMN_LENGTH).notNullable();
      tableBuilder.string('modified_by', COLUMN_LENGTH).notNullable();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      // common soft deletion metadata
      tableBuilder.timestamp('deleted_at').nullable();
      tableBuilder.string('deleted_by', COLUMN_LENGTH).nullable();

      // required properties
      tableBuilder.string('credential_type', COLUMN_LENGTH).notNullable();
      tableBuilder.boolean('is_enabled').notNullable().defaultTo(true);
      tableBuilder.integer('tenant_id').unsigned().notNullable();
      tableBuilder.integer('user_id').unsigned().notNullable();
      tableBuilder
        .foreign('user_id', 'FK_user_id')
        .references('id')
        .inTable('users')
        .onDelete('CASCADE');

      // keycloak properties
      tableBuilder.string('keycloak_id', COLUMN_LENGTH).nullable();
      tableBuilder.string('username', COLUMN_LENGTH).nullable();
      tableBuilder.string('email', COLUMN_LENGTH).nullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
