import { runApp } from '@alcumus/express-app';
import app from './app';
import { USER_SERVICE_PORT } from './constants';
import process from 'process';
import getKnexClient from './lib/clients/knex';

const knexClient = getKnexClient();

runApp(app, {
  port: USER_SERVICE_PORT,
}).catch(async (reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
  await knexClient.destroy();
});
