import { OrganizationAuthProviderType } from '../lib/tenants/types';
import { UserAccountType } from './userAccount';

export interface UserMigrationUniqueFields {
  email?: string;
  username?: string;
}

export interface UserMigrationRequest {
  organizationId?: number;
  isEnabled: boolean;
  firstName: string;
  lastName: string;
  email?: string;
  username?: string;
  password?: string;
  userNumber?: string;
}

export interface UserMigrationResult {
  userId: number;
  organizationId: number;
  userOrganizationId: number;
  userOrganizationAccountId: number;
  alcumusUserId: number;
  email: string | null;
  username: string | null;
  isEnabled: boolean;
  internalAccountId: string | null;
  authProviderName: OrganizationAuthProviderType | string;
  userAccountType: UserAccountType;
  firstName: string;
  lastName: string;
}

export interface UserDataImportFileDetails {
  filename: string;
  organizationId?: number | null;
  numberOfRows?: number;
  authProviderName?: string | null;
  userAccountType: UserAccountType;
}
