import { BaseEntity } from '../types';
import { OrganizationAuthProviderType } from '../lib/tenants/types';

export enum UserAccountType {
  PERSONAL_ACCOUNT = 'PERSONAL_ACCOUNT',
  ORGANIZATION_ACCOUNT = 'ORGANIZATION_ACCOUNT',
  EXTERNAL_ACCOUNT = 'EXTERNAL_ACCOUNT',
}

export interface UserAccount extends BaseEntity {
  userAccountType: UserAccountType;
  authProviderName: OrganizationAuthProviderType | string;
  userId: number;
  internalAccountId?: string | null;
  username?: string | null;
  email?: string | null;
  phoneNumber?: string | null;
  scopedToOrganizationId?: number | null;
  isEnabled: boolean;
  dataImportRowId?: number | null;
  dataImportFileId?: number | null;
  requiresPasswordReset: boolean;
}
