import { OrganizationAuthProviderType } from '../lib/tenants/types';
import { UserAccountType } from './userAccount';

export interface EmployeeDataImportResult {
  employeeId: number | null;
  alcumusUserId: number | null;
  userId: number;
  email: string | null;
  userAccountId: number;
  username: string | null;
  organizationId: number | null;
}

export interface UserAccountImportIntermediate {
  firstName: string;
  lastName: string;
  email: string | null;
  username: string | null;
  userId: number;
  userAccountId: number | null;
  authProviderName: OrganizationAuthProviderType | string;
  isEnabled: boolean;
  userAccountType: UserAccountType;
}

export interface EmployeeImportIntermediate {
  employeeId: number | null;
  alcumusUserId: number | null;
  userId: number;
  organizationId: number;
  firstName: string;
  lastName: string;
  isEnabled: boolean;
}
