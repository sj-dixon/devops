import * as XLSX from 'xlsx';

export default function parseXlsx<T>(data: Buffer): T[] {
  const xlsx = XLSX.read(data);
  const sheet = xlsx.Sheets[xlsx.SheetNames[0]];
  return XLSX.utils.sheet_to_json<T>(sheet);
}
