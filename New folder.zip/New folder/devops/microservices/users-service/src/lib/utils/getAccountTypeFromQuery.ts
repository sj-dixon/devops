import { UserAccountType } from '../../types/userAccount';

export function getAccountType(accountTypeFromQuery?: string): UserAccountType {
  if (
    !accountTypeFromQuery ||
    accountTypeFromQuery.toUpperCase() === 'ORGANIZATION'
  ) {
    return UserAccountType.ORGANIZATION_ACCOUNT;
  } else if (accountTypeFromQuery === 'INDIVIDUAL') {
    return UserAccountType.PERSONAL_ACCOUNT;
  } else {
    throw new Error(
      'Could not understand account type provided in query: ' +
        accountTypeFromQuery
    );
  }
}
