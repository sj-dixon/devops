import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
} from '../tenants/types';
import { Utilities } from '@alcumus/globals';
import { CreateInternalAccountRequest } from '../clients/keycloak/types';
import {
  AdminKeycloakClient,
  getAdminKeycloakClient,
} from '../clients/keycloak';
import { UserAccountEntity } from '../../models/userAccountEntity';
import { UpdateAccountRequest } from '../../types';

export function getTargetAuthProviderType(): OrganizationAuthProviderType {
  return Utilities.ProcessEnv.isEnabled('FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD')
    ? OrganizationAuthProviderType.AZURE_AD
    : OrganizationAuthProviderType.KEYCLOAK;
}

export async function createUserWithUserIdAttribute(
  userId: number,
  organizationId: number,
  authProvider: OrganizationAuthProvider,
  request: CreateInternalAccountRequest
): Promise<string> {
  if (authProvider.authProviderType === OrganizationAuthProviderType.KEYCLOAK) {
    const client: AdminKeycloakClient = getAdminKeycloakClient();
    await client.authenticateAsAdmin();
    return client.createUserWithUserIdAttribute(userId, request, authProvider);
  } else {
    throw new Error('CREATING USERS IN AZURE AD IS NOT SUPPORTED YET');
  }
}

export async function syncUsernameEmailAndPassword(
  account: UserAccountEntity,
  authProvider: OrganizationAuthProvider,
  request: UpdateAccountRequest
): Promise<void> {
  const internalAccountId = account.internalAccountId;

  if (
    !internalAccountId ||
    authProvider.authProviderType === OrganizationAuthProviderType.API
  ) {
    await UserAccountEntity.updateLoginIdentifier(account, request);
    return;
  }

  if (authProvider.authProviderType === OrganizationAuthProviderType.KEYCLOAK) {
    const client: AdminKeycloakClient = getAdminKeycloakClient();
    await client.authenticateAsAdmin();

    await Promise.all([
      client.changeLoginIdentifiersAndPassword(
        internalAccountId,
        account,
        request,
        authProvider
      ),
      UserAccountEntity.updateLoginIdentifier(account, request),
    ]);
  } else {
    throw new Error('PATCHING USERS IN AZURE AD IS  NOT SUPPORTED YET');
  }
}
