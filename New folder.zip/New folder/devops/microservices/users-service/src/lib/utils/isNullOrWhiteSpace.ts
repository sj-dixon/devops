export function isNullOrWhitespace(value?: string) {
  return !value || value.trim() === '';
}
