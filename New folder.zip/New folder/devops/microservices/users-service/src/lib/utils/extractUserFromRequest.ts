import { CreateUserRequest, User } from '../../types';

export function extractUserFromRequest({
  firstName,
  lastName,
}: CreateUserRequest): User {
  return {
    firstName,
    lastName,
  };
}
