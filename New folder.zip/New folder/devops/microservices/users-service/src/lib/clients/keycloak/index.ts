import KcAdminClient from 'keycloak-admin';
import { Utilities } from '@alcumus/globals';
import { UpdateAccountRequest } from '../../../types';
import { UserAccountEntity } from '../../../models/userAccountEntity';
import {
  CreateInternalAccountRequest,
  KeycloakConstants,
  KeycloakCredentials,
  KeycloakUserRepresentation,
} from './types';
import { OrganizationAuthProvider } from '../../tenants/types';
import { toKeycloakEmailOrUsername } from '@alcumus/auth-plugin';

export function getAdminKeycloakClient(): AdminKeycloakClient {
  const constants = Utilities.getKeycloakConstants();
  const configs = {
    baseUrl: constants.URL,
    realmName: constants.REALM,
  };
  const client = new KcAdminClient(configs);
  return new AdminKeycloakClient(client, constants);
}

export class AdminKeycloakClient {
  private _client: KcAdminClient;
  private _constants: KeycloakConstants;

  constructor(client: KcAdminClient, constants: KeycloakConstants) {
    this._client = client;
    this._constants = constants;
  }

  async authenticateAsAdmin(): Promise<void> {
    const credentials: KeycloakCredentials = {
      grantType: 'client_credentials',
      clientId: this._constants.ADMIN_ID,
      clientSecret: this._constants.ADMIN_SECRET,
    };
    await this._client.auth(credentials);
  }

  async authenticateAsUser({
    username,
    password,
  }: {
    username: string;
    password: string;
  }): Promise<void> {
    const credentials: KeycloakCredentials = {
      username,
      password,
      grantType: 'password',
      clientId: this._constants.CLIENT_ID,
      clientSecret: this._constants.CLIENT_SECRET,
    };
    await this._client.auth(credentials);
  }

  async createUserWithUserIdAttribute(
    userId: number,
    {
      firstName,
      lastName,
      email,
      username,
      password,
    }: CreateInternalAccountRequest,
    authProvider?: OrganizationAuthProvider | null
  ): Promise<string> {
    // apply a prefix to usernames and emails persisted in keycloak
    // to ensure that they can be reused across different tenants
    // as long as they are unique within the tenant.
    email = toKeycloakEmailOrUsername(email, authProvider?.userNamePrefix);
    username =
      toKeycloakEmailOrUsername(username, authProvider?.userNamePrefix) ||
      email;

    const userToCreate = {
      username,
      email,
      firstName,
      lastName,
      attributes: {
        userId,
      },
      emailVerified: true,
      enabled: true,
      credentials: [
        {
          type: 'password',
          temporary: false,
          value: password,
        },
      ],
    };

    const newUser = await this._client.users
      .create(userToCreate)
      .catch((err) => {
        const valueToMask = (email ?? username) as string;
        console.log(valueToMask);
        const maskedValue = `${valueToMask[0]}${'*'.repeat(
          valueToMask.length - 1
        )}`;
        console.error(
          `Could not create keycloak account for user ${userId} with masked login identifier ${maskedValue}`
        );
        throw err;
      });
    return newUser.id;
  }

  async changeUserPassword(
    internalAccountId: string,
    { newPassword }: { newPassword?: string }
  ): Promise<void> {
    if (!newPassword) {
      return;
    }
    await this._client.users.resetPassword({
      id: internalAccountId,
      credential: {
        type: 'password',
        temporary: false,
        value: newPassword,
      },
    });
  }

  toKeycloakIdentifier(
    identifier: string | undefined,
    authProvider: OrganizationAuthProvider | null
  ): string | undefined {
    return authProvider
      ? toKeycloakEmailOrUsername(identifier, authProvider?.userNamePrefix)
      : identifier;
  }

  async changeLoginIdentifiersAndPassword(
    internalAccountId: string,
    credential: UserAccountEntity,
    { email, username, isEnabled, newPassword }: UpdateAccountRequest,
    authProvider: OrganizationAuthProvider | null
  ): Promise<void> {
    const baseRequest: KeycloakUserRepresentation = {
      enabled: true,
    };
    const updateRequest: KeycloakUserRepresentation = {
      ...baseRequest,
    };

    if (email !== credential.email) {
      const modifiedEmail = this.toKeycloakIdentifier(email, authProvider);
      updateRequest.email = modifiedEmail;
    }
    if (username !== credential.username) {
      const modifiedUsername = this.toKeycloakIdentifier(
        username,
        authProvider
      );
      updateRequest.username = modifiedUsername;
    }
    if (isEnabled === false) {
      updateRequest.enabled = false;
    }
    if (newPassword) {
      updateRequest.credentials = [
        {
          type: 'password',
          temporary: false,
          value: newPassword,
        },
      ];
    }
    if (updateRequest !== baseRequest) {
      await this._client.users.update(
        {
          id: internalAccountId,
        },
        updateRequest
      );
    }
  }
}
