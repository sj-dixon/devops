import { Knex } from 'knex';
import { Utilities } from '@alcumus/globals';
import { getKnexConfig } from '@alcumus/objection-lib';

const databaseName = Utilities.ProcessEnv.getValueOrDefault(
  'USER_SERVICE_DATABASE_NAME',
  'users_db'
);
const config: Knex.Config = getKnexConfig(databaseName);

export default config;
