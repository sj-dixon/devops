import connect, { Knex } from 'knex';
import { Model } from 'objection';
import config from '../../../knexfile';
import { Utilities } from '@alcumus/globals';

export default function getKnexClient(): Knex {
  const knex = connect(config);
  Model.knex(knex);
  return knex;
}

export function printSqlIfDebugFlagEnabled(query: Knex.QueryBuilder): void {
  if (Utilities.ProcessEnv.isEnabled('DEBUG_DIRECT_SQL_CALLS')) {
    console.log(query.toSQL());
  }
}
