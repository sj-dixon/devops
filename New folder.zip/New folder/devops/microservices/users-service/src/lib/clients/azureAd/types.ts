import { UserAccount } from '../../../types/userAccount';

export interface AzureAdAccountRequestBody {
  givenName: string;
  displayName: string;
  surname: string;
  objectId: string;
  email: string;
  userPrincipalName: string;
}

export type AzureAdAccountResponseBody = UserAccount & {
  userAccountId: number;
  firstName: string;
  lastName: string;
};
