import KeycloakUserRepresentation from 'keycloak-admin/lib/defs/userRepresentation';
import { Credentials } from 'keycloak-admin/lib/utils/auth';
import KeycloakGroupRepresentation from 'keycloak-admin/lib/defs/groupRepresentation';

export interface KeycloakConstants {
  URL: string;
  REALM: string;
  CLIENT_ID: string;
  ADMIN_ID: string;
  CLIENT_SECRET: string;
  ADMIN_SECRET: string;
}

export interface CreateInternalAccountRequest {
  firstName?: string;
  lastName?: string;
  username?: string;
  email?: string;
  password?: string;
}

export {
  KeycloakUserRepresentation,
  Credentials as KeycloakCredentials,
  KeycloakGroupRepresentation,
};
