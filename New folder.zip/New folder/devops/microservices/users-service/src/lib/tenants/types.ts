export interface Tenant {
  id: number;
  tenantName: string;
  tenantIdentifier: string;
}

export enum OrganizationAuthProviderType {
  KEYCLOAK = 'KEYCLOAK',
  AZURE_AD = 'AZURE_AD',
  API = 'API',
}

export interface OrganizationAuthProvider {
  id: number;
  organizationId: number;
  userNamePrefix: string;
  organizationIdentifier: string;
  authProviderType: OrganizationAuthProviderType;
}
