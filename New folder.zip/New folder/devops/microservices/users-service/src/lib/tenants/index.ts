import {
  ALLOW_SUCCESS_OR_NOT_FOUND_RESPONSE,
  getServiceMeshAxiosConfig,
  getServiceMeshUrl,
} from '@alcumus/service-mesh-plugin';
import axios, { AxiosInstance } from 'axios';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
  Tenant,
} from './types';
import { Types } from '@alcumus/globals';

export async function getOrganizationById(
  organizationId: number
): Promise<Tenant | null> {
  const url = getServiceMeshUrl(
    `/v1/organizations/${organizationId}`,
    Types.ServiceEndpoints.TENANTS
  );
  const axiosConfig = getServiceMeshAxiosConfig(
    Types.ServiceEndpoints.TENANTS,
    ALLOW_SUCCESS_OR_NOT_FOUND_RESPONSE
  );

  const result = await axios.get(url, axiosConfig);

  if (result.status === 404) {
    return null;
  } else {
    return result.data as Tenant;
  }
}

export async function getOrganizationIdByIdentifier(
  axiosInstance: AxiosInstance,
  organizationIdentifier: string
): Promise<number | null> {
  const response = await axiosInstance.get(
    `/api/v1/auth/${organizationIdentifier}`
  );
  if (response.status === 404) {
    return null;
  } else {
    return response.data.id;
  }
}

export async function getAuthProvider({
  authProviderName,
  organizationId,
  axiosInstance,
}: {
  axiosInstance: AxiosInstance;
  authProviderName: OrganizationAuthProviderType | string;
  organizationId?: number | null;
}): Promise<OrganizationAuthProvider | null> {
  const url = `/api/v1/authProviders/${authProviderName}${
    organizationId ? `?organizationId=${organizationId}` : ''
  }`;
  const response = await axiosInstance.get(url);
  if (response.status !== 200 && response.status !== 404) {
    throw new Error('Could not find auth provider for organization');
  } else if (response.status === 404) {
    return null;
  } else {
    return response.data;
  }
}

export async function getAuthProviderByOrganizationId(
  organizationId: number | undefined | null,
  targetProviderType: OrganizationAuthProviderType | string
): Promise<OrganizationAuthProvider | null> {
  if (!organizationId) {
    return null;
  }
  const url = getServiceMeshUrl(
    `/v1/organizations/${organizationId}/authProviders/${targetProviderType}`,
    Types.ServiceEndpoints.TENANTS
  );
  const config = getServiceMeshAxiosConfig(Types.ServiceEndpoints.TENANTS);
  const result = await axios.get(url, config);
  if (result.status !== 200 && result.status !== 404) {
    throw new Error('Could not find auth provider for organization');
  } else if (result.status === 404) {
    return null;
  } else {
    return result.data as OrganizationAuthProvider;
  }
}

export async function getAuthProvidersByOrganizationIdentifier(
  organizationIdentifier: string
): Promise<OrganizationAuthProvider[] | null> {
  const url = getServiceMeshUrl(
    `/v1/auth/${organizationIdentifier}/authProviders`,
    Types.ServiceEndpoints.TENANTS
  );
  const config = getServiceMeshAxiosConfig(
    Types.ServiceEndpoints.TENANTS,
    ALLOW_SUCCESS_OR_NOT_FOUND_RESPONSE
  );
  const result = await axios.get(url, config);
  if (result.status === 404 || result.data === []) {
    return null;
  } else {
    return result.data as OrganizationAuthProvider[];
  }
}
