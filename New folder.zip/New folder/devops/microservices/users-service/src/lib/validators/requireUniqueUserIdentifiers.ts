import { UserMigrationUniqueFields } from '../../types/userMigration';
import { UserMigrationError } from '../bulkUpload/types';

export const BULK_DUPLICATION_ERRORS = {
  emailMustBeUnique: {
    key: 'users.bulkUpload.emailMustBeUnique',
    message: 'Email was found multiple times in bulk upload file',
  },
  usernameMustBeUnique: {
    key: 'users.bulkUpload.usernameMustBeUnique',
    message: 'Username was found multiple times in bulk upload file',
  },
};

function getErrorIfDuplicated<T>(
  previousEntries: Set<T>,
  entryToTest: T,
  errorTemplate: UserMigrationError,
  row: number
): UserMigrationError | null {
  if (!entryToTest) {
    return null;
  }
  if (previousEntries.has(entryToTest)) {
    return {
      ...errorTemplate,
      rowNumber: row,
    };
  }
  previousEntries.add(entryToTest);
  return null;
}

export function getNonUniqueUserIdentifierErrors(
  users: UserMigrationUniqueFields[]
): UserMigrationError[] {
  if (!users) {
    return [];
  }

  const errors: UserMigrationError[] = [];

  const emails = new Set();
  const usernames = new Set();

  // The first data row in the spreadsheet is row 2
  // because of the header row (row 1) and the fact that
  // spreadsheets are 1-indexed, unlike arrays.
  const rowOffset = 2;

  for (let index = 0; index < users.length; index++) {
    const user = users[index];
    const possibleErrors = [
      getErrorIfDuplicated(
        emails,
        user.email,
        BULK_DUPLICATION_ERRORS.emailMustBeUnique,
        index + rowOffset
      ),
      getErrorIfDuplicated(
        usernames,
        user.username,
        BULK_DUPLICATION_ERRORS.usernameMustBeUnique,
        index + rowOffset
      ),
    ];
    possibleErrors.forEach((error: UserMigrationError | null) => {
      if (error) {
        errors.push(error);
      }
    });
  }

  return errors;
}
