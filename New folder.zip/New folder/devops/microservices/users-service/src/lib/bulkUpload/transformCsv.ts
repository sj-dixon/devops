import { Types } from '@alcumus/globals';
import { UserDataImportRowWithMappings } from '../../models/types';
import { UserOrganizationProductRowIntermediate } from './types';
import {
  getOrganizationProductMappingsByEmail,
  getOrGenerateUserNumbersByEmail,
  transformIntermediatesToDataRows,
} from './aggregators';

export async function getDataImportRowsWithMappings(
  dataImportFileId: number,
  intermediates: UserOrganizationProductRowIntermediate[],
  cache: Types.LookupCache<string, number | null>
): Promise<UserDataImportRowWithMappings[]> {
  const userNumbersByEmail: Types.StringDictionary =
    getOrGenerateUserNumbersByEmail(intermediates);
  const rowMappingsByUserNumber = await getOrganizationProductMappingsByEmail({
    cache,
    userNumbersByEmail,
    intermediates,
    dataImportFileId,
  });
  const now = new Date();
  return transformIntermediatesToDataRows({
    dataImportFileId,
    intermediates,
    now,
    rowMappingsByUserNumber,
  });
}
