import { EmployeeDataImportResult } from '../../types/importIntermediates';

export interface RawUserDataRow {
  'Email Address': string;
  'First Name': string;
  'Last Name': string;
  'User Name'?: string;
  Archive?: string;
  'User Number'?: string;
}

export interface RawUserDataRowWithOrganization extends RawUserDataRow {
  'Organization Identifier'?: string;
  'Organization Id'?: number;
  'Product Type'?: string;
  'Authentication Provider'?: string;
}

export interface UserOrganizationProductRowIntermediate {
  email?: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  isEnabled?: boolean;
  userNumber?: string;
  productType?: string;
  organizationId?: number;
  organizationIdentifier?: string;
}

export interface UserMigrationError {
  rowNumber?: number;
  key: string;
  message: string;
}

export interface BatchResult {
  migrated: EmployeeDataImportResult[];
  rowsAffected: number;
  errors: number;
  dataImportFileId: number;
}
