import {
  UserMigrationError,
  UserOrganizationProductRowIntermediate,
} from './types';
import { Types } from '@alcumus/globals';

/**
 * Precondition: all intermediates must have a user number
 * */
export function validateIntermediates({
  intermediates,
}: {
  intermediates: UserOrganizationProductRowIntermediate[];
}): UserMigrationError[] {
  const firstNamesByUserNumber = {} as Types.StringDictionary;
  const lastNamesByUserNumber = {} as Types.StringDictionary;
  const emailsByUserNumber = {} as Types.StringDictionary;
  const usernamesByUserNumber = {} as Types.StringDictionary;
  const firstRowNumbersByUserNumber = {} as Types.Dictionary<string, number>;
  const userNumbersByEmail = {} as Types.StringDictionary;

  const multiValueErrors = intermediates.flatMap((intermediate, index) => {
    const rowNumber = index + 1;
    const userNumber = intermediate.userNumber as string;
    if (userNumber && !firstRowNumbersByUserNumber[userNumber]) {
      firstRowNumbersByUserNumber[userNumber] = rowNumber;
    }
    return [
      validateKeyDoesNotHaveMultipleValues(
        firstNamesByUserNumber,
        rowNumber,
        'first name',
        userNumber,
        intermediate.firstName
      ),

      validateKeyDoesNotHaveMultipleValues(
        lastNamesByUserNumber,
        rowNumber,
        'last name',
        userNumber,
        intermediate.lastName
      ),

      validateKeyDoesNotHaveMultipleValues(
        userNumbersByEmail,
        rowNumber,
        'user number',
        intermediate.email,
        intermediate.userNumber
      ),

      // todo support this case and remove the validation
      validateKeyDoesNotHaveMultipleValues(
        emailsByUserNumber,
        rowNumber,
        'email',
        userNumber,
        intermediate.email
      ),

      // todo support this case and remove the validation
      validateKeyDoesNotHaveMultipleValues(
        usernamesByUserNumber,
        rowNumber,
        'username',
        userNumber,
        intermediate.username
      ),
    ];
  });

  const missingValueErrors = intermediates
    .filter((intermediate) => {
      const userNumber = intermediate.userNumber as string;
      return (
        !firstNamesByUserNumber[userNumber] ||
        !lastNamesByUserNumber[userNumber] ||
        !emailsByUserNumber[userNumber]
      );
    })
    .flatMap((intermediate) => {
      const userNumber = intermediate.userNumber as string;
      return [
        validateKeyHasSingleValue(
          firstNamesByUserNumber,
          firstRowNumbersByUserNumber[userNumber],
          'first name',
          userNumber
        ),
        validateKeyHasSingleValue(
          lastNamesByUserNumber,
          firstRowNumbersByUserNumber[userNumber],
          'last name',
          userNumber
        ),
        // todo remove this validation and support username only imports
        validateKeyHasSingleValue(
          emailsByUserNumber,
          firstRowNumbersByUserNumber[userNumber],
          'email',
          userNumber
        ),
      ];
    });

  const basicValidationErrors = intermediates.flatMap((intermediate) => {
    const userNumber = intermediate.userNumber as string;
    return [
      validateUserHasValidEmail(
        emailsByUserNumber[userNumber],
        firstRowNumbersByUserNumber[userNumber]
      ),
    ];
  });

  return [
    ...multiValueErrors,
    ...missingValueErrors,
    ...basicValidationErrors,
  ].filter((value) => value !== null) as UserMigrationError[];
}

function validateUserHasValidEmail(
  email: string,
  rowNumber: number
): UserMigrationError | null {
  if (!email) {
    return null;
  }
  if (
    /[a-zA-Z0-9.!#$%&;'^_`{}~-]+(\+[a-zA-Z0-9]+)?@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+/.test(
      email
    )
  ) {
    return null;
  }
  return {
    key: 'users.dataImport.emailAddressMustBeValid',
    message: `Email address ${email} is not recognized as a valid email.`,
    rowNumber,
  };
}

function validateKeyHasSingleValue(
  dictionary: Types.StringDictionary,
  rowNumber: number,
  columnName: string,
  key: string
): UserMigrationError | null {
  if (!dictionary[key]) {
    return {
      key: 'users.dataImport.userMustHaveValueForColumn',
      message: `User does not have a single value for the ${columnName} column.`,
      rowNumber,
    };
  } else {
    return null;
  }
}

function validateKeyDoesNotHaveMultipleValues<TValue>(
  dictionary: Types.Dictionary<string, TValue>,
  rowNumber: number,
  columnName: string,
  key: string | undefined,
  value: TValue
): UserMigrationError | null {
  if (!key || !value || dictionary[key] === value) {
    return null;
  } else if (!dictionary[key] && value) {
    dictionary[key] = value;
    return null;
  } else {
    return {
      key: 'users.dataImport.userMustNotHaveMultipleValuesForColumn',
      message: `Each user can have at most 1 ${columnName}, but found multiple: ${dictionary[key]} and ${value}.`,
      rowNumber,
    };
  }
}
