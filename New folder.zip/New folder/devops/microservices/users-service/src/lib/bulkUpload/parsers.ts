import {
  RawUserDataRow,
  RawUserDataRowWithOrganization,
  UserOrganizationProductRowIntermediate,
} from './types';
import { UserMigrationRequest } from '../../types/userMigration';

export function parseRawRowsDoNotDeduplicate(
  rawRows: RawUserDataRowWithOrganization[]
): UserOrganizationProductRowIntermediate[] {
  return rawRows.map((current) => ({
    firstName: current['First Name'],
    lastName: current['Last Name'],
    email: current['Email Address'],
    username: current['User Name'],
    userNumber: current['User Number'],
    productType: current['Product Type'],
    organizationId: current['Organization Id'],
    organizationIdentifier: current['Organization Identifier'],
  }));
}

export function transformRawUser(
  organizationId: number
): (user: RawUserDataRow) => UserMigrationRequest {
  return (user: RawUserDataRow) => ({
    email: user['Email Address'] || undefined,
    username: user['User Name'] || undefined,
    firstName: user['First Name'],
    lastName: user['Last Name'],
    isEnabled: !user.Archive || !user.Archive?.toLowerCase().includes('y'),
    organizationId: organizationId,
    userNumber: user['User Number'],
  });
}
