import { UserOrganizationProductRowIntermediate } from './types';
import { v4 as uuidV4 } from 'uuid';
import { Types } from '@alcumus/globals';
import {
  UserDataImportRow,
  UserDataImportRowMapping,
  UserDataImportRowStatus,
  UserDataImportRowWithMappings,
} from '../../models/types';
import { toMySqlDateTimeString } from '@alcumus/objection-lib';

export function getOrGenerateUserNumbersByEmail(
  intermediates: UserOrganizationProductRowIntermediate[]
): Types.StringDictionary {
  return intermediates.reduce((aggregate, current) => {
    const email = current.email as string;

    if (!aggregate[email]) {
      aggregate[email] = current.userNumber || uuidV4();
    }
    // this block is significant because otherwise we have no
    // way for code to use properly use this dictionary later.
    if (!current.userNumber) {
      current.userNumber = aggregate[email];
    }
    return aggregate;
  }, {} as Types.StringDictionary);
}

export async function getOrganizationProductMappingsByEmail({
  cache,
  intermediates,
  userNumbersByEmail,
  dataImportFileId,
}: {
  cache: Types.LookupCache<string, number | null>;
  userNumbersByEmail: Types.StringDictionary;
  intermediates: UserOrganizationProductRowIntermediate[];
  dataImportFileId: number;
}): Promise<Types.Dictionary<string, UserDataImportRowMapping[]>> {
  const dictionary = {} as Types.Dictionary<string, UserDataImportRowMapping[]>;

  return intermediates.reduce(async (aggregatePromise, current) => {
    const userNumber = userNumbersByEmail[current.email as string];
    const aggregate = await aggregatePromise;
    if (!aggregate[userNumber]) {
      aggregate[userNumber] = [];
    }
    const array = aggregate[userNumber];
    const organizationIdentifier = current.organizationIdentifier;
    const organizationId = organizationIdentifier
      ? await cache.get(organizationIdentifier)
      : current.organizationId;
    const product = current.productType;
    array.push({
      organizationIdentifier,
      organizationId,
      dataImportFileId,
      userNumber: userNumber,
      productType: product,
    });
    return aggregate;
  }, Promise.resolve(dictionary));
}

export function transformIntermediatesToDataRows({
  now,
  intermediates,
  dataImportFileId,
  rowMappingsByUserNumber,
}: {
  dataImportFileId: number;
  intermediates: UserOrganizationProductRowIntermediate[];
  now: Date;
  rowMappingsByUserNumber: Types.Dictionary<string, UserDataImportRowMapping[]>;
}): UserDataImportRowWithMappings[] {
  const createdAt = toMySqlDateTimeString(now);
  const uniqueRows = intermediates.reduce((aggregate, current) => {
    // note: User Number is set in getDataImportRowMappings
    const userNumber = current.userNumber as string;

    const value: UserDataImportRow = {
      firstName: current.firstName,
      lastName: current.lastName,
      rowStatus: UserDataImportRowStatus.LOADED,
      email: current.email,
      username: current.username,
      dataImportFileId: dataImportFileId,
      userNumber,
      createdAt,
    };
    if (!aggregate[userNumber]) {
      aggregate[userNumber] = value;
    }

    return aggregate;
  }, {} as Types.Dictionary<string, UserDataImportRow>);

  return Object.values(uniqueRows).map((toCreate) => {
    const { userNumber } = toCreate;
    return {
      dataRow: toCreate,
      mappings: rowMappingsByUserNumber[userNumber],
    };
  });
}
