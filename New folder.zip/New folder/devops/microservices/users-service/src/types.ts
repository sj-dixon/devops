export interface BaseEntity {
  deletedAt?: Date | string | null;
  createdAt?: Date | string;
  modifiedAt?: Date | string;
}

export interface User extends BaseEntity {
  firstName: string;
  lastName: string;
  dataImportFileId?: number;
}

export interface OrgUserMapping extends BaseEntity {
  userId: number;
  organizationId: number;
  isEnabled: boolean;
}

export interface AccountRequest {
  username?: string;
  email?: string;
  phoneNumber?: string;
  isEnabled?: boolean;
}

export interface CreateUserRequest extends User, AccountRequest {
  password?: string;
  createAccount: boolean;
}

export interface UpdateUserRequest {
  userId: number;
  firstName?: string;
  lastName?: string;
}

export interface UpdateAccountRequest extends AccountRequest {
  oldPassword?: string;
  newPassword?: string;
  isEnabled?: boolean;
  internalAccountId?: string;
}

export interface RequestUser {
  userId?: number;
  organizationId?: number;
}
