import { Knex } from 'knex';
import dotenv from 'dotenv';
import path from 'path';
import { Model } from 'objection';
import {
  AdminKeycloakClient,
  getAdminKeycloakClient,
} from '../lib/clients/keycloak';
import { UserAccountEntity } from '../models/userAccountEntity';
import { UserEntity } from '../models/userEntity';
import { UserAccountType } from '../types/userAccount';
import { OrganizationAuthProviderType } from '../lib/tenants/types';

dotenv.config({ path: path.resolve(__dirname, '../../../../.env') });

interface ISeedUser {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  password: string;
  createAccount: boolean;
  userAccountType: UserAccountType;
}

const users: Array<ISeedUser> = [
  {
    firstName: 'Alcumus',
    lastName: 'Admin',
    username: 'alcumusadmin',
    email: 'admin@alcumus.com',
    password: 'Alcdev01!',
    createAccount: true,
    userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
  },
  {
    firstName: 'Alcumus',
    lastName: 'Dev',
    username: 'alcumusdev',
    email: 'dev@alcumus.com',
    password: 'Alcdev01!',
    createAccount: true,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
  },
  {
    firstName: 'Alcumus',
    lastName: 'Tester',
    username: 'alcumustester',
    email: 'tester@alcumus.com',
    password: 'Alcdev01!',
    createAccount: true,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
  },
  {
    firstName: 'External',
    lastName: 'Admin',
    username: 'externaladmin',
    email: 'admin@externalit.com',
    password: 'Alcdev01!',
    createAccount: true,
    userAccountType: UserAccountType.EXTERNAL_ACCOUNT,
  },
  {
    firstName: 'Polly',
    lastName: 'Andersen',
    username: 'polly.andersen',
    email: 'polly.andersen@ecompliance.ca',
    password: 'Alcdev01!',
    createAccount: true,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
  },
];

async function seedUser(user: ISeedUser): Promise<void> {
  try {
    const client: AdminKeycloakClient = getAdminKeycloakClient();
    await client.authenticateAsAdmin();

    const newUser = await UserEntity.create({
      firstName: user.firstName,
      lastName: user.lastName,
    });

    const account = await UserAccountEntity.create(null, {
      userId: newUser.id,
      userAccountType: user.userAccountType,
      username: user.username,
      email: user.email,
      isEnabled: true,
      authProviderName: OrganizationAuthProviderType.KEYCLOAK,
      requiresPasswordReset: true,
    });

    const internalAccountId = await client.createUserWithUserIdAttribute(
      newUser.id,
      user
    );

    await UserAccountEntity.updateLoginIdentifier(account, {
      internalAccountId,
    });
  } catch (err) {
    console.error('Error seeding user', err);
  }
}

export async function seed(knex: Knex): Promise<void> {
  Model.knex(knex);
  await Promise.all(users.map((u) => seedUser(u)));
}
