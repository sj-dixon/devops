import { Knex } from 'knex';
import { UserMigrationResult } from '../types/userMigration';
import { UserOrganizationEntity } from './userOrganizationEntity';
import { UserAccountType } from '../types/userAccount';
import { NULL_PLACEHOLDER_VALUE } from './userAccountEntity';

function getMigrationAccountQueryBuilder(): Knex.QueryBuilder {
  const knex: Knex = UserOrganizationEntity.knex();
  return knex
    .select(
      'user_organizations.id as user_organization_id',
      'user_organizations.id as alcumus_user_id',
      'user_organizations.user_id',
      'user_organizations.organization_id',
      'user_accounts.id as userOrganizationAccountId',
      'user_accounts.auth_provider_name',
      'user_accounts.internal_account_id',
      knex.raw('(?? && ??) as ??', [
        'user_organizations.is_enabled',
        'user_accounts.is_enabled',
        'is_enabled',
      ]),
      'user_accounts.email',
      'user_accounts.username',
      'user_accounts.user_account_type',
      'users.first_name',
      'users.last_name'
    )
    .from('user_organizations')
    .innerJoin('user_accounts', function (this: Knex.JoinClause) {
      this.on('user_accounts.user_id', '=', 'user_organizations.user_id').andOn(
        function (this: Knex.JoinClause) {
          this.on(
            'user_accounts.scoped_to_organization_id',
            '=',
            'user_organizations.organization_id'
          ).orOnVal(
            'user_accounts.scoped_to_organization_id',
            NULL_PLACEHOLDER_VALUE
          );
        }
      );
    })
    .innerJoin('users', function (this: Knex.JoinClause) {
      this.on('users.id', '=', 'user_accounts.user_id');
    });
}

export async function getMigrationAccounts(
  organizationId: number,
  dataImportFileId?: number
): Promise<UserMigrationResult[]> {
  const rawResult = await getMigrationAccountQueryBuilder().where((builder) => {
    builder.where('user_organizations.organization_id', '=', organizationId);
    if (dataImportFileId) {
      builder.andWhere('users.data_import_file_id', '=', dataImportFileId);
    }
  });
  return convertTinyIntegersToBoolean(rawResult);
}

export async function getDataImportMigrationAccounts(
  dataImportFileId: number
): Promise<UserMigrationResult[]> {
  const rawResult = await getMigrationAccountQueryBuilder().where(
    'users.data_import_file_id',
    '=',
    dataImportFileId
  );
  return convertTinyIntegersToBoolean(rawResult);
}

export async function getMigrationAccount(
  userOrganizationId: number
): Promise<UserMigrationResult | null> {
  const query = getMigrationAccountQueryBuilder().where((builder) => {
    builder.where('user_organizations.id', '=', userOrganizationId);
  });
  const rawResults = await query;
  if (!rawResults || rawResults.length > 1) {
    throw new Error(
      `Unable to find a unique record where the alcumus user id = ${userOrganizationId}`
    );
  }

  return convertTinyIntegerToBoolean(rawResults[0]);
}

export async function getMigrationAccountByIdentifiers(
  organizationId: number,
  loginIdentifier: string
): Promise<UserMigrationResult | null> {
  const results = await getMigrationAccountQueryBuilder()
    .where(
      'user_accounts.user_account_type',
      '=',
      UserAccountType.ORGANIZATION_ACCOUNT
    )
    .andWhere('user_accounts.scoped_to_organization_id', '=', organizationId)
    .andWhere((builder) => {
      builder
        .where('user_accounts.email', '=', loginIdentifier)
        .orWhere('user_accounts.username', '=', loginIdentifier);
    });
  if (!results) {
    return null;
  }
  if (results.length > 1) {
    throw new Error(
      `Found multiple user accounts with username ${loginIdentifier}`
    );
  }
  return convertTinyIntegerToBoolean(results[0]);
}

export function convertTinyIntegersToBoolean(
  migrationRecordsWithNumericValue: UserMigrationResult[]
): UserMigrationResult[] {
  return migrationRecordsWithNumericValue
    .map(convertTinyIntegerToBoolean)
    .filter((value) => Boolean(value)) as UserMigrationResult[];
}

export function convertTinyIntegerToBoolean(
  migrationRecord?: UserMigrationResult
): UserMigrationResult | null {
  // mysql returns booleans as tinyints; we usually converted this with objection
  // but here we used knex directly so its up to us.
  if (migrationRecord) {
    migrationRecord.isEnabled = Boolean(migrationRecord.isEnabled);
  }
  return migrationRecord || null;
}
