import { Model } from 'objection';
import path from 'path';
import BaseModel from './baseModel';
import {
  BATCH_SIZE,
  UserDataImportRowWithMappings,
  UserDataImportRowMapping,
} from './types';
import { printSqlIfDebugFlagEnabled } from '../lib/clients/knex';

export class UserDataImportRowMappingEntity
  extends BaseModel
  implements UserDataImportRowMapping
{
  dataImportRowId!: number;
  dataImportFileId!: number;
  userNumber!: string;
  organizationId?: number | null;
  organizationIdentifier?: string | null;
  productType?: string | null;

  static tableName = 'user_data_import_row_mappings';

  static async importRowMappings(
    dataImportFileId: number,
    rowsAndMappings: UserDataImportRowWithMappings[]
  ): Promise<void> {
    const knex = UserDataImportRowMappingEntity.knex();

    const mappings = rowsAndMappings.flatMap((dataRow) => dataRow.mappings);
    await knex.batchInsert(
      UserDataImportRowMappingEntity.tableName,
      mappings,
      BATCH_SIZE
    );

    const query = knex.raw(`
      UPDATE user_data_import_row_mappings 
      INNER JOIN user_data_import_rows 
      ON user_data_import_rows.user_number = user_data_import_row_mappings.user_number
      AND user_data_import_rows.data_import_file_id = user_data_import_row_mappings.data_import_file_id
      SET user_data_import_row_mappings.data_import_row_id = user_data_import_rows.id
      WHERE user_data_import_row_mappings.data_import_file_id = ${dataImportFileId} 
    `);
    printSqlIfDebugFlagEnabled(query);
    await query;
  }
}
