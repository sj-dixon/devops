import { UserOrganizationEntity } from './userOrganizationEntity';
import { NULL_PLACEHOLDER_VALUE, UserAccountEntity } from './userAccountEntity';
import { Knex } from 'knex';
import { printSqlIfDebugFlagEnabled } from '../lib/clients/knex';
import {
  EmployeeDataImportResult,
  EmployeeImportIntermediate,
  UserAccountImportIntermediate,
} from '../types/importIntermediates';

export async function getImportedUsersAndEmployees(
  dataImportFileId: number
): Promise<EmployeeDataImportResult[]> {
  const knex: Knex = UserOrganizationEntity.knex();
  const queryBuilder: Knex.QueryBuilder = knex
    .select(
      'user_organizations.id as employee_id',
      'user_organizations.id as alcumus_user_id',
      'user_organizations.organization_id',
      'users.id as user_id',
      'user_accounts.id as user_account_id',
      'user_accounts.email',
      'user_accounts.username'
    )
    .from('users')
    .leftOuterJoin('user_organizations', function (this: Knex.JoinClause) {
      this.on('users.id', '=', 'user_organizations.user_id').andOnVal(
        'user_organizations.data_import_file_id',
        dataImportFileId
      );
    })
    .innerJoin('user_accounts', function (this: Knex.JoinClause) {
      this.on('user_accounts.user_id', '=', 'users.id')
        .andOnVal('user_accounts.data_import_file_id', dataImportFileId)
        .andOn(function (this: Knex.JoinClause) {
          this.on(
            'user_accounts.scoped_to_organization_id',
            '=',
            'user_organizations.organization_id'
          ).orOnVal(
            'user_accounts.scoped_to_organization_id',
            NULL_PLACEHOLDER_VALUE
          );
        });
    })
    .where('users.data_import_file_id', '=', dataImportFileId);
  printSqlIfDebugFlagEnabled(queryBuilder);
  const results = await queryBuilder;
  return results as EmployeeDataImportResult[];
}

export async function getImportedAccounts(
  dataImportFileId: number
): Promise<UserAccountImportIntermediate[]> {
  const knex: Knex = UserAccountEntity.knex();
  const queryBuilder: Knex.QueryBuilder = knex
    .select(
      'users.id as user_id',
      'users.first_name',
      'users.last_name',
      'user_accounts.id as user_account_id',
      'user_accounts.auth_provider_name',
      'user_accounts.user_account_type',
      'user_accounts.email',
      'user_accounts.username',
      'user_accounts.is_enabled'
    )
    .from('users')
    .innerJoin('user_accounts', function (this: Knex.JoinClause) {
      this.on('user_accounts.user_id', '=', 'users.id').andOn(
        'user_accounts.data_import_file_id',
        '=',
        'users.data_import_file_id'
      );
    })
    .where('users.data_import_file_id', '=', dataImportFileId);
  printSqlIfDebugFlagEnabled(queryBuilder);
  return (await queryBuilder) as UserAccountImportIntermediate[];
}

export async function getImportedEmployees(
  dataImportFileId: number
): Promise<EmployeeImportIntermediate[]> {
  const knex: Knex = UserOrganizationEntity.knex();
  const queryBuilder: Knex.QueryBuilder = knex
    .select(
      'user_organizations.id as employee_id',
      'user_organizations.id as alcumus_user_id',
      'user_organizations.organization_id',
      'user_organizations.is_enabled',
      'users.id as user_id',
      'users.first_name',
      'users.last_name'
    )
    .from('users')
    .leftOuterJoin('user_organizations', function (this: Knex.JoinClause) {
      this.on('users.id', '=', 'user_organizations.user_id').andOn(
        'user_organizations.data_import_file_id',
        '=',
        'users.data_import_file_id'
      );
    })
    .where('users.data_import_file_id', '=', dataImportFileId);
  printSqlIfDebugFlagEnabled(queryBuilder);
  const results = await queryBuilder;
  return results as EmployeeImportIntermediate[];
}
