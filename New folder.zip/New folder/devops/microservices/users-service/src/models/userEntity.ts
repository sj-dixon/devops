import {
  JsonSchemaBuilder,
  SoftDeletableKnexEntity,
} from '@alcumus/objection-lib';
import { Transaction, PartialModelObject } from 'objection';
import BaseModel from './baseModel';
import { User } from '../types';

export class UserEntity
  extends BaseModel
  implements SoftDeletableKnexEntity, User
{
  deletedAt?: string;

  firstName!: string;
  lastName!: string;
  dataImportRowId?: number;
  dataImportFileId?: number;

  static tableName = 'users';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withField({
      fieldName: 'deletedAt',
      fieldType: 'datetime',
      required: false,
    })
    .withStringField('firstName')
    .withStringField('lastName')
    .withIntegerField('dataImportRowId', false)
    .withIntegerField('dataImportFileId', false)
    .build();

  static async create(profile: User, trx?: Transaction): Promise<UserEntity> {
    return UserEntity.query(trx).insertAndFetch(profile);
  }

  static async findByUserId(userId: number): Promise<UserEntity> {
    return UserEntity.query().findById(userId);
  }

  static async findByAlcumusUserId(
    alcumusUserId: number
  ): Promise<UserEntity | null> {
    const result = await UserEntity.query()
      .select('users.*')
      .innerJoin('user_organizations', 'users.id', 'user_organizations.user_id')
      .findOne({
        'user_organizations.id': alcumusUserId,
      });
    return result || null;
  }

  static async findByInternalAccountId(
    internalAccountId?: string
  ): Promise<UserEntity | null> {
    if (!internalAccountId) {
      return null;
    }
    return UserEntity.query()
      .select('users.*')
      .innerJoin('user_accounts', 'users.id', 'user_accounts.user_id')
      .findOne({ 'user_accounts.internal_account_id': internalAccountId });
  }

  static async patch(
    userId: number,
    mutation: PartialModelObject<UserEntity>,
    trx?: Transaction
  ): Promise<number> {
    return UserEntity.query(trx).findById(userId).patch(mutation);
  }
}
