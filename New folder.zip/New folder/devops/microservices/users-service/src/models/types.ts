export enum UserDataImportRowStatus {
  LOADED = 'LOADED',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR',
}

// todo add auth provider name to row entity
export interface UserDataImportRowMapping {
  userNumber: string;
  dataImportFileId: number;
  organizationId?: number | null;
  organizationIdentifier?: string | null;
  productType?: string | null;
}

export interface UserDataImportRow {
  dataImportFileId: number;
  firstName?: string;
  lastName?: string;
  email?: string;
  username?: string;
  userNumber: string;
  rowStatus: UserDataImportRowStatus;
  // if using bulk insertion, use a mysql-formatted date string for createdAt.
  createdAt: Date | string;
}

export interface UserDataImportRowWithMappings {
  dataRow: UserDataImportRow;
  mappings: UserDataImportRowMapping[];
}

export const BATCH_SIZE = 500;
