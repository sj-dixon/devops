import {
  getMySqlCurrentTimestamp,
  JsonSchemaBuilder,
  SoftDeletableKnexEntity,
} from '@alcumus/objection-lib';
import { Transaction, Model } from 'objection';
import { OrgUserMapping } from '../types';
import { getOrganizationsByUserIdAndKeycloakId } from './userOrganizationQuerier';

export class UserOrganizationEntity
  extends Model
  implements SoftDeletableKnexEntity, OrgUserMapping
{
  id!: number;
  createdAt!: string;
  modifiedAt!: string;
  deletedAt?: Date;

  dataImportRowId?: number;
  dataImportFileId?: number;
  invitationCode?: string;
  organizationId!: number;
  userId!: number;
  isEnabled!: boolean;

  static tableName = 'user_organizations';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withIntegerField('id')
    .withStringField('invitationCode', false)
    .withTimestampField('createdAt', true)
    .withTimestampField('modifiedAt', true)
    .withTimestampField('deletedAt', false)
    .withIntegerField('organizationId', true)
    .withIntegerField('userId', true)
    .withIntegerField('dataImportRowId', false)
    .withIntegerField('dataImportFileId', false)
    .withBooleanField('isEnabled')
    .build();

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeInsert() {
    const now = getMySqlCurrentTimestamp();
    this.createdAt = now;
    this.modifiedAt = now;
  }

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeUpdate() {
    this.modifiedAt = getMySqlCurrentTimestamp();
  }

  // noinspection JSUnusedGlobalSymbols
  $afterFind() {
    this.isEnabled = Boolean(this.isEnabled);
  }

  static async create({
    organizationId,
    userId,
    isEnabled,
    invitationCode,
    dataImportFileId,
    dataImportRowId,
    trx,
  }: {
    organizationId: number;
    userId: number;
    isEnabled?: boolean;
    invitationCode?: string;
    dataImportFileId?: number;
    dataImportRowId?: number;
    trx?: Transaction;
  }): Promise<UserOrganizationEntity> {
    return UserOrganizationEntity.query(trx).insertAndFetch({
      organizationId,
      invitationCode,
      userId,
      isEnabled,
      dataImportFileId,
      dataImportRowId,
    });
  }

  static async findByUserId(
    userId: number,
    filterByEnabled = true
  ): Promise<UserOrganizationEntity[]> {
    if (filterByEnabled) {
      return UserOrganizationEntity.query().select('*').where({
        userId,
        isEnabled: true,
      });
    } else {
      return UserOrganizationEntity.query().select('*').where({
        userId,
      });
    }
  }

  static async findByUserIdAndOrganizationId(
    userId: number,
    organizationId: number
  ): Promise<UserOrganizationEntity> {
    return UserOrganizationEntity.query().findOne({
      userId,
      organizationId,
    });
  }

  static async findByAlcumusUserId(
    alcumusUserId: number
  ): Promise<UserOrganizationEntity> {
    return UserOrganizationEntity.query().findById(alcumusUserId);
  }

  static async findByOrganizationId(
    organizationId: number,
    offset = 0,
    limit = 10
  ): Promise<Array<UserOrganizationEntity>> {
    return UserOrganizationEntity.query()
      .select('*')
      .where({
        organizationId,
      })
      .offset(offset)
      .limit(limit);
  }

  static async setEnabledByAlcumusUserId(
    alcumusUserId: number,
    isEnabled: boolean | undefined
  ): Promise<void> {
    if (isEnabled !== undefined) {
      await UserOrganizationEntity.query()
        .where({ id: alcumusUserId })
        .patch({ isEnabled });
    }
  }

  static async findByInternalAccountId(
    internalAccountId: string
  ): Promise<UserOrganizationEntity[]> {
    // this method is login-sensitive so it is not enough to get the
    // user organizations by user id.  If a user is logged in with a
    // org-specific account, their login would have a subset of their
    // overall organizations.  This prevents espionage of other orgs
    // by company admins.
    const intermediates = await getOrganizationsByUserIdAndKeycloakId(
      internalAccountId
    );
    const alcumusUserIds = intermediates
      .filter((x) => x.isEnabled)
      .map((x) => x.alcumusUserId);
    return UserOrganizationEntity.query().whereIn('id', alcumusUserIds);
  }

  static async findByInternalAccountIdAndOrganizationId(
    internalAccountId: string,
    organizationId: number
  ): Promise<UserOrganizationEntity | null> {
    const all = await UserOrganizationEntity.findByInternalAccountId(
      internalAccountId
    );
    return all.find((x) => x.organizationId === organizationId) || null;
  }
}
