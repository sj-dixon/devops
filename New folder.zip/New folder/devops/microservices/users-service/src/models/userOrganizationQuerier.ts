import { printSqlIfDebugFlagEnabled } from '../lib/clients/knex';
import { convertTinyIntegersToBoolean } from './migrationAccounts';
import { Knex } from 'knex';
import { UserOrganizationEntity } from './userOrganizationEntity';
import { NULL_PLACEHOLDER_VALUE } from './userAccountEntity';

export interface UserOrganizationIntermediate {
  alcumusUserId: number;
  userId: number;
  organizationId: number;
  isEnabled: boolean;
}

export async function getOrganizationsByUserIdAndKeycloakId(
  internalAccountId: string
): Promise<UserOrganizationIntermediate[]> {
  const knex: Knex = UserOrganizationEntity.knex();
  const queryBuilder = knex
    .select(
      'user_organizations.id as alcumus_user_id',
      'user_organizations.user_id',
      'user_organizations.organization_id',
      knex.raw('(?? && ??) as ??', [
        'user_organizations.is_enabled',
        'user_accounts.is_enabled',
        'is_enabled',
      ])
    )
    .from('user_organizations')
    .innerJoin('user_accounts', function (this: Knex.JoinClause) {
      this.on('user_accounts.user_id', '=', 'user_organizations.user_id').andOn(
        function (this: Knex.JoinClause) {
          this.on(
            'user_accounts.scoped_to_organization_id',
            '=',
            'user_organizations.organization_id'
          ).orOnVal(
            'user_accounts.scoped_to_organization_id',
            NULL_PLACEHOLDER_VALUE
          );
        }
      );
    })
    .where((builder) => {
      builder.where('user_accounts.internal_account_id', internalAccountId);
    });
  printSqlIfDebugFlagEnabled(queryBuilder);
  const rawResults = await queryBuilder;
  return convertTinyIntegersToBoolean(rawResults);
}
