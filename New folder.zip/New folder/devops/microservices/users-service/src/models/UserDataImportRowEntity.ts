import BaseModel from './baseModel';
import { Knex } from 'knex';
import { printSqlIfDebugFlagEnabled } from '../lib/clients/knex';
import { UserAccountType } from '../types/userAccount';
import { UserDataImportRowMappingEntity } from './UserDataImportRowMappingEntity';
import {
  BATCH_SIZE,
  UserDataImportRow,
  UserDataImportRowStatus,
  UserDataImportRowWithMappings,
} from './types';

export class UserDataImportRowEntity
  extends BaseModel
  implements UserDataImportRow
{
  dataImportFileId!: number;
  userNumber!: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  username?: string;
  rowStatus!: UserDataImportRowStatus;

  public static tableName = 'user_data_import_rows';

  static async importRows(dataRows: UserDataImportRow[]): Promise<void> {
    const knex = UserDataImportRowEntity.knex();
    await knex.batchInsert(
      UserDataImportRowEntity.tableName,
      dataRows,
      BATCH_SIZE
    );
  }

  static async importRowsWithMappings(
    dataRowsAndMappings: UserDataImportRowWithMappings[],
    dataImportFileId: number
  ): Promise<void> {
    const dataRows = dataRowsAndMappings.map((entry) => entry.dataRow);
    await UserDataImportRowEntity.importRows(dataRows);
    await UserDataImportRowMappingEntity.importRowMappings(
      dataImportFileId,
      dataRowsAndMappings
    );
  }

  static async importUsers(dataImportFileId: number): Promise<void> {
    const knex = UserDataImportRowEntity.knex();
    const tableName = knex.raw('?? (??, ??, ??, ??, ??, ??) ', [
      'users',
      'first_name',
      'last_name',
      'data_import_row_id',
      'data_import_file_id',
      'created_at',
      'modified_at',
    ]);
    const query = knex
      .from(tableName)
      .insert(function (this: Knex.QueryBuilder) {
        this.from('user_data_import_rows')
          .where('data_import_file_id', knex.raw(dataImportFileId))
          .select(
            'first_name',
            'last_name',
            'id as data_import_row_id',
            'data_import_file_id',
            'created_at',
            'modified_at'
          );
      });

    printSqlIfDebugFlagEnabled(query);
    await query;
  }

  static async importUserAccounts(
    dataImportFileId: number,
    organizationId: number | null,
    userAccountType: UserAccountType
  ): Promise<void> {
    // 3 cases:
    // 1 - importing organization accounts for single-company import => use organizationId argument
    // 2 - importing organization accounts for multi-company import => use organization id from row - not supported yet.
    // 3 - importing personal accounts => use 0 as the organization id. 0 is a placeholder value for null, since null evades unique constraint.
    const organizationIdToUse =
      userAccountType === UserAccountType.ORGANIZATION_ACCOUNT
        ? organizationId
        : 0;
    if (
      organizationIdToUse === 0 &&
      userAccountType === UserAccountType.ORGANIZATION_ACCOUNT
    ) {
      throw new Error(
        'Organization accounts not yet supported on multi-company bulk import'
      );
    }

    const knex = UserDataImportRowEntity.knex();
    const tableName = knex.raw('?? (??, ??, ??, ??, ??, ??, ??, ??, ??, ??) ', [
      'user_accounts',
      'email',
      'username',
      'data_import_row_id',
      'data_import_file_id',
      'user_id',
      'scoped_to_organization_id',
      'user_account_type',
      'auth_provider_name',
      'created_at',
      'modified_at',
    ]);
    const query = knex
      .from(tableName)
      .insert(function (this: Knex.QueryBuilder) {
        this.select(
          'user_data_import_rows.email',
          'user_data_import_rows.username',
          'user_data_import_rows.id as data_import_row_id',
          'user_data_import_rows.data_import_file_id',
          'users.id as user_id',
          knex.raw('? as ??', [
            organizationIdToUse,
            'scoped_to_organization_id',
          ]),
          knex.raw('? as ??', [userAccountType, 'user_account_type']),
          'user_data_import_files.auth_provider_name',
          'user_data_import_rows.created_at',
          'user_data_import_rows.modified_at'
        )
          .from('user_data_import_rows')
          .innerJoin(
            'users',
            'users.data_import_row_id',
            '=',
            'user_data_import_rows.id'
          )
          .innerJoin(
            'user_data_import_files',
            'user_data_import_files.id',
            '=',
            'user_data_import_rows.data_import_file_id'
          )
          .where(
            'user_data_import_rows.data_import_file_id',
            '=',
            dataImportFileId
          );
      })
      .onConflict(['email', 'username'])
      .ignore();

    printSqlIfDebugFlagEnabled(query);
    await query;
  }

  static async importUserOrganizations(
    dataImportFileId: number,
    organizationId?: number
  ): Promise<void> {
    const knex = UserDataImportRowEntity.knex();
    const tableName = knex.raw('?? (??, ??, ??, ??, ??, ??) ', [
      'user_organizations',
      'user_id',
      'organization_id',
      'data_import_row_id',
      'data_import_file_id',
      'created_at',
      'modified_at',
    ]);

    const query = knex
      .from(tableName)
      .insert(function (this: Knex.QueryBuilder) {
        this.select(
          'users.id as user_id',
          organizationId
            ? knex.raw('? as ??', [organizationId, 'organization_id'])
            : 'user_data_import_row_mappings.organization_id',
          'user_data_import_rows.id as data_import_row_id',
          'user_data_import_rows.data_import_file_id',
          'user_data_import_rows.created_at',
          'user_data_import_rows.modified_at'
        )
          .from('user_data_import_rows')
          .innerJoin(
            'users',
            'users.data_import_row_id',
            '=',
            'user_data_import_rows.id'
          );
        if (!organizationId) {
          this.innerJoin(
            'user_data_import_row_mappings',
            function (this: Knex.JoinClause) {
              this.on(
                'user_data_import_row_mappings.data_import_row_id',
                '=',
                'user_data_import_rows.id'
              )
                .andOn(
                  'user_data_import_row_mappings.data_import_file_id',
                  '=',
                  'user_data_import_rows.data_import_file_id'
                )
                .andOnNotNull('user_data_import_row_mappings.organization_id');
            }
          );
        }
        this.where(
          'user_data_import_rows.data_import_file_id',
          '=',
          dataImportFileId
        );
      });

    printSqlIfDebugFlagEnabled(query);
    await query;
  }
}
