import {
  BaseKnexEntityModel,
  JsonSchemaBuilder,
  SoftDeletableKnexEntity,
} from '@alcumus/objection-lib';
import { Transaction } from 'objection';
import { UpdateAccountRequest } from '../types';
import { UserAccount, UserAccountType } from '../types/userAccount';
import { OrganizationAuthProviderType } from '../lib/tenants/types';

export const NULL_PLACEHOLDER_VALUE = 0;

export class UserAccountEntity
  extends BaseKnexEntityModel
  implements SoftDeletableKnexEntity, UserAccount
{
  deletedAt?: Date | null;
  isEnabled!: boolean;
  requiresPasswordReset!: boolean;

  userAccountType!: UserAccountType;
  authProviderName!: OrganizationAuthProviderType | string;
  userId!: number;
  scopedToOrganizationId?: number | null;
  dataImportRowId?: number | null;
  dataImportFileId?: number | null;

  internalAccountId?: string | null;
  email?: string | null;
  username?: string | null;
  phoneNumber?: string | null;

  static tableName = 'user_accounts';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withField({
      fieldName: 'deletedAt',
      fieldType: 'datetime',
      required: false,
    })
    .withStringField('userAccountType', true)
    .withStringField('authProviderName', true)
    .withStringField('internalAccountId', false)
    .withIntegerField('userId', true)
    .withIntegerField('scopedToOrganizationId', false)
    .withIntegerField('dataImportRowId', false)
    .withIntegerField('dataImportFileId', false)
    .withStringField('username')
    .withStringField('email')
    .withStringField('phoneNumber', false)
    .withBooleanField('isEnabled')
    .withBooleanField('requiresPasswordReset')
    .build();

  $beforeInsert() {
    super.$beforeInsert();
    if (this.scopedToOrganizationId === null) {
      this.scopedToOrganizationId = NULL_PLACEHOLDER_VALUE;
    }
  }

  // noinspection JSUnusedGlobalSymbols
  $afterFind() {
    this.isEnabled = Boolean(this.isEnabled);
    this.requiresPasswordReset = Boolean(this.requiresPasswordReset);

    // in mysql, unique constraints between two columns where one column is null
    // are not respected.  Null !== Null.
    if (this.scopedToOrganizationId === NULL_PLACEHOLDER_VALUE) {
      this.scopedToOrganizationId = null;
    }
  }

  static async updateLoginIdentifier(
    oldCredential: UserAccountEntity,
    newCredential: UpdateAccountRequest
  ): Promise<void> {
    if (
      !newCredential.email &&
      !newCredential.username &&
      newCredential.isEnabled === undefined &&
      !newCredential.internalAccountId
    ) {
      return;
    }
    if (
      newCredential.email === oldCredential.email &&
      newCredential.username === oldCredential.username &&
      newCredential.isEnabled === oldCredential.isEnabled &&
      newCredential.internalAccountId === oldCredential.internalAccountId
    ) {
      return;
    }
    await UserAccountEntity.query()
      .patch({
        username: newCredential.username,
        email: newCredential.email,
        isEnabled: newCredential.isEnabled,
        internalAccountId: newCredential.internalAccountId,
      })
      .findById(oldCredential.id);
  }

  static async find(accountId: number): Promise<UserAccountEntity | null> {
    const account = await UserAccountEntity.query().findById(accountId);
    return account || null;
  }

  /**
   * @deprecated - this method is unreliable if you have multiple accounts.
   * @param userId
   */
  // todo this should return an array.
  static async findOneByUserId(
    userId: number
  ): Promise<UserAccountEntity | null> {
    const account = await UserAccountEntity.query().findOne({
      userId,
    });
    return account || null;
  }

  static async findAllByUserId(userId: number): Promise<UserAccountEntity[]> {
    return UserAccountEntity.query().where({
      userId,
    });
  }

  static async findByLoginIdentifiers(
    loginIdentifier: string,
    organizationId?: number
  ): Promise<UserAccountEntity | null> {
    const account = await UserAccountEntity.query()
      .findOne({
        scopedToOrganizationId: organizationId || 0,
      })
      .where((builder) => {
        builder
          .where('email', '=', loginIdentifier)
          .orWhere('username', '=', loginIdentifier);
      });

    return account || null;
  }

  static async findByInternalAccountId(
    internalAccountId: string
  ): Promise<UserAccountEntity | null> {
    const account = await UserAccountEntity.query().findOne({
      internalAccountId,
    });
    return account || null;
  }

  static async findByUserAndAccountId(
    userId: number,
    accountId?: number
  ): Promise<UserAccountEntity | null> {
    const account = await UserAccountEntity.query().findOne({
      userId: userId,
      id: accountId,
    });
    return account || null;
  }

  static async create(
    trx: Transaction,
    credentials: UserAccount
  ): Promise<UserAccountEntity> {
    return UserAccountEntity.query(trx).insertAndFetch(credentials);
  }

  static async patch(
    userAccountId: number,
    account: Partial<UserAccount>,
    transaction?: Transaction
  ): Promise<UserAccountEntity> {
    if (account.scopedToOrganizationId === null) {
      account.scopedToOrganizationId = NULL_PLACEHOLDER_VALUE;
    }
    return UserAccountEntity.query(transaction).patchAndFetchById(
      userAccountId,
      account
    );
  }
}
