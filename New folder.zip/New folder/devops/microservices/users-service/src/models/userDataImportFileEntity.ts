import { BaseKnexEntityModel } from '@alcumus/objection-lib';
import { UserDataImportFileDetails } from '../types/userMigration';
import { UserAccountType } from '../types/userAccount';

export class UserDataImportFileEntity extends BaseKnexEntityModel {
  organizationId?: number | null;
  numberOfRows!: number;
  filename!: string;
  authProviderName?: string | null;
  userAccountType!: UserAccountType;

  static tableName = 'user_data_import_files';

  static async create(
    base: UserDataImportFileDetails,
    numberOfRows: number
  ): Promise<UserDataImportFileEntity> {
    return UserDataImportFileEntity.query().insertAndFetch({
      ...base,
      numberOfRows,
    });
  }
}
