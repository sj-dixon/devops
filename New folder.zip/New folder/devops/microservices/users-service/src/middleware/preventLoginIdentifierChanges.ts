import { expressValidator } from '@alcumus/express-app';

export const preventLoginIdentifierChanges = expressValidator
  .body(['username', 'email'], 'users.patch.cannotChangeLoginIdentifier')
  .not()
  .exists();
