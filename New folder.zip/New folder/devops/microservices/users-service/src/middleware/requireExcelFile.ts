import { NextFunction, Response } from 'express';
import { Types } from '@alcumus/globals';

export function requireExcelFile(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const files = request.files as Types.File[];
  if (!files || !files.length) {
    response.status(400).json({ message: 'Please upload a file' });
    return;
  }

  const [excel] = files;
  if (
    !excel.mimetype.includes('spreadsheet') &&
    !excel.mimetype.includes('excel')
  ) {
    response.status(400).json({ message: 'Please upload an excel file' });
    return;
  }

  next();
}
