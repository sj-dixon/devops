import { NextFunction, Response } from 'express';
import { Types, Utilities } from '@alcumus/globals';
import { getAuthProvider } from '../lib/tenants';
import { getAccountType } from '../lib/utils/getAccountTypeFromQuery';
import { UserAccountType } from '../types/userAccount';

export async function requireApiClientAppHasAuthProvider(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const organizationId = Number(request.params.organizationId);
  const requestedAccountType = getAccountType(
    request.query.userAccountType as string | undefined
  );
  const requestingAppName = request.requestedBy
    ?.requestedByApplication as string;

  const axiosInstance = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'tenants'
  );

  const authProvider = await getAuthProvider({
    organizationId:
      requestedAccountType === UserAccountType.ORGANIZATION_ACCOUNT
        ? organizationId
        : null,
    authProviderName: requestingAppName,
    axiosInstance,
  });
  if (!authProvider) {
    response.status(400).json({
      message: `Organization ${organizationId} does not have an auth provider with name "${requestingAppName}" that can be used to migrate passwords`,
    });
  } else {
    next();
  }
}
