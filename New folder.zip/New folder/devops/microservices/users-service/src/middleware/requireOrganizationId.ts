import { expressValidator } from '@alcumus/express-app';

// todo validate that the organization id actually belongs to an organization
export const requireOrganizationId = expressValidator
  .body('organizationId', 'users.provision.requireOrganizationId')
  .exists()
  .bail();
