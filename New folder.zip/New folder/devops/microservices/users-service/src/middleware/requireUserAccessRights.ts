import { Types } from '@alcumus/globals';
import { NextFunction, Response } from 'express';
import { UserAccountEntity } from '../models/userAccountEntity';
import { UserOrganizationEntity } from '../models/userOrganizationEntity';
import { UserAccountType } from '../types/userAccount';

export async function requireUserAccessRights(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const requestedBy = request.userInfo?.internalAccountId;
  if (!requestedBy) {
    response.status(403).json({
      message: 'Authentication header was accepted but does not specify a user',
    });
    return;
  }

  const requestedByAccount = await UserAccountEntity.findByInternalAccountId(
    requestedBy
  );

  if (!requestedByAccount) {
    response.status(403).send({
      message:
        "Authentication header was accepted but the server doesn't know any users matching the token.",
    });
    return;
  }

  const userId = Number(request.params.userId);
  const accountId = Number(request.params.accountId);

  if (Number.isNaN(accountId) && userId !== requestedByAccount.userId) {
    response.status(403).send({
      message:
        "Account id must be specified if modifying another user's account",
    });
    return;
  }

  const userAccount = accountId
    ? await UserAccountEntity.findByUserAndAccountId(userId, accountId)
    : requestedByAccount;

  if (!userAccount) {
    response.sendStatus(404);
    return;
  }

  if (
    userAccount.internalAccountId &&
    userAccount.internalAccountId === requestedBy
  ) {
    next();
    return;
  }

  if (userAccount.userAccountType === UserAccountType.PERSONAL_ACCOUNT) {
    // user is trying to modify a different user's personal account.
    response.sendStatus(403);
    return;
  }

  if (userAccount.userAccountType === UserAccountType.ORGANIZATION_ACCOUNT) {
    const requestedByOrganization =
      await UserOrganizationEntity.findByInternalAccountIdAndOrganizationId(
        requestedBy,
        userAccount.scopedToOrganizationId as number
      );
    if (!requestedByOrganization) {
      // user is trying to modify a user account belonging to a different organization
      response.sendStatus(403);
      return;
    }
  }

  next();
}
