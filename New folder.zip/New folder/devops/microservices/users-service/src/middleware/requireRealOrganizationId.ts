import { Types } from '@alcumus/globals';
import { NextFunction, Response } from 'express';
import { getOrganizationById } from '../lib/tenants';

export async function requireRealOrganizationId(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const organizationId = Number(request.params.organizationId);
  if (!organizationId || Number.isNaN(organizationId)) {
    response.sendStatus(400);
    return;
  }

  const organization = await getOrganizationById(organizationId);
  if (!organization) {
    response
      .status(404)
      .json({ message: `Organization ${organizationId} not found` });
  } else {
    next();
  }
}
