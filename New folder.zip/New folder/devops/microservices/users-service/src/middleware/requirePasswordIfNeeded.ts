import { expressValidator } from '@alcumus/express-app';
import PasswordValidator from 'password-validator';

export const PASSWORD_POLICY = new PasswordValidator();
PASSWORD_POLICY.is().min(8);
PASSWORD_POLICY.is().max(50);
PASSWORD_POLICY.has().uppercase();
PASSWORD_POLICY.has().lowercase();
PASSWORD_POLICY.has().digits();
PASSWORD_POLICY.has().not().spaces();
PASSWORD_POLICY.has().symbols();

const isCreatingAccounts: expressValidator.CustomValidator = (value, { req }) =>
  req.body.createAccount;

const hasNewPassword: expressValidator.CustomValidator = (value, { req }) =>
  req.body.newPassword;

export const requirePasswordIfNeeded = expressValidator
  .body('password', 'users.new.mustSpecifyPasswordWhenCreatingAccounts')
  .if(isCreatingAccounts)
  .exists()
  .bail();

export const requireStrongPasswordIfNeeded = expressValidator
  .body('password', 'users.password.strongPasswordRequired')
  .if(isCreatingAccounts)
  .custom((value) => PASSWORD_POLICY.validate(value));

export const requireOldPasswordIfChanging = expressValidator
  .body('oldPassword', 'users.patch.oldPasswordRequiredWhenChangingPassword')
  .if(hasNewPassword)
  .exists()
  .bail();

export const requireStrongPasswordIfChanging = expressValidator
  .body('newPassword', 'users.password.strongPasswordRequired')
  .if(hasNewPassword)
  .custom((value) => PASSWORD_POLICY.validate(value));

export const requireDifferentPasswordsIfChanging = expressValidator
  .body('newPassword', 'users.password.requireDifferentPasswords')
  .if(hasNewPassword)
  .custom((value, { req }) => value !== req.body.oldPassword);
