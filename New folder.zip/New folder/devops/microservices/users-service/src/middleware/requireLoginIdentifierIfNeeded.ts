import { expressValidator } from '@alcumus/express-app';
import { Request, Response, NextFunction } from 'express';
import { isNullOrWhitespace } from '../lib/utils';

export const requireLoginIdentifierIfNeeded = async (
  request: Request,
  response: Response,
  next: NextFunction
) => {
  // todo can await next() be simplified to next()?
  if (!request.body.createAccount) {
    await expressValidator
      .body('email', 'users.new.cannotSpecifyEmailIfNoAccountCreated')
      .custom(isNullOrWhitespace)
      .run(request);
    next();
    return;
  }
  if (
    isNullOrWhitespace(request.body.email) &&
    isNullOrWhitespace(request.body.username)
  ) {
    await expressValidator
      .body(['username', 'email'], 'users.new.mustHaveUserNameOrEmail')
      .exists()
      .custom((value) => !isNullOrWhitespace(value))
      .bail()
      .run(request);
    next();
    return;
  }
  if (isNullOrWhitespace(request.body.email) || request.body.username) {
    await expressValidator
      .body('username', 'users.new.mustHaveUserNameIfEmailNotPresent')
      .exists()
      .custom((value) => !isNullOrWhitespace(value))
      .bail()
      .run(request);
  }
  if (isNullOrWhitespace(request.body.username) || request.body.email) {
    await expressValidator
      .body('email', 'users.new.mustHaveEmailIfUserNameNotPresent')
      .exists()
      .custom((value) => !isNullOrWhitespace(value))
      .isEmail()
      .bail()
      .run(request);
  }
  next();
};
