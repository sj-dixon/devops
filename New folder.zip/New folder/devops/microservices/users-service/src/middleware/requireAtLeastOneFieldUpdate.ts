import { Types } from '@alcumus/globals';
import { Response, NextFunction } from 'express';

export function requireAtLeastOneFieldUpdate(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const obj = request.body;
  const isObjectEmpty =
    obj &&
    Object.keys(obj).length === 0 &&
    Object.getPrototypeOf(obj) === Object.prototype;
  if (isObjectEmpty) {
    response.status(400).send({ message: 'Must update at least one field' });
    return;
  }
  next();
}
