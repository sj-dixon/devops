import { Utilities } from '@alcumus/globals';

export const USER_SERVICE_PORT =
  Number(Utilities.ProcessEnv.getValue('USERS_SERVICE_PORT')) || 8012;

const BASE_PATH_V1 = '/api/v1';

export const ENDPOINTS = {
  USERS: `${BASE_PATH_V1}/users`,
  ME: `${BASE_PATH_V1}/me`,
  MY_ACCOUNT: `${BASE_PATH_V1}/me/accounts`,
  MY_ORGANIZATIONS: `${BASE_PATH_V1}/me/organizations`,
  MIGRATE_TENANT: `${BASE_PATH_V1}/migrate/organizations`,
  MIGRATE_USER: `${BASE_PATH_V1}/migrate/users`,
  MIGRATE_USERS_BATCH: `${BASE_PATH_V1}/migrate/users/batch`,
  MIGRATE_AUTH: `${BASE_PATH_V1}/migrate/auth`,
  ACCOUNTS: `${BASE_PATH_V1}/accounts`,
  EMPLOYEES: `${BASE_PATH_V1}/employees`,
  IMPORTS: `${BASE_PATH_V1}/imports`,
};
