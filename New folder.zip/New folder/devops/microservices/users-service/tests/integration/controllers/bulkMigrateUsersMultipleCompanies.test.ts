import { UserMigrationResult } from '../../../src/types/userMigration';
import { ENVIRONMENT, generateRandomNumber } from '../routes/testHelpers';
import { bulkMigrateIntermediatesMultipleCompanies } from '../../../src/controllers/bulkUpload/bulkMigrateUsersMultipleCompanies';
import { getDataImportMigrationAccounts } from '../../../src/models/migrationAccounts';
import knexConfig from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities, Types } from '@alcumus/globals';
import { UserAccountType } from '../../../src/types/userAccount';
import { v4 as uuidV4 } from 'uuid';
import {
  BatchResult,
  RawUserDataRowWithOrganization,
} from '../../../src/lib/bulkUpload/types';
import { parseRawRowsDoNotDeduplicate } from '../../../src/lib/bulkUpload/parsers';
import { getOrGenerateUserNumbersByEmail } from '../../../src/lib/bulkUpload/aggregators';
import { EmployeeDataImportResult } from '../../../src/types/importIntermediates';
import 'jest-extended';

const AUTH_PROVIDER_NAME = 'UNKNOWN2';
let knex: Knex;

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('Controllers/bulkMigrateUsersMultipleCompanies', () => {
  let organizationId: number;
  let cacheGetter: jest.Mock;
  let cache: Types.LookupCache<string, number | null>;

  beforeEach(() => {
    organizationId = generateRandomNumber();
    cacheGetter = jest.fn();
    cache = new Types.LookupCache<string, number | null>(cacheGetter);
  });

  function runImport(
    rawRows: RawUserDataRowWithOrganization[]
  ): Promise<BatchResult> {
    return bulkMigrateUsersMultipleCompanies({
      filename: 'whatever',
      rawRows,
      authProviderName: AUTH_PROVIDER_NAME,
      cache,
      needVerboseResponse: true,
    });
  }

  describe('Creates personal accounts', () => {
    it('Can create one user in an organization', async () => {
      const raw = getRawRow({ organizationId });
      const batchResult = await runImport([raw]);

      const expectedAccount: UserMigrationResult = getExpectedMigrationAccount(
        raw,
        organizationId
      );
      await assertMigrationAndBatchResultsAreConsistent(
        [raw],
        [expectedAccount],
        batchResult
      );
    });

    it('creates one user using organization identifier', async () => {
      const organizationIdentifier = uuidV4();
      cacheGetter.mockResolvedValue(organizationId);
      const raw = getRawRow({ organizationIdentifier });

      const expectedAccount: UserMigrationResult = getExpectedMigrationAccount(
        raw,
        organizationId
      );
      const batchResult = await runImport([raw]);
      await assertMigrationAndBatchResultsAreConsistent(
        [raw],
        [expectedAccount],
        batchResult
      );
    });

    it('creates one user in two separate organizations', async () => {
      const organizationId2 = generateRandomNumber();
      const username = uuidV4();
      const email = `${username}@example.com`;
      const raws = [
        getRawRow({ organizationId, username, email }),
        getRawRow({ organizationId: organizationId2, username, email }),
      ];

      const expected = [
        getExpectedMigrationAccount(raws[0], organizationId),
        getExpectedMigrationAccount(raws[1], organizationId2),
      ];

      const batchResult = await runImport(raws);
      const moreResults = await assertMigrationAndBatchResultsAreConsistent(
        raws,
        expected,
        batchResult
      );

      // assert only 1 user exists.
      assertArraysHaveEqualMembers(
        [moreResults[0]],
        moreResults,
        (result) => result.userId
      );
    });

    it('given email and username, creates one user in zero organizations', async () => {
      const username = uuidV4();
      const raw = getRawRow({ username });
      const batchResult = await runImport([raw]);
      const expected: EmployeeDataImportResult = {
        organizationId: null,
        employeeId: null,
        alcumusUserId: null,
        username,
        email: raw['Email Address'],
        userId: expect.any(Number),
        userAccountId: expect.any(Number),
      };
      expect(batchResult.migrated).toEqual([expected]);
    });

    it('Characterization - given product and organization, creates one user in organizations with no product info', async () => {
      const username = uuidV4();
      const organizationId = generateRandomNumber();
      const productType = uuidV4();
      const raw = getRawRow({ username, organizationId, productType });
      const batchResult = await runImport([raw]);
      const expected: EmployeeDataImportResult = {
        organizationId,
        employeeId: expect.any(Number),
        alcumusUserId: expect.any(Number),
        username,
        email: raw['Email Address'],
        userId: expect.any(Number),
        userAccountId: expect.any(Number),
      };
      expect(batchResult.migrated).toEqual([expected]);
    });
  });
});

function getRawRow({
  organizationIdentifier,
  organizationId,
  username = uuidV4(),
  email = `${uuidV4()}@example.com`,
  productType,
}: {
  organizationId?: number;
  organizationIdentifier?: string;
  username?: string;
  email?: string;
  productType?: string;
}): RawUserDataRowWithOrganization {
  const baseUser = {
    'Organization Id': organizationId,
    'Organization Identifier': organizationIdentifier,
    'User Name': username,
    'Email Address': email,
    'First Name': username,
    'Last Name': 'Last Name',
    ...(productType && { 'Product Type': productType }),
  };

  return baseUser;
}

function getExpectedMigrationAccount(
  raw: RawUserDataRowWithOrganization,
  organizationId: number
): UserMigrationResult {
  return {
    email: raw['Email Address'],
    username: raw['User Name'] as string,
    alcumusUserId: expect.any(Number),
    authProviderName: AUTH_PROVIDER_NAME,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    internalAccountId: null,
    firstName: raw['First Name'],
    lastName: raw['Last Name'],
    organizationId,
    userOrganizationAccountId: expect.any(Number),
    userId: expect.any(Number),
    userOrganizationId: expect.any(Number),
    isEnabled: true,
  };
}

function bulkMigrateUsersMultipleCompanies({
  filename,
  authProviderName,
  rawRows,
  cache,
  needVerboseResponse = false,
  maxRecords = 100,
}: {
  filename: string;
  authProviderName: string;
  rawRows: RawUserDataRowWithOrganization[];
  cache: Types.LookupCache<string, number | null>;
  needVerboseResponse?: boolean;
  maxRecords?: number;
}): Promise<BatchResult> {
  const intermediates = parseRawRowsDoNotDeduplicate(rawRows);

  const userNumbersByEmail: Types.StringDictionary =
    getOrGenerateUserNumbersByEmail(intermediates);

  return bulkMigrateIntermediatesMultipleCompanies({
    filename,
    authProviderName,
    intermediates,
    userNumbersByEmail,
    cache,
    needVerboseResponse,
    maxRecords,
  });
}

async function assertMigrationAndBatchResultsAreConsistent(
  rawRows: RawUserDataRowWithOrganization[],
  expectedAccounts: UserMigrationResult[],
  batchResult: BatchResult
): Promise<UserMigrationResult[]> {
  const expectedMigrated = expectedAccounts.map((account) => ({
    alcumusUserId: account.alcumusUserId,
    email: account.email,
    username: account.username,
    employeeId: account.alcumusUserId,
    userAccountId: account.userOrganizationAccountId,
    organizationId: account.organizationId,
    userId: account.userId,
  }));
  const expectedBatchResult = {
    dataImportFileId: expect.any(Number),
    migrated: expect.toIncludeSameMembers(expectedMigrated),
    rowsAffected: rawRows.length,
    errors: 0,
  };

  const migrationAccounts = await getDataImportMigrationAccounts(
    batchResult.dataImportFileId
  );

  expect(batchResult).toEqual(expectedBatchResult);
  expect(migrationAccounts).toEqual(expect.arrayContaining(expectedAccounts));

  assertArraysHaveEqualMembers(
    batchResult.migrated,
    migrationAccounts,
    (migrated) => migrated.alcumusUserId
  );
  assertArraysHaveEqualMembers(
    batchResult.migrated,
    migrationAccounts,
    (migrated) => migrated.username
  );
  assertArraysHaveEqualMembers(
    batchResult.migrated,
    migrationAccounts,
    (migrated) => migrated.email
  );
  assertArraysHaveEqualMembers(
    expectedAccounts,
    migrationAccounts,
    (migrated) => migrated.organizationId
  );

  return migrationAccounts;
}

function assertArraysHaveEqualMembers<T1, T2, TValue>(
  array1: T1[],
  array2: T2[],
  getter: (t: T2 | T1) => TValue
): void {
  const set1 = new Set(array1.map(getter));
  const set2 = new Set(array2.map(getter));
  expect(set1).toEqual(set2);
}
