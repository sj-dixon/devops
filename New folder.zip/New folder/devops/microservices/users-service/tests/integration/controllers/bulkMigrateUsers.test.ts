import {
  UserMigrationRequest,
  UserMigrationResult,
} from '../../../src/types/userMigration';
import { ENVIRONMENT, generateRandomNumber } from '../routes/testHelpers';
import { bulkMigrateUsers } from '../../../src/controllers/bulkUpload/bulkMigrateUsers';
import { getMigrationAccounts } from '../../../src/models/migrationAccounts';
import knexConfig from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities } from '@alcumus/globals';
import { UserAccountType } from '../../../src/types/userAccount';
import { BatchResult } from '../../../src/lib/bulkUpload/types';
import { EmployeeDataImportResult } from '../../../src/types/importIntermediates';

let knex: Knex;

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

async function invokeBulkMigration(
  users: UserMigrationRequest[],
  organizationId: number,
  userAccountType = UserAccountType.ORGANIZATION_ACCOUNT
): Promise<BatchResult> {
  return bulkMigrateUsers(
    users,
    {
      filename: `bulk.${organizationId}.xlsx`,
      organizationId,
      authProviderName: 'UNKNOWN',
      userAccountType,
    },
    true
  );
}

describe('Controllers/bulkMigrateUsers', () => {
  let organizationId: number;

  beforeEach(() => {
    organizationId = generateRandomNumber();
  });

  describe('bulkMigrateUsers with organization accounts', () => {
    it('Given a user, Should create a user in the database', async () => {
      const users = getMigrationBatch(organizationId, 1);
      const result = await invokeBulkMigration(users, organizationId);
      const actualFromDatabase = await getMigrationAccounts(organizationId);
      expect(result.rowsAffected).toEqual(1);
      assertRowsHaveExpectedValues(users, actualFromDatabase);
      assertBatchResultHasExpectedValues(users, result);
    });

    it('Given 2 users,  Should create a user in the database and return migrated records', async () => {
      const numberOfRows = 2;
      const users = getMigrationBatch(organizationId, numberOfRows);
      const result = await invokeBulkMigration(users, organizationId);
      const actualFromDatabase = await getMigrationAccounts(organizationId);
      expect(result.rowsAffected).toEqual(numberOfRows);
      assertRowsHaveExpectedValues(users, actualFromDatabase);
      assertBatchResultHasExpectedValues(users, result);
    });

    it('Given two organizations with 1 user each, can reuse the same email and username', async () => {
      const username = `collisionTest.${generateRandomNumber()}`;
      const organizationId2 = generateRandomNumber();
      const org1Users = [getCollidingUser(username, organizationId)];
      const org2Users = [getCollidingUser(username, organizationId2)];

      const org1Result = await invokeBulkMigration(org1Users, organizationId);
      const org2Result = await invokeBulkMigration(org2Users, organizationId2);

      const actualOrg1Users = await getMigrationAccounts(organizationId);
      const actualOrg2Users = await getMigrationAccounts(organizationId);

      assertBatchResultHasExpectedValues(org1Users, org1Result);
      assertBatchResultHasExpectedValues(org2Users, org2Result);

      assertRowsHaveExpectedValues(org1Users, actualOrg1Users);
      assertRowsHaveExpectedValues(org2Users, actualOrg2Users);
    });

    it('Same organization does not allow re-registering same username', async () => {
      const username = `collisionTest.${generateRandomNumber()}`;
      const orgUsers = [getCollidingUser(username, organizationId)];

      const firstRunResult = await invokeBulkMigration(
        orgUsers,
        organizationId
      );
      // Running same upload again to attempt duplicate registrations
      const duplicateUploadResult = await invokeBulkMigration(
        orgUsers,
        organizationId
      );

      const actualOrgUsers = await getMigrationAccounts(organizationId);

      firstRunResult.migrated.forEach((user) => {
        expect(user.alcumusUserId).toBeDefined();
        expect(
          actualOrgUsers.map((u) => u.email).includes(user.email)
        ).toBeTruthy();
      });
      expect(firstRunResult.rowsAffected).toEqual(1);
      // Ensure that the duplicate run returned same set of users when attempted to upload duplicates
      duplicateUploadResult.migrated.forEach((user) => {
        const match = firstRunResult.migrated.find(
          (u) => u.email === user.email && u.username === user.username
        );
        expect(match).toBeDefined();
        expect(user.alcumusUserId).toEqual(match?.alcumusUserId);
      });
      assertRowsHaveExpectedValues(orgUsers, actualOrgUsers);
    });

    it('Does not return verbose response when not desired', async () => {
      const numberOfRows = 5;
      const users = getMigrationBatch(organizationId, numberOfRows);
      const result = await bulkMigrateUsers(
        users,
        {
          filename: `bulk.${organizationId}.xlsx`,
          organizationId,
          authProviderName: 'UNKNOWN',
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
        },
        false
      );
      const actualFromDatabase = await getMigrationAccounts(organizationId);
      expect(result.migrated.length).toEqual(0);
      expect(result.rowsAffected).toEqual(numberOfRows);
      assertRowsHaveExpectedValues(users, actualFromDatabase);
    });

    it('Does not return verbose response when number of records exceed threshold', async () => {
      const numberOfRows = 5;
      const threshold = 3;
      const users = getMigrationBatch(organizationId, numberOfRows);
      const result = await bulkMigrateUsers(
        users,
        {
          filename: `bulk.${organizationId}.xlsx`,
          organizationId,
          authProviderName: 'UNKNOWN',
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
        },
        true,
        threshold
      );
      const actualFromDatabase = await getMigrationAccounts(organizationId);
      expect(result.migrated.length).toEqual(0);
      expect(result.rowsAffected).toEqual(numberOfRows);
      assertRowsHaveExpectedValues(users, actualFromDatabase);
    });
  });

  describe('bulkMigrateUsers with individual accounts', () => {
    it('can create personal accounts', async () => {
      const users = getMigrationBatch(organizationId, 1);
      const result = await invokeBulkMigration(
        users,
        organizationId,
        UserAccountType.PERSONAL_ACCOUNT
      );
      const actualFromDatabase = await getMigrationAccounts(organizationId);
      assertBatchResultHasExpectedValues(users, result);
      assertRowsHaveExpectedValues(
        users,
        actualFromDatabase,
        UserAccountType.PERSONAL_ACCOUNT
      );
    });
  });
});

function getMigrationBatch(
  organizationId: number,
  numberOfRows: number
): UserMigrationRequest[] {
  // generate an array of length N populated by the index
  return Array.from(Array(numberOfRows).keys()).map((index) =>
    getMigrationRequest(organizationId, index)
  );
}

function getMigrationRequest(
  runId: number,
  sequenceId: number
): UserMigrationRequest {
  const username = `user.${runId}.${sequenceId}`;
  return {
    organizationId: runId,
    username,
    email: `${username}@bulkmigrateuser.test`,
    firstName: `User${sequenceId}`,
    lastName: `Test${runId}`,
    isEnabled: true,
  };
}

function getCollidingUser(
  username: string,
  organizationId: number
): UserMigrationRequest {
  return {
    organizationId,
    username,
    email: `${username}@collision.com`,
    firstName: `SameDetails`,
    lastName: `AsUserInOtherOrg`,
    isEnabled: true,
  };
}

function assertRowsHaveExpectedValues(
  requests: UserMigrationRequest[],
  actual: UserMigrationResult[],
  expectedAccountType = UserAccountType.ORGANIZATION_ACCOUNT
): void {
  const expectedEmails = new Set(requests.map((item) => item.email));
  const expectedUsernames = new Set(requests.map((item) => item.username));
  const expectedFirstNames = new Set(requests.map((item) => item.firstName));
  const expectedLastNames = new Set(requests.map((item) => item.lastName));

  const actualAlcumusUserIds = new Set(
    actual.map((item) => item.alcumusUserId)
  );
  const actualEmails = new Set(actual.map((item) => item.email));
  const actualUserIds = new Set(actual.map((item) => item.userId));
  const actualUserOrganizationIds = new Set(
    actual.map((item) => item.userOrganizationId)
  );
  const actualAccountIds = new Set(
    actual.map((item) => item.userOrganizationAccountId)
  );
  const actualUsernames = new Set(actual.map((item) => item.username));
  const actualIsEnabled = new Set(actual.map((item) => item.isEnabled));
  const actualFirstNames = new Set(actual.map((item) => item.firstName));
  const actualLastNames = new Set(actual.map((item) => item.lastName));

  const actualAccountTypes = new Set(
    actual.map((item) => item.userAccountType)
  );

  expect(actual).toHaveLength(requests.length);
  expect(actualIsEnabled).toEqual(new Set([true]));
  expect(actualAlcumusUserIds).toEqual(actualUserOrganizationIds);
  expect(actualAlcumusUserIds.size).toEqual(requests.length);
  expect(actualAccountIds.size).toEqual(requests.length);
  expect(actualEmails).toEqual(expectedEmails);
  expect(actualEmails.size).toEqual(requests.length);
  expect(actualUsernames).toEqual(expectedUsernames);
  expect(actualUsernames.size).toEqual(requests.length);
  expect(actualUserIds.size).toEqual(requests.length);
  expect(actualFirstNames).toEqual(expectedFirstNames);
  expect(actualLastNames).toEqual(expectedLastNames);
  expect(actualAccountTypes).toEqual(new Set([expectedAccountType]));
}

function assertBatchResultHasExpectedValues(
  expected: UserMigrationRequest[],
  actual: BatchResult
) {
  const expectedMigrations: EmployeeDataImportResult[] = expected.map(
    (user) => ({
      userId: expect.any(Number),
      employeeId: expect.any(Number),
      email: user.email || null,
      username: user.username || null,
      alcumusUserId: expect.any(Number),
      organizationId: user.organizationId || null,
      userAccountId: expect.any(Number),
    })
  );
  expect(actual.migrated).toEqual(expectedMigrations);
  expect(actual.rowsAffected).toEqual(expected.length);
}
