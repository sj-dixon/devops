import connectToKnex, { Knex } from 'knex';
import knexConfig from '../../../src/lib/clients/knex/config';
import { Model } from 'objection';
import { generateRandomNumber } from '../routes/testHelpers';
import { createUser } from '../routes/migrate/migrationTestHelpers';
import { getImportedUsersAndEmployees } from '../../../src/models/dataImportQuerier';
import { UserDataImportFileEntity } from '../../../src/models/userDataImportFileEntity';
import { UserAccountType } from '../../../src/types/userAccount';
import { OrganizationAuthProviderType } from '../../../src/lib/tenants/types';
import { uuidV4 } from '@alcumus/globals/build/utilities';
import { UserEntity } from '../../../src/models/userEntity';
import { UserAccountEntity } from '../../../src/models/userAccountEntity';
import { EmployeeDataImportResult } from '../../../src/types/importIntermediates';

let knex: Knex;
beforeAll(() => {
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('models/dataImportQuerier', () => {
  describe('getImportedUsersAndEmployees', () => {
    it('can query a basic employee account', async () => {
      const organizationId = generateRandomNumber();
      const dataImportFile = await UserDataImportFileEntity.create(
        {
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
          authProviderName: OrganizationAuthProviderType.AZURE_AD,
          organizationId,
          filename: uuidV4(),
        },
        1
      );
      const dataImportFileId = dataImportFile.id;
      const employeeAccount = await createUser(
        'Donny',
        'Darko',
        organizationId,
        {
          dataImportFileId,
        }
      );
      const actual = await getImportedUsersAndEmployees(dataImportFileId);
      const expected: EmployeeDataImportResult = {
        email: employeeAccount.email,
        username: employeeAccount.username,
        userId: employeeAccount.userId,
        alcumusUserId: employeeAccount.alcumusUserId,
        employeeId: employeeAccount.alcumusUserId,
        userAccountId: employeeAccount.userOrganizationAccountId,
        organizationId: employeeAccount.organizationId,
      };
      expect(actual).toEqual([expected]);
    });

    it('can query a basic user account without organizations', async () => {
      const dataImportFile = await UserDataImportFileEntity.create(
        {
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
          authProviderName: OrganizationAuthProviderType.AZURE_AD,
          organizationId: null,
          filename: uuidV4(),
        },
        1
      );
      const dataImportFileId = dataImportFile.id;
      const user = await UserEntity.create({
        dataImportFileId,
        firstName: 'Henry',
        lastName: 'Sugar',
      });
      const username = uuidV4();
      const account = await UserAccountEntity.create(undefined, {
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
        authProviderName: OrganizationAuthProviderType.AZURE_AD,
        dataImportFileId,
        email: `${username}@example.com`,
        username,
        userId: user.id,
        internalAccountId: uuidV4(),
        isEnabled: true,
        scopedToOrganizationId: null,
        requiresPasswordReset: false,
      });
      const actual = await getImportedUsersAndEmployees(dataImportFileId);
      const expected: EmployeeDataImportResult = {
        email: account.email as string,
        username: account.username as string,
        userId: account.userId,
        alcumusUserId: null,
        employeeId: null,
        userAccountId: account.id,
        organizationId: null,
      };
      expect(actual).toEqual([expected]);
    });
  });
});
