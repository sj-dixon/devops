import { v4 as uuidV4 } from 'uuid';
import { UserAccountEntity } from '../../../src/models/userAccountEntity';
import { OrganizationAuthProviderType } from '../../../src/lib/tenants/types';
import { UserAccountType } from '../../../src/types/userAccount';
import { UserEntity } from '../../../src/models/userEntity';
import knexConfig from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { UserOrganizationEntity } from '../../../src/models/userOrganizationEntity';
import { generateRandomNumber } from '../routes/testHelpers';

let knex: Knex;
beforeAll(() => {
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('models/userEntity', () => {
  describe('findByInternalAccountId', () => {
    it('retrieves user by associated account internal account id', async () => {
      const internalAccountId = uuidV4();
      const otherInfo = uuidV4();
      const user = await UserEntity.create({
        firstName: otherInfo,
        lastName: otherInfo,
      });
      await UserAccountEntity.create(undefined, {
        isEnabled: true,
        internalAccountId,
        username: otherInfo,
        authProviderName: OrganizationAuthProviderType.AZURE_AD,
        scopedToOrganizationId: null,
        userId: user.id,
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
        email: `${otherInfo}@email.com`,
        requiresPasswordReset: false,
      });
      const retrieved = await UserEntity.findByInternalAccountId(
        internalAccountId
      );
      expect(retrieved).toEqual(user);
    });
  });

  describe('findByUserId', () => {
    it('returns user if found', async () => {
      const user = await UserEntity.create({
        firstName: uuidV4(),
        lastName: uuidV4(),
      });
      const actual = await UserEntity.findByUserId(user.id);
      expect(actual).toEqual(user);
    });

    it('returns undefined if not found', async () => {
      const actual = await UserEntity.findByUserId(-1);
      expect(actual).toBeUndefined();
    });
  });

  describe('findByAlcumusUserId', () => {
    it('returns user if found', async () => {
      const user = await UserEntity.create({
        firstName: uuidV4(),
        lastName: uuidV4(),
      });
      const userOrganization = await UserOrganizationEntity.create({
        organizationId: generateRandomNumber(),
        userId: user.id,
        isEnabled: true,
      });
      const actual = await UserEntity.findByAlcumusUserId(userOrganization.id);
      expect(actual).toEqual(user);
    });

    it('returns null if not found', async () => {
      const actual = await UserEntity.findByAlcumusUserId(-1);
      expect(actual).toBeNull();
    });
  });
});
