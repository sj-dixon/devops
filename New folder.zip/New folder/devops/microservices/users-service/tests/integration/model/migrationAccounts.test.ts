import { createUser } from '../routes/migrate/migrationTestHelpers';
import { generateRandomNumber } from '../routes/testHelpers';
import {
  getMigrationAccount,
  getMigrationAccountByIdentifiers,
  getMigrationAccounts,
} from '../../../src/models/migrationAccounts';
import knexConfig from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { UserDataImportFileEntity } from '../../../src/models/userDataImportFileEntity';
import { UserAccountType } from '../../../src/types/userAccount';
import { v4 as uuidV4 } from 'uuid';
import { UserAccountEntity } from '../../../src/models/userAccountEntity';
import { OrganizationAuthProviderType } from '../../../src/lib/tenants/types';

let knex: Knex;
beforeAll(() => {
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('models/migrationAccounts', () => {
  describe('getMigrationAccount', () => {
    it('returns a single migration account', async () => {
      const organizationId = generateRandomNumber();
      const user = await createUser('Donny', 'Darko', organizationId);
      const actual = await getMigrationAccount(user.alcumusUserId);
      expect(actual).toEqual(user);
    });
  });

  describe('getMigrationAccounts', () => {
    it('returns a single migration account when not created via DI', async () => {
      const organizationId = generateRandomNumber();
      const user = await createUser('Donny', 'Darko', organizationId);
      const actual = await getMigrationAccounts(organizationId);
      expect(actual).toEqual([user]);
    });

    it('returns a single organization account account when created via DI', async () => {
      const organizationId = generateRandomNumber();
      const file = await UserDataImportFileEntity.create(
        {
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
          authProviderName: 'auth1',
          filename: uuidV4(),
          organizationId,
        },
        1
      );
      const user = await createUser('Donny', 'Darko', organizationId, {
        dataImportFileId: file.id,
        userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
      });
      const actual = await getMigrationAccounts(organizationId);
      expect(actual).toEqual([user]);
    });

    it('returns a single personal account account when created via DI', async () => {
      const organizationId = generateRandomNumber();
      const file = await UserDataImportFileEntity.create(
        {
          userAccountType: UserAccountType.PERSONAL_ACCOUNT,
          authProviderName: 'auth1',
          filename: uuidV4(),
          organizationId,
        },
        1
      );
      const user = await createUser('Donny', 'Darko', organizationId, {
        dataImportFileId: file.id,
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
      });
      const actual = await getMigrationAccounts(organizationId);
      expect(actual).toEqual([user]);
    });

    it('characterization - given a personal and organization account, returns 2 records differing by account id', async () => {
      const organizationId = generateRandomNumber();
      const file = await UserDataImportFileEntity.create(
        {
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
          authProviderName: 'auth1',
          filename: uuidV4(),
          organizationId,
        },
        1
      );
      const user = await createUser('Donny', 'Darko', organizationId, {
        dataImportFileId: file.id,
        userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
      });
      const account2 = await UserAccountEntity.create(undefined, {
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
        isEnabled: true,
        email: null,
        username: uuidV4(),
        userId: user.userId,
        scopedToOrganizationId: null,
        authProviderName: OrganizationAuthProviderType.KEYCLOAK,
        requiresPasswordReset: false,
      });
      const expectedUser2 = {
        ...user,
        userAccountType: account2.userAccountType,
        authProviderName: account2.authProviderName,
        internalAccountId: account2.internalAccountId,
        userOrganizationAccountId: account2.id,
        email: account2.email,
        username: account2.username,
      };
      const actual = await getMigrationAccounts(organizationId);
      expect(actual).toEqual(expect.arrayContaining([user, expectedUser2]));
      expect(actual).toHaveLength(2);
    });
  });

  describe('getMigrationAccountByIdentifiers', () => {
    const organizationId = generateRandomNumber();

    it('returns single migration account by email', async () => {
      const user = await createUser('Donny', 'Darko', organizationId);
      const actual = await getMigrationAccountByIdentifiers(
        organizationId,
        user.email as string
      );
      expect(actual).toEqual(user);
    });

    it('returns single migration account by username', async () => {
      const user = await createUser('Donny', 'Darko', organizationId);
      const actual = await getMigrationAccountByIdentifiers(
        organizationId,
        user.username as string
      );
      expect(actual).toEqual(user);
    });
  });
});
