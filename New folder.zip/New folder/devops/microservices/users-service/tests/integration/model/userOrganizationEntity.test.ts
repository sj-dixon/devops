import { v4 as uuidV4 } from 'uuid';
import { UserAccountEntity } from '../../../src/models/userAccountEntity';
import { OrganizationAuthProviderType } from '../../../src/lib/tenants/types';
import { UserAccountType } from '../../../src/types/userAccount';
import { UserEntity } from '../../../src/models/userEntity';
import knexConfig from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { UserOrganizationEntity } from '../../../src/models/userOrganizationEntity';
import { generateRandomNumber } from '../routes/testHelpers';

let knex: Knex;
beforeAll(() => {
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('models/userOrganizationEntity', () => {
  describe('findByInternalAccountIdAndOrganizationId', () => {
    it('retrieves user by associated account internal account id', async () => {
      const internalAccountId = uuidV4();
      const organizationId = generateRandomNumber();
      const userOrganization = await createUserWithAccountAndOrganization(
        internalAccountId,
        organizationId
      );
      const retrieved =
        await UserOrganizationEntity.findByInternalAccountIdAndOrganizationId(
          internalAccountId,
          organizationId
        );
      expect(retrieved).toEqual(userOrganization);
    });

    it('returns one record at a time if two records exist', async () => {
      const internalAccountId = uuidV4();
      const organizationId1 = generateRandomNumber();
      const organizationId2 = generateRandomNumber();
      const user = await createUserWithAccount(internalAccountId);
      const org1 = await createUserOrganization(organizationId1, user.id);
      const org2 = await createUserOrganization(organizationId2, user.id);
      const retrieved1 =
        await UserOrganizationEntity.findByInternalAccountIdAndOrganizationId(
          internalAccountId,
          organizationId1
        );
      const retrieved2 =
        await UserOrganizationEntity.findByInternalAccountIdAndOrganizationId(
          internalAccountId,
          organizationId2
        );
      expect(retrieved1).toEqual(org1);
      expect(retrieved2).toEqual(org2);
    });
  });

  describe('findByInternalAccountId', () => {
    it('retrieves user by associated account internal account id', async () => {
      const internalAccountId = uuidV4();
      const organizationId = generateRandomNumber();
      const userOrganization = await createUserWithAccountAndOrganization(
        internalAccountId,
        organizationId
      );
      const retrieved = await UserOrganizationEntity.findByInternalAccountId(
        internalAccountId
      );
      expect(retrieved).toEqual([userOrganization]);
    });

    it('returns two records if two records exist', async () => {
      const internalAccountId = uuidV4();
      const organizationId1 = generateRandomNumber();
      const organizationId2 = generateRandomNumber();
      const user = await createUserWithAccount(internalAccountId);
      const org1 = await createUserOrganization(organizationId1, user.id);
      const org2 = await createUserOrganization(organizationId2, user.id);
      const retrieved = await UserOrganizationEntity.findByInternalAccountId(
        internalAccountId
      );
      expect(retrieved).toEqual(expect.arrayContaining([org1, org2]));
      expect(retrieved).toHaveLength(2);
    });
  });
});

async function createUserWithAccountAndOrganization(
  internalAccountId: string,
  organizationId: number
): Promise<UserOrganizationEntity> {
  const user = await createUserWithAccount(internalAccountId);
  return createUserOrganization(organizationId, user.id);
}

async function createUserOrganization(
  organizationId: number,
  userId: number
): Promise<UserOrganizationEntity> {
  return UserOrganizationEntity.create({
    organizationId,
    userId: userId,
    isEnabled: true,
  });
}

async function createUserWithAccount(
  internalAccountId: string
): Promise<UserEntity> {
  const otherInfo = uuidV4();
  const user = await UserEntity.create({
    firstName: otherInfo,
    lastName: otherInfo,
  });
  await UserAccountEntity.create(undefined, {
    isEnabled: true,
    internalAccountId,
    username: otherInfo,
    authProviderName: OrganizationAuthProviderType.AZURE_AD,
    scopedToOrganizationId: null,
    userId: user.id,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    email: `${otherInfo}@email.com`,
    requiresPasswordReset: false,
  });
  return user;
}
