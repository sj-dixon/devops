import { ENVIRONMENT } from '../testHelpers';
import knexConfig from '../../../../src/lib/clients/knex/config';
import { Utilities } from '@alcumus/globals';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { UserEntity } from '../../../../src/models/userEntity';
import request from 'supertest';
import { UserOrganizationEntity } from '../../../../src/models/userOrganizationEntity';
import { ENDPOINTS } from '../../../../src/constants';
import { v4 as uuidV4 } from 'uuid';

Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);

import { app } from '../testApp';

const ORGANIZATION_ID = 123;
let knex: Knex;
let user: UserEntity;
let route: string;
let dateNowSpy: jest.SpyInstance;

beforeAll(() => {
  knex = connectToKnex(knexConfig);
  Model.knex(knex);

  dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(() => 1487076708000);
});

beforeEach(async () => {
  user = await UserEntity.create(
    {
      firstName: 'Elton',
      lastName: 'John',
    },
    undefined
  );
});

afterAll(async () => {
  dateNowSpy.mockRestore();
  await knex.destroy();
});

describe('/api/v1/employees/{alcumusUserId}', () => {
  describe('GET /organization', () => {
    it('When user is part of organization, return organization membership', async () => {
      const expected = await UserOrganizationEntity.create({
        organizationId: ORGANIZATION_ID,
        userId: user.id,
        isEnabled: true,
        invitationCode: uuidV4(),
      });
      route = `${ENDPOINTS.EMPLOYEES}/${expected.id}/organization`;

      const result = await request(app)
        .get(route)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([result.status, result.body]).toEqual([
        200,
        {
          ...expected,
          alcumusUserId: expected.id,
        },
      ]);
    });
  });
});
