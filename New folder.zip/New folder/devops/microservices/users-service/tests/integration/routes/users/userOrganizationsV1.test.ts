import { ENVIRONMENT } from '../testHelpers';
import knexConfig from '../../../../src/lib/clients/knex/config';
import { Utilities } from '@alcumus/globals';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { UserEntity } from '../../../../src/models/userEntity';
import request from 'supertest';
import { UserOrganizationEntity } from '../../../../src/models/userOrganizationEntity';
import { ENDPOINTS } from '../../../../src/constants';
import { v4 as uuidV4 } from 'uuid';

Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);

import { app } from '../testApp';

const ORGANIZATION_ID = 123;
let knex: Knex;
let user: UserEntity;
let route: string;
let dateNowSpy: jest.SpyInstance;

beforeAll(() => {
  knex = connectToKnex(knexConfig);
  Model.knex(knex);

  dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(() => 1487076708000);
});

beforeEach(async () => {
  user = await UserEntity.create(
    {
      firstName: 'Ted',
      lastName: 'Mosby',
    },
    undefined
  );
  route = `${ENDPOINTS.USERS}/${user.id}/organizations`;
});

afterAll(async () => {
  dateNowSpy.mockRestore();
  await knex.destroy();
});

describe('/api/v1/users/{userId}', () => {
  describe('GET /organizations', () => {
    it('When user is part of organization, return organization membership', async () => {
      const expected = await UserOrganizationEntity.create({
        organizationId: ORGANIZATION_ID,
        userId: user.id,
        isEnabled: true,
        invitationCode: uuidV4(),
      });
      const result = await request(app)
        .get(route)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([result.status, result.body]).toEqual([
        200,
        [
          {
            ...expected,
            alcumusUserId: expected.id,
          },
        ],
      ]);
    });
  });

  describe('GET /{organizationId}', () => {
    it('When user is part of organization, return organization membership with a particular org', async () => {
      const expected = await UserOrganizationEntity.create({
        organizationId: ORGANIZATION_ID,
        userId: user.id,
        isEnabled: true,
        invitationCode: uuidV4(),
      });
      const result = await request(app)
        .get(`${route}/${ORGANIZATION_ID}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([result.status, result.body]).toEqual([
        200,
        {
          ...expected,
          alcumusUserId: expected.id,
        },
      ]);
    });

    it('When user is part of organization, return not found when wrong org id is sent', async () => {
      const result = await request(app)
        .get(`${route}/${ORGANIZATION_ID + 1}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([result.status, result.body]).toEqual([404, {}]);
    });
  });

  describe('POST /organizations', () => {
    it('When user is added to organization, it is retrievable via API', async () => {
      const result = await request(app)
        .post(route)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send({
          organizationId: ORGANIZATION_ID,
          isEnabled: true,
        });
      const expected = {
        id: expect.any(Number),
        userId: user.id,
        organizationId: ORGANIZATION_ID,
        isEnabled: true,
        createdAt: '2017-02-14T12:51:48.000Z',
        modifiedAt: '2017-02-14T12:51:48.000Z',
        deletedAt: null,
        invitationCode: null,
        dataImportRowId: null,
        dataImportFileId: null,
      };

      expect([result.status, result.body]).toEqual([
        201,
        {
          ...expected,
          alcumusUserId: result.body?.id,
        },
      ]);
    });
  });
});
