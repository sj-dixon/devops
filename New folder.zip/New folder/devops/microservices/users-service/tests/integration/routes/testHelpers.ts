import axios, { AxiosRequestConfig } from 'axios';
import MockAdapter from 'axios-mock-adapter';
import qs from 'querystring';
import { Utilities } from '@alcumus/globals';
import { CreateUserRequest } from '../../../src/types';
import { UserEntity } from '../../../src/models/userEntity';
import { extractUserFromRequest } from '../../../src/lib/utils';
import { UserAccountEntity } from '../../../src/models/userAccountEntity';
import { KeycloakCredentials } from '../../../src/lib/clients/keycloak/types';
import { OrganizationAuthProviderType } from '../../../src/lib/tenants/types';
import { UserAccount, UserAccountType } from '../../../src/types/userAccount';

export const mockAxios = new MockAdapter(axios);

export const ENVIRONMENT = {
  KEYCLOAK_SERVER_URL: 'http://secret-lair:8080/auth',
  KEYCLOAK_SERVER_REALM: 'secret-realm',
  KEYCLOAK_ADMIN_ID: 'secret-cli',
  KEYCLOAK_ADMIN_SECRET: '9012cf7e-e4d3-4e38-9186-93973f5c5326',
  KEYCLOAK_CLIENT_ID: 'regular-cli',
  KEYCLOAK_CLIENT_SECRET: 'banana split',
  SERVICE_MESH_HOST: 'https://secret-cloud:5000/api',
  SERVICE_MESH_API_KEY: 'carbonated ice cream',
  FEATURE_TOGGLE_USE_LINKERD: 'true',
  FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD: 'false', // should not break if changed,

  AZURE_AD_REDIRECT_URI: 'not important',
  AZURE_AD_CLIENT_ID: 'not important',
  AZURE_AD_CLIENT_SECRET: 'not important',
};

export const FAKE_TIME_FN = () => 1487076708000;

export function generateRandomNumber(): number {
  return Math.floor(Math.random() * 10000000) + 10000;
}

export function getAuthToken(info: object): string {
  return `fakeHeader.${Buffer.from(JSON.stringify(info)).toString(
    'base64'
  )}.fakeSignature`;
}

export function setupAxiosInterceptors(): void {
  axios.interceptors.response.use((response) => {
    console.log(
      `${response.config.method} ${response.config.url} -> ${response.status}`
    );
    return response;
  });
  axios.interceptors.request.use((request) => {
    console.log(
      `${request.method} ${request.url} with ${JSON.stringify(request.data)}`
    );
    return request;
  });
}

export function mockKeycloakAuth(
  expectedCredentials: KeycloakCredentials,
  replyOnce = true
): jest.Mock<(number | object)[]> {
  const environment = Utilities.getKeycloakConstants();
  const tokenApiBaseUrl = `${environment.URL}/realms/${environment.REALM}`;
  const callback = jest.fn(() => [
    200,
    {
      accessToken: 'abcdef2123',
      token_type: 'Bearer',
      scope: 'profile email',
      expires_in: 10,
    },
  ]);
  const handler = (config: AxiosRequestConfig) => {
    expect(qs.parse(config.data)).toEqual({
      client_id: expectedCredentials.clientId,
      grant_type: expectedCredentials.grantType,
      password: expectedCredentials.password,
      username: expectedCredentials.username,
    });
    return callback();
  };
  if (replyOnce) {
    mockAxios
      .onPost(`${tokenApiBaseUrl}/protocol/openid-connect/token`)
      .replyOnce(handler);
  } else {
    mockAxios
      .onPost(`${tokenApiBaseUrl}/protocol/openid-connect/token`)
      .reply(handler);
  }
  return callback;
}

export function mockKeycloakAccountCreation(
  keycloakCredentialId: string
): jest.Mock<(number | object)[]> {
  const adminApiBaseUrl = `${ENVIRONMENT.KEYCLOAK_SERVER_URL}/admin/realms/${ENVIRONMENT.KEYCLOAK_SERVER_REALM}`;
  const mockPostUser = jest.fn(() => [
    200,
    {
      id: keycloakCredentialId,
    },
    {
      location: `${adminApiBaseUrl}/users/${keycloakCredentialId}`,
    },
  ]);

  mockAxios.onPost(`${adminApiBaseUrl}/users`).replyOnce(mockPostUser);
  return mockPostUser;
}

export function mockKeycloakPasswordChange(
  internalAccountId: string,
  newPassword: string
): jest.Mock {
  const environment = Utilities.getKeycloakConstants();
  const adminApiBaseUrl = `${environment.URL}/admin/realms/${environment.REALM}`;
  const callback = jest.fn(() => [
    200,
    {
      id: internalAccountId,
    },
    {
      location: `${adminApiBaseUrl}/users/${internalAccountId}`,
    },
  ]);
  mockAxios
    .onPut(`${adminApiBaseUrl}/users/${internalAccountId}`)
    .replyOnce((config) => {
      expect(JSON.parse(config.data)).toEqual(
        expect.objectContaining({
          enabled: true,
          credentials: [
            {
              type: 'password',
              temporary: false,
              value: newPassword,
            },
          ],
        })
      );
      return callback();
    });
  return callback;
}

export function mockKeycloakUserEdit(
  internalAccountId: string,
  email?: string,
  username?: string,
  enabled?: boolean
): jest.Mock<number[]> {
  const environment = Utilities.getKeycloakConstants();
  const adminApiBaseUrl = `${environment.URL}/admin/realms/${environment.REALM}`;
  const callback = jest.fn(() => [200]);
  mockAxios
    .onPut(`${adminApiBaseUrl}/users/${internalAccountId}`)
    .replyOnce((config) => {
      const expected = {
        ...(!!email && { email }),
        ...(!!username && { username }),
        ...(!!enabled && { enabled }),
      };
      expect(JSON.parse(config.data)).toEqual(
        expect.objectContaining(expected)
      );
      return callback();
    });
  return callback;
}

export async function createUserWithAccount(
  userRequest: CreateUserRequest,
  internalAccountId: string,
  authProviderName = OrganizationAuthProviderType.KEYCLOAK
): Promise<[UserEntity, UserAccountEntity]> {
  expect(userRequest.createAccount).toBe(true); // for consistency

  const userProperties = extractUserFromRequest(userRequest);
  const userEntity = await UserEntity.create(userProperties);
  const userCredentialProperties: UserAccount = {
    username: userRequest.username,
    email: userRequest.email,
    phoneNumber: userRequest.phoneNumber,
    scopedToOrganizationId: null,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    internalAccountId,
    userId: userEntity.id,
    isEnabled: true,
    requiresPasswordReset: false,
    dataImportFileId: null,
    dataImportRowId: null,
    authProviderName,
  };
  const credentials = await UserAccountEntity.create(
    undefined,
    userCredentialProperties
  );
  return [userEntity, credentials];
}

export function mockOrganizationLookup(organizationId: number): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/organizations/${organizationId}`;
  const onReply = jest.fn(() => [
    200,
    {
      id: organizationId,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockAuthProviderLookup(
  organizationId: number,
  keycloakPrefix: string
): jest.Mock {
  const providerType = OrganizationAuthProviderType.KEYCLOAK;
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/authProviders/${providerType}?organizationId=${organizationId}`;
  const onReply = jest.fn(() => [
    200,
    {
      id: 1234,
      organizationId,
      userNamePrefix: keycloakPrefix,
      organizationIdentifier: 'abcdef',
      authProviderType: providerType,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).reply(onReply);
  return onReply;
}

export function mockApiAuthProviderLookup(
  organizationId: number,
  authProviderName: string
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/authProviders/${authProviderName}?organizationId=${organizationId}`;
  const onReply = jest.fn(() => [
    200,
    {
      id: 1234,
      organizationId,
      userNamePrefix: null,
      organizationIdentifier: 'abcdef',
      authProviderName,
      authProviderType: OrganizationAuthProviderType.API,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockLookupFailure(url: string): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}${url}`;
  const onReply = jest.fn(() => [
    404,
    {
      message: 'doesnt matter',
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockOrganizationLookupByIdentifier(
  organizationIdentifier: string,
  organizationId: number
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/auth/${organizationIdentifier}`;
  const onReply = jest.fn(() => [
    200,
    {
      id: organizationId,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}
