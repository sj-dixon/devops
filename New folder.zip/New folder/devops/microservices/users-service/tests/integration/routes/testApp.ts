import './evilMock';
import app from '../../../src/app';

export { app };
