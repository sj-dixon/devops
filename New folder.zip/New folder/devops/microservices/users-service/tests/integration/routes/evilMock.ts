import { NextFunction, Response } from 'express';
import { Types } from '@alcumus/globals';

// todo remove this evil testing hack
jest.mock('@alcumus/auth-plugin', () => {
  const nextMiddleware = (
    request: Request,
    response: Response,
    next: NextFunction
  ) => {
    next();
  };

  // noinspection JSUnusedGlobalSymbols
  return {
    authenticationMiddlewares: () => [nextMiddleware],
    toKeycloakEmailOrUsername: (val?: string, prefix?: string) =>
      val ? `${prefix}${val}` : val,
    requireAuthentication:
      () =>
      (request: Types.Request, response: Response, next: NextFunction) => {
        if (request.headers.authorization?.endsWith('fakeSignature')) {
          next();
        } else {
          response.sendStatus(403);
        }
      },
  };
});
