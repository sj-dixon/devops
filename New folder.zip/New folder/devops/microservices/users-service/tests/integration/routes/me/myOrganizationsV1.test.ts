import '../evilMock';
import {
  ENVIRONMENT,
  generateRandomNumber,
  getAuthToken,
} from '../testHelpers';
import knexConfig from '../../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities } from '@alcumus/globals';
import { v4 as uuidV4 } from 'uuid';

import {
  createAdditionalOrganizationAccount,
  createPersonalAccount,
  createUser,
} from '../migrate/migrationTestHelpers';
import { app } from '../testApp';
import supertest from 'supertest';
import { ENDPOINTS } from '../../../../src/constants';

let knex: Knex;

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('api/v1/me/organizations', () => {
  let organizationId: number;

  beforeEach(() => {
    organizationId = generateRandomNumber();
  });

  describe('GET /', () => {
    it('When user has 1 account in 1 organization, Should return triad', async () => {
      const userCredentials = getCredentials(organizationId);
      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      const expected = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );
      const response = await getMyOrganizations(
        userCredentials.internalAccountId
      );
      expect([response.status, response.body]).toEqual([200, [expected]]);
    });

    it('When user has 2 accounts in 2 organizations, Should return 1 triad', async () => {
      const organizationId2 = generateRandomNumber();
      const userCredentials = getCredentials(organizationId);
      const userCredentials2 = getCredentials(organizationId2);

      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      await createAdditionalOrganizationAccount(
        migrationAccount.userId,
        organizationId2,
        userCredentials2
      );

      const response = await getMyOrganizations(
        userCredentials.internalAccountId
      );

      const expected = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );
      expect([response.status, response.body]).toEqual([200, [expected]]);
    });

    it('When user has 3 accounts in 2 organizations, Should return logged in organization id', async () => {
      const organizationId2 = generateRandomNumber();
      const userCredentials = getCredentials(organizationId);
      const userCredentials2 = getCredentials(organizationId2);
      const personalCredentials = getCredentials(generateRandomNumber());

      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      await createAdditionalOrganizationAccount(
        migrationAccount.userId,
        organizationId2,
        userCredentials2
      );
      await createPersonalAccount(migrationAccount.userId, personalCredentials);

      const response = await getMyOrganizations(
        userCredentials.internalAccountId
      );

      const expected = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );
      expect([response.status, response.body]).toEqual([200, [expected]]);
    });

    it('When user is using personal account, Should return all organizations', async () => {
      const organizationId2 = generateRandomNumber();
      const userCredentials = getCredentials(organizationId);
      const userCredentials2 = getCredentials(organizationId2);
      const personalCredentials = getCredentials(generateRandomNumber());

      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      const [, { id: alcumusUserId2 }] =
        await createAdditionalOrganizationAccount(
          migrationAccount.userId,
          organizationId2,
          userCredentials2
        );
      await createPersonalAccount(migrationAccount.userId, personalCredentials);

      const response = await getMyOrganizations(
        personalCredentials.internalAccountId
      );

      const expected1 = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );

      const expected2 = getExpectedResult(
        alcumusUserId2,
        migrationAccount.userId,
        organizationId2
      );
      expect([response.status, response.body]).toEqual([
        200,
        expect.arrayContaining([expected1, expected2]),
      ]);
    });

    it('when multiple people belong to an organization, return just my membership', async () => {
      const userCredentials = getCredentials(organizationId);
      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      await createUser(
        'Barry',
        'Allen',
        organizationId,
        getCredentials(organizationId)
      );
      const expected = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );
      const response = await getMyOrganizations(
        userCredentials.internalAccountId
      );
      expect([response.status, response.body]).toEqual([200, [expected]]);
    });
  });

  describe('GET /:organizationId', () => {
    it('When user has 1 account in 1 organization, Should return triad', async () => {
      const userCredentials = getCredentials(organizationId);
      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      const expected = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );
      const response = await getSpecificOrganization(
        migrationAccount.userId,
        userCredentials.internalAccountId,
        organizationId
      );
      expect([response.status, response.body]).toEqual([200, expected]);
    });

    it('Given company signin, when user has 2 accounts in 2 organizations, Should return organization for signed in account', async () => {
      const organizationId2 = generateRandomNumber();
      const userCredentials = getCredentials(organizationId);
      const userCredentials2 = getCredentials(organizationId2);

      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      await createAdditionalOrganizationAccount(
        migrationAccount.userId,
        organizationId2,
        userCredentials2
      );

      const loggedInOrganizationResponse = await getSpecificOrganization(
        migrationAccount.userId,
        userCredentials.internalAccountId,
        organizationId
      );
      const otherOrganizationResponse = await getSpecificOrganization(
        migrationAccount.userId,
        userCredentials.internalAccountId,
        organizationId2
      );

      const expected = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );
      expect([
        loggedInOrganizationResponse.status,
        loggedInOrganizationResponse.body,
      ]).toEqual([200, expected]);
      expect([
        otherOrganizationResponse.status,
        otherOrganizationResponse.body,
      ]).toEqual([
        404,
        {
          message: `This user account does not have access to organization ${organizationId2}`,
        },
      ]);
    });

    it('Given company account signin, when user has 3 accounts in 2 organizations, Should return logged in organization only', async () => {
      const organizationId2 = generateRandomNumber();
      const userCredentials = getCredentials(organizationId);
      const userCredentials2 = getCredentials(organizationId2);
      const personalCredentials = getCredentials(generateRandomNumber());

      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      await createAdditionalOrganizationAccount(
        migrationAccount.userId,
        organizationId2,
        userCredentials2
      );
      await createPersonalAccount(migrationAccount.userId, personalCredentials);

      const loggedInOrganizationResponse = await getSpecificOrganization(
        migrationAccount.userId,
        userCredentials.internalAccountId,
        organizationId
      );
      const otherOrganizationResponse = await getSpecificOrganization(
        migrationAccount.userId,
        userCredentials.internalAccountId,
        organizationId2
      );

      const expected = getExpectedResult(
        migrationAccount.alcumusUserId,
        migrationAccount.userId,
        organizationId
      );
      expect([
        loggedInOrganizationResponse.status,
        loggedInOrganizationResponse.body,
      ]).toEqual([200, expected]);
      expect([
        otherOrganizationResponse.status,
        otherOrganizationResponse.body,
      ]).toEqual([
        404,
        {
          message: `This user account does not have access to organization ${organizationId2}`,
        },
      ]);
    });

    it('When user is using personal account, Should return all organizations', async () => {
      const organizationId2 = generateRandomNumber();
      const userCredentials = getCredentials(organizationId);
      const userCredentials2 = getCredentials(organizationId2);
      const personalCredentials = getCredentials(generateRandomNumber());

      const migrationAccount = await createUser(
        'Barry',
        'Allen',
        organizationId,
        userCredentials
      );
      const [, userOrganization2] = await createAdditionalOrganizationAccount(
        migrationAccount.userId,
        organizationId2,
        userCredentials2
      );
      await createPersonalAccount(migrationAccount.userId, personalCredentials);

      const [organizationResponse1, organizationResponse2] = await Promise.all([
        getSpecificOrganization(
          migrationAccount.userId,
          personalCredentials.internalAccountId,
          organizationId
        ),
        getSpecificOrganization(
          migrationAccount.userId,
          personalCredentials.internalAccountId,
          organizationId2
        ),
      ]);

      const [expected1, expected2] = [
        getExpectedResult(
          migrationAccount.alcumusUserId,
          migrationAccount.userId,
          organizationId
        ),
        getExpectedResult(
          userOrganization2.id,
          migrationAccount.userId,
          organizationId2
        ),
      ];

      expect([
        organizationResponse1.status,
        organizationResponse2.status,
        organizationResponse1.body,
        organizationResponse2.body,
      ]).toEqual([200, 200, expected1, expected2]);
    });
  });
});

function getExpectedResult(
  alcumusUserId: number,
  userId: number,
  organizationId: number
): object {
  return {
    id: alcumusUserId,
    alcumusUserId,
    organizationId,
    userId,
    isEnabled: true,
    createdAt: expect.any(String),
    modifiedAt: expect.any(String),
    deletedAt: null,
    dataImportFileId: null,
    dataImportRowId: null,
    invitationCode: null,
  };
}

function getMyOrganizations(internalAccountId: string): supertest.Test {
  const encodedUserInfo = getAuthToken({
    sub: internalAccountId,
  });
  return supertest(app)
    .get(ENDPOINTS.MY_ORGANIZATIONS)
    .auth(encodedUserInfo, { type: 'bearer' })
    .send();
}

function getSpecificOrganization(
  userId: number,
  internalAccountId: string,
  organizationId: number
): supertest.Test {
  const encodedUserInfo = getAuthToken({
    sub: internalAccountId,
  });
  return supertest(app)
    .get(`${ENDPOINTS.MY_ORGANIZATIONS}/${organizationId}`)
    .auth(encodedUserInfo, { type: 'bearer' })
    .send();
}

function getCredentials(organizationId: number) {
  const identifier = uuidV4();
  return {
    internalAccountId: `${identifier}`,
    username: `${identifier}-${organizationId}`,
    email: `${identifier}@${organizationId}.com`,
  };
}
