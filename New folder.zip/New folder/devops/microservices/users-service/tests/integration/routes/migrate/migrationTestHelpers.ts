import { UserMigrationResult } from '../../../../src/types/userMigration';
import { UserEntity } from '../../../../src/models/userEntity';
import { UserAccountEntity } from '../../../../src/models/userAccountEntity';
import { UserOrganizationEntity } from '../../../../src/models/userOrganizationEntity';
import { UserAccountType } from '../../../../src/types/userAccount';
import { OrganizationAuthProviderType } from '../../../../src/lib/tenants/types';

type UserAccountOrganizationTuple = [UserAccountEntity, UserOrganizationEntity];

export interface OptionalUserCreationParameters {
  username?: string;
  email?: string;
  internalAccountId?: string;
  dataImportFileId?: number;
  userAccountType?: UserAccountType;
}

export async function createUser(
  firstName: string,
  lastName: string,
  organizationId: number,
  optionals: OptionalUserCreationParameters = {}
): Promise<UserMigrationResult> {
  const user = await UserEntity.create({
    firstName,
    lastName,
    dataImportFileId: optionals.dataImportFileId,
  });
  const [account, membership] = await createAdditionalOrganizationAccount(
    user.id,
    organizationId,
    optionals
  );
  return {
    email: account.email as string,
    username: account.username as string,
    userId: user.id,
    userOrganizationId: membership.id,
    alcumusUserId: membership.id,
    userOrganizationAccountId: account.id,
    internalAccountId: optionals?.internalAccountId || null,
    authProviderName: OrganizationAuthProviderType.KEYCLOAK,
    userAccountType:
      optionals.userAccountType || UserAccountType.ORGANIZATION_ACCOUNT,
    organizationId,
    isEnabled: true,
    firstName,
    lastName,
  };
}

export async function createAdditionalOrganizationAccount(
  userId: number,
  organizationId: number,
  {
    username,
    email,
    internalAccountId,
    dataImportFileId,
    userAccountType = UserAccountType.ORGANIZATION_ACCOUNT,
  }: OptionalUserCreationParameters = {}
): Promise<UserAccountOrganizationTuple> {
  username = username || `extra.${userId}.${organizationId}`;
  email = email || `${username}@avengers.com`;
  return Promise.all([
    UserAccountEntity.query().insertAndFetch({
      userId: userId,
      userAccountType,
      username,
      email,
      scopedToOrganizationId: organizationId,
      internalAccountId,
      authProviderName: OrganizationAuthProviderType.KEYCLOAK,
      dataImportFileId,
    }),
    addUserToOrganization(userId, organizationId, {
      dataImportFileId,
    }),
  ]);
}

export async function createPersonalAccount(
  userId: number,
  { username, email, internalAccountId }: OptionalUserCreationParameters = {}
): Promise<UserAccountEntity> {
  username = username || `extra.${userId}.personal`;
  email = email || `${username}@avengers.com`;
  return UserAccountEntity.query().insertAndFetch({
    userId: userId,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    username,
    email,
    scopedToOrganizationId: null,
    internalAccountId,
  });
}

export async function addUserToOrganization(
  userId: number,
  organizationId: number,
  { dataImportFileId }: OptionalUserCreationParameters
): Promise<UserOrganizationEntity> {
  return UserOrganizationEntity.create({
    organizationId: organizationId,
    userId: userId,
    dataImportFileId,
  });
}
