import { UserEntity } from '../../../../src/models/userEntity';
import { UserDataImportFileEntity } from '../../../../src/models/userDataImportFileEntity';
import { generateRandomNumber } from '../testHelpers';
import { UserAccountType } from '../../../../src/types/userAccount';
import { Utilities } from '@alcumus/globals';
import { UserAccountEntity } from '../../../../src/models/userAccountEntity';
import { UserOrganizationEntity } from '../../../../src/models/userOrganizationEntity';
import { OrganizationAuthProviderType } from '../../../../src/lib/tenants/types';
import { app } from '../testApp';
import supertest from 'supertest';
import { ENDPOINTS } from '../../../../src/constants';
import {
  EmployeeImportIntermediate,
  UserAccountImportIntermediate,
} from '../../../../src/types/importIntermediates';
import knexConfig from '../../../../src/lib/clients/knex/config';
import { Model } from 'objection';
import connectToKnex, { Knex } from 'knex';

const authProviderName = 'EMILY_IN_PARIS';
const SERVICE_MESH_API_KEY =
  'The Paris office is different than the American one';

let knex: Knex;

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv({
    SERVICE_MESH_API_KEY,
  });
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('/api/v1/imports/:dataImportFileId', () => {
  let organizationId: number;

  beforeEach(async () => {
    organizationId = generateRandomNumber();
  });

  describe('GET /accounts', () => {
    it('Given valid api key, returns 200 response with accounts', async () => {
      const email = `${Utilities.uuidV4()}@savoir.com`;
      const [dataImportFile, user, userAccount] = await createFakeImport(
        organizationId,
        {
          email,
        }
      );
      const response = await supertest(app)
        .get(`${ENDPOINTS.IMPORTS}/${dataImportFile.id}/accounts`)
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send();
      const expected: UserAccountImportIntermediate[] = [
        {
          firstName: user.firstName,
          lastName: user.lastName,
          email,
          username: null,
          userAccountId: userAccount.id,
          userId: user.id,
          authProviderName: OrganizationAuthProviderType.AZURE_AD,
          userAccountType: UserAccountType.PERSONAL_ACCOUNT,
          isEnabled: true,
        },
      ];
      expect([response.status, response.body]).toEqual([200, expected]);
    });

    it('given email with + symbol, returns expected account', async () => {
      const email = `${Utilities.uuidV4()}+123@savoir.com`;
      const [dataImportFile, user, userAccount] = await createFakeImport(
        organizationId,
        {
          email,
        }
      );
      const response = await supertest(app)
        .get(`${ENDPOINTS.IMPORTS}/${dataImportFile.id}/accounts`)
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send();
      const expected: UserAccountImportIntermediate[] = [
        {
          firstName: user.firstName,
          lastName: user.lastName,
          email,
          username: null,
          userAccountId: userAccount.id,
          userId: user.id,
          authProviderName: OrganizationAuthProviderType.AZURE_AD,
          userAccountType: UserAccountType.PERSONAL_ACCOUNT,
          isEnabled: true,
        },
      ];
      expect([response.status, response.body]).toEqual([200, expected]);
    });
  });

  describe('GET /employees', () => {
    it('Given valid api key, returns 200 response with employees', async () => {
      const [dataImportFile, user, , employee] = await createFakeImport(
        organizationId,
        {
          email: `${Utilities.uuidV4()}@savoir.com`,
        }
      );
      const response = await supertest(app)
        .get(`${ENDPOINTS.IMPORTS}/${dataImportFile.id}/employees`)
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send();
      const expected: EmployeeImportIntermediate[] = [
        {
          firstName: user.firstName,
          lastName: user.lastName,
          alcumusUserId: employee.id,
          organizationId: organizationId,
          employeeId: employee.id,
          userId: user.id,
          isEnabled: true,
        },
      ];
      expect([response.status, response.body]).toEqual([200, expected]);
    });
  });
});

async function createFakeImport(
  organizationId: number,
  {
    email,
  }: {
    email: string;
  }
): Promise<
  [
    UserDataImportFileEntity,
    UserEntity,
    UserAccountEntity,
    UserOrganizationEntity
  ]
> {
  const dataImportFile = await UserDataImportFileEntity.create(
    {
      organizationId,
      userAccountType: UserAccountType.PERSONAL_ACCOUNT,
      authProviderName,
      filename: Utilities.uuidV4(),
    },
    1
  );

  const dataImportFileId = dataImportFile.id;
  const user = await UserEntity.create({
    firstName: 'Emily',
    lastName: 'Cooper',
    dataImportFileId,
  });
  const userAccount = await UserAccountEntity.create(undefined, {
    dataImportFileId,
    isEnabled: true,
    userId: user.id,
    email,
    requiresPasswordReset: false,
    username: null,
    dataImportRowId: null, // not important here.
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    authProviderName: OrganizationAuthProviderType.AZURE_AD,
  });
  const employee = await UserOrganizationEntity.create({
    organizationId,
    userId: user.id,
    dataImportFileId,
    isEnabled: true,
  });
  return [dataImportFile, user, userAccount, employee];
}
