import { Utilities } from '@alcumus/globals';
import { ENVIRONMENT, generateRandomNumber } from '../testHelpers';
import knexConfig from '../../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import supertest from 'supertest';
import { app } from '../testApp';
import { ENDPOINTS } from '../../../../src/constants';
import { Buffer } from 'buffer';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';

let knex: Knex;
let duplicatesFile: Buffer;
const CLIENT_APP = Utilities.uuidV4();

beforeAll(async () => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  knex = connectToKnex(knexConfig);
  Model.knex(knex);

  duplicatesFile = await promisify(fs.readFile)(
    path.join(__dirname, 'duplicatesTest.xlsx')
  );
});

describe('/api/v1/migrate/users/batch/large', () => {
  let organizationId: number;

  beforeEach(() => {
    organizationId = generateRandomNumber();
  });

  describe('POST /', () => {
    it('When adding user without an api key, Then should return 401 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_USERS_BATCH}/large`)
        .set('x-api-client-app', CLIENT_APP)
        .attach('file', Buffer.from('this is a string'));
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });
    it('When adding user with an invalid api key, Then should return 401 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_USERS_BATCH}/large`)
        .set('x-api-key', 'wrong api key')
        .set('x-api-client-app', CLIENT_APP)
        .attach('file', Buffer.from('this is a string'));
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('When uploading something other than an excel file, Then should return 400 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_USERS_BATCH}/large`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', CLIENT_APP)
        .attach('file', Buffer.from('this is a string'));
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: 'Please upload a file',
        },
      ]);
    });

    it('When uploading excel with invalid mime type, Then should return 400 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_USERS_BATCH}/large`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', CLIENT_APP)
        .attach('file', duplicatesFile, {
          contentType: 'application/octet-stream',
          filename: 'something.xlsx',
        });
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: 'Please upload an excel file',
        },
      ]);
    });
  });
});
