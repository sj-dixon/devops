import { v4 as uuidV4 } from 'uuid';
import {
  ENVIRONMENT,
  generateRandomNumber,
  mockAuthProviderLookup,
  mockKeycloakAccountCreation,
  mockKeycloakAuth,
  mockKeycloakPasswordChange,
  mockKeycloakUserEdit,
} from '../testHelpers';
import knexConfig from '../../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Utilities } from '@alcumus/globals';
import { Model } from 'objection';
import supertest from 'supertest';
import { app } from '../testApp';
import { ENDPOINTS } from '../../../../src/constants';
import {
  createAdditionalOrganizationAccount,
  createUser,
} from './migrationTestHelpers';
import { UserAccountEntity } from '../../../../src/models/userAccountEntity';
import { AccountRequest } from '../../../../src/types';

const internalAccountId = uuidV4();
let knex: Knex;

describe('/api/v1/migrate/users/', () => {
  let organizationId: number;
  let prefix: string;
  let authProviderLookup: jest.Mock;

  beforeAll(async () => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(knexConfig);
    Model.knex(knex);
  });

  beforeEach(() => {
    organizationId = generateRandomNumber();
    prefix = `test${organizationId}_`;
    authProviderLookup = mockAuthProviderLookup(organizationId, prefix);
  });

  afterAll(async () => {
    await knex.destroy();
  });

  describe('PATCH :userId/credentials', () => {
    it('When request has no api key, reject with 401 response', async () => {
      const userRequest = {
        password: 'abc123',
      };
      const response = await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${generateRandomNumber()}/credentials`
        )
        .send(userRequest);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When changing a made-up user, Then should return 404 response', async () => {
      const userRequest = {
        password: 'abc123',
      };

      const response = await supertest(app)
        .patch(`${ENDPOINTS.MIGRATE_USER}/888888888/credentials`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);
      expect([response.status, response.body]).toEqual([404, {}]);
    });

    it('When changing to a weak password, Then should return 200 response', async () => {
      const loginMock = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const newPassword = 'abc123';
      const mockPasswordReset = mockKeycloakPasswordChange(
        internalAccountId,
        newPassword
      );
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId,
        { internalAccountId }
      );

      const userRequest = {
        password: newPassword,
      };

      const response = await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${migrationResult.userOrganizationId}/credentials`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);

      expect([response.status, response.body]).toEqual([200, migrationResult]);
      expect(mockPasswordReset).toHaveBeenCalledTimes(1);
      expect(loginMock).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(1);
    });

    it('When changing a user with multiple organizations, Then should return 200 response with correct org', async () => {
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId,
        { internalAccountId }
      );
      await createAdditionalOrganizationAccount(
        migrationResult.userId,
        generateRandomNumber()
      );
      const userRequest = {
        username: `bruce.banner.${migrationResult.userId}`,
      };
      const [mockLogin, mockPut] = mockUserUpdate(
        internalAccountId,
        userRequest,
        prefix
      );

      const response = await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${migrationResult.userOrganizationId}/credentials`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);
      expect([response.status, response.body]).toEqual([
        200,
        {
          ...migrationResult,
          username: userRequest.username,
        },
      ]);
      expect(mockLogin).toHaveBeenCalledTimes(1);
      expect(mockPut).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(1);
    });

    it('When archiving a user, Then change username and isEnabled->false AND disable keycloak account  ', async () => {
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId,
        { internalAccountId }
      );
      const userRequest = {
        username: `bruce.banner.${migrationResult.userId}`,
        isEnabled: false,
      };
      const [mockLogin, mockPut] = mockUserUpdate(
        internalAccountId,
        userRequest,
        prefix
      );

      const response = await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${migrationResult.userOrganizationId}/credentials`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);
      expect([response.status, response.body]).toEqual([
        200,
        {
          ...migrationResult,
          username: userRequest.username,
          isEnabled: false,
        },
      ]);
      expect(mockLogin).toHaveBeenCalledTimes(1);
      expect(mockPut).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(1);
    });

    it('When setting password on an account without a keycloak id, Then create the keycloak account and return result', async () => {
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId,
        { internalAccountId: undefined }
      );

      const userRequest = {
        password: 'abc123',
      };
      const internalAccountId = 'myFakeId1';
      const loginMock = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const mockPostUser = mockKeycloakAccountCreation(internalAccountId);

      const response = await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${migrationResult.userOrganizationId}/credentials`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);
      const actualAccountInDatabase = (await UserAccountEntity.findOneByUserId(
        migrationResult.userId
      )) as UserAccountEntity;

      expect(loginMock).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(1);
      expectUserToHaveBeenPosted(
        mockPostUser,
        prefix,
        migrationResult.email as string,
        migrationResult.username as string
      );
      expect([response.status, response.body]).toEqual([
        200,
        {
          ...migrationResult,
          internalAccountId,
        },
      ]);
      expect(actualAccountInDatabase.internalAccountId).toEqual(
        internalAccountId
      );
    });

    it('When updating the username THEN setting password, Then set the password using the new username', async () => {
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId,
        { internalAccountId: undefined }
      );

      const request1 = {
        username: `the.hulk.${organizationId}`,
        email: `hulk.${organizationId}@avengers.com`,
      };
      const request2 = {
        password: 'abc123',
      };
      const internalAccountId = 'myFakeId2';
      const loginMock = mockKeycloakAuth(
        {
          clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
          grantType: 'client_credentials',
        },
        false
      );
      const mockPostUser = mockKeycloakAccountCreation(internalAccountId);

      // update username and email BEFORE setting password
      await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${migrationResult.userOrganizationId}/credentials`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(request1);
      const response2 = await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${migrationResult.userOrganizationId}/credentials`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(request2);

      expect(loginMock).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(2);
      expectUserToHaveBeenPosted(
        mockPostUser,
        prefix,
        request1.email,
        request1.username
      );
      expect([response2.status, response2.body]).toEqual([
        200,
        {
          ...migrationResult,
          ...request1,
          internalAccountId,
        },
      ]);
    });

    function expectUserToHaveBeenPosted(
      mockPostUser: jest.Mock,
      prefix: string,
      email: string,
      username: string
    ): void {
      expect(mockPostUser).toHaveBeenCalledTimes(1);
      expect(JSON.parse(mockPostUser.mock.calls[0][0].data)).toEqual(
        expect.objectContaining({
          email: prefix + email,
          username: prefix + username,
        })
      );
    }
  });

  describe('PATCH :userId', () => {
    it('When profile update submitted without valid API key, returns 401 response', async () => {
      const migrationRecord = await createUser('Tony', 'Stark', organizationId);

      const userRequest = {
        firstName: 'Not',
        lastName: 'GonnaWork',
      };

      const response = await supertest(app)
        .patch(
          `${ENDPOINTS.MIGRATE_USER}/${migrationRecord.userOrganizationId}`
        )
        .send(userRequest);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When changing a made-up user, Then should return 404 response', async () => {
      const userRequest = {
        firstName: 'Not',
        lastName: 'GonnaWork',
      };

      const response = await supertest(app)
        .patch(`${ENDPOINTS.MIGRATE_USER}/8888888`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: 'User Not Found',
        },
      ]);
    });

    function patchUser(
      userRequest: object,
      alcumusUserId: number
    ): supertest.Test {
      return supertest(app)
        .patch(`${ENDPOINTS.MIGRATE_USER}/${alcumusUserId}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);
    }

    it('When profile update submitted with valid API key, returns 200 response containing user profile', async () => {
      const migrationRecord = await createUser(
        'Bruce',
        'Banner',
        organizationId
      );
      const userRequest = {
        firstName: 'The',
        lastName: 'Hulk',
      };

      const response = await patchUser(
        userRequest,
        migrationRecord.alcumusUserId
      );
      expect([response.status, response.body]).toEqual([
        200,
        expect.objectContaining(userRequest),
      ]);
      expect(authProviderLookup).not.toHaveBeenCalledTimes(1);
    });

    it('When changing a user with multiple organizations, Then should return 200 response with correct org', async () => {
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId
      );
      await createAdditionalOrganizationAccount(
        migrationResult.userId,
        generateRandomNumber()
      );

      const userRequest = {
        firstName: 'Incredible',
        lastName: 'Hulk',
      };

      const response = await patchUser(
        userRequest,
        migrationResult.alcumusUserId
      );
      expect([response.status, response.body]).toEqual([
        200,
        expect.objectContaining(userRequest),
      ]);
      expect(authProviderLookup).not.toHaveBeenCalledTimes(1);
    });
  });

  describe('GET /:alcumusUserId', () => {
    it('When retrieving a user, Should return 200 response with body', async () => {
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId
      );
      const response = await supertest(app)
        .get(`${ENDPOINTS.MIGRATE_USER}/${migrationResult.alcumusUserId}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, migrationResult]);
    });
  });
});

function mockUserUpdate(
  internalAccountId: string,
  accountRequest: AccountRequest,
  prefix: string
): jest.Mock[] {
  const mockLogin = mockKeycloakAuth({
    clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
    grantType: 'client_credentials',
  });
  const mockUserUpdate = mockKeycloakUserEdit(
    internalAccountId,
    accountRequest.email ? prefix + accountRequest.email : undefined,
    accountRequest.username ? prefix + accountRequest.username : undefined,
    accountRequest.isEnabled !== undefined ? accountRequest.isEnabled : true
  );
  return [mockLogin, mockUserUpdate];
}
