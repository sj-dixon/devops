import { app } from '../testApp';
import { ENDPOINTS } from '../../../../src/constants';
import { Model } from 'objection';
import connectToKnex, { Knex } from 'knex';
import knexConfig from '../../../../src/lib/clients/knex/config';
import { Utilities } from '@alcumus/globals';
import {
  ENVIRONMENT,
  generateRandomNumber,
  mockApiAuthProviderLookup,
  mockAuthProviderLookup,
  mockKeycloakAccountCreation,
  mockKeycloakAuth,
  mockOrganizationLookup,
} from '../testHelpers';
import supertest from 'supertest';
import { v4 as uuidV4 } from 'uuid';
import fs from 'fs';
import { promisify } from 'util';
import path from 'path';
import { Buffer } from 'buffer';
import { UserAccountEntity } from '../../../../src/models/userAccountEntity';
import {
  createAdditionalOrganizationAccount,
  createUser,
} from './migrationTestHelpers';
import { UserAccountType } from '../../../../src/types/userAccount';
import { OrganizationAuthProviderType } from '../../../../src/lib/tenants/types';

const AUTH_PROVIDER_NAME = 'UNKNOWN';
const internalAccountId = uuidV4();
let knex: Knex;

describe('/api/v1/migrate/{organizationId}/', () => {
  let organizationId: number;
  let organizationLookup: jest.Mock;
  let authProviderLookup: jest.Mock;

  beforeAll(async () => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(knexConfig);
    Model.knex(knex);
  });

  beforeEach(() => {
    organizationId = generateRandomNumber();
    organizationLookup = mockOrganizationLookup(organizationId);
    authProviderLookup = mockApiAuthProviderLookup(
      organizationId,
      AUTH_PROVIDER_NAME
    );
  });

  afterAll(async () => {
    await knex.destroy();
  });

  describe('POST /users/register', () => {
    it('When adding user without an api key, Then should return 401 response', async () => {
      const userRequest = {
        firstName: 'Tony',
        lastName: 'Stark',
        isEnabled: true,
        email: `tony.stark.${organizationId}@avengers.com`,
        username: `tony.stark.${organizationId}`,
        password: 'insecure',
      };
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/register`)
        .send(userRequest);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
      expect(organizationLookup).not.toHaveBeenCalled();
    });

    it('When adding user with insecure password, Then should retrieve it and receive 200 response', async () => {
      const [mockLogin, mockPostUser] = setupKeycloakMocks(internalAccountId);
      const mockAuthProvider = mockAuthProviderLookup(
        organizationId,
        `org${organizationId}`
      );
      const userRequest = {
        firstName: 'Tony',
        lastName: 'Stark',
        isEnabled: true,
        email: `tony.stark.${organizationId}@avengers.com`,
        username: `tony.stark.${organizationId}`,
        password: 'insecure',
      };
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/register`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);
      const persistedAccount = await UserAccountEntity.findByLoginIdentifiers(
        userRequest.email,
        organizationId
      );
      expect(persistedAccount).toEqual(
        expect.objectContaining({
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
          scopedToOrganizationId: organizationId,
          requiresPasswordReset: false,
        })
      );
      expect([response.status, response.body]).toEqual([
        201,
        {
          userId: persistedAccount?.userId,
          alcumusUserId: response.body?.userOrganizationId,
          firstName: userRequest.firstName,
          lastName: userRequest.lastName,
          organizationId,
          userOrganizationId: expect.any(Number),
          userOrganizationAccountId: persistedAccount?.id,
          email: userRequest.email,
          username: userRequest.username,
          isEnabled: true,
          authProviderName: OrganizationAuthProviderType.KEYCLOAK,
          userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
          internalAccountId,
        },
      ]);
      expect(mockLogin).toHaveBeenCalled();
      expect(mockPostUser).toHaveBeenCalled();
      expect(mockAuthProvider).toHaveBeenCalled();
      expect(organizationLookup).toHaveBeenCalled();
    });

    it('When adding user with same username twice, Then should retrieve it and receive 200 response', async () => {
      const internalAccountId2 = uuidV4();
      const organizationId2 = generateRandomNumber();
      const [[mockLogin1, mockPostUser1], [mockLogin2, mockPostUser2]] = [
        setupKeycloakMocks(internalAccountId),
        setupKeycloakMocks(internalAccountId2),
      ];
      const organizationLookup2 = mockOrganizationLookup(organizationId2);
      const mockAuthProvider1 = mockAuthProviderLookup(
        organizationId,
        `org${organizationId}`
      );
      const mockAuthProvider2 = mockAuthProviderLookup(
        organizationId2,
        `org${organizationId2}`
      );
      const userRequest = {
        firstName: 'Tony',
        lastName: 'Stark',
        isEnabled: true,
        email: `tony.stark@avengers.com`,
        username: `tony.stark`,
        password: 'insecure',
      };
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/register`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);

      const response2 = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId2}/users/register`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userRequest);

      expect([response.status, response.body]).toEqual([
        201,
        expect.objectContaining({
          username: userRequest.username,
          email: userRequest.email,
          organizationId: organizationId,
        }),
      ]);

      expect([response2.status, response2.body]).toEqual([
        201,
        expect.objectContaining({
          username: userRequest.username,
          email: userRequest.email,
          organizationId: organizationId2,
        }),
      ]);
      expect(mockLogin1).toHaveBeenCalledTimes(1);
      expect(mockPostUser1).toHaveBeenCalledTimes(1);
      expect(mockAuthProvider1).toHaveBeenCalledTimes(1);
      expect(organizationLookup).toHaveBeenCalledTimes(1);

      expect(mockLogin2).toHaveBeenCalledTimes(1);
      expect(mockPostUser2).toHaveBeenCalledTimes(1);
      expect(mockAuthProvider2).toHaveBeenCalledTimes(1);
      expect(organizationLookup2).toHaveBeenCalledTimes(1);
    });
  });

  describe('POST /users/batch', () => {
    let duplicatesFile: Buffer;

    beforeAll(async () => {
      duplicatesFile = await promisify(fs.readFile)(
        path.join(__dirname, 'duplicatesTest.xlsx')
      );
    });

    it('When adding user without an api key, Then should return 401 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/batch`)
        .set('x-api-client-app', AUTH_PROVIDER_NAME)
        .attach('file', Buffer.from('this is a string'));
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When adding user without an api client name, Then should return 400 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/batch`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .attach('file', Buffer.from('this is a string'));
      expect([response.status, response.body]).toEqual([
        400,
        {
          message:
            "request.headers should have required property 'x-api-client-app'",
        },
      ]);
    });

    it('When adding user with an invalid api client name, Then should return 422 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/batch`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', 'WRONG VALUE')
        .attach('file', Buffer.from('this is a string'));
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: `Organization ${organizationId} does not have an auth provider with name "WRONG VALUE" that can be used to migrate passwords`,
        },
      ]);
    });

    it('When uploading something other than an excel file, Then should return 400 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/batch`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', AUTH_PROVIDER_NAME)
        .attach('file', Buffer.from('this is a string'));
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: 'Please upload a file',
        },
      ]);
      expect(organizationLookup).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(1);
    });

    it('When uploading excel with invalid mime type, Then should return 400 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/batch`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', AUTH_PROVIDER_NAME)
        .attach('file', duplicatesFile, {
          contentType: 'application/octet-stream',
          filename: 'something.xlsx',
        });
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: 'Please upload an excel file',
        },
      ]);
      expect(organizationLookup).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(1);
    });

    it('When adding duplicated users, Then should return 422 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users/batch`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', AUTH_PROVIDER_NAME)
        .attach('file', duplicatesFile, {
          contentType:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          filename: 'something.xlsx',
        });
      expect([response.status, response.body]).toEqual([
        422,
        [
          {
            key: 'users.bulkUpload.emailMustBeUnique',
            message: 'Email was found multiple times in bulk upload file',
            rowNumber: 3,
          },
        ],
      ]);
      expect(organizationLookup).toHaveBeenCalledTimes(1);
      expect(authProviderLookup).toHaveBeenCalledTimes(1);
    });
  });

  describe('GET /users', () => {
    it('When getting users of non-existent organization, Then should return 404 response', async () => {
      const id = generateRandomNumber();
      const response = await supertest(app)
        .get(`${ENDPOINTS.MIGRATE_TENANT}/${id}/users`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Organization ${id} not found`,
        },
      ]);
    });

    it('When getting users, Then should retrieve list of users and receive 200 response', async () => {
      const expectedUser = await createUser('Tony', 'Stark', organizationId);
      const response = await supertest(app)
        .get(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, [expectedUser]]);
      expect(organizationLookup).toHaveBeenCalledTimes(1);
    });

    it('Characterization - When user has two accounts, return both as separate records', async () => {
      const [firstName, lastName] = ['Robert', 'Stark'];
      const expectedUser = await createUser(
        firstName,
        lastName,
        organizationId
      );

      // also add the personal account to the list.
      const additionalAccount = await UserAccountEntity.create(undefined, {
        userId: expectedUser.userId,
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
        username: `${firstName}.${lastName}.${organizationId}`,
        email: `${firstName}.${lastName}.${organizationId}@avengers.com`,
        isEnabled: true,
        authProviderName: OrganizationAuthProviderType.KEYCLOAK,
        requiresPasswordReset: false,
      });

      const response = await supertest(app)
        .get(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        200,
        expect.arrayContaining([
          expectedUser,
          {
            ...expectedUser,
            userAccountType: additionalAccount.userAccountType,
            userOrganizationAccountId: additionalAccount.id,
            internalAccountId: additionalAccount.internalAccountId,
            authProviderName: additionalAccount.authProviderName,
            email: additionalAccount.email,
            username: additionalAccount.username,
          },
        ]),
      ]);
      expect(organizationLookup).toHaveBeenCalledTimes(1);
    });

    it('When getting users, Then should exclude organization accounts scoped to other organizations', async () => {
      const [firstName, lastName] = ['Robert', 'Stark'];
      const otherOrganizationId = generateRandomNumber();

      const expectedUser = await createUser(
        firstName,
        lastName,
        organizationId
      );
      await createAdditionalOrganizationAccount(
        expectedUser.userId,
        otherOrganizationId
      );

      const response = await supertest(app)
        .get(`${ENDPOINTS.MIGRATE_TENANT}/${organizationId}/users`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, [expectedUser]]);
      expect(organizationLookup).toHaveBeenCalledTimes(1);
    });
  });
});

export function setupKeycloakMocks(keycloakAccountId: string): jest.Mock[] {
  const mockLogin = mockKeycloakAuth({
    clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
    grantType: 'client_credentials',
  });
  const mockPostUser = mockKeycloakAccountCreation(keycloakAccountId);
  return [mockLogin, mockPostUser];
}
