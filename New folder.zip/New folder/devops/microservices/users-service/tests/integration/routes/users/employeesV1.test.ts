import { ENVIRONMENT, getAuthToken } from '../testHelpers';
import { app } from '../testApp';
import request from 'supertest';
import { ENDPOINTS } from '../../../../src/constants';
import { UserEntity } from '../../../../src/models/userEntity';
import config from '../../../../src/knexfile';
import connect, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities } from '@alcumus/globals';
import { v4 as uuidV4 } from 'uuid';
import { UserOrganizationEntity } from '../../../../src/models/userOrganizationEntity';

describe('/api/v1/employees', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;
  let encodedUserInfo: string;
  let user: UserEntity;
  let userOrganization: UserOrganizationEntity;

  beforeAll(async () => {
    knex = connect(config);
    Model.knex(knex);
    const internalAccountId = uuidV4();
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => 1487076708000);

    user = await UserEntity.create({
      firstName: 'Luis de Margarita',
      lastName: 'Silva von Ambergris',
    });
    userOrganization = await UserOrganizationEntity.create({
      organizationId: 12,
      userId: user.id,
    });
    encodedUserInfo = getAuthToken({
      sub: internalAccountId,
    });

    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  });

  afterAll(async () => {
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  describe(`GET /:alcumusUserId`, () => {
    it('returns a single user from the database', async () => {
      const response = await request(app)
        .get(`${ENDPOINTS.EMPLOYEES}/${userOrganization.id}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, user]);
    });
  });
});
