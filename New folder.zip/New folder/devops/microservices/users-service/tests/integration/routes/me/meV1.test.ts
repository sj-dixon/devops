import knexConfig from '../../../../src/knexfile';
import supertest from 'supertest';
import '../evilMock';
import {
  createUserWithAccount,
  generateRandomNumber,
  getAuthToken,
  ENVIRONMENT,
  FAKE_TIME_FN,
} from '../testHelpers';
import { app } from '../testApp';
import { Utilities } from '@alcumus/globals';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { ENDPOINTS } from '../../../../src/constants';
import { UserEntity } from '../../../../src/models/userEntity';
import { v4 as uuidV4 } from 'uuid';

const OLD_PASSWORD = 'Aa12345678!@';

describe('integration: PATCH users-service / routes / users', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;

  let encodedUserInfo: string;
  let userAccount: UserEntity;
  let username: string;
  let internalAccountId: string;

  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(knexConfig);
    Model.knex(knex);
    dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(FAKE_TIME_FN);
  });
  afterAll(async () => {
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  beforeEach(async () => {
    const randomId = generateRandomNumber();
    internalAccountId = uuidV4();
    username = `meV1-${randomId}`;
    [userAccount] = await createUserWithAccount(
      {
        createAccount: true,
        email: `meV1-${randomId}@mev1.ts`,
        username,
        firstName: 'Tony',
        lastName: 'Stark',
        phoneNumber: '123456789',
        password: OLD_PASSWORD,
      },
      internalAccountId
    );
    encodedUserInfo = getAuthToken({
      sub: internalAccountId,
    });
  });

  describe('GET /me', () => {
    it('returns current user account', async () => {
      const result = await supertest(app)
        .get(ENDPOINTS.ME)
        .auth(encodedUserInfo, { type: 'bearer' })
        .send();
      expect([result.status, result.body]).toEqual([200, userAccount]);
    });
  });

  describe('PATCH /me', () => {
    it('patches profile information without touching keycloak', async () => {
      const update = {
        firstName: 'Iron',
        lastName: 'Man',
      };
      const patchResult = await supertest(app)
        .patch(ENDPOINTS.ME)
        .auth(encodedUserInfo, { type: 'bearer' })
        .send(update);
      expect([patchResult.status, patchResult.body]).toEqual([
        200,
        {
          ...userAccount,
          ...update,
        },
      ]);
    });
  });

  describe('middlewares', () => {
    it('accepts empty request', async () => {
      const patchResult = await supertest(app)
        .patch(ENDPOINTS.ME)
        .auth(encodedUserInfo, { type: 'bearer' })
        .send({});
      expect([patchResult.status, patchResult.body]).toEqual([
        200,
        userAccount,
      ]);
    });
  });
});
