import supertest from 'supertest';
import { app } from '../testApp';
import { ENDPOINTS } from '../../../../src/constants';
import { BAD_REQUEST_STATUS } from '../../../unit/middleware/testHelpers';
import { ENVIRONMENT } from '../testHelpers';
import { CreateUserRequest } from '../../../../src/types';
import { Utilities } from '@alcumus/globals';

describe('integration: PATCH users-service / routes / users', () => {
  function assertResponseHasExpectedError(
    result: supertest.Response,
    errorProperty: string,
    errorKey: string
  ) {
    expect([result.status, result.body]).toEqual([
      BAD_REQUEST_STATUS,
      {
        errors: {
          [errorProperty]: {
            key: errorKey,
            message: errorKey,
          },
        },
      },
    ]);
  }

  describe(`POST ${ENDPOINTS.USERS}`, () => {
    beforeAll(() => {
      Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    });

    function sendPostAndExpectError(
      update: CreateUserRequest,
      errorProperty: string,
      errorKey: string
    ) {
      return async () => {
        const postResult = await supertest(app)
          .post(ENDPOINTS.USERS)
          .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
          .send(update);
        assertResponseHasExpectedError(postResult, errorProperty, errorKey);
      };
    }

    it(
      'requires email does not exist if not creating credentials',
      sendPostAndExpectError(
        {
          email: 'notanEmail',
          createAccount: false,
          firstName: 'Tony',
          lastName: 'Stark',
          password: 'Aab123123123!',
        },
        'email',
        'users.new.cannotSpecifyEmailIfNoAccountCreated'
      )
    );

    it(
      'requires email to be email',
      sendPostAndExpectError(
        {
          email: 'notanEmail',
          createAccount: true,
          firstName: 'Tony',
          lastName: 'Stark',
          password: 'Aab123123123!',
        },
        'email',
        'users.new.mustHaveEmailIfUserNameNotPresent'
      )
    );

    it(
      'requires password if creating credentials',
      sendPostAndExpectError(
        {
          createAccount: true,
          email: 'tony.stark@avengers.com',
          firstName: 'Tony',
          lastName: 'Stark',
        },
        'password',
        'users.new.mustSpecifyPasswordWhenCreatingAccounts'
      )
    );

    it(
      'requires strong password if creating credentials',
      sendPostAndExpectError(
        {
          createAccount: true,
          email: 'tony.stark@avengers.com',
          firstName: 'Tony',
          lastName: 'Stark',
          password: 'weaksauce',
        },
        'password',
        'users.password.strongPasswordRequired'
      )
    );
  });
});
