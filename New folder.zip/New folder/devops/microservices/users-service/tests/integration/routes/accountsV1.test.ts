import request from 'supertest';
import { app } from './testApp';
import { ENDPOINTS } from '../../../src/constants';
import { Utilities } from '@alcumus/globals';
import {
  AzureAdAccountRequestBody,
  AzureAdAccountResponseBody,
} from '../../../src/lib/clients/azureAd/types';
import { UserAccountEntity } from '../../../src/models/userAccountEntity';
import { UserAccount, UserAccountType } from '../../../src/types/userAccount';
import { OrganizationAuthProviderType } from '../../../src/lib/tenants/types';
import knexConfig from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { UserEntity } from '../../../src/models/userEntity';
import { v4 as uuidV4 } from 'uuid';
import {
  ENVIRONMENT,
  generateRandomNumber,
  mockLookupFailure,
  mockOrganizationLookupByIdentifier,
} from './testHelpers';

let knex: Knex;
beforeAll(() => {
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

const { SERVICE_MESH_API_KEY } = ENVIRONMENT;
const AZURE_AD_CALLBACK_API_KEY = 'sugar pie';

describe('/users/api/v1/accounts', () => {
  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv({
      ...ENVIRONMENT,
      AZURE_AD_CALLBACK_API_KEY,
    });
  });
  describe('POST /', () => {
    it('Given missing api key, returns 401', async () => {
      const objectId = uuidV4();
      const body: AzureAdAccountRequestBody = getRequest(objectId);
      const response = await request(app).post(ENDPOINTS.ACCOUNTS).send(body);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-azure-api-key' header required",
        },
      ]);
    });
    it('Given invalid api key, returns 401', async () => {
      const objectId = uuidV4();
      const body: AzureAdAccountRequestBody = getRequest(objectId);
      const response = await request(app)
        .post(ENDPOINTS.ACCOUNTS)
        .set('x-azure-api-key', 'not correct')
        .send(body);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-azure-api-key header has an incorrect api key',
        },
      ]);
    });

    it('Given valid api key and user, creates user', async () => {
      const objectId = uuidV4();
      const body: AzureAdAccountRequestBody = getRequest(objectId);

      const response = await request(app)
        .post(ENDPOINTS.ACCOUNTS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(body);
      const expected: UserAccount & { id: number } = {
        id: response.body.userAccountId,
        userId: response.body.userId,
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
        authProviderName: OrganizationAuthProviderType.AZURE_AD,
        internalAccountId: objectId,
        scopedToOrganizationId: null,
        email: body.email,
        isEnabled: true,
        username: null,
        createdAt: expect.any(String),
        modifiedAt: expect.any(String),
        dataImportFileId: null,
        dataImportRowId: null,
        phoneNumber: null,
        deletedAt: null,
        requiresPasswordReset: false,
      };
      const persisted = await UserAccountEntity.findByInternalAccountId(
        objectId
      );
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedAccountAfterAzureInitiatedAccountCreation(body),
      ]);
      expect(persisted).toEqual(expected);
    });

    it('When creating user with already used login identifiers, returns 500 error', async () => {
      const existingObjectId = uuidV4();
      const objectId = uuidV4();
      const body: AzureAdAccountRequestBody = getRequest(objectId);

      await createExistingUser(existingObjectId, body);

      const response = await request(app)
        .post(ENDPOINTS.ACCOUNTS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(body);

      expect([response.status, response.body]).toEqual([
        409,
        getEmailConflictMatcher(body.email),
      ]);
    });

    it('If called twice, returns error second time', async () => {
      const objectId = uuidV4();
      const body: AzureAdAccountRequestBody = getRequest(objectId);
      const response1 = await request(app)
        .post(ENDPOINTS.ACCOUNTS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(body);
      const response2 = await request(app)
        .post(ENDPOINTS.ACCOUNTS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(body);

      expect([response1.status, response1.body]).toEqual([
        200,
        getExpectedAccountAfterAzureInitiatedAccountCreation(body),
      ]);
      expect([response2.status, response2.body]).toEqual([
        409,
        getEmailConflictMatcher(body.email),
      ]);
    });
  });

  describe('GET /usernames/:loginIdentifier', () => {
    it('Given missing api key, returns 401', async () => {
      const response = await request(app)
        .get(`${ENDPOINTS.ACCOUNTS}/usernames/${uuidV4()}`)
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });
    it('Given invalid api key, returns 401', async () => {
      const response = await request(app)
        .get(`${ENDPOINTS.ACCOUNTS}/usernames/${uuidV4()}`)
        .set('x-api-key', 'not correct')
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('given nonexistent username, returns 404', async () => {
      const identifier = uuidV4();
      const response = await request(app)
        .get(`${ENDPOINTS.ACCOUNTS}/usernames/${identifier}`)
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `No user account was found for login ${identifier}`,
        },
      ]);
    });

    it('given nonexistent organization identifier, returns 404', async () => {
      const userIdentifier = uuidV4();
      const organizationIdentifier = uuidV4();
      const url = `/v1/auth/${organizationIdentifier}`;
      const mockLookup = mockLookupFailure(url);

      const response = await request(app)
        .get(
          `${ENDPOINTS.ACCOUNTS}/usernames/${userIdentifier}?organizationIdentifier=${organizationIdentifier}`
        )
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `No organization found with identifier ${organizationIdentifier}.`,
        },
      ]);
      expect(mockLookup).toHaveBeenCalledTimes(1);
    });

    it(
      'given valid personal account email, returns 200 with account',
      returnsValidPersonalAccount({
        email: `${uuidV4()}@example.com`,
      })
    );

    it(
      'given valid personal account username, returns 200 with account',
      returnsValidPersonalAccount({
        username: uuidV4(),
      })
    );

    it(
      'given valid organization account username, returns 200 with account',
      returnsValidOrganizationAccount({
        username: uuidV4(),
      })
    );

    it(
      'given valid organization account username, returns 200 with account',
      returnsValidOrganizationAccount({
        email: `${uuidV4()}@example.com`,
      })
    );
  });

  describe('PATCH /usernames/:loginIdentifier', () => {
    const requestBody = {
      objectId: uuidV4(),
      authProviderType: OrganizationAuthProviderType.AZURE_AD,
    };

    it('Given missing api key, returns 401', async () => {
      const response = await request(app)
        .patch(`${ENDPOINTS.ACCOUNTS}/usernames/${uuidV4()}`)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('Given invalid api key, returns 401', async () => {
      const response = await request(app)
        .patch(`${ENDPOINTS.ACCOUNTS}/usernames/${uuidV4()}`)
        .set('x-api-key', 'not correct')
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('given nonexistent username, returns 404', async () => {
      const identifier = uuidV4();
      const response = await request(app)
        .patch(`${ENDPOINTS.ACCOUNTS}/usernames/${identifier}`)
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `No user account was found for login ${identifier}`,
        },
      ]);
    });

    it('given nonexistent organization identifier, returns 404', async () => {
      const userIdentifier = uuidV4();
      const organizationIdentifier = uuidV4();
      const url = `/v1/auth/${organizationIdentifier}`;
      const mockLookup = mockLookupFailure(url);

      const response = await request(app)
        .patch(
          `${ENDPOINTS.ACCOUNTS}/usernames/${userIdentifier}?organizationIdentifier=${organizationIdentifier}`
        )
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `No organization found with identifier ${organizationIdentifier}.`,
        },
      ]);
      expect(mockLookup).toHaveBeenCalledTimes(1);
    });

    it('given keycloak user, updates account information', async () => {
      const userIdentifier = uuidV4();

      const user = await UserEntity.create({
        firstName: uuidV4(),
        lastName: uuidV4(),
      });
      const account = await UserAccountEntity.create(undefined, {
        username: userIdentifier,
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
        email: `${userIdentifier}@example.com`,
        scopedToOrganizationId: null,
        userId: user.id,
        authProviderName: OrganizationAuthProviderType.KEYCLOAK,
        isEnabled: true,
        internalAccountId: uuidV4(),
        requiresPasswordReset: false,
      });

      const response = await request(app)
        .patch(`${ENDPOINTS.ACCOUNTS}/usernames/${userIdentifier}`)
        .set('x-api-key', SERVICE_MESH_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        200,
        {
          ...account,
          internalAccountId: requestBody.objectId,
          authProviderName: requestBody.authProviderType,
          requiresPasswordReset: false,
        },
      ]);
    });
  });
});

function getRequest(objectId: string): AzureAdAccountRequestBody {
  return {
    userPrincipalName: `${objectId}@servicesqabi.onmicrosoft.com`,
    email: `alcumusdevelopers+${objectId}@gmail.com`,
    objectId,
    surname: 'Mac',
    givenName: 'Big',
    displayName: 'Big Mac',
  };
}

function getExpectedAccountAfterAzureInitiatedAccountCreation(
  request: AzureAdAccountRequestBody
): object {
  const subset: AzureAdAccountResponseBody = {
    authProviderName: OrganizationAuthProviderType.AZURE_AD,
    scopedToOrganizationId: null,
    userId: expect.any(Number),
    userAccountId: expect.any(Number),
    internalAccountId: request.objectId,
    username: null,
    email: request.email,
    dataImportFileId: null,
    dataImportRowId: null,
    isEnabled: true,
    phoneNumber: null,
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    firstName: request.givenName,
    lastName: request.surname,
    requiresPasswordReset: false,
  };
  return {
    ...subset,
    id: expect.any(Number),
    deletedAt: null,
    createdAt: expect.any(String),
    modifiedAt: expect.any(String),
  };
}

async function createExistingUser(
  objectId: string,
  body: AzureAdAccountRequestBody,
  requiresPasswordReset = false
): Promise<void> {
  const existingUser = await UserEntity.create({
    firstName: 'Henry',
    lastName: 'Sugar',
  });

  await UserAccountEntity.create(undefined, {
    userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    authProviderName: OrganizationAuthProviderType.AZURE_AD,
    userId: existingUser.id,
    internalAccountId: objectId,
    email: body.email,
    scopedToOrganizationId: null,
    isEnabled: true,
    requiresPasswordReset,
  });
}

function getEmailConflictMatcher(email: string): object {
  return {
    message: `Email ${email} is already taken.`,
  };
}

function returnsValidPersonalAccount({
  username,
  email,
}: {
  username?: string;
  email?: string;
}): () => Promise<void> {
  return async () => {
    await endpointShouldReturnValidAccount({
      username,
      email,
      userAccountType: UserAccountType.PERSONAL_ACCOUNT,
    });
  };
}

function returnsValidOrganizationAccount({
  username,
  email,
}: {
  username?: string;
  email?: string;
}): () => Promise<void> {
  return async () => {
    const organizationIdentifier = uuidV4();
    const organizationId = generateRandomNumber();
    const mockLookup = mockOrganizationLookupByIdentifier(
      organizationIdentifier,
      organizationId
    );
    await endpointShouldReturnValidAccount({
      organizationIdentifier,
      organizationId,
      username,
      email,
      userAccountType: UserAccountType.ORGANIZATION_ACCOUNT,
    });
    expect(mockLookup).toHaveBeenCalledTimes(organizationIdentifier ? 1 : 0);
  };
}

async function endpointShouldReturnValidAccount({
  organizationIdentifier,
  organizationId,
  username,
  email,
  userAccountType,
}: {
  organizationIdentifier?: string;
  organizationId?: number;
  username?: string;
  email?: string;
  userAccountType: UserAccountType;
}): Promise<void> {
  const user = await UserEntity.create({
    firstName: uuidV4(),
    lastName: uuidV4(),
  });
  const account = await UserAccountEntity.create(undefined, {
    username,
    userAccountType,
    email,
    scopedToOrganizationId: organizationId,
    userId: user.id,
    authProviderName: OrganizationAuthProviderType.AZURE_AD,
    isEnabled: true,
    internalAccountId: uuidV4(),
    requiresPasswordReset: false,
  });

  const url = `${ENDPOINTS.ACCOUNTS}/usernames/${username || email}${
    organizationIdentifier
      ? `?organizationIdentifier=${organizationIdentifier}`
      : ''
  }`;
  const response = await request(app)
    .get(url)
    .set('x-api-key', SERVICE_MESH_API_KEY)
    .send();

  const expected = {
    ...account,
    firstName: user.firstName,
    lastName: user.lastName,
  };
  expect([response.status, response.body]).toEqual([200, expected]);
}
