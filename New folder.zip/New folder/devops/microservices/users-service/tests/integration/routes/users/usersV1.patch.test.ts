import '../evilMock';
import {
  createUserWithAccount,
  generateRandomNumber,
  getAuthToken,
  ENVIRONMENT,
  FAKE_TIME_FN,
} from '../testHelpers';
import { app } from '../testApp';
import knexConfig from '../../../../src/knexfile';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities } from '@alcumus/globals';
import supertest from 'supertest';
import { ENDPOINTS } from '../../../../src/constants';
import { UserEntity } from '../../../../src/models/userEntity';
import { v4 as uuidV4 } from 'uuid';

const OLD_PASSWORD = 'Aa12345678!@';

let knex: Knex;
let dateNowSpy: jest.SpyInstance;

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  knex = connectToKnex(knexConfig);
  Model.knex(knex);
  dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(FAKE_TIME_FN);
});

afterAll(async () => {
  await knex.destroy();
  dateNowSpy.mockClear();
});

describe('/api/v1/users', () => {
  let encodedUserInfo: string;
  let userEntity: UserEntity;
  let username: string;
  let internalAccountId: string;
  let email: string;

  beforeEach(async () => {
    const randomId = generateRandomNumber();
    internalAccountId = uuidV4();
    username = `usersV1-${randomId}`;
    email = `usersV1-${randomId}@usersV1.ts`;
    [userEntity] = await createUserWithAccount(
      {
        createAccount: true,
        email,
        username,
        firstName: 'Peter',
        lastName: 'Parker',
        password: OLD_PASSWORD,
      },
      internalAccountId
    );
    encodedUserInfo = getAuthToken({
      sub: internalAccountId,
    });
  });

  describe('PATCH /users/:userId', () => {
    it('can patch user profile without overwriting fields', async () => {
      const changes = {
        firstName: 'Spider',
        lastName: 'Man',
      };
      const patchResult = await supertest(app)
        .patch(`${ENDPOINTS.USERS}/${userEntity.id}`)
        .auth(encodedUserInfo, { type: 'bearer' })
        .send(changes);
      expect([patchResult.status, patchResult.body]).toEqual([
        200,
        {
          ...userEntity,
          ...changes,
        },
      ]);
    });
  });
});
