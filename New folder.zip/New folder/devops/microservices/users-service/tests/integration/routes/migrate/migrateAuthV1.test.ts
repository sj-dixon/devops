import { Utilities } from '@alcumus/globals';
import { ENVIRONMENT, generateRandomNumber, mockAxios } from '../testHelpers';
import knexConfig from '../../../../src/lib/clients/knex/config';
import supertest from 'supertest';
import { app } from '../testApp';
import { ENDPOINTS } from '../../../../src/constants';
import { createUser } from './migrationTestHelpers';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { v4 as uuidV4 } from 'uuid';

let knex: Knex;

describe('/api/v1/migrate/logins/', () => {
  let organizationId: number;
  let organizationIdentifier: string;
  let mockAuthProvider: jest.Mock;

  beforeAll(async () => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(knexConfig);
    Model.knex(knex);
  });

  beforeEach(() => {
    organizationIdentifier = uuidV4();
    organizationId = generateRandomNumber();
    mockAuthProvider = mockAuthProviderCall(
      organizationIdentifier,
      organizationId
    );
  });

  afterAll(async () => {
    await knex.destroy();
  });

  describe('GET :userIdentifier', () => {
    it('When requesting user without api token, returns 401 invalid', async () => {
      const loginIdentifier = uuidV4();
      const url = `${ENDPOINTS.MIGRATE_AUTH}/${organizationIdentifier}/logins/${loginIdentifier}`;
      const response = await supertest(app).get(url).send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
      expect(mockAuthProvider).not.toHaveBeenCalled();
    });

    it('When requesting non-existent organization using valid token, returns 404 not found', async () => {
      const organizationIdentifier2 = uuidV4();
      const loginIdentifier = uuidV4();
      const url = `${ENDPOINTS.MIGRATE_AUTH}/${organizationIdentifier2}/logins/${loginIdentifier}`;
      const mockAuthProvider404 = mockAuthProviderLookupFailure(
        organizationIdentifier2
      );
      const response = await supertest(app)
        .get(url)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `No organization found with identifier ${organizationIdentifier2}.`,
        },
      ]);
      expect(mockAuthProvider).not.toHaveBeenCalled();
      expect(mockAuthProvider404).toHaveBeenCalled();
    });

    it('When requesting non-existent user using valid token, returns 404 not found', async () => {
      const loginIdentifier = uuidV4();
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.MIGRATE_AUTH}/${organizationIdentifier}/logins/${loginIdentifier}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `No user found with identifier ${loginIdentifier}.`,
        },
      ]);
      expect(mockAuthProvider).toHaveBeenCalled();
    });

    it('When requesting user via username, return 200 and migration record', async () => {
      const username = `banner.${organizationId}`;
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId,
        { username }
      );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.MIGRATE_AUTH}/${organizationIdentifier}/logins/${username}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, migrationResult]);
      expect(mockAuthProvider).toHaveBeenCalled();
    });

    it('When requesting user via email, return 200 and migration record', async () => {
      const email = `banner.${organizationId}@example.com`;
      const migrationResult = await createUser(
        'Tony',
        'Stark',
        organizationId,
        { email }
      );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.MIGRATE_AUTH}/${organizationIdentifier}/logins/${email}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, migrationResult]);
      expect(mockAuthProvider).toHaveBeenCalled();
    });

    it('When requesting user via identifier when username=email, return 200 and migration record', async () => {
      const email = `banner.${organizationId}@example.com`;
      const migrationResult = await createUser(
        'Bruce',
        'Banner',
        organizationId,
        { username: email, email }
      );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.MIGRATE_AUTH}/${organizationIdentifier}/logins/${email}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, migrationResult]);
      expect(mockAuthProvider).toHaveBeenCalled();
    });

    it('When requesting user via identifier when two users have same username, return 200 and migration record', async () => {
      const username = `reusedAcrossMany`;
      const organizationId2 = generateRandomNumber();
      const migrationResult = await createUser(
        'Billy',
        'Banner',
        organizationId,
        { username }
      );
      await createUser('Billy', 'Banner', organizationId2, { username });

      const response = await supertest(app)
        .get(
          `${ENDPOINTS.MIGRATE_AUTH}/${organizationIdentifier}/logins/${username}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, migrationResult]);
      expect(mockAuthProvider).toHaveBeenCalled();
    });
  });
});

function mockAuthProviderCall(
  organizationIdentifier: string,
  organizationId: number
): jest.Mock {
  const url = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/auth/${organizationIdentifier}/authProviders`;
  const mockAuthProvider = jest.fn(() => [
    200,
    [
      {
        organizationId,
      },
    ],
  ]);
  mockAxios.onGet(url).replyOnce(mockAuthProvider);
  return mockAuthProvider;
}

function mockAuthProviderLookupFailure(
  organizationIdentifier: string
): jest.Mock {
  const url = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/auth/${organizationIdentifier}/authProviders`;
  const mockAuthProvider = jest.fn(() => [404, 'Not Found']);
  mockAxios.onGet(url).replyOnce(mockAuthProvider);
  return mockAuthProvider;
}
