import {
  ENVIRONMENT,
  generateRandomNumber,
  mockKeycloakAuth,
  FAKE_TIME_FN,
  mockKeycloakAccountCreation,
} from '../testHelpers';
import { app } from '../testApp';
import request, { Response, Test } from 'supertest';
import { ENDPOINTS } from '../../../../src/constants';
import knexConfig from '../../../../src/knexfile';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { CreateUserRequest } from '../../../../src/types';
import { extractUserFromRequest } from '../../../../src/lib/utils';
import { Utilities } from '@alcumus/globals';
import { v4 as uuidV4 } from 'uuid';
import { UserAccountEntity } from '../../../../src/models/userAccountEntity';
import { UserAccountType } from '../../../../src/types/userAccount';

describe('Integration Test: Users Service', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;

  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(knexConfig);
    Model.knex(knex);
    dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(FAKE_TIME_FN);
  });
  afterAll(async () => {
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  describe('POST /users', () => {
    let email: string;
    let phoneNumber: string;
    let agent: request.SuperTest<request.Test>;

    beforeEach(() => {
      phoneNumber = `${generateRandomNumber()}`;
      email = `john-${phoneNumber}@example.com`;
      agent = request(app);
    });

    function createUser(userToCreate: CreateUserRequest): Test {
      return agent
        .post(ENDPOINTS.USERS)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userToCreate);
    }

    function getUser(id: number): Test {
      return agent
        .get(`${ENDPOINTS.USERS}/${id}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
    }

    it('creates a user without credentials', (done) => {
      const userToCreate: CreateUserRequest = {
        firstName: 'John',
        lastName: 'Doe',
        createAccount: false,
      };
      const expected = {
        ...userToCreate,
        // override fields not kept
        createAccount: undefined,
        dataImportRowId: null,
        dataImportFileId: null,

        // mock out fields set by Objection
        id: expect.any(Number),
        deletedAt: null,
        modifiedAt: expect.any(String),
        createdAt: expect.any(String),
      };
      agent
        .post(ENDPOINTS.USERS)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(userToCreate)
        .expect(201)
        .expect((response: Response) => {
          expect(response.body).toEqual(expected);
        })
        .end(done);
    });

    it('can persist and then retrieve same entity from db', async (done) => {
      const userToCreate: CreateUserRequest = {
        firstName: 'John',
        lastName: 'Doe',
        createAccount: false,
      };
      const created = await createUser(userToCreate);
      const id = created.body.id;
      getUser(id)
        .expect(200)
        .expect((response: Response) => {
          expect(response.body).toEqual(created.body);
        })
        .end(done);
    });

    it('creates a user with a credential', async () => {
      const userToCreate: CreateUserRequest = {
        firstName: 'John',
        lastName: 'Doe',
        email,
        phoneNumber,
        username: `john-${phoneNumber}`,
        password: 'Aa12345678!!',
        createAccount: true,
      };

      const keycloakCredentialId = uuidV4();
      const mockLogin = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const mockPostUser = mockKeycloakAccountCreation(keycloakCredentialId);

      const created = await createUser(userToCreate);
      const userId = created.body.id;
      const user = await getUser(userId);
      const credentials = await UserAccountEntity.findByLoginIdentifiers(
        userToCreate.username as string
      );

      const expectedCredentials = {
        userId,
        internalAccountId: keycloakCredentialId,
        phoneNumber,
        username: userToCreate.username,
        email,
        userAccountType: UserAccountType.PERSONAL_ACCOUNT,
        scopedToOrganizationId: null,
        isEnabled: true,
      };

      expect([created.status, created.body]).toEqual([
        201,
        expect.objectContaining({
          ...extractUserFromRequest(userToCreate),
          credentials: expect.objectContaining(expectedCredentials),
        }),
      ]);
      expect(created.body).toEqual(expect.objectContaining(user.body));
      expect(created.body.credentials).toEqual(credentials);
      expect(mockLogin).toHaveBeenCalled();
      expect(mockPostUser).toHaveBeenCalled();

      // passwords that are set via API should be reset at the earliest
      // opportunity since it means that the user was not created
      // as a result of the invitation flow.
      expect(credentials?.requiresPasswordReset).toEqual(true);
    });

    it('creates a user with an email only', async () => {
      const userToCreate: CreateUserRequest = {
        firstName: 'John',
        lastName: 'Doe',
        email,
        phoneNumber,
        password: 'Aa12345678!!',
        createAccount: true,
      };

      const keycloakCredentialId = uuidV4();
      const mockLogin = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const mockPostUser = mockKeycloakAccountCreation(keycloakCredentialId);

      const created = await createUser(userToCreate);
      const credentials = await UserAccountEntity.findByLoginIdentifiers(
        userToCreate.email as string
      );

      expect(mockLogin).toHaveBeenCalledTimes(1);
      expect(mockPostUser).toHaveBeenCalledTimes(1);
      expect([created.status, created.body]).toEqual([
        201,
        expect.objectContaining({
          ...extractUserFromRequest(userToCreate),
          credentials: expect.objectContaining({
            userId: created.body?.id,
            internalAccountId: keycloakCredentialId,
            phoneNumber,
            username: null,
            email,
            userAccountType: UserAccountType.PERSONAL_ACCOUNT,
            scopedToOrganizationId: null,
            isEnabled: true,
          }),
        }),
      ]);

      // passwords that are set via API should be reset at the earliest
      // opportunity since it means that the user was not created
      // as a result of the invitation flow.
      expect(credentials?.requiresPasswordReset).toEqual(true);
    });

    it('rejected if user when necessary fields are not specified', (done) => {
      const userToCreate: CreateUserRequest = {
        firstName: 'John',
        lastName: 'Doe',
        phoneNumber,
        createAccount: true,
      };
      createUser(userToCreate).expect(
        400,
        {
          errors: {
            username: {
              key: 'users.new.mustHaveUserNameOrEmail',
              message: 'users.new.mustHaveUserNameOrEmail',
            },
            email: {
              key: 'users.new.mustHaveUserNameOrEmail',
              message: 'users.new.mustHaveUserNameOrEmail',
            },
            password: {
              key: 'users.new.mustSpecifyPasswordWhenCreatingAccounts',
              message: 'users.new.mustSpecifyPasswordWhenCreatingAccounts',
            },
          },
        },
        done
      );
    });
  });
});
