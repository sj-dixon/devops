import '../evilMock';
import {
  createUserWithAccount,
  ENVIRONMENT,
  generateRandomNumber,
  getAuthToken,
  mockKeycloakAuth,
  mockKeycloakPasswordChange,
  mockKeycloakUserEdit,
} from '../testHelpers';
import knexConfig from '../../../../src/knexfile';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { v4 as uuidV4 } from 'uuid';
import { UserEntity } from '../../../../src/models/userEntity';
import { app } from '../testApp';
import supertest, { Test } from 'supertest';
import { ENDPOINTS } from '../../../../src/constants';
import { UserAccountEntity } from '../../../../src/models/userAccountEntity';
import { Utilities } from '@alcumus/globals';
import { UserAccountType } from '../../../../src/types/userAccount';

const OLD_PASSWORD = 'Aa12345678!@';

describe('api/v1/users/{id}/accounts', () => {
  let knex: Knex;
  let encodedUserInfo: string;
  let userEntity: UserEntity;
  let userCredential: UserAccountEntity;
  let username: string;
  let email: string;
  let internalAccountId: string;

  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(knexConfig);
    Model.knex(knex);
  });
  afterAll(async () => {
    await knex.destroy();
  });

  beforeEach(async () => {
    const randomId = generateRandomNumber();
    internalAccountId = uuidV4();
    username = `meV1-${randomId}`;
    email = `meV1-${randomId}@mev1.ts`;

    [userEntity, userCredential] = await createUserWithAccount(
      {
        createAccount: true,
        email,
        username,
        firstName: 'Tony',
        lastName: 'Stark',
        phoneNumber: '123456789',
        password: OLD_PASSWORD,
      },
      internalAccountId
    );

    encodedUserInfo = getAuthToken({
      sub: internalAccountId,
    });
  });

  describe('GET /accounts', () => {
    it('retrieves user account credentials', async () => {
      const result = await supertest(app)
        .get(`${ENDPOINTS.USERS}/${userEntity.id}/accounts`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([result.status, result.body]).toEqual([200, [userCredential]]);
    });
  });

  describe('GET /accounts/{id}', () => {
    it('retrieves single credential by id', async () => {
      const result = await supertest(app)
        .get(
          `${ENDPOINTS.USERS}/${userEntity.id}/accounts/${userCredential.id}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([result.status, result.body]).toEqual([200, userCredential]);
    });
  });

  function getExpectedResult(username?: string, email?: string): object {
    return expect.objectContaining({
      username,
      email,
      userId: userEntity.id,
      id: userCredential.id,
      internalAccountId,
      userAccountType: UserAccountType.PERSONAL_ACCOUNT,
      deletedAt: null,
    });
  }

  describe('PATCH /accounts', () => {
    it('can change login identifiers', async () => {
      const patch = {
        email: `edit-${email}`,
        username: `edit-${username}`,
      };
      const adminLogin = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const loginChange = mockKeycloakUserEdit(
        internalAccountId,
        patch.email,
        patch.username,
        true
      );

      const patchResult = await patchUserAccounts(userEntity.id, patch);
      expect([patchResult.status, patchResult.body]).toEqual([
        200,
        getExpectedResult(patch.username, patch.email),
      ]);
      expect(adminLogin).toHaveBeenCalled();
      expect(loginChange).toHaveBeenCalled();
    });

    it('can change password', async () => {
      const adminLogin = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const patch = {
        newPassword: 'wildRose1234!@#$',
      };

      const passwordUpdate = mockKeycloakPasswordChange(
        internalAccountId,
        patch.newPassword
      );
      const updated = await patchUserAccounts(userEntity.id, patch);

      expect([updated.status, updated.body]).toEqual([
        200,
        getExpectedResult(username, email),
      ]);
      expect(adminLogin).toHaveBeenCalled();
      expect(passwordUpdate).toHaveBeenCalled();
    });
  });

  describe('PATCH /accounts/{id}', () => {
    it('can change login identifiers', async () => {
      const patch = {
        email: `edit-${email}`,
        username: `edit-${username}`,
      };
      const adminLogin = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const loginChange = mockKeycloakUserEdit(
        internalAccountId,
        patch.email,
        patch.username,
        true
      );

      const patchResult = await patchUserAccountWithId(
        userEntity.id,
        userCredential.id,
        patch
      );
      expect([patchResult.status, patchResult.body]).toEqual([
        200,
        getExpectedResult(patch.username, patch.email),
      ]);
      expect(adminLogin).toHaveBeenCalled();
      expect(loginChange).toHaveBeenCalled();
    });

    it('can change password', async () => {
      const adminLogin = mockKeycloakAuth({
        clientId: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
        grantType: 'client_credentials',
      });
      const patch = {
        newPassword: 'wildRose1234!@#$',
      };

      const passwordUpdate = mockKeycloakPasswordChange(
        internalAccountId,
        patch.newPassword
      );
      const updated = await patchUserAccountWithId(
        userEntity.id,
        userCredential.id,
        patch
      );

      expect([updated.status, updated.body]).toEqual([
        200,
        getExpectedResult(username, email),
      ]);
      expect(adminLogin).toHaveBeenCalled();
      expect(passwordUpdate).toHaveBeenCalled();
    });
  });

  function patchUserAccounts(userId: number, expected: object): supertest.Test {
    return supertest(app)
      .patch(`${ENDPOINTS.USERS}/${userId}/accounts`)
      .auth(encodedUserInfo, { type: 'bearer' })
      .send({ userId, ...expected });
  }

  function patchUserAccountWithId(
    userId: number,
    accountId: number,
    expected: object
  ): Test {
    return supertest(app)
      .patch(`${ENDPOINTS.USERS}/${userId}/accounts/${accountId}`)
      .auth(encodedUserInfo, { type: 'bearer' })
      .send({ userId, ...expected });
  }
});
