import { ENVIRONMENT, getAuthToken } from '../testHelpers';
import { app } from '../testApp';
import request from 'supertest';
import { ENDPOINTS } from '../../../../src/constants';
import { UserEntity } from '../../../../src/models/userEntity';
import { UserAccountEntity } from '../../../../src/models/userAccountEntity';
import config from '../../../../src/knexfile';
import connect, { Knex } from 'knex';
import { Model } from 'objection';
import { UserAccountType } from '../../../../src/types/userAccount';
import { OrganizationAuthProviderType } from '../../../../src/lib/tenants/types';
import { Utilities } from '@alcumus/globals';
import { v4 as uuidV4 } from 'uuid';

describe('/api/v1/users', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;
  let encodedUserInfo: string;
  let user: UserEntity;
  let credential: UserAccountEntity;

  beforeAll(async () => {
    knex = connect(config);
    Model.knex(knex);
    const internalAccountId = uuidV4();
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => 1487076708000);

    user = await UserEntity.create({
      firstName: 'Luis de Margarita',
      lastName: 'Silva von Ambergris',
    });
    encodedUserInfo = getAuthToken({
      sub: internalAccountId,
    });

    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);

    credential = await UserAccountEntity.create(undefined, {
      userAccountType: UserAccountType.PERSONAL_ACCOUNT,
      internalAccountId,
      email: `${user.id}@random.org`,
      username: `${user.id}`,
      userId: user.id,
      isEnabled: true,
      authProviderName: OrganizationAuthProviderType.KEYCLOAK,
      requiresPasswordReset: false,
    });
  });

  afterAll(async () => {
    await knex.destroy();
    dateNowSpy.mockClear();
  });

  describe(`GET /:userId`, () => {
    it('returns a single user from the database', async () => {
      const response = await request(app)
        .get(`${ENDPOINTS.USERS}/${user.id}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, user]);
    });
  });

  describe(`GET /:userId/credential`, () => {
    it('returns user credentials', async () => {
      const response = await request(app)
        .get(`${ENDPOINTS.USERS}/${user.id}/accounts`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.statusCode, response.body]).toEqual([200, [credential]]);
    });

    it('returns user credential for given credential id', async () => {
      const result = await request(app)
        .get(`${ENDPOINTS.USERS}/${user.id}/accounts/${credential.id}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([result.status, result.body]).toEqual([200, credential]);
    });
  });
});
