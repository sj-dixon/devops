import { UserOrganizationProductRowIntermediate } from '../../../../src/lib/bulkUpload/types';
import { validateIntermediates } from '../../../../src/lib/bulkUpload/validators';

describe('lib/bulkUpload/validators', () => {
  describe('validateIntermediates', () => {
    it('should not return a validation error if empty', () => {
      const result = validateIntermediates({
        intermediates: [],
      });
      expect(result).toEqual([]);
    });

    describe('First and Last Name Validation', () => {
      it('should expect every user to have a name', () => {
        const intermediate: UserOrganizationProductRowIntermediate = {
          userNumber: '1234',
        };
        const result = validateIntermediates({
          intermediates: [intermediate],
        });
        expect(result).toEqual([
          {
            key: 'users.dataImport.userMustHaveValueForColumn',
            message: `User does not have a single value for the first name column.`,
            rowNumber: 1,
          },
          {
            key: 'users.dataImport.userMustHaveValueForColumn',
            message: `User does not have a single value for the last name column.`,
            rowNumber: 1,
          },
          {
            key: 'users.dataImport.userMustHaveValueForColumn',
            message: `User does not have a single value for the email column.`,
            rowNumber: 1,
          },
        ]);
      });

      it('should expect every user to have a distinct name', () => {
        const intermediate1: UserOrganizationProductRowIntermediate = {
          firstName: 'Nelson',
          lastName: 'Mandela',
          userNumber: '1234',
          email: 'nelson@mandela.com',
        };
        const intermediate2: UserOrganizationProductRowIntermediate = {
          firstName: 'Jonny',
          userNumber: '1234',
          email: 'nelson@mandela.com',
        };
        const intermediate3: UserOrganizationProductRowIntermediate = {
          lastName: 'Appleseed',
          userNumber: '1234',
          email: 'nelson@mandela.com',
        };
        const result = validateIntermediates({
          intermediates: [intermediate1, intermediate2, intermediate3],
        });
        expect(result).toEqual([
          {
            key: 'users.dataImport.userMustNotHaveMultipleValuesForColumn',
            message: `Each user can have at most 1 first name, but found multiple: ${intermediate1.firstName} and ${intermediate2.firstName}.`,
            rowNumber: 2,
          },
          {
            key: 'users.dataImport.userMustNotHaveMultipleValuesForColumn',
            message: `Each user can have at most 1 last name, but found multiple: ${intermediate1.lastName} and ${intermediate3.lastName}.`,
            rowNumber: 3,
          },
        ]);
      });

      it('distinguishes between users', () => {
        const intermediate1: UserOrganizationProductRowIntermediate = {
          firstName: 'Nelson',
          lastName: 'Mandela',
          userNumber: '123',
          email: 'nelson@mandela.com',
        };
        const intermediate2: UserOrganizationProductRowIntermediate = {
          firstName: 'Nelson2',
          lastName: 'Mandela2',
          userNumber: '456',
          email: 'nelson2@mandela.com',
        };
        const intermediate3: UserOrganizationProductRowIntermediate = {
          firstName: 'Nelson2',
          lastName: 'Mandela2',
          userNumber: '5123',
          email: 'nelson3@mandela.com',
        };
        const actual = validateIntermediates({
          intermediates: [intermediate1, intermediate2, intermediate3],
        });
        expect(actual).toEqual([]);
      });

      it('allows redundant information to be omitted', () => {
        const intermediate1: UserOrganizationProductRowIntermediate = {
          firstName: 'Nelson',
          lastName: 'Mandela',
          userNumber: '123',
          email: 'nelson@mandela.com',
        };
        const intermediate2: UserOrganizationProductRowIntermediate = {
          firstName: intermediate1.firstName,
          userNumber: '123',
          email: 'nelson@mandela.com',
        };
        const intermediate3: UserOrganizationProductRowIntermediate = {
          lastName: intermediate1.lastName,
          userNumber: '123',
          email: 'nelson@mandela.com',
        };
        const intermediate4: UserOrganizationProductRowIntermediate = {
          firstName: 'Jonny',
          lastName: 'Appleseed',
          userNumber: '456',
          email: 'jonny@Appleseed.com',
        };
        const actual = validateIntermediates({
          intermediates: [
            intermediate1,
            intermediate2,
            intermediate3,
            intermediate4,
          ],
        });
        expect(actual).toEqual([]);
      });
    });

    describe('Email and Username Validation', () => {
      it('cannot have a single email mapped to two different user numbers', () => {
        const intermediate1: UserOrganizationProductRowIntermediate = {
          userNumber: '123',
          email: 'bobby@smiles.com',
          firstName: 'Bobby',
          lastName: 'Smiles',
        };
        const intermediate2: UserOrganizationProductRowIntermediate = {
          ...intermediate1,
          userNumber: '456',
        };
        const actual = validateIntermediates({
          intermediates: [intermediate1, intermediate2],
        });
        expect(actual).toEqual([
          {
            key: 'users.dataImport.userMustNotHaveMultipleValuesForColumn',
            message:
              'Each user can have at most 1 user number, but found multiple: 123 and 456.',
            rowNumber: 2,
          },
        ]);
      });

      // If we start requiring email for ALL users and do NOT allow usernames as an alternative,
      // stop calling this test a characterization test.
      it('Characterization - requires email address to exist', () => {
        const intermediate: UserOrganizationProductRowIntermediate = {
          userNumber: '123',
          firstName: 'Bobby',
          lastName: 'Smiles',
        };
        const actual = validateIntermediates({
          intermediates: [intermediate],
        });
        expect(actual).toEqual([
          {
            key: 'users.dataImport.userMustHaveValueForColumn',
            message: 'User does not have a single value for the email column.',
            rowNumber: 1,
          },
        ]);
      });

      it('cannot have invalid email address', () => {
        const base = {
          firstName: 'Bobby',
          lastName: 'Smiles',
        };
        const invalidIntermediates: UserOrganizationProductRowIntermediate[] = [
          {
            ...base,
            userNumber: '101',
            email: 'bobby',
          },
          {
            ...base,
            userNumber: '103',
            email: '@gmail.com',
          },
          {
            ...base,
            userNumber: '104',
            email: 'bobby@gmail',
          },
        ];
        const validIntermediates: UserOrganizationProductRowIntermediate[] = [
          {
            ...base,
            userNumber: '201',
            email: 'bobby+123@gmail.com',
          },
          {
            ...base,
            userNumber: '202',
            email: 'bobby123@gmail.com',
          },
          {
            ...base,
            userNumber: '102',
            email: 'bobby&@gmail.com',
          },
        ];

        const actual = validateIntermediates({
          intermediates: [...invalidIntermediates, ...validIntermediates],
        });
        const expected = invalidIntermediates.map(
          (
            intermediate: UserOrganizationProductRowIntermediate,
            index: number
          ) => ({
            key: 'users.dataImport.emailAddressMustBeValid',
            message: `Email address ${intermediate.email} is not recognized as a valid email.`,
            rowNumber: index + 1,
          })
        );
        expect(actual).toEqual(expected);
      });

      it('cannot have two emails/usernames associated with same user number', () => {
        const intermediate1: UserOrganizationProductRowIntermediate = {
          userNumber: '123',
          email: 'bobby@smiles.com',
          username: 'username1',
          firstName: 'Bobby',
          lastName: 'Smiles',
        };
        const intermediate2: UserOrganizationProductRowIntermediate = {
          ...intermediate1,
          email: 'bobby@grins.com',
          username: 'username2',
        };
        const actual = validateIntermediates({
          intermediates: [intermediate1, intermediate2],
        });
        expect(actual).toEqual([
          {
            key: 'users.dataImport.userMustNotHaveMultipleValuesForColumn',
            message:
              'Each user can have at most 1 email, but found multiple: bobby@smiles.com and bobby@grins.com.',
            rowNumber: 2,
          },
          {
            key: 'users.dataImport.userMustNotHaveMultipleValuesForColumn',
            message:
              'Each user can have at most 1 username, but found multiple: username1 and username2.',
            rowNumber: 2,
          },
        ]);
      });

      it('allows email to be shared by same user', () => {
        const intermediate1: UserOrganizationProductRowIntermediate = {
          userNumber: '123',
          email: 'bobby@smiles.com',
          firstName: 'Bobby',
          lastName: 'Smiles',
        };
        const intermediate2: UserOrganizationProductRowIntermediate = {
          userNumber: '123',
          email: 'bobby@smiles.com',
          firstName: 'Bobby',
          lastName: 'Smiles',
        };
        const intermediate3: UserOrganizationProductRowIntermediate = {
          userNumber: '123',
          email: 'bobby@smiles.com',
          firstName: 'Bobby',
          lastName: 'Smiles',
        };

        const actual = validateIntermediates({
          intermediates: [intermediate1, intermediate2, intermediate3],
        });
        expect(actual).toEqual([]);
      });
    });
  });
});
