import { UserOrganizationProductRowIntermediate } from '../../../../src/lib/bulkUpload/types';

export const lastName = 'last name';
export const firstName = 'first name';

export function getIntermediate({
  organizationIdentifier,
  organizationId,
  username,
  productType,
  userNumber,
}: {
  organizationId?: number;
  organizationIdentifier?: string;
  username?: string;
  productType?: string;
  userNumber?: string;
}): UserOrganizationProductRowIntermediate {
  return {
    organizationId,
    organizationIdentifier,
    username,
    email: `${username}@example.com`,
    firstName,
    lastName,
    productType,
    userNumber,
  };
}
