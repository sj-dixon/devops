import { v4 as uuidV4, validate } from 'uuid';
import { Types } from '@alcumus/globals';
import { UserOrganizationProductRowIntermediate } from '../../../../src/lib/bulkUpload/types';
import {
  getOrganizationProductMappingsByEmail,
  getOrGenerateUserNumbersByEmail,
} from '../../../../src/lib/bulkUpload/aggregators';
import { getIntermediate } from './helpers';

const dataImportFileId = 999;
const productType = 'Product1';
const userNumber = 'a12345';
const organizationId = 123;
const username = uuidV4();
const organizationIdentifier = 'org1';

let getter: jest.Mock = jest.fn();
let cache: Types.LookupCache<string, number>;

beforeEach(() => {
  getter.mockReset();
  cache = new Types.LookupCache<string, number>(getter);
});

describe('lib/bulkUpload/aggregators', () => {
  describe('getOrGenerateUserNumbersByEmail', () => {
    it('returns map of user numbers based on email', () => {
      const email = 'sharkie@isengard.com';
      const input: UserOrganizationProductRowIntermediate = {
        email,
      };
      const actual = getOrGenerateUserNumbersByEmail([input]);
      expect(actual).toEqual({
        [email]: expect.any(String),
      });
      expect(validate(actual[email])).toEqual(true);
      expect(input.userNumber).toEqual(actual[email]);
    });

    it('does not set user number if already set - single element', () => {
      const email = 'sharkie@isengard.com';
      const userNumber = '123142431';
      const input: UserOrganizationProductRowIntermediate = {
        email,
        userNumber,
      };
      const actual = getOrGenerateUserNumbersByEmail([input]);
      expect(actual).toEqual({
        [email]: userNumber,
      });
      expect(input.userNumber).toEqual(userNumber);
    });

    it('does not set user number if already set - two elements', () => {
      const email = 'sharkie@isengard.com';
      const userNumber = '123142431';
      const userNumber2 = '1231231';
      const input1: UserOrganizationProductRowIntermediate = {
        email,
        userNumber,
      };
      const input2: UserOrganizationProductRowIntermediate = {
        email,
        userNumber: userNumber2,
      };
      const actual = getOrGenerateUserNumbersByEmail([input1, input2]);
      expect(actual).toEqual({
        [email]: userNumber,
      });
      expect(input1.userNumber).toEqual(userNumber);
      expect(input2.userNumber).toEqual(userNumber2);
    });
  });

  describe('getOrganizationProductMappingsByEmail', () => {
    it('given 2 users in same company, returns 2 keys and one element each', async () => {
      const userNumber2 = 'abc1234';
      const username2 = 'obama';
      const rawRows = [
        getIntermediate({ organizationId, productType, userNumber, username }),
        getIntermediate({
          organizationId,
          productType,
          username: username2,
          userNumber: userNumber2,
        }),
      ];
      const expected = {
        [userNumber]: [
          {
            organizationId,
            dataImportFileId,
            productType,
            organizationIdentifier: undefined,
            userNumber,
          },
        ],
        [userNumber2]: [
          {
            organizationId,
            dataImportFileId,
            productType,
            organizationIdentifier: undefined,
            userNumber: userNumber2,
          },
        ],
      };
      const actual = await getDataImportRowMappings(rawRows);
      expect(actual).toEqual(expected);
      expect(getter).not.toHaveBeenCalled();
    });

    it('given 1 user in 2 companies, returns 1 key with two elements', async () => {
      const organizationId2 = 456;
      const username = uuidV4();
      const rawRows = [
        getIntermediate({ organizationId, productType, username, userNumber }),
        getIntermediate({
          organizationId: organizationId2,
          productType,
          username,
          userNumber,
        }),
      ];
      const expected = {
        [userNumber]: expect.arrayContaining([
          {
            organizationId,
            dataImportFileId,
            productType,
            organizationIdentifier: undefined,
            userNumber,
          },
          {
            organizationId: organizationId2,
            dataImportFileId,
            productType,
            organizationIdentifier: undefined,
            userNumber,
          },
        ]),
      };
      const actual = await getDataImportRowMappings(rawRows);
      expect(actual).toEqual(expected);
      expect(getter).not.toHaveBeenCalled();
    });

    it('given 1 user, 1 company and 2 products -> returns 1 key two elements', async () => {
      const product2 = 'Product2';
      const rawRows = [
        getIntermediate({ organizationId, productType, username, userNumber }),
        getIntermediate({
          organizationId,
          productType: product2,
          username,
          userNumber,
        }),
      ];
      const expected = {
        [userNumber]: expect.arrayContaining([
          {
            organizationId,
            dataImportFileId,
            userNumber,
            productType,
            organizationIdentifier: undefined,
          },
          {
            organizationId,
            dataImportFileId,
            userNumber,
            productType: product2,
            organizationIdentifier: undefined,
          },
        ]),
      };
      const actual = await getDataImportRowMappings(rawRows);
      expect(actual).toEqual(expected);
      expect(getter).not.toHaveBeenCalled();
    });

    it('given 1 user with organization identifier, uses cache to lookup id', async () => {
      getter.mockResolvedValueOnce(organizationId);
      const rawRows = [
        getIntermediate({ organizationIdentifier, productType, userNumber }),
      ];

      const expected = {
        [userNumber]: expect.arrayContaining([
          {
            organizationId,
            dataImportFileId,
            productType,
            organizationIdentifier,
            userNumber,
          },
        ]),
      };
      const actual = await getDataImportRowMappings(rawRows);
      expect(actual).toEqual(expected);
      expect(getter).toHaveBeenCalledWith(organizationIdentifier);
    });
  });
});

function getDataImportRowMappings(
  intermediates: UserOrganizationProductRowIntermediate[]
) {
  const userNumbersByEmail: Types.StringDictionary =
    getOrGenerateUserNumbersByEmail(intermediates);
  return getOrganizationProductMappingsByEmail({
    cache,
    userNumbersByEmail,
    intermediates,
    dataImportFileId,
  });
}
