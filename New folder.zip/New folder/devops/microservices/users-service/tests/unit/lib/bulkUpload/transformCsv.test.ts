import { v4 as uuidV4 } from 'uuid';
import { getDataImportRowsWithMappings } from '../../../../src/lib/bulkUpload/transformCsv';
import { Types } from '@alcumus/globals';
import {
  UserDataImportRowStatus,
  UserDataImportRowWithMappings,
} from '../../../../src/models/types';
import { getIntermediate, firstName, lastName } from './helpers';

const dataImportFileId = 999;
const productType = 'Product1';
const userNumber = 'a12345';
const organizationId = 123;
const username = uuidV4();

const EXPECTED_ROW_STATUS = UserDataImportRowStatus.LOADED;

describe('transformCsv', () => {
  let getter: jest.Mock = jest.fn();
  let cache: Types.LookupCache<string, number>;

  beforeEach(() => {
    getter.mockReset();
    cache = new Types.LookupCache<string, number>(getter);
  });

  describe('getDataImportRowsWithMappings', () => {
    it('given mappings object and employee number, returns object with mapping', async () => {
      const rawRow = getIntermediate({
        organizationId,
        username,
        productType,
        userNumber,
      });
      const actual = await getDataImportRowsWithMappings(
        dataImportFileId,
        [rawRow],
        cache
      );
      const expected: UserDataImportRowWithMappings[] = [
        {
          dataRow: {
            firstName,
            lastName,
            username,
            email: `${username}@example.com`,
            dataImportFileId,
            rowStatus: EXPECTED_ROW_STATUS,
            userNumber: userNumber,
            createdAt: expect.any(String),
          },
          mappings: [
            {
              dataImportFileId,
              organizationId,
              organizationIdentifier: undefined,
              userNumber: userNumber,
              productType,
            },
          ],
        },
      ];
      expect(actual).toEqual(expected);
    });

    it('given mappings object, returns object with mapping and generated number', async () => {
      const rawRow = getIntermediate({
        organizationId,
        username,
        productType,
        userNumber,
      });
      const actual = await getDataImportRowsWithMappings(
        dataImportFileId,
        [rawRow],
        cache
      );
      const expected: UserDataImportRowWithMappings[] = [
        {
          dataRow: {
            firstName,
            lastName,
            username,
            email: `${username}@example.com`,
            dataImportFileId,
            rowStatus: EXPECTED_ROW_STATUS,
            userNumber: expect.any(String),
            createdAt: expect.any(String),
          },
          mappings: [
            {
              dataImportFileId,
              organizationId,
              organizationIdentifier: undefined,
              userNumber: expect.any(String),
              productType,
            },
          ],
        },
      ];
      expect(actual).toEqual(expected);
      expect(actual[0].dataRow.userNumber).toEqual(
        actual[0].mappings[0].userNumber
      );
    });

    it('given same email in three rows, returns object with mappings and single generated user number', async () => {
      const organizationId2 = 12341;
      const productType2 = 'Product 2';
      const rawRow = getIntermediate({
        organizationId,
        username,
        productType,
      });
      const rawRow2 = getIntermediate({
        organizationId: organizationId2,
        productType: productType2,
        username,
      });
      const rawRow3 = getIntermediate({
        organizationId,
        productType: productType2,
        username,
      });
      const actual = await getDataImportRowsWithMappings(
        dataImportFileId,
        [rawRow, rawRow2, rawRow3],
        cache
      );
      const userNumber = actual[0].dataRow.userNumber;
      const expected: UserDataImportRowWithMappings[] = [
        {
          dataRow: {
            firstName,
            lastName,
            username,
            email: `${username}@example.com`,
            dataImportFileId,
            rowStatus: EXPECTED_ROW_STATUS,
            userNumber: userNumber,
            createdAt: expect.any(String),
          },
          mappings: expect.arrayContaining([
            {
              dataImportFileId,
              organizationId,
              organizationIdentifier: undefined,
              userNumber: userNumber,
              productType,
            },
            {
              dataImportFileId,
              organizationId: organizationId2,
              organizationIdentifier: undefined,
              userNumber: userNumber,
              productType: productType2,
            },
            {
              dataImportFileId,
              organizationId,
              organizationIdentifier: undefined,
              userNumber: userNumber,
              productType: productType2,
            },
          ]),
        },
      ];
      expect(actual).toEqual(expected);
    });
  });
});
