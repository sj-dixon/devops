import {
  BULK_DUPLICATION_ERRORS,
  getNonUniqueUserIdentifierErrors,
} from '../../../../src/lib/validators/requireUniqueUserIdentifiers';

describe('requireUniqueUserIdentifiers', () => {
  describe('getBulkUploadDuplicationErrors', () => {
    it('returns empty array if no users provided', () => {
      expect(getNonUniqueUserIdentifierErrors([])).toEqual([]);
    });

    it('returns empty array if users do not have values specified', () => {
      expect(getNonUniqueUserIdentifierErrors([{}, {}])).toEqual([]);
    });

    it('returns error if username is duplicated', () => {
      const errors = getNonUniqueUserIdentifierErrors([
        {
          username: 'hi',
        },
        {
          username: 'hi',
        },
      ]);
      expect(errors).toEqual([
        {
          ...BULK_DUPLICATION_ERRORS.usernameMustBeUnique,
          rowNumber: 3,
        },
      ]);
    });

    it('returns error if email is duplicated', () => {
      const errors = getNonUniqueUserIdentifierErrors([
        {
          email: 'hi',
        },
        {
          email: 'hi',
        },
      ]);
      expect(errors).toEqual([
        {
          ...BULK_DUPLICATION_ERRORS.emailMustBeUnique,
          rowNumber: 3,
        },
      ]);
    });

    it('returns empty array if no duplicates are present', () => {
      const errors = getNonUniqueUserIdentifierErrors([
        {
          email: '1@b.com',
          username: 'a1',
        },
        {
          email: '2@b.com',
          username: 'a2',
        },
      ]);
      expect(errors).toEqual([]);
    });
  });
});
