import { PASSWORD_POLICY } from '../../../src/middleware/requirePasswordIfNeeded';

describe('Users Service / middlewares / PASSWORD_POLICY', () => {
  function validatePassword(passwordToCheck: string, expected: boolean) {
    const result = PASSWORD_POLICY.validate(passwordToCheck);
    const errors = PASSWORD_POLICY.validate(passwordToCheck, {
      list: true,
    });
    if (expected != result) {
      console.log(errors);
    }
    expect(result).toBe(expected);
  }

  it('accepts password with numbers, uppercase, lowercase, symbol', () => {
    validatePassword('Aa1234567890', false);
    validatePassword('AA123456789!', false);
    validatePassword('aa123456789!', false);
    validatePassword('Aa123456789! ', false);
    validatePassword('Aa123456789!', true);
  });

  it('expects password to be within given length limits', () => {
    const TOO_LONG =
      'Aa!4567890123456789012345678901234567890123456789012345678901234567890123456789';
    validatePassword('', false);
    validatePassword('Aa1!', false);
    validatePassword(TOO_LONG, false);
  });

  it('accepts a wide variety of symbols', () => {
    const validateSymbolIsAccepted = (symbol: string) =>
      validatePassword('Aa12345678' + symbol, true);
    const validateSymbolIsRejected = (symbol: string) =>
      validatePassword('Aa12345678' + symbol, false);
    validateSymbolIsAccepted('!');
    validateSymbolIsAccepted('@');
    validateSymbolIsAccepted('#');
    validateSymbolIsAccepted('$');
    validateSymbolIsAccepted('%');
    validateSymbolIsAccepted('^');
    validateSymbolIsAccepted('*');
    validateSymbolIsAccepted('=');
    validateSymbolIsAccepted('-');
    validateSymbolIsAccepted('€'); // euro

    // technically these are not treated as symbols
    validateSymbolIsRejected('再见'); // Chinese for goodbye
    validateSymbolIsRejected('木'); // Japanese kanji for tree
    validateSymbolIsRejected('Є'); // greek letter epsilon

    // but we can still use them if we have a different symbol
    validateSymbolIsAccepted('再见!');
    validateSymbolIsAccepted('木!');
    validateSymbolIsAccepted('Є!');
  });
});
