import { Application } from 'express';
import request from 'supertest';
import { BAD_REQUEST_STATUS, getTestApp } from './testHelpers';
import { preventLoginIdentifierChanges } from '../../../src/middleware/preventLoginIdentifierChanges';

describe('Users Service / middlewares / preventLoginIdentifierChanges', () => {
  let app: Application;

  function submitRequest(body: { username?: string; email?: string }) {
    return request(app).post('/').send(body);
  }

  const CANNOT_CHANGE_LOGIN = {
    key: 'users.patch.cannotChangeLoginIdentifier',
    message: 'users.patch.cannotChangeLoginIdentifier',
  };

  describe('requireUserId', () => {
    beforeEach(() => {
      app = getTestApp(preventLoginIdentifierChanges);
    });
    it('passes if problem properties do not exist', (done) => {
      submitRequest({}).expect(200, done);
    });
    it('rejected if email is specified', (done) => {
      submitRequest({ email: 'hacker@vile.ru' }).expect(
        BAD_REQUEST_STATUS,
        {
          errors: {
            email: CANNOT_CHANGE_LOGIN,
          },
        },
        done
      );
    });
    it('rejected if email is specified', (done) => {
      submitRequest({ username: 'hacker' }).expect(
        BAD_REQUEST_STATUS,
        {
          errors: {
            username: CANNOT_CHANGE_LOGIN,
          },
        },
        done
      );
    });
    it('rejected if both email and username are specified', (done) => {
      submitRequest({ username: 'hacker', email: 'hacker@vile.ru' }).expect(
        BAD_REQUEST_STATUS,
        {
          errors: {
            username: CANNOT_CHANGE_LOGIN,
            email: CANNOT_CHANGE_LOGIN,
          },
        },
        done
      );
    });
  });
});
