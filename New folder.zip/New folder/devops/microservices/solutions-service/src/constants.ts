import { Utilities } from '@alcumus/globals';

export const SERVICE_NAME = 'Solutions Service';

export const SOLUTIONS_SERVICE_PORT =
  Number(Utilities.ProcessEnv.getValue('SOLUTIONS_SERVICE_PORT')) || 8018;

const BASE_V1 = '/api/v1';
export const ENDPOINTS = {
  PRODUCTS: `${BASE_V1}/products`,
};
