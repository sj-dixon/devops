import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS, SERVICE_NAME } from './constants';
import { Application } from 'express';
import path from 'path';
import { products } from './routes/products';

const apiSpec = './api-spec.yaml';

const app = configureApp({
  serviceName: SERVICE_NAME,
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
    validateResponse: true,
  },
  setup: (theApp: Application) => {
    theApp.use(ENDPOINTS.PRODUCTS, products);
  },
});

export default app;
