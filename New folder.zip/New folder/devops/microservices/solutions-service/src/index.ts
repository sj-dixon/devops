import { runApp } from '@alcumus/express-app';
import app from './app';
import process from 'process';
import { SOLUTIONS_SERVICE_PORT } from './constants';

runApp(app, {
  port: SOLUTIONS_SERVICE_PORT,
}).catch(async (reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
  process.exit(1);
});
