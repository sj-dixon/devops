import express, { Router, Response } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { allProducts } from '../allProducts';

const products: Router = express.Router();

products.get(
  '/',
  Middlewares.requireApiKeyHeader,
  (request: Types.Request, response: Response) => {
    response.status(200).json(allProducts);
  }
);

export { products };
