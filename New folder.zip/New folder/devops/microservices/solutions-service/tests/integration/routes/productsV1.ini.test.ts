import app from '../../../src/app';
import supertest from 'supertest';
import { ENDPOINTS } from '../../../src/constants';
import { Utilities } from '@alcumus/globals';
import { allProducts } from '../../../src/allProducts';

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv({
    SERVICE_MESH_API_KEY: 'correct',
  });
});

describe('/api/v1/products', () => {
  describe('GET /', () => {
    it('given api key, returns expected products', async () => {
      const response = await supertest(app)
        .get(ENDPOINTS.PRODUCTS)
        .set('x-api-key', 'correct');
      expect([response.status, response.body]).toEqual([200, allProducts]);
    });
  });
});
