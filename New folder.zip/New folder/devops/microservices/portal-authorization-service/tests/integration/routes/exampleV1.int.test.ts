import app from '../../../src/app';
import supertest from 'supertest';
import { ENDPOINTS } from '../../../src/constants';
import { Utilities } from '@alcumus/globals';

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv({
    SERVICE_MESH_API_KEY: 'correct',
  });
});

describe('/api/v1/example', () => {
  describe('GET /', () => {
    it('Given missing api key, returns 401', async () => {
      const response = await supertest(app).get(ENDPOINTS.EXAMPLE).send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('Given invalid api key, returns 401 response', async () => {
      const response = await supertest(app)
        .get(ENDPOINTS.EXAMPLE)
        .set('x-api-key', 'not correct')
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('Given valid api key, returns 200 response with expected message', async () => {
      const response = await supertest(app)
        .get(ENDPOINTS.EXAMPLE)
        .set('x-api-key', 'correct')
        .send();
      expect([response.status, response.body]).toEqual([
        200,
        {
          message: 'Hello World!',
        },
      ]);
    });
  });
});
