import express, { Router, Response } from 'express';
import { Middlewares, Types } from '@alcumus/globals';

const exampleV1: Router = express.Router();

exampleV1.get(
  '/',
  Middlewares.requireApiKeyHeader,
  (request: Types.Request, response: Response) => {
    response.status(200).json({ message: 'Hello World!' });
  }
);

export { exampleV1 };
