import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS, SERVICE_NAME } from './constants';
import { Application } from 'express';
import path from 'path';
import { exampleV1 } from './routes/exampleV1';

const apiSpec = './api-spec.yaml';

const app = configureApp({
  serviceName: SERVICE_NAME,
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
    validateResponse: true,
  },
  setup: (theApp: Application) => {
    theApp.use(ENDPOINTS.EXAMPLE, exampleV1);
  },
});

export default app;
