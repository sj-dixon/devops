import { Utilities } from '@alcumus/globals';

export const SERVICE_NAME = 'Portal Authorization Service';

export const PORTAL_AUTHORIZATION_SERVICE_PORT =
  Number(Utilities.ProcessEnv.getValue('PORTAL_AUTHORIZATION_SERVICE_PORT')) ||
  8019;

const BASE_V1 = '/api/v1';
export const ENDPOINTS = {
  EXAMPLE: `${BASE_V1}/example`,
};
