# portal-authorization-service

You can use this service as your starting point to writing a microservice within this monorepo.

### Steps to run the portal authorization service
- Run `npm ci && npm run clean && npm run bootstrap && npm run build`
- Run `npm run start-dev`
- Run this command in your terminal to see service health endpoint responding: `curl -i http://localhost:8019/api/health`
