# billing-service

This service allows to create Subscriptions for products
