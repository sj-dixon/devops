import request from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { seedProduct } from '../../../src/lib/utils/stripe/seed';
import { products } from '../stubs';

// noinspection DuplicatedCode
describe('Integration: billing-service /v1/plans', () => {
  it('should return response for GET /plans', async () => {
    const result = await request(app).get(ENDPOINTS.PLANS);

    expect(result.status).toEqual(200);
    expect(result.body.length).toEqual(4);
  });

  it('should return response for GET /plans?productId=123', async () => {
    const result = await request(app).get(`${ENDPOINTS.PLANS}?productId=123`);

    expect([result.status, result.body]).toEqual([200, []]);
  });

  it('should return response for GET /plans?productId', async () => {
    const newPlan = {
      name: 'New Plan 1',
      maxSeats: 100,
      prices: [
        {
          price: 1000,
          billingFrequency: 'yearly',
          currency: 'CAD',
        },
      ],
    };

    const seededProduct = await seedProduct({
      name: 'New Product',
      plans: [newPlan],
    });

    const result = await request(app).get(
      `${ENDPOINTS.PLANS}?productId=${seededProduct.id}`
    );

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject([newPlan]);
  });

  it('should return response for GET /plans/{planId}', async () => {
    const result = await request(app).get(`${ENDPOINTS.PLANS}/1`);

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject(products[0].plans![0]);
  });
});
