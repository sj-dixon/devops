import jsonWebToken from 'jsonwebtoken';
import request from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { BillingAccountEntity } from '../../../src/models/billingAccount';
import {
  createBillingAccount,
  createSubscription,
  EC_STARTER_MONTHLY_PRICE_ID,
  FID_STANDARD_MONTHLY_PRICE_ID,
} from '../stubs';
import { ENVIRONMENT } from '../../testHelpers';

jest.mock('jsonwebtoken');
const mockedJsonWebToken = jsonWebToken as jest.Mocked<typeof jsonWebToken>;

// noinspection DuplicatedCode
describe('Integration: billing-service /v1/billingAccounts/{id}/subscriptions', () => {
  let billingAccount: BillingAccountEntity;

  beforeAll(async () => {
    billingAccount = await createBillingAccount();
    await createSubscription(billingAccount.id, EC_STARTER_MONTHLY_PRICE_ID, {
      externalId: 'stripeSubscriptionId1',
    });
    await createSubscription(billingAccount.id, EC_STARTER_MONTHLY_PRICE_ID, {
      externalId: 'stripeSubscriptionId2',
      status: 'canceled',
    });
    await createSubscription(billingAccount.id, FID_STANDARD_MONTHLY_PRICE_ID, {
      externalId: 'stripeSubscriptionId3',
      status: 'canceled',
    });
  });

  beforeEach(() => {
    mockedJsonWebToken.verify.mockReset();
    mockedJsonWebToken.sign.mockReset();
  });

  it('should return all subscriptions', async () => {
    const result = await request(app)
      .get(`${ENDPOINTS.BILLING_ACCOUNTS}/${billingAccount.id}/subscriptions`)
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

    expect(result.status).toEqual(200);
    expect(result.body.length).toBe(3);
    expect(result.body[0].externalId).toBe('stripeSubscriptionId1');
    expect(result.body[0].status).toBe('active');
    expect(result.body[0].price.product.name).toBe('eCompliance');
    expect(result.body[0].price.plan.name).toBe('Starter');
    expect(result.body[0].price.price).toBe(1500);
    expect(result.body[0].price.currency).toBe('CAD');

    expect(result.body[1].externalId).toBe('stripeSubscriptionId2');
    expect(result.body[1].status).toBe('canceled');
    expect(result.body[1].price.product.name).toBe('eCompliance');
    expect(result.body[1].price.plan.name).toBe('Starter');
    expect(result.body[1].price.price).toBe(1500);
    expect(result.body[1].price.currency).toBe('CAD');

    expect(result.body[2].externalId).toBe('stripeSubscriptionId3');
    expect(result.body[2].status).toBe('canceled');
    expect(result.body[2].price.product.name).toBe('FieldID');
    expect(result.body[2].price.plan.name).toBe('Standard');
    expect(result.body[2].price.price).toBe(24000);
    expect(result.body[2].price.currency).toBe('CAD');
  });

  it('should work with status filters', async () => {
    const result = await request(app)
      .get(
        `${ENDPOINTS.BILLING_ACCOUNTS}/${billingAccount.id}/subscriptions?status=canceled`
      )
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

    expect(result.status).toEqual(200);
    expect(result.body.length).toBe(2);
    expect(result.body[0].externalId).toBe('stripeSubscriptionId2');
    expect(result.body[1].externalId).toBe('stripeSubscriptionId3');
  });

  it('should work with product filters', async () => {
    const result = await request(app)
      .get(
        `${ENDPOINTS.BILLING_ACCOUNTS}/${billingAccount.id}/subscriptions?productId=2`
      )
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

    expect(result.status).toEqual(200);
    expect(result.body.length).toBe(1);
    expect(result.body[0].externalId).toBe('stripeSubscriptionId3');
  });
});
