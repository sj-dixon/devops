import jsonWebToken from 'jsonwebtoken';
import request from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { BillingAccountEntity } from '../../../src/models/billingAccount';
import { stripeMocks } from '../../stripeMocks';
import {
  createBillingAccount,
  createSubscription,
  EC_PRODUCT_ID,
  EC_STANDARD_MONTHLY_PRICE_ID,
  EC_STANDARD_PLAN_ID,
  FID_STANDARD_MONTHLY_PRICE_ID,
} from '../stubs';
import { ENVIRONMENT, expectStripeTestId } from '../../testHelpers';
import PriceRepository from '../../../src/repositories/PriceRepository';
import syncSubscriptionWithStripe from '../../../src/models/syncSubscriptionWithStripe';
import { SubscriptionEntity } from '../../../src/models/subscription';

jest.mock('jsonwebtoken');
jest.mock('../../../src/models/syncSubscriptionWithStripe');

const mockedSyncSubscriptionWithStripe =
  syncSubscriptionWithStripe as jest.MockedFunction<
    typeof syncSubscriptionWithStripe
  >;
const mockedJsonWebToken = jsonWebToken as jest.Mocked<typeof jsonWebToken>;

// noinspection DuplicatedCode
describe('Integration: billing-service /v1/subscriptions', () => {
  let billingAccount: BillingAccountEntity;

  beforeAll(async () => {
    billingAccount = await createBillingAccount();
    mockedJsonWebToken.verify.mockImplementation((token) => {
      if (token === 'billing-account-token') {
        return {
          type: 'BillingAccountToken',
          billingAccountId: billingAccount.id,
        };
      }
    });
  });

  it('POST /subscriptions/initiate returns URL', async () => {
    const result = await request(app)
      .post(`${ENDPOINTS.SUBSCRIPTIONS}/initiate`)
      .set('Authorization', 'Bearer billing-account-token')
      .send({
        price: EC_STANDARD_MONTHLY_PRICE_ID,
        seats: 3,
        successUrl: 'https://success.com',
        cancelUrl: 'https://cancel.com',
      });

    expect(result.status).toEqual(200);
    expect(result.body.url).toEqual('https://redirect.com');

    expect(stripeMocks.checkout.sessions.create).toBeCalled();
    expect(stripeMocks.checkout.sessions.create).toBeCalledWith({
      customer: billingAccount.externalId,
      success_url: 'https://success.com',
      cancel_url: 'https://cancel.com',
      automatic_tax: {
        enabled: true,
      },
      mode: 'subscription',
      payment_method_types: ['card'],
      customer_update: {
        address: 'auto',
      },
      line_items: [
        {
          price: (await PriceRepository.getById(EC_STANDARD_MONTHLY_PRICE_ID))
            .externalId,
          quantity: 3,
        },
      ],
    });
  });

  it('GET /subscriptions/stripeCheckoutSessionId returns Subscription', async () => {
    const result = await request(app)
      .post(`${ENDPOINTS.SUBSCRIPTIONS}/initiate`)
      .set('Authorization', 'Bearer billing-account-token')
      .send({
        price: EC_STANDARD_MONTHLY_PRICE_ID,
        seats: 3,
        successUrl: 'https://success.com',
        cancelUrl: 'https://cancel.com',
      });

    expect(result.status).toEqual(200);
    expect(result.body.url).toEqual('https://redirect.com');

    expect(stripeMocks.checkout.sessions.create).toBeCalled();

    stripeMocks.checkout.sessions.retrieve.mockResolvedValueOnce({
      subscription: 'stripeSubscriptionId',
      customer: billingAccount.externalId,
      status: 'complete',
    });

    mockedSyncSubscriptionWithStripe.mockImplementationOnce(async () => {
      return createSubscription(
        billingAccount.id,
        FID_STANDARD_MONTHLY_PRICE_ID
      );
    });

    mockedSyncSubscriptionWithStripe.mockResolvedValueOnce({
      id: 123,
      externalId: 'stripeSubscriptionId',
    } as unknown as SubscriptionEntity);

    const getSubscriptionResponse = await request(app)
      .get(`${ENDPOINTS.SUBSCRIPTIONS}/stripeCheckoutSessionId/checkout123`)
      .set('Authorization', 'Bearer billing-account-token');

    expect(getSubscriptionResponse.status).toEqual(200);
    expect(getSubscriptionResponse.body).toMatchObject({
      billingAccountId: 1,
    });

    expect(stripeMocks.checkout.sessions.retrieve).toBeCalled();
    expect(stripeMocks.checkout.sessions.retrieve).toBeCalledWith(
      'checkout123'
    );
    expect(mockedSyncSubscriptionWithStripe).toBeCalledWith(
      'stripeSubscriptionId'
    );

    await SubscriptionEntity.query().deleteById(
      getSubscriptionResponse.body.id
    );
  });

  it('POST /subscriptions/initiate fails if an active subscription exists', async () => {
    await createSubscription(billingAccount.id, EC_STANDARD_MONTHLY_PRICE_ID);

    const result = await request(app)
      .post(`${ENDPOINTS.SUBSCRIPTIONS}/initiate`)
      .set('Authorization', 'Bearer billing-account-token')
      .send({
        price: EC_STANDARD_MONTHLY_PRICE_ID,
        seats: 3,
        successUrl: 'https://success.com',
        cancelUrl: 'https://cancel.com',
      });

    expect(result.status).toEqual(403);
    expect(result.body.message).toEqual(
      'This billing account already has an active subscription for product [1]'
    );

    // try again, but for another product, this should work
    const result2 = await request(app)
      .post(`${ENDPOINTS.SUBSCRIPTIONS}/initiate`)
      .set('Authorization', 'Bearer billing-account-token')
      .send({
        price: FID_STANDARD_MONTHLY_PRICE_ID,
        seats: 3,
        successUrl: 'https://success.com',
        cancelUrl: 'https://cancel.com',
      });

    expect(result2.status).toEqual(200);
    expect(result2.body.url).toEqual('https://redirect.com');
  });

  it('POST /subscriptions/manage returns URL', async () => {
    const result = await request(app)
      .post(`${ENDPOINTS.SUBSCRIPTIONS}/manage`)
      .set('Authorization', 'Bearer billing-account-token')
      .send({
        returnUrl: 'https://app.com',
      });

    expect(result.status).toEqual(200);
    expect(result.body.url).toEqual('https://redirect.com');

    expect(stripeMocks.billingPortal.sessions.create).toBeCalled();
    expect(stripeMocks.billingPortal.sessions.create).toBeCalledWith({
      customer: billingAccount.externalId,
      return_url: 'https://app.com',
    });
  });

  it('GET /subscriptions returns subscriptions', async () => {
    await createSubscription(billingAccount.id, EC_STANDARD_MONTHLY_PRICE_ID);

    const result = await request(app)
      .get(`${ENDPOINTS.SUBSCRIPTIONS}`)
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

    expect(result.status).toEqual(200);
    expect(result.body.length).toEqual(2);
    expect(result.body[0]).toMatchObject({
      deletedAt: null,
      billingAccountId: billingAccount.id,
      status: 'active',
      externalId: expectStripeTestId('sub'),
      cardNumber: '****',
      cardExpiry: '01/2022',
      price: {
        externalId: expectStripeTestId('price'),
        currency: 'CAD',
        billingFrequency: 'monthly',
        plan: {
          id: EC_STANDARD_PLAN_ID,
          productId: EC_PRODUCT_ID,
          name: 'Standard',
          maxSeats: 20,
        },
      },
    });
  });

  it('GET /subscriptions/{id} returns subscription', async () => {
    const subscription = await createSubscription(
      billingAccount.id,
      EC_STANDARD_MONTHLY_PRICE_ID
    );

    const result = await request(app)
      .get(`${ENDPOINTS.SUBSCRIPTIONS}/${subscription.id}`)
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject({
      deletedAt: null,
      billingAccountId: billingAccount.id,
      status: 'active',
      externalId: expectStripeTestId('sub'),
      cardNumber: '****',
      cardExpiry: '01/2022',
      price: {
        externalId: expectStripeTestId('price'),
        currency: 'CAD',
        billingFrequency: 'monthly',
        plan: {
          id: EC_STANDARD_PLAN_ID,
          name: 'Standard',
          maxSeats: 20,
          productId: EC_PRODUCT_ID,
        },
      },
    });
  });
});
