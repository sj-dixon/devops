import request from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { products } from '../stubs';

// noinspection DuplicatedCode
describe('Integration: billing-service /v1/products', () => {
  it('should return response for GET /products', async () => {
    const result = await request(app).get(ENDPOINTS.PRODUCTS);

    expect(result.status).toEqual(200);
    expect(result.body.length).toEqual(2);
  });

  it('should return response for GET /products/{productId}', async () => {
    const result = await request(app).get(`${ENDPOINTS.PRODUCTS}/1`);

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject({
      name: products[0].name,
    });
  });
});
