import jsonWebToken from 'jsonwebtoken';
import request from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { BillingAccountEntity } from '../../../src/models/billingAccount';
import { stripeMocks } from '../../stripeMocks';
import {
  billingAccount as billingAccountStub,
  createBillingAccount,
} from '../stubs';
import { ENVIRONMENT, expectStripeTestId } from '../../testHelpers';

jest.mock('jsonwebtoken');
const mockedJsonWebToken = jsonWebToken as jest.Mocked<typeof jsonWebToken>;

// noinspection DuplicatedCode
describe('Integration: billing-service /v1/billingAccounts', () => {
  let billingAccount: BillingAccountEntity;

  beforeAll(async () => {
    billingAccount = await createBillingAccount();
  });

  beforeEach(() => {
    mockedJsonWebToken.verify.mockReset();
    mockedJsonWebToken.sign.mockReset();
  });

  describe('GET /billingAccounts', () => {
    it('should work with valid API Key', async () => {
      const result = await request(app)
        .get(ENDPOINTS.BILLING_ACCOUNTS)
        .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

      expect(result.status).toEqual(200);
      expect(result.body.length).toEqual(1);
      expect(result.body[0]).toMatchObject({
        accountHolderName: 'John Doe',
        accountHolderEmail: 'billingaccount@email.com',
        billingAddress: {
          line1: '123 Queen St.',
          line2: 'Unit 101',
          city: 'Toronto',
          state: 'ON',
          country: 'CA',
        },
      });
    });

    it('should return 401 without API Key', async () => {
      const result = await request(app).get(ENDPOINTS.BILLING_ACCOUNTS);

      expect([result.status, result.body]).toEqual([
        401,
        { message: "'x-api-key' header required" },
      ]);
    });

    it('should return 401 with wrong API Key', async () => {
      const result = await request(app)
        .get(ENDPOINTS.BILLING_ACCOUNTS)
        .set('x-api-key', 'wrong');

      expect([result.status, result.body]).toEqual([
        401,
        { message: 'x-api-key header has an incorrect api key' },
      ]);
    });
  });

  describe('GET /billingAccounts/{billingAccountId}', () => {
    it('should work when API Key is valid', async () => {
      const result = await request(app)
        .get(`${ENDPOINTS.BILLING_ACCOUNTS}/${billingAccount.id}`)
        .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

      expect(result.status).toEqual(200);
      expect(result.body).toMatchObject(billingAccountStub);
    });
  });

  it('POST /billingAccounts/{billingAccountId}/token generates a billing account token', async () => {
    mockedJsonWebToken.sign.mockImplementationOnce(() => 'generated-token');

    const result = await request(app)
      .post(`${ENDPOINTS.BILLING_ACCOUNTS}/${billingAccount.id}/token`)
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY);

    expect([result.status, result.body]).toEqual([
      200,
      { token: 'generated-token' },
    ]);
    expect(result.body.token).toBeDefined();
  });

  it('GET /billingAccounts/me returns billing account associated with token', async () => {
    mockedJsonWebToken.verify.mockImplementation(() => ({
      type: 'BillingAccountToken',
      billingAccountId: billingAccount.id,
    }));

    const result = await request(app)
      .get(`${ENDPOINTS.BILLING_ACCOUNTS}/me`)
      .set('Authorization', `Bearer test-token`);

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject(billingAccountStub);

    expect(mockedJsonWebToken.verify).toBeCalledWith(
      'test-token',
      ENVIRONMENT.BILLING_SERVICE_TOKEN_SECRET
    );
  });

  it('PATCH /billingAccounts/{billingAccountId} updates billing account', async () => {
    const result = await request(app)
      .patch(`${ENDPOINTS.BILLING_ACCOUNTS}/${billingAccount.id}`)
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY)
      .send({
        accountHolderEmail: 'billingaccount2@email.com',
        billingEmail: '123@email.com',
        billingAddress: {
          city: 'Waterloo',
        },
      });

    const updatedAccountDetails = {
      ...billingAccountStub,
      accountHolderEmail: 'billingaccount2@email.com',
      billingEmail: '123@email.com',
      billingAddress: {
        ...billingAccountStub.billingAddress,
        city: 'Waterloo',
      },
    };

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject(updatedAccountDetails);
    expect(stripeMocks.customers.update).toBeCalledTimes(1);
    expect(stripeMocks.customers.update).toBeCalledWith(
      expectStripeTestId('cus'),
      {
        email: '123@email.com',
        address: {
          city: 'Waterloo',
        },
      }
    );
  });

  it('POST /billingAccounts creates Billing Account', async () => {
    const result = await request(app)
      .post(ENDPOINTS.BILLING_ACCOUNTS)
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY)
      .send(billingAccountStub);

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject({
      accountHolderName: 'John Doe',
      accountHolderEmail: 'billingaccount@email.com',
      externalId: expectStripeTestId('cus'),
      billingAddress: {
        line1: '123 Queen St.',
        line2: 'Unit 101',
        city: 'Toronto',
        state: 'ON',
        country: 'CA',
      },
    });
    expect(stripeMocks.customers.create).toBeCalledWith({
      email: 'billingaccount@email.com',
      name: 'John Doe',
      address: {
        ...billingAccountStub.billingAddress,
        postalCode: undefined,
        postal_code: billingAccountStub.billingAddress.postalCode,
      },
    });
  });

  it('POST /billingAccounts creates Billing Account, uses billing email if provided', async () => {
    const result = await request(app)
      .post(ENDPOINTS.BILLING_ACCOUNTS)
      .set('x-api-key', ENVIRONMENT.BILLING_SERVICE_API_KEY)
      .send({
        ...billingAccountStub,
        billingEmail: '123@email.com',
      });

    expect(result.status).toEqual(200);
    expect(result.body).toMatchObject({
      accountHolderName: 'John Doe',
      accountHolderEmail: 'billingaccount@email.com',
      billingEmail: '123@email.com',
      externalId: expectStripeTestId('cus'),
      billingAddress: {
        line1: '123 Queen St.',
        line2: 'Unit 101',
        city: 'Toronto',
        state: 'ON',
        country: 'CA',
      },
    });
    expect(stripeMocks.customers.create).toBeCalledWith({
      email: '123@email.com',
      name: 'John Doe',
      address: {
        ...billingAccountStub.billingAddress,
        postalCode: undefined,
        postal_code: billingAccountStub.billingAddress.postalCode,
      },
    });
  });
});
