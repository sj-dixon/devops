import request from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import validateStripeWebhookRequest from '../../../src/middlewares/validateStripeWebhookRequest';
import { BillingAccountEntity } from '../../../src/models/billingAccount';
import { SubscriptionEntity } from '../../../src/models/subscription';
import { stripeMocks } from '../../stripeMocks';
import { EC_STANDARD_MONTHLY_PRICE_ID } from '../stubs';
import PriceRepository from '../../../src/repositories/PriceRepository';
import { DateTime } from 'luxon';

jest.mock('../../../src/middlewares/validateStripeWebhookRequest');
const mockedValidationMiddleware =
  validateStripeWebhookRequest as jest.MockedFunction<
    typeof validateStripeWebhookRequest
  >;

describe('Integration: billing-service /v1/stripe/webhook', () => {
  let billingAccount: BillingAccountEntity;

  const accountDetails = {
    accountHolderName: 'John Doe',
    accountHolderEmail: 'billingaccount@email.com',
    externalId: 'stripe-customer-id',
    billingAddress: {
      line1: '123 Queen St.',
      line2: 'Unit 101',
      city: 'Toronto',
      state: 'ON',
      country: 'CA',
      postalCode: 'N2NZ2Z',
    },
  };

  beforeAll(async () => {
    billingAccount = await BillingAccountEntity.query().insertGraphAndFetch(
      accountDetails
    );
  });

  it('dirty read on subscription webhook is not present', async () => {
    mockedValidationMiddleware.mockImplementation(async (req, res, next) => {
      next();
    });

    stripeMocks.subscriptions.retrieve.mockResolvedValue({
      id: 'stripe-subscription-id',
      customer: {
        id: 'stripe-customer-id',
      },
      default_payment_method: {
        card: {
          brand: 'visa',
          last4: '1234',
          exp_month: '11',
          exp_year: '2021',
        },
      },
      status: 'active',
      items: {
        data: [
          {
            price: {
              id: (await PriceRepository.getById(EC_STANDARD_MONTHLY_PRICE_ID))
                .externalId,
            },
            quantity: 3,
          },
        ],
      },
      current_period_end: DateTime.fromObject(
        {
          year: 2021,
          month: 2,
          day: 10,
        },
        { zone: 'utc' }
      ).toSeconds(),
      current_period_start: DateTime.fromObject(
        {
          year: 2021,
          month: 1,
          day: 10,
        },
        { zone: 'utc' }
      ).toSeconds(),
    });

    await Promise.all([
      request(app)
        .post(`${ENDPOINTS.STRIPE_WEBHOOK}`)
        .send({
          type: 'customer.subscription.created',
          data: {
            object: {
              id: 'subscriptionId',
            },
          },
        }),
      request(app)
        .post(`${ENDPOINTS.STRIPE_WEBHOOK}`)
        .send({
          type: 'customer.subscription.created',
          data: {
            object: {
              id: 'subscriptionId',
            },
          },
        }),
    ]);

    const count = await SubscriptionEntity.query()
      .where('externalId', 'subscriptionId')
      .resultSize();

    // Only single row created in DB
    expect(count).toBe(1);
  });
});
