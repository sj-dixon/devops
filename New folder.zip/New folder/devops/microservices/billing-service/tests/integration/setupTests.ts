import { Utilities } from '@alcumus/globals';
import { Knex } from 'knex';
import Stripe from 'stripe';
import { getTestKnexClient } from '../../src/lib/clients/knex';
import stripe from '../../src/lib/clients/stripe';
import { seedProduct } from '../../src/lib/utils/stripe/seed';
import { stripeMocks } from '../stripeMocks';
import { products as testSeedProducts } from './stubs';
import { ENVIRONMENT, resetTestDatabase } from '../testHelpers';

jest.mock('../../src/lib/clients/stripe');
const mockedStripe = stripe as jest.MockedFunction<typeof stripe>;
mockedStripe.mockReturnValue(stripeMocks as unknown as Stripe);

let knex: Knex;

beforeAll(async () => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  knex = getTestKnexClient();
  await resetTestDatabase(knex);

  knex = getTestKnexClient();

  await knex.migrate.latest();

  stripeMocks.setup();

  for (const product of testSeedProducts) {
    await seedProduct(product);
  }
});

afterAll(async () => {
  await knex.destroy();
});

beforeEach(() => {
  stripeMocks.setup();
});

afterEach(() => {
  stripeMocks.reset();
});
