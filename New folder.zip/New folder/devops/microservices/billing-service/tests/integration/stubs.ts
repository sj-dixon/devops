import { BillingAccountEntity } from '../../src/models/billingAccount';
import { SubscriptionEntity } from '../../src/models/subscription';
import { Product } from '../../src/types';
import { PartialModelObject } from 'objection';
import { generateStripeTestId } from '../testHelpers';

/**
 * This file provides DB entities and functions to create those,
 * which will be used in our tests.
 */

export const billingAccount = {
  accountHolderName: 'John Doe',
  accountHolderEmail: 'billingaccount@email.com',
  billingAddress: {
    line1: '123 Queen St.',
    line2: 'Unit 101',
    city: 'Toronto',
    state: 'ON',
    country: 'CA',
    postalCode: 'N2NZ2Z',
  },
};

export const EC_PRODUCT_ID = 1;
export const EC_STARTER_PLAN_ID = 1;
export const EC_STARTER_MONTHLY_PRICE_ID = 1;
export const EC_STANDARD_PLAN_ID = 2;
export const EC_STANDARD_MONTHLY_PRICE_ID = 2;
export const FID_PRODUCT_ID = 2;
export const FID_STARTER_PLAN_ID = 3;
export const FID_STARTER_MONTHLY_PRICE_ID = 4;
export const FID_STANDARD_PLAN_ID = 4;
export const FID_STANDARD_MONTHLY_PRICE_ID = 4;

export const products: Array<Product> = [
  {
    // Product ID = 1
    name: 'eCompliance',
    plans: [
      {
        // Plan ID = 1
        name: 'Starter',
        maxSeats: 20,
        prices: [
          {
            billingFrequency: 'monthly',
            price: 1500,
            currency: 'CAD',
          },
        ],
      },
      {
        // Plan ID = 2
        name: 'Standard',
        maxSeats: 20,
        prices: [
          {
            billingFrequency: 'monthly',
            price: 18000,
            currency: 'CAD',
          },
        ],
      },
    ],
  },
  {
    // Product ID = 2
    name: 'FieldID',
    plans: [
      {
        // Plan ID = 3
        name: 'Starter',
        maxSeats: 20,
        prices: [
          {
            billingFrequency: 'monthly',
            price: 1800,
            currency: 'CAD',
          },
        ],
      },
      {
        // Plan ID = 4
        name: 'Standard',
        maxSeats: 20,
        prices: [
          {
            billingFrequency: 'monthly',
            price: 24000,
            currency: 'CAD',
          },
        ],
      },
    ],
  },
];

export async function createBillingAccount() {
  return BillingAccountEntity.query().insertGraphAndFetch({
    ...billingAccount,
    externalId: generateStripeTestId('cus'),
  });
}

export async function createSubscription(
  billingAccountId: number | string,
  priceId: number,
  overrides: PartialModelObject<SubscriptionEntity> = {}
) {
  return SubscriptionEntity.query().insert({
    billingAccountId,
    priceId,
    externalId: generateStripeTestId('sub'),
    seats: 1,
    status: 'active',
    cardNumber: '****',
    cardExpiry: '01/2022',
    ...overrides,
  });
}
