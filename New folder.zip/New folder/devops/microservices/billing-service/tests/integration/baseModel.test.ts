import { parseISO } from 'date-fns';
import { BillingAccountEntity } from '../../src/models/billingAccount';

const NOW_INSTANT_MS = 1624573658246;

describe('BaseModel test', () => {
  const accountDetails = {
    accountHolderName: 'John Doe',
    accountHolderEmail: 'billingaccount@email.com',
    externalId: 'stripe-customer-id',
  };

  let nowSpy: jest.SpyInstance;

  beforeEach(() => {
    nowSpy = jest.spyOn(Date, 'now').mockReturnValue(NOW_INSTANT_MS);
  });

  it('when serialized, has valid ISO8601 strings for dates', async () => {
    const { id } = await BillingAccountEntity.query().insert(accountDetails);

    const account = await BillingAccountEntity.query().findById(id);

    const json = JSON.parse(JSON.stringify(account));

    expect(json.createdAt).toBe('2021-06-24T22:27:38.000Z');
    expect(json.modifiedAt).toBe('2021-06-24T22:27:38.000Z');
    expect(parseISO(json.createdAt)).toBeInstanceOf(Date);
    expect(parseISO(json.modifiedAt)).toBeInstanceOf(Date);
  });
});
