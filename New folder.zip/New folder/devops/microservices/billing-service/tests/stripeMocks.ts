import { generateStripeTestId } from './testHelpers';

/**
 * This object is a Stripe mock, and it resembles the Stripe SDK,
 * but with the functions we use replaced with mock functions
 */
const stripeMockFns = {
  prices: {
    create: jest.fn(),
  },
  products: {
    create: jest.fn(),
  },
  customers: {
    create: jest.fn(),
    update: jest.fn(),
  },
  checkout: {
    sessions: {
      create: jest.fn(),
      retrieve: jest.fn(),
    },
  },
  billingPortal: {
    sessions: {
      create: jest.fn(),
    },
  },
  subscriptions: {
    retrieve: jest.fn(),
  },
};

export const stripeMocks = {
  ...stripeMockFns,
  /**
   * Setup standard mock return / resolve values expected throughout the tests,
   * should be called in beforeEach
   */
  setup() {
    stripeMockFns.prices.create.mockImplementation(async () => ({
      id: generateStripeTestId('price'),
    }));
    stripeMockFns.products.create.mockImplementation(async () => ({
      id: generateStripeTestId('price'),
    }));
    stripeMockFns.checkout.sessions.create.mockResolvedValue({
      url: 'https://redirect.com',
    });
    stripeMockFns.billingPortal.sessions.create.mockResolvedValue({
      url: 'https://redirect.com',
    });
    stripeMockFns.customers.create.mockImplementation(async () => ({
      id: generateStripeTestId('cus'),
    }));
  },
  /**
   * Resets the mock functions so that tests do not have shared mock data,
   * should be called in afterEach
   */
  reset() {
    stripeMockFns.prices.create.mockReset();
    stripeMockFns.products.create.mockReset();
    stripeMockFns.customers.create.mockReset();
    stripeMockFns.customers.update.mockReset();
    stripeMockFns.checkout.sessions.create.mockReset();
    stripeMockFns.checkout.sessions.retrieve.mockReset();
    stripeMockFns.billingPortal.sessions.create.mockReset();
  },
};
