import { Types } from '@alcumus/globals';
import { Response } from 'express';
import { JsonWebTokenError, TokenExpiredError } from 'jsonwebtoken';
import { parseBillingAccountIdFromToken } from '../../../src/lib/jwt/billingAccounts';
import requireBillingAccountToken from '../../../src/middlewares/requireBillingAccountToken';

jest.mock('../../../src/lib/jwt/billingAccounts');

const mockedParseBillingAccountIdFromToken =
  parseBillingAccountIdFromToken as jest.MockedFunction<
    typeof parseBillingAccountIdFromToken
  >;

describe('test requireBillingAccountToken middleware', () => {
  const requestHeaderMethod = jest.fn();
  const responseSendMethod = jest.fn();
  const responseStatusMethod = jest.fn();

  const request = {
    header: requestHeaderMethod,
  } as unknown as Types.Request;

  const response = {
    send: responseSendMethod,
    status: responseStatusMethod,
  } as unknown as Response;

  beforeEach(() => {
    requestHeaderMethod.mockClear();
    responseStatusMethod.mockClear();
    responseSendMethod.mockClear();

    responseStatusMethod.mockReturnThis();
  });

  it('passes when valid token is present', async () => {
    const nextFn = jest.fn();
    requestHeaderMethod.mockReturnValue(`Bearer test-token`);

    mockedParseBillingAccountIdFromToken.mockReturnValue(1);

    await requireBillingAccountToken(request, response, nextFn);

    expect(nextFn).toBeCalled();
  });

  it('fails when token is expired', async () => {
    const nextFn = jest.fn();
    requestHeaderMethod.mockReturnValue(`Bearer test-token`);

    mockedParseBillingAccountIdFromToken.mockImplementation(() => {
      throw new TokenExpiredError('Token Expired', new Date());
    });

    await requireBillingAccountToken(request, response, nextFn);

    expect(nextFn).not.toBeCalled();
    expect(responseStatusMethod).toBeCalledWith(401);
    expect(responseSendMethod).toBeCalledWith({ message: 'token.expired' });
  });

  it('fails when token is invalid', async () => {
    const nextFn = jest.fn();
    requestHeaderMethod.mockReturnValue(`Bearer test-token`);

    mockedParseBillingAccountIdFromToken.mockImplementation(() => {
      throw new JsonWebTokenError('Token Invalid');
    });

    await requireBillingAccountToken(request, response, nextFn);

    expect(nextFn).not.toBeCalled();
    expect(responseStatusMethod).toBeCalledWith(401);
    expect(responseSendMethod).toBeCalledWith({ message: 'token.invalid' });
  });
});
