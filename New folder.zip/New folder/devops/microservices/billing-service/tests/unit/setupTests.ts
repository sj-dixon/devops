import { Utilities } from '@alcumus/globals';
import { Knex } from 'knex';
import { getTestKnexClient } from '../../src/lib/clients/knex';
import { seedProduct } from '../../src/lib/utils/stripe/seed';
import seedData from '../../src/lib/utils/stripe/seedData';
import { ENVIRONMENT, resetTestDatabase } from '../testHelpers';
import stripe from '../../src/lib/clients/stripe';
import { stripeMocks } from '../stripeMocks';
import { Stripe } from 'stripe';

jest.mock('../../src/lib/clients/stripe');
const mockedStripe = stripe as jest.MockedFunction<typeof stripe>;
mockedStripe.mockReturnValue(stripeMocks as unknown as Stripe);

let knex: Knex;

beforeAll(async () => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  knex = getTestKnexClient();
  await resetTestDatabase(knex);

  knex = getTestKnexClient();
  await knex.migrate.latest();

  stripeMocks.setup();

  await seedProduct(seedData[0]);
});

afterAll(async () => {
  await knex.destroy();
});

afterEach(() => {
  stripeMocks.reset();
});
