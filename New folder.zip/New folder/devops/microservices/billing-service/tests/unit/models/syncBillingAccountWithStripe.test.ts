import Stripe from 'stripe';
import stripe from '../../../src/lib/clients/stripe';
import { BillingAccountEntity } from '../../../src/models/billingAccount';
import syncBillingAccountWithStripe, {
  SyncBillingAccountWithStripeError,
} from '../../../src/models/syncBillingAccountWithStripe';

jest.mock('../../../src/lib/clients/stripe');
const mockedStripe = stripe as jest.MockedFunction<typeof stripe>;

describe('syncBillingAccountWithStripe', () => {
  const mockStripeCustomerRetrieve = jest.fn();
  let billingAccount: BillingAccountEntity;

  const accountDetails = {
    accountHolderName: 'John Doe',
    accountHolderEmail: 'billingaccount@email.com',
    externalId: 'stripe-customer-id',
    billingAddress: {
      line1: '123 Queen St.',
      line2: 'Unit 101',
      city: 'Toronto',
      state: 'ON',
      country: 'CA',
      postalCode: 'N2NZ2Z',
    },
  };

  beforeAll(async () => {
    mockedStripe.mockReturnValue({
      customers: {
        retrieve: mockStripeCustomerRetrieve,
      },
    } as unknown as Stripe);

    billingAccount = await BillingAccountEntity.query().insertGraphAndFetch(
      accountDetails
    );
  });

  it('throws if billing account is not present', async () => {
    mockStripeCustomerRetrieve.mockResolvedValueOnce({});

    expect(
      syncBillingAccountWithStripe('stripe-customer-id-absent')
    ).rejects.toBeInstanceOf(SyncBillingAccountWithStripeError);
  });

  it('updates email and address', async () => {
    mockStripeCustomerRetrieve.mockResolvedValueOnce({
      email: 'new@email.com',
      address: {
        line1: 'Line 1',
        line2: 'Line 2',
        city: 'City',
        country: 'Country',
        state: 'State',
        postal_code: 'Postal Code',
      },
    });

    await syncBillingAccountWithStripe('stripe-customer-id');

    expect(mockStripeCustomerRetrieve).toHaveBeenCalled();
    expect(mockStripeCustomerRetrieve).toHaveBeenCalledWith(
      'stripe-customer-id'
    );

    const account = await BillingAccountEntity.withBillingAddress().findById(
      billingAccount.id
    );

    expect(account.accountHolderEmail).toBe('billingaccount@email.com');
    expect(account.billingEmail).toBe('new@email.com');
    expect(account.billingAddress).toMatchObject({
      line1: 'Line 1',
      line2: 'Line 2',
      city: 'City',
      country: 'Country',
      state: 'State',
      postalCode: 'Postal Code',
    });
  });

  it('creates billing address if absent', async () => {
    await BillingAccountEntity.query().insert({
      accountHolderName: 'John Doe',
      accountHolderEmail: 'billingaccount@email.com',
      externalId: 'stripe-customer-id-2',
    });

    mockStripeCustomerRetrieve.mockResolvedValueOnce({
      email: 'new@email.com',
      address: {
        line1: 'Line 1',
        line2: 'Line 2',
        city: 'City',
        country: 'Country',
        state: 'State',
        postal_code: 'Postal Code',
      },
    });

    await syncBillingAccountWithStripe('stripe-customer-id-2');

    expect(mockStripeCustomerRetrieve).toHaveBeenCalled();
    expect(mockStripeCustomerRetrieve).toHaveBeenCalledWith(
      'stripe-customer-id-2'
    );

    const account = await BillingAccountEntity.withBillingAddress().findById(
      billingAccount.id
    );

    expect(account.accountHolderEmail).toBe('billingaccount@email.com');
    expect(account.billingEmail).toBe('new@email.com');
    expect(account.billingAddress).toMatchObject({
      line1: 'Line 1',
      line2: 'Line 2',
      city: 'City',
      country: 'Country',
      state: 'State',
      postalCode: 'Postal Code',
    });
  });
});
