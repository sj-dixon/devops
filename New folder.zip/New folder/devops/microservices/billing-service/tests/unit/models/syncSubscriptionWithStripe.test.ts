import Stripe from 'stripe';
import stripe from '../../../src/lib/clients/stripe';
import { BillingAccountEntity } from '../../../src/models/billingAccount';
import { SubscriptionEntity } from '../../../src/models/subscription';
import syncSubscriptionWithStripe from '../../../src/models/syncSubscriptionWithStripe';
import PriceRepository from '../../../src/repositories/PriceRepository';
import { EC_STANDARD_MONTHLY_PRICE_ID } from '../../integration/stubs';
import { DateTime } from 'luxon';

jest.mock('../../../src/lib/clients/stripe');
const mockedStripe = stripe as jest.MockedFunction<typeof stripe>;

const currentPeriodEnd = DateTime.fromObject(
  {
    year: 2021,
    month: 2,
    day: 10,
  },
  { zone: 'utc' }
).toSeconds();

const currentPeriodStart = DateTime.fromObject(
  {
    year: 2021,
    month: 1,
    day: 10,
  },
  { zone: 'utc' }
).toSeconds();

describe('syncSubscriptionWithStripe', () => {
  const mockStripeSubscriptionRetrieve = jest.fn();
  let billingAccount: BillingAccountEntity;

  const accountDetails = {
    accountHolderName: 'John Doe',
    accountHolderEmail: 'billingaccount@email.com',
    externalId: 'stripe-customer-id',
    billingAddress: {
      line1: '123 Queen St.',
      line2: 'Unit 101',
      city: 'Toronto',
      state: 'ON',
      country: 'CA',
      postalCode: 'N2NZ2Z',
    },
  };

  beforeAll(async () => {
    mockedStripe.mockReturnValue({
      subscriptions: {
        retrieve: mockStripeSubscriptionRetrieve,
      },
    } as unknown as Stripe);

    billingAccount = await BillingAccountEntity.query().insertGraphAndFetch(
      accountDetails
    );
  });

  it('creates subscription if not present', async () => {
    mockStripeSubscriptionRetrieve.mockResolvedValueOnce({
      id: 'stripe-subscription-id',
      customer: {
        id: 'stripe-customer-id',
      },
      default_payment_method: {
        card: {
          brand: 'visa',
          last4: '1234',
          exp_month: '11',
          exp_year: '2021',
        },
      },
      status: 'active',
      current_period_end: currentPeriodEnd,
      current_period_start: currentPeriodStart,
      items: {
        data: [
          {
            price: {
              id: (await PriceRepository.getById(EC_STANDARD_MONTHLY_PRICE_ID))
                .externalId,
            },
            quantity: 3,
          },
        ],
      },
    });

    await syncSubscriptionWithStripe('stripe-subscription-id');

    expect(mockStripeSubscriptionRetrieve).toHaveBeenCalled();
    expect(mockStripeSubscriptionRetrieve).toHaveBeenCalledWith(
      'stripe-subscription-id',
      {
        expand: [
          'default_payment_method',
          'customer.invoice_settings.default_payment_method',
        ],
      }
    );

    const account = await SubscriptionEntity.findByExternalId(
      'stripe-subscription-id'
    );

    expect(account).not.toBeNull();
    expect(account).toMatchObject({
      seats: 3,
      cardNumber: 'visa - 1234',
      cardExpiry: '11/2021',
      status: 'active',
      externalId: 'stripe-subscription-id',
      nextPaymentDate: '2021-02-10T00:00:00.000Z',
      previousPaymentDate: '2021-01-10T00:00:00.000Z',
    });
  });

  it('updates subscription if present', async () => {
    await SubscriptionEntity.query().insert({
      externalId: 'stripe-subscription-id-2',
      seats: 0,
      status: 'pending',
      billingAccountId: billingAccount.id,
      priceId: EC_STANDARD_MONTHLY_PRICE_ID,
      cardNumber: '',
      cardExpiry: '',
    });

    mockStripeSubscriptionRetrieve.mockResolvedValueOnce({
      id: 'stripe-subscription-id-2',
      customer: {
        id: 'stripe-customer-id',
      },
      default_payment_method: {
        card: {
          brand: 'visa',
          last4: '1234',
          exp_month: '11',
          exp_year: '2021',
        },
      },
      status: 'active',
      items: {
        data: [
          {
            price: {
              id: (await PriceRepository.getById(EC_STANDARD_MONTHLY_PRICE_ID))
                .externalId,
            },
            quantity: 3,
          },
        ],
      },
      current_period_end: currentPeriodEnd,
      current_period_start: currentPeriodStart,
    });

    await syncSubscriptionWithStripe('stripe-subscription-id-2');

    expect(mockStripeSubscriptionRetrieve).toHaveBeenCalled();
    expect(mockStripeSubscriptionRetrieve).toHaveBeenCalledWith(
      'stripe-subscription-id-2',
      {
        expand: [
          'default_payment_method',
          'customer.invoice_settings.default_payment_method',
        ],
      }
    );

    const account = await SubscriptionEntity.findByExternalId(
      'stripe-subscription-id-2'
    );

    expect(account).not.toBeNull();
    expect(account).toMatchObject({
      seats: 3,
      cardNumber: 'visa - 1234',
      cardExpiry: '11/2021',
      status: 'active',
      externalId: 'stripe-subscription-id-2',
    });
  });
});
