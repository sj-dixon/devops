export { config as default } from './lib/clients/knex/config';
