import { Types } from '@alcumus/globals';
import { NextFunction, Response } from 'express';
import { JsonWebTokenError, TokenExpiredError } from 'jsonwebtoken';
import { parseBillingAccountIdFromToken } from '../lib/jwt/billingAccounts';
import getBearerToken from '../lib/utils/getBearerToken';

export default async function requireBillingAccountToken(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const bearerToken = getBearerToken(request);

  if (!bearerToken) {
    response.status(401).send({ message: 'token.required' });
  } else {
    try {
      parseBillingAccountIdFromToken(bearerToken);
      next();
    } catch (err: any) {
      if (err instanceof TokenExpiredError) {
        response.status(401).send({ message: 'token.expired' });
      } else if (err instanceof JsonWebTokenError) {
        response.status(401).send({ message: 'token.invalid' });
      } else {
        throw err;
      }
    }
  }
}
