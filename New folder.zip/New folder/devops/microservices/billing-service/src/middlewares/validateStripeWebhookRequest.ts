import { Types } from '@alcumus/globals';
import { NextFunction, Response } from 'express';
import stripe from '../lib/clients/stripe';
import { getStripeWebhookSecret } from '../lib/clients/stripe/config';

/**
 * This middleware will the verify signature on a Stripe Webhook request
 * @param request
 * @param response
 * @param next
 */
export default async function validateStripeWebhookRequest(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const signature = request.header('stripe-signature') || '';

  try {
    stripe().webhooks.constructEvent(
      request.rawBody!,
      signature,
      getStripeWebhookSecret()
    );
    next();
  } catch (err) {
    const error = err as Error;
    console.error(request.id, error.message, error.stack);
    response.status(400).send('Could not verify webhook signature');
  }
}
