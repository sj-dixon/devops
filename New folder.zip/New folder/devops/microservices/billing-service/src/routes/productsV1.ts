import express, { Response, Router } from 'express';
import { Types } from '@alcumus/globals';
import { ProductEntity } from '../models/product';

const productsV1Router: Router = express.Router({ mergeParams: true });

productsV1Router.get(
  '/',
  async (request: Types.Request, response: Response) => {
    response.json(await ProductEntity.query());
  }
);

productsV1Router.get(
  '/:id',
  async (request: Types.Request, response: Response) => {
    const product = await ProductEntity.query().findById(request.params.id);

    if (product) {
      response.json(product);
    } else {
      response.status(404).json({ error: 'Product not found' });
    }
  }
);

export { productsV1Router };
