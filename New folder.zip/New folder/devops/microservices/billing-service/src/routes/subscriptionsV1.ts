import { Middlewares } from '@alcumus/globals';
import express, { Request, Response, Router } from 'express';
import stripe from '../lib/clients/stripe';
import { parseBillingAccountIdFromToken } from '../lib/jwt/billingAccounts';
import getBearerToken from '../lib/utils/getBearerToken';
import requireBillingAccountToken from '../middlewares/requireBillingAccountToken';
import { SubscriptionEntity } from '../models/subscription';
import BillingAccountRepository from '../repositories/BillingAccountRepository';
import PriceRepository from '../repositories/PriceRepository';
import syncSubscriptionWithStripe from '../models/syncSubscriptionWithStripe';
import {
  BILLING_SERVICE_API_KEY_ENV_NAME,
  BILLING_SERVICE_API_KEY_HEADER_NAME,
} from '../constants';

const subscriptionsV1Router: Router = express.Router({ mergeParams: true });

subscriptionsV1Router.post(
  '/initiate',
  requireBillingAccountToken,
  async (request: Request, response: Response) => {
    const accountId = parseBillingAccountIdFromToken(getBearerToken(request)!);

    if (!accountId) {
      response.status(401).json({ message: 'Invalid Billing Account ID' });
    } else {
      const account = await BillingAccountRepository.getById(accountId);
      const price = await PriceRepository.getById(request.body.price);

      if (!price) {
        response.status(404).json({ message: 'Price not found' });
        return;
      }

      const activeSubscriptionsCount =
        await BillingAccountRepository.getActiveSubscriptions(accountId, {
          productId: price.product?.id,
        }).resultSize();

      if (activeSubscriptionsCount !== 0) {
        response.status(403).json({
          message: `This billing account already has an active subscription for product [${price.product?.id}]`,
        });
        return;
      }

      const checkoutSession = await stripe().checkout.sessions.create({
        customer: account!.externalId,
        success_url: request.body.successUrl,
        cancel_url: request.body.cancelUrl,
        automatic_tax: {
          enabled: true,
        },
        mode: 'subscription',
        payment_method_types: ['card'],
        customer_update: {
          address: 'auto',
        },
        line_items: [
          {
            price: price.externalId,
            quantity: request.body.seats,
          },
        ],
      });

      response.json({
        url: checkoutSession.url,
        checkoutSessionId: checkoutSession.id,
      });
    }
  }
);

subscriptionsV1Router.post(
  '/manage',
  requireBillingAccountToken,
  async (request: Request, response: Response) => {
    const accountId = parseBillingAccountIdFromToken(getBearerToken(request)!);

    if (!accountId) {
      response.status(401).json({ message: 'Invalid Billing Account ID' });
    } else {
      const account = await BillingAccountRepository.getById(accountId);

      const billingPortalSession = await stripe().billingPortal.sessions.create(
        {
          customer: account!.externalId!,
          return_url: request.body.returnUrl,
        }
      );

      response.json({
        url: billingPortalSession.url,
      });
    }
  }
);

subscriptionsV1Router.get(
  '/:id',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    const subscription = await SubscriptionEntity.find(
      Number(request.params.id)
    );

    if (!subscription) {
      response.status(404).json({ message: 'Subscription Not Found' });
    } else {
      response.json(subscription);
    }
  }
);

subscriptionsV1Router.get(
  '/stripeCheckoutSessionId/:sessionId',
  requireBillingAccountToken,
  async (request: Request, response: Response) => {
    const accountId = parseBillingAccountIdFromToken(
      getBearerToken(request) as string
    );

    if (!accountId) {
      response.status(401).json({ message: 'Invalid Billing Account ID' });
      return;
    }

    const checkoutSession = await stripe().checkout.sessions.retrieve(
      request.params.sessionId
    );

    const account = await BillingAccountRepository.getById(accountId);

    if (checkoutSession.customer !== account?.externalId) {
      response.status(401).json({
        message: 'Billing Account ID does not match Checkout customer ID',
      });
      return;
    }

    if (checkoutSession.status !== 'complete') {
      response.status(400).json({ message: 'Checkout session not completed' });
      return;
    }

    const subscription = await syncSubscriptionWithStripe(
      checkoutSession.subscription as string
    );

    response.json(await SubscriptionEntity.find(subscription.id));
  }
);

subscriptionsV1Router.get(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    response.json(await SubscriptionEntity.withRelations());
  }
);

export { subscriptionsV1Router };
