import express, { Response, Router } from 'express';
import { Types } from '@alcumus/globals';
import { PlanEntity } from '../models/plan';

const plansV1Router: Router = express.Router({ mergeParams: true });

plansV1Router.get('/', async (request: Types.Request, response: Response) => {
  const query = PlanEntity.query().withGraphJoined('[prices]');

  const { productId, billingFrequency } = request.query;

  if (productId) {
    query.where('productId', productId);
  }

  if (billingFrequency) {
    query.where('billingFrequency', billingFrequency);
  }

  response.json(await query);
});

plansV1Router.get(
  '/:id',
  async (request: Types.Request, response: Response) => {
    const plan = await PlanEntity.query()
      .withGraphJoined('[prices]')
      .findById(request.params.id);

    if (plan) {
      response.json(plan);
    } else {
      response.status(404).json({ error: 'Plan not found' });
    }
  }
);

export { plansV1Router };
