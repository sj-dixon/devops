import { Middlewares } from '@alcumus/globals';
import express, { Request, Response, Router } from 'express';
import Stripe from 'stripe';
import stripe from '../lib/clients/stripe';
import {
  generateBillingAccountToken,
  parseBillingAccountIdFromToken,
} from '../lib/jwt/billingAccounts';
import getBearerToken from '../lib/utils/getBearerToken';
import requireBillingAccountToken from '../middlewares/requireBillingAccountToken';
import { BillingAccountEntity } from '../models/billingAccount';
import { BillingAddressEntity } from '../models/billingAddress';
import { SubscriptionEntity } from '../models/subscription';
import { BillingAccount } from '../types';
import {
  BILLING_SERVICE_API_KEY_ENV_NAME,
  BILLING_SERVICE_API_KEY_HEADER_NAME,
} from '../constants';

const billingAccountsV1Router: Router = express.Router({ mergeParams: true });

billingAccountsV1Router.get(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    response.json(await BillingAccountEntity.withBillingAddress());
  }
);

billingAccountsV1Router.post(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    const body: BillingAccount = request.body;

    const billingAddress = body.billingAddress || {};

    const stripeCustomer = await stripe().customers.create({
      name: body.accountHolderName,
      email: body.billingEmail || body.accountHolderEmail,
      address: {
        line1: billingAddress.line1,
        line2: billingAddress.line2,
        city: billingAddress.city,
        country: billingAddress.country,
        state: billingAddress.state,
        postal_code: billingAddress.postalCode,
      },
    });

    const account = await BillingAccountEntity.query().insertGraph({
      ...body,
      externalId: stripeCustomer.id,
    });

    response.json(await BillingAccountEntity.find(account.id));
  }
);

billingAccountsV1Router.get(
  '/me',
  requireBillingAccountToken,
  async (request: Request, response: Response) => {
    const accountId = parseBillingAccountIdFromToken(getBearerToken(request)!);

    if (!accountId) {
      response.status(401).json({ message: 'Invalid Billing Account ID' });
    } else {
      const account = await BillingAccountEntity.find(accountId);

      if (!account) {
        response.status(404).json({ message: 'Billing Account Not Found' });
      } else {
        response.json(account);
      }
    }
  }
);

billingAccountsV1Router.get(
  '/me/subscriptions',
  requireBillingAccountToken,
  async (request: Request, response: Response) => {
    const accountId = parseBillingAccountIdFromToken(getBearerToken(request)!);

    if (!accountId) {
      response.status(401).json({ message: 'Invalid Billing Account ID' });
    } else {
      const account = await BillingAccountEntity.find(accountId);

      if (!account) {
        response.status(404).json({ message: 'Billing Account Not Found' });
      } else {
        response.json(
          await SubscriptionEntity.filterByStatusAndProductId(
            account.$relatedQuery('subscriptions'),
            request.query.status as string | undefined,
            request.query.productId as string | undefined
          )
        );
      }
    }
  }
);

billingAccountsV1Router.get(
  '/:id',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    const account = await BillingAccountEntity.find(Number(request.params.id));

    if (!account) {
      response.status(404).json({ message: 'Billing Account Not Found' });
    } else {
      response.json(account);
    }
  }
);

billingAccountsV1Router.get(
  '/:id/subscriptions',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    const account = await BillingAccountEntity.find(Number(request.params.id));

    if (!account) {
      response.status(404).json({ message: 'Billing Account Not Found' });
    } else {
      response.json(
        await SubscriptionEntity.filterByStatusAndProductId(
          account.$relatedQuery('subscriptions'),
          request.query.status as string | undefined,
          request.query.productId as string | undefined
        )
      );
    }
  }
);

billingAccountsV1Router.patch(
  '/:id',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    const account = await BillingAccountEntity.query().findById(
      request.params.id
    );

    if (!account) {
      response.status(404).json({ message: 'Billing Account Not Found' });
    } else {
      const body: BillingAccount = request.body;

      const stripeUpdate: Stripe.CustomerUpdateParams = {
        name: body.accountHolderName,
        email: body.billingEmail || body.accountHolderEmail,
        address: {
          line1: body.billingAddress.line1,
          line2: body.billingAddress.line2,
          city: body.billingAddress.city,
          country: body.billingAddress.country,
          state: body.billingAddress.state,
          postal_code: body.billingAddress.postalCode,
        },
      };

      await stripe().customers.update(account.externalId, stripeUpdate);

      await BillingAccountEntity.query()
        .findById(account.id)
        .patch(request.body);

      if (request.body.billingAddress) {
        await BillingAddressEntity.query()
          .where('billingAccountId', account.id)
          .patch(request.body.billingAddress);
      }

      response.json(await BillingAccountEntity.find(account.id));
    }
  }
);

billingAccountsV1Router.post(
  '/:id/token',
  Middlewares.requireCustomApiKeyHeader(
    BILLING_SERVICE_API_KEY_HEADER_NAME,
    BILLING_SERVICE_API_KEY_ENV_NAME
  ),
  async (request: Request, response: Response) => {
    const account = await BillingAccountEntity.find(Number(request.params.id));

    if (!account) {
      response.status(404).json({ message: 'Billing Account Not Found' });
    } else {
      response.json({ token: generateBillingAccountToken(account) });
    }
  }
);

export { billingAccountsV1Router };
