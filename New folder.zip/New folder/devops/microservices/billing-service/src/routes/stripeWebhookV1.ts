import { Types } from '@alcumus/globals';
import express, { Response, Router } from 'express';
import validateStripeWebhookRequest from '../middlewares/validateStripeWebhookRequest';
import syncBillingAccountWithStripe from '../models/syncBillingAccountWithStripe';
import syncSubscriptionWithStripe from '../models/syncSubscriptionWithStripe';

const stripeWebhookV1Router: Router = express.Router({ mergeParams: true });

stripeWebhookV1Router.post(
  '/',
  validateStripeWebhookRequest,
  async (request: Types.Request, response: Response) => {
    const event = request.body;
    const eventType = event.type as string;

    const customerUpdateEventPattern = /^customer\.[a-z]+$/;
    const subscriptionUpdatEventPattern = /^customer\.subscription\.[a-z]+$/;

    if (eventType.match(customerUpdateEventPattern)) {
      // Handle customer data updates
      await syncBillingAccountWithStripe(event.data.object.id);
      response.status(200).send('OK');
    } else if (eventType.match(subscriptionUpdatEventPattern)) {
      // Handle subscription updates
      await syncSubscriptionWithStripe(event.data.object.id);
      response.status(200).send('OK');
    } else {
      // Any other events
      response.status(500).send('Webhook event not supported');
    }
  }
);

export default stripeWebhookV1Router;
