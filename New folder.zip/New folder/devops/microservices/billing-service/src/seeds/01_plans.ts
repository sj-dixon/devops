import { Knex } from 'knex';
import { Model } from 'objection';
import { seedProduct } from '../lib/utils/stripe/seed';
import seedData from '../lib/utils/stripe/seedData';

export async function seed(knex: Knex): Promise<void> {
  Model.knex(knex);

  await seedProduct(seedData[0]);
}
