import Stripe from 'stripe';
import stripe from '../lib/clients/stripe';
import { BillingAccountEntity } from '../models/billingAccount';
import { BillingAddressEntity } from '../models/billingAddress';

export class SyncBillingAccountWithStripeError extends Error {
  constructor(message: string | undefined) {
    super(message);
    this.name = 'SyncBillingAccountWithStripeError';
  }
}

/**
 * Update billing account and address from Stripe Customer object
 * (Used in webhook)
 * @param stripeCustomerId
 * @returns
 */
export default async function syncBillingAccountWithStripe(
  stripeCustomerId: string
): Promise<BillingAccountEntity> {
  /**
   * Since Stripe does not guarantee the order of events, it's better to fetch the latest
   * object from Stripe and sync database with it, instead of using data from the event
   */
  const stripeCustomer = (await stripe().customers.retrieve(
    stripeCustomerId
  )) as Stripe.Customer;

  const billingAccount = await BillingAccountEntity.findByExternalId(
    stripeCustomerId
  );

  if (!billingAccount) {
    throw new SyncBillingAccountWithStripeError(
      `Could not find billing account for stripe customer id '${stripeCustomerId}'`
    );
  }

  const addressUpdate = {
    billingAccountId: billingAccount.id,
    line1: stripeCustomer.address?.line1 || '',
    line2: stripeCustomer.address?.line2 || '',
    city: stripeCustomer.address?.city || '',
    state: stripeCustomer.address?.state || '',
    country: stripeCustomer.address?.country || '',
    postalCode: stripeCustomer.address?.postal_code || '',
  };

  await BillingAddressEntity.query()
    .insertAndFetch(addressUpdate)
    .onConflict('billingAccountId')
    .merge();

  return billingAccount
    .$query()
    .patchAndFetch({ billingEmail: stripeCustomer.email });
}
