import { JsonSchemaBuilder } from '@alcumus/objection-lib';
import { PartialModelObject, Transaction } from 'objection';
import { Product } from '../types';
import BaseModel from './baseModel';

export class ProductEntity extends BaseModel implements Product {
  name!: string;

  static tableName = 'products';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withField({
      fieldName: 'deletedAt',
      fieldType: 'datetime',
      required: false,
    })
    .withStringField('name')
    .build();

  static get relationMappings() {
    return {
      plans: {
        relation: BaseModel.HasManyRelation,
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        modelClass: require('./plan').PlanEntity,
        join: {
          from: 'products.id',
          to: 'plans.product_id',
        },
      },
    };
  }

  static async create(
    profile: Product,
    trx?: Transaction
  ): Promise<ProductEntity> {
    return ProductEntity.query(trx).insert(profile);
  }

  static async find(userId: number): Promise<ProductEntity> {
    return ProductEntity.query().findById(userId);
  }

  static async update(
    userId: number,
    mutation: PartialModelObject<ProductEntity>,
    trx?: Transaction
  ): Promise<number> {
    return ProductEntity.query(trx).findById(userId).patch(mutation);
  }
}
