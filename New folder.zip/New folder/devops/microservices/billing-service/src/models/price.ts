import { JsonSchemaBuilder } from '@alcumus/objection-lib';
import { PartialModelObject, Transaction } from 'objection';
import { Plan, Price, Product } from '../types';
import BaseModel from './baseModel';
import * as uuid from 'uuid';

export class PriceEntity extends BaseModel implements Price {
  name?: string;
  uuid?: string | ArrayLike<number>;
  currency?: string;
  billingFrequency?: string;
  externalId?: string;
  maxSeats?: number;
  planId?: number;
  product?: Product;
  plan?: Plan;

  static tableName = 'prices';

  static get relationMappings() {
    return {
      plan: {
        relation: BaseModel.BelongsToOneRelation,
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        modelClass: require('./plan').PlanEntity,
        join: {
          from: 'prices.plan_id',
          to: 'plans.id',
        },
      },
      product: {
        relation: BaseModel.HasOneThroughRelation,
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        modelClass: require('./product').ProductEntity,
        join: {
          from: 'prices.plan_id',
          through: {
            from: 'plans.id',
            to: 'plans.product_id',
          },
          to: 'products.id',
        },
      },
    };
  }

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withField({
      fieldName: 'deletedAt',
      fieldType: 'datetime',
      required: false,
    })
    .withStringField('currency')
    .withIntegerField('price')
    .withStringField('billingFrequency')
    .withStringField('externalId')
    .build();

  $beforeInsert() {
    super.$beforeInsert();
    // We need to pass a 16-byte buffer so that the return value is a Buffer
    this.uuid = uuid.v4({}, Buffer.alloc(16));
  }

  $afterFind() {
    // Cast the Buffer to a UUIDv4 compliant string using the library
    if (this.uuid instanceof Buffer) {
      this.uuid = uuid.stringify(this.uuid);
    }
  }

  static async create(price: Price, trx?: Transaction): Promise<PriceEntity> {
    return this.query(trx).insert(price);
  }

  static async find(userId: number): Promise<PriceEntity> {
    return this.query().findById(userId);
  }

  static async findByExternalId(externalId: string): Promise<PriceEntity> {
    return this.query().where('externalId', externalId).first();
  }

  static async update(
    userId: number,
    mutation: PartialModelObject<PriceEntity>,
    trx?: Transaction
  ): Promise<number> {
    return this.query(trx).findById(userId).patch(mutation);
  }
}
