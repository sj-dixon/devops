import { JsonSchemaBuilder } from '@alcumus/objection-lib';
import { PartialModelObject, Transaction } from 'objection';
import { BillingAddress } from '../types';
import BaseModel from './baseModel';
import { BillingAccountEntity } from './billingAccount';

export class BillingAddressEntity extends BaseModel implements BillingAddress {
  billingAccountId!: number;
  line1!: string;
  line2!: string;
  city!: string;
  state!: string;
  country!: string;
  postalCode!: string;

  static tableName = 'billing_addresses';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withField({
      fieldName: 'deletedAt',
      fieldType: 'datetime',
      required: false,
    })
    .withStringField('line1')
    .withStringField('line2')
    .withStringField('city')
    .withStringField('state')
    .withStringField('country')
    .withStringField('postalCode')
    .build();

  static relationMappings = {
    billingAccount: {
      relation: BaseModel.BelongsToOneRelation,
      modelClass: BillingAccountEntity,
      join: {
        from: 'billing_addressses.billing_account_id',
        to: 'billing_accounts.id',
      },
    },
  };

  static async create(
    data: BillingAddress,
    trx?: Transaction
  ): Promise<BillingAddressEntity> {
    return BillingAddressEntity.query(trx).insert(data);
  }

  static async find(id: number): Promise<BillingAddressEntity | null> {
    return BillingAddressEntity.query().findById(id);
  }

  static async findByBillingAccountId(
    billingAccountId: number
  ): Promise<BillingAddressEntity | null> {
    return BillingAddressEntity.query()
      .where('billingAccountId', billingAccountId)
      .first();
  }

  static async update(
    id: number,
    mutation: PartialModelObject<BillingAddressEntity>,
    trx?: Transaction
  ): Promise<number> {
    return BillingAddressEntity.query(trx).findById(id).patch(mutation);
  }
}
