import Stripe from 'stripe';
import stripe from '../lib/clients/stripe';
import mapStripeStatus from '../lib/utils/stripe/mapStripeStatus';
import { BillingAccountEntity } from './billingAccount';
import { SubscriptionEntity } from './subscription';
import { PriceEntity } from './price';
import { DateTime } from 'luxon';
import { toMySqlDateTimeString } from '@alcumus/objection-lib';

export class SyncSubscriptionWithStripeError extends Error {
  constructor(message: string | undefined) {
    super(message);
    this.name = 'SyncSubscriptionWithStripeError';
  }
}

/**
 * Update subscription from Stripe Subscription object
 * (Used in webhook)
 * @returns
 * @param stripeSubscriptionId
 */
export default async function syncSubscriptionWithStripe(
  stripeSubscriptionId: string
): Promise<SubscriptionEntity> {
  /**
   * Since Stripe does not guarantee the order of events, it's better to fetch the latest
   * object from Stripe and sync database with it, instead of using data from the event
   */
  const stripeSubscription = await stripe().subscriptions.retrieve(
    stripeSubscriptionId,
    {
      expand: [
        'default_payment_method',
        'customer.invoice_settings.default_payment_method',
      ],
    }
  );

  const stripeCustomer = stripeSubscription.customer as Stripe.Customer;

  // If a subscription does not have payment method attached to it,
  // that means the default payment method on customer will be used
  const paymentMethod = (stripeSubscription.default_payment_method ||
    stripeCustomer.invoice_settings
      .default_payment_method) as Stripe.PaymentMethod;

  const lineItem = stripeSubscription.items.data[0];
  const stripePriceId = lineItem.price.id;
  const stripeQuantity = lineItem.quantity;

  const billingAccount = await BillingAccountEntity.findByExternalId(
    stripeCustomer.id
  );
  const price = await PriceEntity.findByExternalId(stripePriceId);

  if (!billingAccount) {
    throw new SyncSubscriptionWithStripeError(
      `Could not find billing account for stripe customer id : '${stripeCustomer.id}'`
    );
  }

  if (!price) {
    throw new SyncSubscriptionWithStripeError(
      `Could not find price for stripe price id '${stripePriceId}'`
    );
  }

  const card = paymentMethod.card;

  const update = {
    externalId: stripeSubscriptionId,
    billingAccountId: billingAccount.id,
    priceId: price.id,
    status: mapStripeStatus(stripeSubscription.status),
    seats: stripeQuantity,
    cardNumber: `${card?.brand} - ${card?.last4}`,
    cardExpiry: `${card?.exp_month}/${card?.exp_year}`,
    nextPaymentDate: toMySqlDateTimeString(
      DateTime.fromSeconds(stripeSubscription.current_period_end).toJSDate()
    ),
    previousPaymentDate: toMySqlDateTimeString(
      DateTime.fromSeconds(stripeSubscription.current_period_start).toJSDate()
    ),
  };

  return SubscriptionEntity.query()
    .insertAndFetch(update)
    .onConflict('externalId')
    .merge();
}
