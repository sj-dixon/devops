import { JsonSchemaBuilder } from '@alcumus/objection-lib';
import { PartialModelObject, Transaction } from 'objection';
import { ExternalIdType, Plan, Price } from '../types';
import BaseModel from './baseModel';

export class PlanEntity extends BaseModel implements Plan {
  name?: string;
  maxSeats?: number;
  productId?: number;
  prices?: Price[];

  externalId?: string;
  externalIdType?: ExternalIdType;

  static tableName = 'plans';

  static get relationMappings() {
    return {
      product: {
        relation: BaseModel.BelongsToOneRelation,
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        modelClass: require('./product').ProductEntity,
        join: {
          from: 'plans.product_id',
          to: 'products.id',
        },
      },
      prices: {
        relation: BaseModel.HasManyRelation,
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        modelClass: require('./price').PriceEntity,
        join: {
          from: 'plans.id',
          to: 'prices.plan_id',
        },
      },
    };
  }

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withField({
      fieldName: 'deletedAt',
      fieldType: 'datetime',
      required: false,
    })
    .withStringField('name')
    .withIntegerField('maxSeats')
    .build();

  static async create(profile: Plan, trx?: Transaction): Promise<PlanEntity> {
    return PlanEntity.query(trx).insert(profile);
  }

  static async find(userId: number): Promise<PlanEntity> {
    return PlanEntity.query().findById(userId);
  }

  static async findByExternalId(
    externalId: string,
    externalIdType: ExternalIdType
  ): Promise<PlanEntity> {
    return PlanEntity.query()
      .where('externalId', externalId)
      .where('externalIdType', externalIdType)
      .first();
  }

  static async update(
    userId: number,
    mutation: PartialModelObject<PlanEntity>,
    trx?: Transaction
  ): Promise<number> {
    return PlanEntity.query(trx).findById(userId).patch(mutation);
  }
}
