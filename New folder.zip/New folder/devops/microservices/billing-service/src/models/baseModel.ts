import { getMySqlCurrentTimestamp } from '@alcumus/objection-lib';
import { DateTime } from 'luxon';
import { Model } from 'objection';
import { BaseEntity, SoftDeletableEntity } from '../types';

export default abstract class BaseModel
  extends Model
  implements BaseEntity, SoftDeletableEntity
{
  id!: number;
  createdAt!: DateTime | string;
  modifiedAt!: DateTime | string;
  deletedAt!: DateTime | string;

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeInsert() {
    const now = getMySqlCurrentTimestamp();
    this.createdAt = now;
    this.modifiedAt = now;
  }

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeUpdate() {
    this.modifiedAt = getMySqlCurrentTimestamp();
  }
}
