import { JsonSchemaBuilder } from '@alcumus/objection-lib';
import { PartialModelObject, QueryBuilderType, Transaction } from 'objection';
import { BillingAccount, BillingAddress } from '../types';
import BaseModel from './baseModel';
import { BillingAddressEntity } from './billingAddress';
import { SubscriptionEntity } from './subscription';

export class BillingAccountEntity extends BaseModel implements BillingAccount {
  billingAddressId?: number;

  externalId!: string;
  accountHolderName!: string;
  accountHolderEmail!: string;
  billingEmail!: string;
  billingAddress!: BillingAddress;

  static tableName = 'billing_accounts';

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withField({
      fieldName: 'deletedAt',
      fieldType: 'datetime',
      required: false,
    })
    .withStringField('accountHolderName')
    .withStringField('accountHolderEmail')
    .withStringField('billingEmail')
    .build();

  static relationMappings = {
    billingAddress: {
      relation: BaseModel.HasOneRelation,
      modelClass: BillingAddressEntity,
      join: {
        from: 'billing_accounts.id',
        to: 'billing_addresses.billing_account_id',
      },
    },
    subscriptions: {
      relation: BaseModel.HasManyRelation,
      modelClass: SubscriptionEntity,
      join: {
        from: 'billing_accounts.id',
        to: 'subscriptions.billing_account_id',
      },
    },
  };

  static withBillingAddress(): QueryBuilderType<BillingAccountEntity> {
    return BillingAccountEntity.query().withGraphJoined('billingAddress');
  }

  static async create(
    data: BillingAccount,
    trx?: Transaction
  ): Promise<BillingAccountEntity> {
    return BillingAccountEntity.query(trx).insert(data);
  }

  static async find(id: number): Promise<BillingAccountEntity | null> {
    return BillingAccountEntity.withBillingAddress().findById(id);
  }

  static async findByExternalId(
    externalId: string
  ): Promise<BillingAccountEntity | null> {
    return BillingAccountEntity.query().where('externalId', externalId).first();
  }

  static async update(
    id: number,
    mutation: PartialModelObject<BillingAccountEntity>,
    trx?: Transaction
  ): Promise<number> {
    return BillingAccountEntity.query(trx).findById(id).patch(mutation);
  }
}
