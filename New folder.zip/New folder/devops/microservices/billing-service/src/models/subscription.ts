import { Model, QueryBuilderType } from 'objection';
import {
  BillingAccount,
  Plan,
  Subscription,
  SubscriptionStatus,
} from '../types';
import BaseModel from './baseModel';
import { ProductEntity } from './product';
import { PriceEntity } from './price';
import { DateTime } from 'luxon';

export class SubscriptionEntity extends BaseModel implements Subscription {
  externalId?: string;
  billingAccountId?: number;
  planId?: number;
  priceId?: number;

  billingAccount!: BillingAccount;
  plan!: Plan;
  seats!: number;
  status!: SubscriptionStatus;
  cardNumber!: string;
  cardExpiry!: string;

  nextPaymentDate!: DateTime | string;
  previousPaymentDate!: DateTime | string;

  static tableName = 'subscriptions';

  static relationMappings = {
    price: {
      relation: BaseModel.BelongsToOneRelation,
      modelClass: PriceEntity,
      join: {
        from: 'subscriptions.price_id',
        to: 'prices.id',
      },
    },
  };

  static async findByExternalId(
    externalId: string
  ): Promise<SubscriptionEntity | null> {
    return SubscriptionEntity.withRelations()
      .where('subscriptions.externalId', externalId)
      .first();
  }

  static filterByStatusAndProductId(
    query: QueryBuilderType<Model>,
    status: string | undefined,
    productId: string | undefined
  ): QueryBuilderType<Model> {
    if (status) {
      query.where('status', status);
    }

    if (productId) {
      query.whereExists(
        SubscriptionEntity.relatedQuery('price').whereExists(
          PriceEntity.relatedQuery<ProductEntity>('product').where(
            'product.id',
            productId
          )
        )
      );
    }

    return query.withGraphJoined('price.[plan, product]');
  }

  static withRelations(): QueryBuilderType<SubscriptionEntity> {
    return SubscriptionEntity.query().withGraphJoined('price.[plan, product]');
  }

  static async find(id: number): Promise<SubscriptionEntity> {
    return SubscriptionEntity.withRelations().findById(id);
  }
}
