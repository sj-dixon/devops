import { DateTime } from 'luxon';

export interface BaseEntity {
  createdAt?: DateTime | string;
  modifiedAt?: DateTime | string;
}

export enum ExternalIdType {
  StripeProduct = 'STRIPE_PRODUCT',
}

export interface SoftDeletableEntity {
  deletedAt?: DateTime | string;
}

export interface Product extends BaseEntity {
  id?: number;
  name?: string;
  externalId?: string;
  plans?: Plan[];
}

export interface Plan extends BaseEntity {
  id?: number;
  name?: string;
  maxSeats?: number;
  productId?: number;
  prices?: Price[];
  externalId?: string;
  externalIdType?: ExternalIdType;
}

export interface Price extends BaseEntity {
  id?: number;
  uuid?: string | ArrayLike<number>;
  billingFrequency?: string;
  price?: number;
  currency?: string;
  externalId?: string;
  planId?: number;
  product?: Product;
  plan?: Plan;
}

export interface BillingAccount extends BaseEntity {
  id?: number;
  externalId?: string;

  accountHolderName: string;
  accountHolderEmail: string;
  billingEmail: string;
  billingAddress: BillingAddress;
}

export interface BillingAddress extends BaseEntity {
  id?: number;
  billingAccountId?: number;

  line1: string;
  line2: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
}

/**
 * Pending = Subscription has not yet started, may start or get deleted
 * Active = Active and paid for till next billing date
 * Past due = Stripe has tried to charge for the next month / year but failed.
 * It will stay in this state till Stripe either fails multiple times or succeeds.
 * Canceled = Subscription canceled due to normal expiry or failing to charge
 */
export type SubscriptionStatus = 'pending' | 'active' | 'past_due' | 'canceled';

export interface Subscription extends BaseEntity {
  id?: number;
  externalId?: string;
  billingAccountId?: number;
  planId?: number;

  billingAccount: BillingAccount;
  plan: Plan;
  seats: number;
  status: SubscriptionStatus;

  cardNumber: string;
  cardExpiry: string;

  nextPaymentDate: DateTime | string;
  previousPaymentDate: DateTime | string;
}
