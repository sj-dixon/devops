import connect, { Knex } from 'knex';
import { Model } from 'objection';
import { config, testConfig } from './config';
import { Utilities } from '@alcumus/globals';

export function getKnexClient(): Knex {
  const knex = connect(config);
  Model.knex(knex);
  return knex;
}

export function getTestKnexClient(): Knex {
  const knex = connect(testConfig);
  Model.knex(knex);
  return knex;
}

export function printSqlIfDebugFlagEnabled(query: Knex.QueryBuilder): void {
  if (Utilities.ProcessEnv.isEnabled('DEBUG_DIRECT_SQL_CALLS')) {
    console.log(query.toSQL());
  }
}
