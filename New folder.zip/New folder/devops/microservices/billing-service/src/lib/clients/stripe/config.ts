import { Utilities } from '@alcumus/globals';
import Stripe from 'stripe';

export function getStripeConfig(): Stripe.StripeConfig {
  return {
    apiVersion: Utilities.ProcessEnv.getValueOrDefault(
      'BILLING_SERVICE_STRIPE_API_VERSION',
      '2020-08-27'
    ) as any,
  };
}

export const getStripeSecretKey = () =>
  Utilities.ProcessEnv.getValueOrThrow('BILLING_SERVICE_STRIPE_SECRET_KEY');

export const getStripeWebhookSecret = () =>
  Utilities.ProcessEnv.getValueOrThrow('BILLING_SERVICE_STRIPE_WEBHOOK_SECRET');
