import { Knex } from 'knex';
import { Utilities } from '@alcumus/globals';
import { getKnexConfig } from '@alcumus/objection-lib';
import path from 'path';

const migrationsDirectory = path.join(
  __dirname,
  '..',
  '..',
  '..',
  'migrations'
);

const databaseName = Utilities.ProcessEnv.getValueOrDefault(
  'BILLING_SERVICE_DATABASE_NAME',
  'billing_service_db'
);
export const config: Knex.Config = getKnexConfig(databaseName);

export const testDatabaseName = Utilities.ProcessEnv.getValueOrDefault(
  'BILLING_SERVICE_TEST_DATABASE_NAME',
  'billing_service_test_db'
);

export const testConfig: Knex.Config = {
  ...getKnexConfig(testDatabaseName, migrationsDirectory),
  acquireConnectionTimeout: 1000,
};
