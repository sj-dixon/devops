import Stripe from 'stripe';
import { getStripeConfig, getStripeSecretKey } from './config';

export default () => new Stripe(getStripeSecretKey(), getStripeConfig());
