import Stripe from 'stripe';
import { SubscriptionStatus } from '../../../types';

/**
 * Util function to map Stripe's status to Billing service status
 * @param stripeStatus
 * @returns
 */
export default function mapStripeStatus(
  stripeStatus: Stripe.Subscription.Status
): SubscriptionStatus {
  switch (stripeStatus) {
    case 'incomplete':
      return 'pending';
    case 'incomplete_expired':
      return 'pending';
    case 'canceled':
      return 'canceled';
    case 'past_due':
      return 'past_due';
    case 'trialing':
      return 'active';
    case 'active':
      return 'active';
    case 'unpaid':
      return 'canceled';
  }
}
