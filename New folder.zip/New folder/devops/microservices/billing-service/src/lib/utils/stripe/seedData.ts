import { Product } from '../../../types';

export default [
  {
    name: 'eCompliance',
    plans: [
      {
        name: 'Starter',
        maxSeats: 20,
        prices: [
          {
            billingFrequency: 'monthly',
            price: 1500,
            currency: 'CAD',
          },
          {
            billingFrequency: 'yearly',
            price: 18000,
            currency: 'CAD',
          },
        ],
      },
      {
        name: 'Standard',
        maxSeats: 150,
        prices: [
          {
            billingFrequency: 'monthly',
            price: 2000,
            currency: 'CAD',
          },
          {
            billingFrequency: 'yearly',
            price: 19200,
            currency: 'CAD',
          },
        ],
      },
    ],
  },
] as Array<Product>;
