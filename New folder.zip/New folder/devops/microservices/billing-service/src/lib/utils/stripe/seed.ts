import { PlanEntity } from '../../../models/plan';
import { ProductEntity } from '../../../models/product';
import { ExternalIdType, Plan, Price, Product } from '../../../types';
import stripe from '../../clients/stripe';
import systemMetadata from './systemMetadata';
import { PriceEntity } from '../../../models/price';

export async function seedProduct(product: Product): Promise<ProductEntity> {
  const createdProduct = await ProductEntity.create({
    ...product,
    plans: undefined,
  });

  for (const plan of product.plans || []) {
    const stripeProductId = (
      await stripe().products.create({
        // TODO: Either remove the plan suffix or localize this
        name: `${product.name} ${plan.name} plan`,
        metadata: {
          // Add OS metadata to the Stripe object so
          // it's easier to ID who created which object
          ...systemMetadata,
        },
      })
    ).id;

    const createdPlan = await PlanEntity.create({
      ...plan,
      prices: undefined,
      productId: createdProduct.id,
      externalId: stripeProductId,
      externalIdType: ExternalIdType.StripeProduct,
    });

    for (const price of plan.prices || []) {
      await seedPlan(createdProduct, createdPlan, price);
    }
  }

  return createdProduct;
}

export async function seedPlan(
  product: Product,
  plan: Plan,
  price: Price
): Promise<void> {
  const stripePriceId = (
    await stripe().prices.create({
      nickname: plan.name!,
      currency: price.currency!,
      unit_amount: price.price!,
      product: plan.externalId,
      tax_behavior: 'exclusive',
      recurring: {
        interval: price.billingFrequency === 'yearly' ? 'year' : 'month',
      },
      metadata: {
        ...systemMetadata,
      },
    })
  ).id;

  await PriceEntity.create({
    ...price,
    planId: plan.id,
    externalId: stripePriceId,
  });
}
