import { PlanEntity } from '../../../models/plan';
import { ProductEntity } from '../../../models/product';
import { Plan, Product } from '../../../types';
import stripe from '../../clients/stripe';
import { PriceEntity } from '../../../models/price';

export async function reapProduct(product: Product) {
  try {
    for (const plan of await PlanEntity.query().where(
      'productId',
      product.id!
    )) {
      await stripe().products.update(plan.externalId!, { active: false });
      await reapPlan(plan);
    }

    await ProductEntity.query().deleteById(product.id!);
  } catch (e) {
    console.error(`Could not reap Product: ${product.externalId}: ${e}`);
  }
}

export async function reapPlan(plan: Plan) {
  for (const price of await PriceEntity.query().where('planId', plan.id)) {
    try {
      await stripe().prices.update(price.externalId!, {
        active: false,
      });
      await PriceEntity.query().deleteById(price.id!);
    } catch (e) {
      console.error(`Could not reap Price: ${price.externalId}: ${e}`);
    }
  }
  await PlanEntity.query().deleteById(plan.id!);
}
