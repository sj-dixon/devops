import os from 'os';

/**
 * Create an object that can be passed to Stripe Object's metadata,
 * to track which machine / system created the object.
 */
export default {
  created_by_os: os.type(),
  created_by_platform: os.platform(),
  created_by_hostname: os.hostname(),
  created_by_system_username: os.userInfo().username,
};
