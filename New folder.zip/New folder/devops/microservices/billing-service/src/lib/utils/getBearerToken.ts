import { Request } from 'express';

/**
 * Given a request object, this will return the Bearer Auth token
 */
export default function getBearerToken(request: Request): undefined | string {
  const header: string = request.header('Authorization') || '';
  const regexMatch = header.match(/Bearer (.*)/i);

  return regexMatch?.[1];
}
