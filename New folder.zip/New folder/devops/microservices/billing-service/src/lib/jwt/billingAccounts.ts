import { Utilities } from '@alcumus/globals';
import { JwtPayload } from 'jsonwebtoken';
import { decode, sign } from '.';
import { BillingAccount } from '../../types';

export interface DecodedBillingAccountToken {
  billingAccountId: string;
}

export function generateBillingAccountToken(
  billingAccount: BillingAccount
): string {
  const expiresInSeconds = Number(
    Utilities.ProcessEnv.getValueOrDefault(
      'BILLING_SERVICE_TOKEN_EXPIRATION_SECONDS',
      '3600'
    )
  );

  return sign(
    {
      // Private claims
      type: 'BillingAccountToken',
      billingAccountId: billingAccount.id,

      // Public claims
      sub: billingAccount.id,
    },
    expiresInSeconds
  );
}

export function parseBillingAccountIdFromToken(
  token: string
): undefined | number {
  const decoded = decode(token) as JwtPayload;

  const accountId = parseInt(decoded.billingAccountId);

  if (decoded.type === 'BillingAccountToken' && !isNaN(accountId)) {
    return accountId;
  }
}
