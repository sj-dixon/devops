import { Utilities } from '@alcumus/globals';
import jsonWebToken, { JwtPayload } from 'jsonwebtoken';

function getSigningSecret(): string {
  return Utilities.ProcessEnv.getValueOrThrow('BILLING_SERVICE_TOKEN_SECRET');
}

export function sign(payload: any, expiresInSeconds: number): string {
  return jsonWebToken.sign(payload, getSigningSecret(), {
    expiresIn: expiresInSeconds,
  });
}

export function decode(token: string): JwtPayload {
  return jsonWebToken.verify(token, getSigningSecret()) as JwtPayload;
}

export default { sign, decode };
