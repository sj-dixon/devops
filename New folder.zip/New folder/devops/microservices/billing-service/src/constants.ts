import { Utilities } from '@alcumus/globals';

export const BILLING_SERVICE_PORT =
  Number(Utilities.ProcessEnv.getValue('BILLING_SERVICE_PORT')) || 8013;

export const BASE_PATH_V1 = '/api/v1';

export const BILLING_SERVICE_API_KEY_ENV_NAME = 'BILLING_SERVICE_API_KEY';
export const BILLING_SERVICE_API_KEY_HEADER_NAME = 'x-api-key';

export const ENDPOINTS = {
  PRODUCTS: `${BASE_PATH_V1}/products`,
  PLANS: `${BASE_PATH_V1}/plans`,
  BILLING_ACCOUNTS: `${BASE_PATH_V1}/billingAccounts`,
  SUBSCRIPTIONS: `${BASE_PATH_V1}/subscriptions`,
  STRIPE_WEBHOOK: `${BASE_PATH_V1}/stripe/webhook`,
};
