import { Knex } from 'knex';

const TABLE = 'products';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE, (schema) => {
    schema.datetime('created_at').alter();
    schema.datetime('modified_at').alter();
    schema.datetime('deleted_at').alter();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE, (schema) => {
    schema.timestamp('created_at').alter();
    schema.timestamp('modified_at').alter();
    schema.timestamp('deleted_at').alter();
  });
}
