import { Knex } from 'knex';

const TABLE_NAME = 'prices';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // common metadata
      tableBuilder.increments('id').primary();
      // UUIDs must be stored as binary
      tableBuilder.binary('uuid', 16).unique().notNullable();
      tableBuilder.timestamp('created_at').notNullable();
      tableBuilder.timestamp('modified_at').notNullable();

      // common soft deletion metadata
      tableBuilder.timestamp('deleted_at').nullable();

      // Stores external IDs, currently Stripe, but naming it generic
      // so we are not tied to any service provider
      tableBuilder.string('external_id').notNullable();

      tableBuilder.integer('plan_id').unsigned().notNullable();

      // Stores prices in the minimum currency unit, i.e, cents
      tableBuilder.integer('price').unsigned().notNullable();
      // Making currency a string instead of enum as was brought up recently
      tableBuilder.string('currency').notNullable();
      tableBuilder.string('billing_frequency').notNullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
