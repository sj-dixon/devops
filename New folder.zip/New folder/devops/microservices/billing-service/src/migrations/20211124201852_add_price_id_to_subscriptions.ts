import { Knex } from 'knex';

const TABLE_NAME = 'subscriptions';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.integer('price_id').unsigned().notNullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropColumn('price_id');
  });
}
