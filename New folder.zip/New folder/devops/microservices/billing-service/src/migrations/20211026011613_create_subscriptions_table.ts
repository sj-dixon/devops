import { Knex } from 'knex';

const TABLE_NAME = 'subscriptions';

export async function up(knex: Knex): Promise<void> {
  // noinspection DuplicatedCode
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // common metadata
      tableBuilder.increments('id').primary();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      // common soft deletion metadata
      tableBuilder.timestamp('deleted_at').nullable();

      // Foreign key to reference a Billing Account
      tableBuilder.integer('billing_account_id').unsigned().notNullable();

      tableBuilder
        .enum('status', ['pending', 'active', 'past_due', 'canceled'])
        .notNullable();
      tableBuilder.string('external_id').notNullable();
      tableBuilder.integer('plan_id').unsigned().notNullable();
      tableBuilder.integer('seats').unsigned().notNullable();

      // TODO: Drop these columns when Payment Method entity is introduced
      tableBuilder.string('card_number').notNullable();
      tableBuilder.string('card_expiry').notNullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
