import { Knex } from 'knex';

const TABLE_NAME = 'subscriptions';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropColumn('plan_id');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.integer('plan_id').unsigned().notNullable();
  });
}
