import { Knex } from 'knex';

const TABLE_NAME = 'plans';
const UK_NAME = 'uniq_plans_external_id';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropColumns(
      'external_id',
      'price',
      'currency',
      'billing_frequency'
    );
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.string('external_id').notNullable();
    tableBuilder.integer('price').unsigned().notNullable();
    tableBuilder.string('currency').notNullable();
    tableBuilder.string('billing_frequency').notNullable();
    tableBuilder.unique(['external_id'], UK_NAME);
  });
}
