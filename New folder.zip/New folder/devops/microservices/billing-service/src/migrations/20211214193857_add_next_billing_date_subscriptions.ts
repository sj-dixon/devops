import { Knex } from 'knex';

const TABLE_NAME = 'subscriptions';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.datetime('previous_payment_date').nullable();
    tableBuilder.datetime('next_payment_date').nullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropColumns('next_payment_date', 'previous_payment_date');
  });
}
