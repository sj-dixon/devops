import { Knex } from 'knex';

const TABLE_NAME = 'plans';
const UNIQUE_KEY_NAME = 'uniq_plans_external_id_external_id_type';
const UNIQUE_COLUMNS = ['external_id', 'external_id_type'];

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.unique(UNIQUE_COLUMNS, UNIQUE_KEY_NAME);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropUnique(UNIQUE_COLUMNS, UNIQUE_KEY_NAME);
  });
}
