import { Knex } from 'knex';

const TABLE_NAME = 'subscriptions';
const COLUMN_NAME = 'price_id';
const FK_NAME = 'FK_subscriptions_prices_price_id';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder
      .foreign(COLUMN_NAME, FK_NAME)
      .references('id')
      .inTable('prices')
      .onDelete('RESTRICT');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropForeign(COLUMN_NAME, FK_NAME);
  });
}
