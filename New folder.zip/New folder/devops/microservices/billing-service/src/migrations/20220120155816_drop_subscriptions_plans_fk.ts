import { Knex } from 'knex';

const TABLE_NAME = 'subscriptions';
const COLUMN_NAME = 'plan_id';
const TARGET_TABLE_NAME = 'plans';
const FK_NAME = `FK_${TABLE_NAME}_${TARGET_TABLE_NAME}_${COLUMN_NAME}`;

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropForeign(COLUMN_NAME, FK_NAME);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder
      .foreign(COLUMN_NAME, FK_NAME)
      .references('id')
      .inTable(TARGET_TABLE_NAME)
      .onDelete('RESTRICT');
  });
}
