import { Knex } from 'knex';

const TABLE_NAME = 'billing_addresses';

export async function up(knex: Knex): Promise<void> {
  // noinspection DuplicatedCode
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // common metadata
      tableBuilder.increments('id').primary();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      // common soft deletion metadata
      tableBuilder.timestamp('deleted_at').nullable();

      // Foreign key to reference a Billing Account
      tableBuilder.integer('billing_account_id').unsigned().notNullable();

      tableBuilder.string('line1').notNullable();
      tableBuilder.string('line2').notNullable();
      tableBuilder.string('city').notNullable();
      tableBuilder.string('state').notNullable();
      tableBuilder.string('country').notNullable();
      tableBuilder.string('postal_code').notNullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
