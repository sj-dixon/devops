import { Knex } from 'knex';

const TABLE_NAME = 'billing_addresses';
const COLUMN_NAME = 'billing_account_id';
const FK_NAME = 'FK_billing_addresses_billing_accounts_billing_account_id';
const UK_NAME = 'uniq_billing_addresses_billing_account_id';

const REF_TABLE = 'billing_accounts';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.unique([COLUMN_NAME], UK_NAME);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    // When dropping a UNIQUE index in MySQL, we have to delete the FK first
    // otherwise it won't allow us to drop the UNIQUE index.
    tableBuilder.dropForeign(COLUMN_NAME, FK_NAME);
    tableBuilder.dropUnique([COLUMN_NAME], UK_NAME);
    // Recreate the FK
    tableBuilder
      .foreign(COLUMN_NAME, FK_NAME)
      .references('id')
      .inTable(REF_TABLE)
      .onDelete('RESTRICT');
  });
}
