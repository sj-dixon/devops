import { Knex } from 'knex';

const TABLE_NAME = 'billing_accounts';
const UK_NAME = 'uniq_billing_accounts_external_id';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.unique(['external_id'], UK_NAME);
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropUnique(['external_id'], UK_NAME);
  });
}
