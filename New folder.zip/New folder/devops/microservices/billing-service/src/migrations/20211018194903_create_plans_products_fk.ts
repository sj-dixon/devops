import { Knex } from 'knex';

const TABLE_NAME = 'plans';
const COLUMN_NAME = 'product_id';
const FK_NAME = 'FK_plans_products_product_id';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder
      .foreign(COLUMN_NAME, FK_NAME)
      .references('id')
      .inTable('products')
      .onDelete('RESTRICT');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropForeign(COLUMN_NAME, FK_NAME);
  });
}
