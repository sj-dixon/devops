import { Knex } from 'knex';

const TABLE_NAME = 'billing_addresses';
const COLUMN_NAME = 'billing_account_id';
const FK_NAME = 'FK_billing_addresses_billing_accounts_billing_account_id';

const REF_TABLE = 'billing_accounts';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder
      .foreign(COLUMN_NAME, FK_NAME)
      .references('id')
      .inTable(REF_TABLE)
      .onDelete('RESTRICT');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropForeign(COLUMN_NAME, FK_NAME);
  });
}
