import { Knex } from 'knex';

const TABLE_NAME = 'plans';

export async function up(knex: Knex): Promise<void> {
  // noinspection DuplicatedCode
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // common metadata
      tableBuilder.increments('id').primary();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      // common soft deletion metadata
      tableBuilder.timestamp('deleted_at').nullable();

      tableBuilder.string('name').notNullable();
      // Stores external IDs, currently Stripe, but naming it generic
      // so we are not tied to any service provider
      tableBuilder.string('external_id').notNullable();

      tableBuilder.integer('product_id').unsigned().notNullable();

      // Stores prices in the minimum currency unit, i.e, cents
      tableBuilder.integer('price').unsigned().notNullable();
      tableBuilder.enum('currency', ['CAD']).notNullable();
      tableBuilder.integer('max_seats').unsigned().notNullable();
      tableBuilder.string('billing_frequency').notNullable();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TABLE_NAME);
}
