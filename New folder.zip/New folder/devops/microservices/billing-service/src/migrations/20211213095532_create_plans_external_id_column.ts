import { Knex } from 'knex';

const TABLE_NAME = 'plans';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.string('external_id').notNullable();
    tableBuilder.string('external_id_type').notNullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropColumns('external_id', 'external_id_type');
  });
}
