import { Knex } from 'knex';

const TABLE_NAME = 'billing_accounts';
const COLUMN = 'billing_email';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    // If this is null, we use the account_holder_email
    tableBuilder.string(COLUMN).nullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (tableBuilder) => {
    tableBuilder.dropColumn(COLUMN);
  });
}
