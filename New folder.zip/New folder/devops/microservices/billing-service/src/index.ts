import { runApp } from '@alcumus/express-app';
import app from './app';
import process from 'process';
import { BILLING_SERVICE_PORT } from './constants';
import { Model } from 'objection';
import { getKnexClient } from './lib/clients/knex';

Model.knex(getKnexClient());

runApp(app, {
  port: BILLING_SERVICE_PORT,
}).catch(async (reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
  process.exit(1);
});
