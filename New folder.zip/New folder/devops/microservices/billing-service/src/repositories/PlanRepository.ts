import { QueryBuilderType } from 'objection';
import { PlanEntity } from '../models/plan';

export default class PlanRepository {
  static async getById(id: number): Promise<PlanEntity> {
    return PlanEntity.query().findById(id);
  }

  static getPlansForProduct(productId: number): QueryBuilderType<PlanEntity> {
    return PlanEntity.query().where('productId', productId);
  }
}
