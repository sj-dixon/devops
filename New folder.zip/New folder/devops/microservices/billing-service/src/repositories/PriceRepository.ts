import { PriceEntity } from '../models/price';

export default class PriceRepository {
  static async getById(id: number): Promise<PriceEntity> {
    return PriceEntity.query().withGraphJoined('[plan,product]').findById(id);
  }
}
