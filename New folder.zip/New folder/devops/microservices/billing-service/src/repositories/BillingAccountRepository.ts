import { QueryBuilderType } from 'objection';
import { BillingAccountEntity } from '../models/billingAccount';
import { SubscriptionEntity } from '../models/subscription';
import { ProductEntity } from '../models/product';
import { PriceEntity } from '../models/price';

export default class BillingAccountRepository {
  static async getById(
    billingAccountId: number
  ): Promise<BillingAccountEntity | null> {
    return BillingAccountEntity.withBillingAddress().findById(billingAccountId);
  }

  static getActiveSubscriptions(
    billingAccountId: number,
    { productId }: { productId?: number } = {}
  ): QueryBuilderType<SubscriptionEntity> {
    const query = SubscriptionEntity.query()
      .whereIn('status', ['active', 'past_due'])
      .where('billingAccountId', billingAccountId);

    if (productId) {
      query.whereExists(
        SubscriptionEntity.relatedQuery('price').whereExists(
          PriceEntity.relatedQuery<ProductEntity>('product').where(
            'product.id',
            productId
          )
        )
      );
    }

    return query;
  }
}
