import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import path from 'path';
import { productsV1Router } from './routes/productsV1';
import { plansV1Router } from './routes/plansV1';
import { billingAccountsV1Router } from './routes/billingAccountsV1';
import { subscriptionsV1Router } from './routes/subscriptionsV1';
import stripeWebhookV1Router from './routes/stripeWebhookV1';
import { Types } from '@alcumus/globals';
import { ServerResponse } from 'http';
import { Application } from 'express';

const app = configureApp({
  apiOptions: {
    apiSpec: path.join(__dirname, '..', 'build', 'api', 'api-spec.yaml'),
    specType: 'openapi',
    validateResponse: true,
  },
  middlewareOptions: {
    jsonParser: {
      verify: (
        request: Types.Request,
        response: ServerResponse,
        buffer: Buffer,
        encoding: BufferEncoding
      ) => {
        // This is a hack, it's intention is to make rawBody available on request object
        // This string rawBody is needed for Stripe to authenticate webhook calls
        // Read more here: https://stackoverflow.com/questions/18710225/node-js-get-raw-request-body-using-express
        if (buffer && buffer.length) {
          request.rawBody = buffer.toString(encoding);
        }
      },
    },
  },
  setup: (theApp: Application) => {
    theApp.use(ENDPOINTS.PRODUCTS, productsV1Router);
    theApp.use(ENDPOINTS.PLANS, plansV1Router);
    theApp.use(ENDPOINTS.BILLING_ACCOUNTS, billingAccountsV1Router);
    theApp.use(ENDPOINTS.SUBSCRIPTIONS, subscriptionsV1Router);
    theApp.use(ENDPOINTS.STRIPE_WEBHOOK, stripeWebhookV1Router);
  },
});

export default app;
