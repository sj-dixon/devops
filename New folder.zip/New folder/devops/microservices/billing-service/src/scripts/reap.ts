import { Knex } from 'knex';
import { Model } from 'objection';
import { getKnexClient } from '../lib/clients/knex';
import { reapProduct } from '../lib/utils/stripe/reap';
import { ProductEntity } from '../models/product';

/**
 * Reap = opposite of seed, remove things from database and external APIs
 * @param knex
 */
async function reap(knex: Knex): Promise<void> {
  Model.knex(knex);

  for (const product of await ProductEntity.query()) {
    await reapProduct(product);
  }

  knex.destroy();
}

reap(getKnexClient());
