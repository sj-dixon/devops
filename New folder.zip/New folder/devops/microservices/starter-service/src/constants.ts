import { Utilities } from '@alcumus/globals';

export const SERVICE_NAME = 'Starter Service';

export const STARTER_SERVICE_PORT =
  Number(Utilities.ProcessEnv.getValue('STARTER_SERVICE_PORT')) || 8999;

const BASE_V1 = '/api/v1';
export const ENDPOINTS = {
  EXAMPLE: `${BASE_V1}/example`,
};
