# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.4.0](https://github.com/Alcumus/services/compare/auth-service@0.3.0...auth-service@0.4.0) (2021-12-06)


### Features

* Removed FEATURE_TOGGLE_MIGRATE_PASSWORDS_ON_LOGIN ([322f055](https://github.com/Alcumus/services/commit/322f0553dbf1f3bf6553f43a400bd6e450846d17))
* **billing-service:** add Price entity ([a2c3485](https://github.com/Alcumus/services/commit/a2c3485d414b63e2c75a6b30e1df2a2588389fcc))
* azure ad authority now reflects custom login policy. ([07f0b5d](https://github.com/Alcumus/services/commit/07f0b5d53103fcfc76ee755100cd27f4b6a25d6d))
* impersonate api middleware, user service api contract updates and more ([923ffc7](https://github.com/Alcumus/services/commit/923ffc754b0a54c72a27201738de64e4835d4c27))
* migration endpoint is now responsible only for password validation. ([61af696](https://github.com/Alcumus/services/commit/61af69621a25d372066f68810e712f221ab0a057))
* sketch of basic support for api-based password validation (login side). ([c67fde4](https://github.com/Alcumus/services/commit/c67fde48f63d6c04bf67389cf192efd988c7bdf9))





# [0.3.0](https://github.com/Alcumus/services/compare/auth-service@0.2.0...auth-service@0.3.0) (2021-11-11)


### db

* **Password Migration:** Added authProviderName column to auth provider, and removed organizationIdentifier. ([aff82c5](https://github.com/Alcumus/services/commit/aff82c5e5ed3e1036433bc82c9b729d0e69258c9))


### Features

* **Authorization Code Flow:** sketch of api endpoint contracts ([ca652d3](https://github.com/Alcumus/services/commit/ca652d30d3fbc81055c724f01cb6d85924cec33d))
* **OAuth2:** Introduced endpoints for retrieving auth url and token. ([2c50e40](https://github.com/Alcumus/services/commit/2c50e40379c5864754e055ecc2d87e0a955a25a6))
* **Password Migration:** implemented logic to update the user account auth provider type after successful login. ([269158d](https://github.com/Alcumus/services/commit/269158d863aef3ed2f0d71bbdda411a85287ad73))
* **Password Migration:** implemented logic to validate a login against keycloak. ([6343f19](https://github.com/Alcumus/services/commit/6343f199025565d957588f273704bd2149d931f0))
* **Password Migration:** introduced endpoint for password migration ([2961ba4](https://github.com/Alcumus/services/commit/2961ba46c0a0e357fb50fe4d5beec3ff22d2fd45))
* **Password Migration:** Login now migrates passwords from original provider -> Keycloak and Keycloak -> Azure. ([099d9d2](https://github.com/Alcumus/services/commit/099d9d2f009d8a236cdf04954652e89b2bb87c49))
* **Password Migration:** now migrating login credentials fully over to Azure AD. ([79d3b8f](https://github.com/Alcumus/services/commit/79d3b8f5f7500c6a46a2b445847d837d9e652033))


### BREAKING CHANGES

* **Password Migration:** keycloakUserNamePrefix -> userNamePrefix





# [0.2.0](https://github.com/Alcumus/services/compare/auth-service@0.1.0...auth-service@0.2.0) (2021-11-02)

**Note:** Version bump only for package auth-service





# [0.1.0](https://github.com/Alcumus/services/compare/auth-service@0.0.7...auth-service@0.1.0) (2021-10-21)


### Bug Fixes

* added additional fix to solve deployment. ([bd713a5](https://github.com/Alcumus/services/commit/bd713a58c8cef44545ad44fc5aa2c8f5c762846c))
* Adjusted login route to use camelCase response structure when using local keycloak instance. ([2e86169](https://github.com/Alcumus/services/commit/2e861697925b16f2a9dc54c6f48b78b2ba715da8))
* fixed path. ([876881b](https://github.com/Alcumus/services/commit/876881bce8afc17127ff9a8573102c7708c36975))
* Made dockerfiles consistent and removed npm run bootstrap since its a postinstall step and ran anyways. ([9bd3f40](https://github.com/Alcumus/services/commit/9bd3f4011bc5250623a5d0c8bea5ee01c41b9563))
* Made refresh token use new response structure as well. ([9b31dc7](https://github.com/Alcumus/services/commit/9b31dc7878ed26b95509e1b37d6ddc4e17cdfe50))
* Now returning saml token directly. ([44ab518](https://github.com/Alcumus/services/commit/44ab518665e95954df39d593a0586037f77cc19f))
* removed references to feature toggle. ([c62e01b](https://github.com/Alcumus/services/commit/c62e01b5f8c3128f24ccb717ca344b97ca14c531))
* status -> sendStatus ([6973f93](https://github.com/Alcumus/services/commit/6973f93ccf8abe947691cef5e53d32dc53934d26))


### Features

* **BI-133:** added validation endpoint. ([d396169](https://github.com/Alcumus/services/commit/d3961697abed318ab968863ef9a88f9daa080191))
* **BI-133:** added x-access-token security schema to existing routes. ([4fa2894](https://github.com/Alcumus/services/commit/4fa2894468541c167e61b47556725f177085fce5))
* **BI-133:** implemented new middleware for doublechecking token validity. ([8c4d961](https://github.com/Alcumus/services/commit/8c4d961d9c5bc3f9bb6696e845f5140e8d3324be))
* **BI-133:** refactored test. ([1614e13](https://github.com/Alcumus/services/commit/1614e1397cd4c21c28a2ef72103ae2e5dba2d3a1))
* **BI-133:** restored 401 responses to some code and updated tests. ([a830956](https://github.com/Alcumus/services/commit/a830956e2978bf278d775d73c80032b9ccc1f2a2))
* **BI-138:** login now accepts an organization identifier and will retrieve prefix from tenant service. ([0f7d5b3](https://github.com/Alcumus/services/commit/0f7d5b3c01d8b10fedb4b13399301107fbeb5c65))
* **BI-138:** refactored integration test and added new one. ([2b3e739](https://github.com/Alcumus/services/commit/2b3e7391dc50de28b778cb4cdd7a7bcb4ed2ce22))
* **BI-143:** Removed SAML login feature toggle from auth service. ([4009938](https://github.com/Alcumus/services/commit/4009938731b057b61f582cb1ceda7c71fdcbbd05))
* added package, ran clean and build. ([911c3a4](https://github.com/Alcumus/services/commit/911c3a4b5b911abe26194478a9846cb3e4ca5391))
* **BI-33:** credentials -> accounts ([bc1e971](https://github.com/Alcumus/services/commit/bc1e97120797fd7132e6b6fb0c1ae018f19b12a4))
* Implemented full communication chain for SAML login. ([dd76b95](https://github.com/Alcumus/services/commit/dd76b95389f85a9f8240476dfedb32d52089457e))
* prepared way for ecompliance saml token. ([02160f0](https://github.com/Alcumus/services/commit/02160f0637e58605f5f61b5cd75f2551183560da))
* re-implemented keycloak direct usage based on feature toggle. ([b0fba6c](https://github.com/Alcumus/services/commit/b0fba6c0c2993094f9ddb13f9e3fcbf004a2c3b8))
* removed email validation because we now accept both emails and usernames. ([8457f18](https://github.com/Alcumus/services/commit/8457f18277f0db9616ab56790407e4ffa5c75981))
