import { OrganizationAuthProviderType } from '../../../src/lib/clients/services/types';
import MockAdapter from 'axios-mock-adapter';
import { KeycloakOAuthGrant } from '../../../src/types';
import axios, { AxiosRequestConfig } from 'axios';
import * as queryString from 'querystring';

export const mockAxios = new MockAdapter(axios);

export const ENVIRONMENT = {
  KEYCLOAK_SERVER_URL: 'http://secret-lair:8080/auth',
  KEYCLOAK_SERVER_REALM: 'secret-realm',
  KEYCLOAK_ADMIN_ID: 'secret-cli',
  KEYCLOAK_ADMIN_SECRET: '9012cf7e-e4d3-4e38-9186-93973f5c5326',
  KEYCLOAK_CLIENT_ID: 'regular-cli',
  KEYCLOAK_CLIENT_SECRET: 'banana split',
  SERVICE_MESH_HOST: 'https://secret-cloud:5000/api',
  SERVICE_MESH_API_KEY: 'carbonated ice cream',
  FEATURE_TOGGLE_USE_LINKERD: 'true',

  AZURE_AD_CLIENT_ID: 'not important',
  AZURE_AD_CLIENT_SECRET: 'not important',
  AZURE_AD_REDIRECT_URI: 'not important',
};

export const ACCESS_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJ1c2VySWQiOiJzb21lLXVzZXItaWQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJoZXN0aWEtdXNlci0xIn0.__2MxnL55c4XIe2JbrLsedQgrTnefdLJ56YpIxFkJzM';
export const REFRESH_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM4MDIyLCJ1c2VySWQiOiJzb21lLXVzZXItaWQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJoZXN0aWEtdXNlci0xIn0.DEH_Eh041Pyyfp4tphOxYUsmlYQQRBYUX3Yh7aTDSJc';
export const NOW_INSTANT_MS = 1487076708000;
export const NOW_INSTANT_SECONDS = NOW_INSTANT_MS / 1000;

export const KEYCLOAK_TOKEN: KeycloakOAuthGrant = {
  access_token: ACCESS_TOKEN,
  refresh_token: REFRESH_TOKEN,
  expires_in: 100,
  refresh_expires_in: 1000,
  token_type: 'Bearer',
};

export const SUCCESS_TOKEN = {
  accessToken: ACCESS_TOKEN,
  refreshToken: REFRESH_TOKEN,
  expiresIn: KEYCLOAK_TOKEN.expires_in,
  expiresAt: NOW_INSTANT_SECONDS + KEYCLOAK_TOKEN.expires_in,
  refreshExpiresIn: KEYCLOAK_TOKEN.refresh_expires_in,
  refreshExpiresAt: NOW_INSTANT_SECONDS + KEYCLOAK_TOKEN.refresh_expires_in,
  tokenType: KEYCLOAK_TOKEN.token_type,
};

export const PROFILE = {
  firstName: 'firsty',
  lastName: 'lasty',
};

export function mockApiAuthProviderLookup(
  authProviderName: string
): [jest.Mock, string, string, string] {
  const authProvider = {
    id: 1234,
    organizationId: null,
    userNamePrefix: null,
    organizationIdentifier: null,
    authProviderName,
    authProviderType: OrganizationAuthProviderType.API,

    callbackUrl: 'https://originalsystem.com/api/v1/validate',
    apiTokenHeaderName: 'secret-key',
    apiTokenHeaderValue: 'secret-value',
  };
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/authProviders/${authProviderName}`;
  const onReply = jest.fn(() => [200, authProvider]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return [
    onReply,
    authProvider.callbackUrl,
    authProvider.apiTokenHeaderName,
    authProvider.apiTokenHeaderValue,
  ];
}

export function mockAuthProviderLookup(
  expectedPrefix = '',
  organizationIdentifier?: string,
  authProviderType = OrganizationAuthProviderType.KEYCLOAK
): jest.Mock {
  const serviceMeshUrl = `${
    ENVIRONMENT.SERVICE_MESH_HOST
  }/v1/authProviders/${authProviderType}${
    organizationIdentifier
      ? `?organizationIdentifier=${organizationIdentifier}`
      : ''
  }`;
  const onReply = jest.fn(() => [
    200,
    {
      id: 1234,
      organizationId: 521312,
      userNamePrefix: expectedPrefix,
      authProviderType: authProviderType,
      authProviderName: authProviderType,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockOrganizationLookupByIdentifier(
  organizationIdentifier: string
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/auth/${organizationIdentifier}`;
  const onReply = jest.fn(() => [
    200,
    {
      id: 1234,
      organizationIdentifier,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockUserAccountLookup(
  username: string,
  organizationIdentifier?: string,
  authProviderName:
    | OrganizationAuthProviderType
    | string = OrganizationAuthProviderType.KEYCLOAK,
  requiresPasswordReset = false,
  scopedToOrganizationId = 0
): jest.Mock {
  const serviceMeshUrl = `${
    ENVIRONMENT.SERVICE_MESH_HOST
  }/v1/accounts/usernames/${username}${
    organizationIdentifier
      ? `?organizationIdentifier=${organizationIdentifier}`
      : ''
  }`;
  const onReply = jest.fn(() => [
    200,
    {
      id: 1234,
      alcumusUserId: 1234,
      userOrganizationAccountId: 23456,
      username: username,
      authProviderName,
      requiresPasswordReset,
      ...PROFILE,
      scopedToOrganizationId,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockPatchCredentials(
  alcumusUserId: number,
  expectedStatus: number
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/migrate/users/${alcumusUserId}/credentials`;
  const onReply = jest.fn(() => [
    expectedStatus,
    {
      id: 1234,
      alcumusUserId: 1234,
      authProviderName: OrganizationAuthProviderType.AZURE_AD,
    },
  ]);
  mockAxios.onPatch(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockValidKeycloakLogin(
  username: string,
  password: string
): jest.Mock {
  const url = `${ENVIRONMENT.KEYCLOAK_SERVER_URL}/realms/${ENVIRONMENT.KEYCLOAK_SERVER_REALM}/protocol/openid-connect/token`;
  const onReply = jest.fn((axiosRequestConfig: AxiosRequestConfig) => {
    const data = queryString.decode(axiosRequestConfig.data);
    expect(data).toEqual({
      username: username,
      password: password,
      client_id: ENVIRONMENT.KEYCLOAK_CLIENT_ID,
      client_secret: ENVIRONMENT.KEYCLOAK_CLIENT_SECRET,
      grant_type: 'password',
    });
    return [200, KEYCLOAK_TOKEN];
  });
  mockAxios.onPost(url).replyOnce(onReply);
  return onReply;
}

export function mockInvalidKeycloakLogin(
  username: string,
  password: string
): jest.Mock {
  const url = `${ENVIRONMENT.KEYCLOAK_SERVER_URL}/realms/${ENVIRONMENT.KEYCLOAK_SERVER_REALM}/protocol/openid-connect/token`;
  const onReply = jest.fn((axiosRequestConfig: AxiosRequestConfig) => {
    const data = queryString.decode(axiosRequestConfig.data);
    expect(data).toEqual({
      username: username,
      password: password,
      client_id: ENVIRONMENT.KEYCLOAK_CLIENT_ID,
      client_secret: ENVIRONMENT.KEYCLOAK_CLIENT_SECRET,
      grant_type: 'password',
    });
    return [
      401,
      {
        message: 'dont care',
      },
    ];
  });
  mockAxios.onPost(url).replyOnce(onReply);
  return onReply;
}
