import { Utilities } from '@alcumus/globals';
import axios from 'axios';
import request from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';

jest.mock('axios');

function mockValidationWithStatus(
  status: number,
  data: object | null
): jest.Mocked<typeof axios> {
  const mockedAxios = axios as jest.Mocked<typeof axios>;
  // mock access token validation
  mockedAxios.get.mockImplementationOnce(() =>
    Promise.resolve({
      status: status,
      data: data,
    })
  );
  return mockedAxios;
}

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv({
    KEYCLOAK_SERVER_URL: 'http://keycloak/auth',
    KEYCLOAK_SERVER_REALM: 'test',
    KEYCLOAK_CLIENT_ID: 'client',
    KEYCLOAK_CLIENT_SECRET: 'sh',
  });
});

afterAll(() => {
  Utilities.ProcessEnv.clearOverrides();
});

describe(`api/v1/${ENDPOINTS.TOKENS}/validate`, () => {
  it('should reject missing token', async () => {
    const response = await request(app)
      .get(`${ENDPOINTS.TOKENS}/validate`)
      .send();
    expect(response.status).toEqual(401);
    expect(response.body).toEqual({
      message: "'x-access-token' header required",
    });
  });

  it('should reject invalid token', async () => {
    const invalidKeycloakTokenResponse = {
      error: 'invalid_token',
      error_description: 'Token invalid: Token is not active',
    };
    mockValidationWithStatus(401, invalidKeycloakTokenResponse);
    const response = await request(app)
      .get(`${ENDPOINTS.TOKENS}/validate`)
      .set('x-access-token', 'made up')
      .send();
    expect(response.status).toEqual(401);
    expect(response.body).toEqual({
      message: 'Access Token not Valid',
    });
  });

  it('should accept valid token', async () => {
    const validKeycloakTokenResponse = {
      sub: 'xxx-xxx-xxx-xxx-xxx',
      name: 'John Smith',
      preferred_username: 'jsmith',
      given_name: 'John',
      family_name: 'Smith',
      email: 'john.smith@example.com',
    };
    mockValidationWithStatus(200, validKeycloakTokenResponse);
    const response = await request(app)
      .get(`${ENDPOINTS.TOKENS}/validate`)
      .set('x-access-token', 'made up')
      .send();
    expect(response.status).toEqual(200);
  });
});
