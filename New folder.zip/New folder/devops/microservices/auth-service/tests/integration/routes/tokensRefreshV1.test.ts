import { Utilities } from '@alcumus/globals';
import request from 'supertest';
import axios from 'axios';
import { ENDPOINTS } from '../../../src/constants';
import authServiceApp from '../../../src/app';
import { StandardLoginToken, KeycloakOAuthGrant } from '../../../src/types';

jest.mock('axios');

const ACCESS_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJ1c2VySWQiOiJzb21lLXVzZXItaWQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJoZXN0aWEtdXNlci0xIn0.__2MxnL55c4XIe2JbrLsedQgrTnefdLJ56YpIxFkJzM';
const REFRESH_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM4MDIyLCJ1c2VySWQiOiJzb21lLXVzZXItaWQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJoZXN0aWEtdXNlci0xIn0.DEH_Eh041Pyyfp4tphOxYUsmlYQQRBYUX3Yh7aTDSJc';

const NOW_INSTANT_MS = 10_000_000;
const NOW_INSTANT_SECONDS = NOW_INSTANT_MS / 1000;

const KEYCLOAK_TOKEN: KeycloakOAuthGrant = {
  access_token: ACCESS_TOKEN,
  refresh_token: REFRESH_TOKEN,
  refresh_expires_in: 1000,
  expires_in: 100,
  token_type: 'Bearer',
};

const STANDARD_TOKEN_OUTPUT: StandardLoginToken = {
  accessToken: ACCESS_TOKEN,
  refreshToken: REFRESH_TOKEN,
  refreshExpiresIn: 1000,
  refreshExpiresAt: NOW_INSTANT_SECONDS + 1000,
  expiresIn: 100,
  expiresAt: NOW_INSTANT_SECONDS + 100,
  tokenType: 'Bearer',
};

const KEYCLOAK_URL =
  'http://keycloak/auth/realms/test/protocol/openid-connect/token';
const KEYCLOAK_URL_QUERY = `grant_type=refresh_token&client_id=client&client_secret=sh&refresh_token=${REFRESH_TOKEN}`;

function mockRefreshWithStatus(
  status: number,
  data: object | null
): jest.Mocked<typeof axios> {
  const mockedAxios = axios as jest.Mocked<typeof axios>;

  // mock access token validation
  mockedAxios.get.mockImplementationOnce(() =>
    Promise.resolve({
      status: 200,
      data: {},
    })
  );

  // mock logout
  mockedAxios.post.mockImplementationOnce(() =>
    Promise.resolve({
      status: status,
      data: data,
    })
  );
  return mockedAxios;
}

async function submitTokenRefreshRequest(body: { refreshToken?: string }) {
  return request(authServiceApp)
    .post(`${ENDPOINTS.TOKENS}/refresh`)
    .set('x-access-token', 'made up')
    .send(body);
}

describe(`Integration Test: ${ENDPOINTS.TOKENS}/refresh`, () => {
  let dateNowSpy: jest.SpyInstance;

  beforeEach(() => {
    Utilities.ProcessEnv.overrideEnv({
      KEYCLOAK_SERVER_URL: 'http://keycloak/auth',
      KEYCLOAK_SERVER_REALM: 'test',
      KEYCLOAK_CLIENT_ID: 'client',
      KEYCLOAK_CLIENT_SECRET: 'sh',
    });
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => NOW_INSTANT_MS); // ms
  });

  afterEach(() => {
    dateNowSpy.mockClear();
    jest.clearAllMocks();
    Utilities.ProcessEnv.clearOverrides();
  });

  it('returns 400 if body is missing parameters', async () => {
    const response = await submitTokenRefreshRequest({});
    expect(response.status).toEqual(400);
  });

  it('succeeds when Keycloak succeeds', async () => {
    const mockedAxios = mockRefreshWithStatus(200, KEYCLOAK_TOKEN);

    const response = await submitTokenRefreshRequest({
      refreshToken: REFRESH_TOKEN,
    });

    expect(mockedAxios.post).toHaveBeenCalledWith(
      KEYCLOAK_URL,
      KEYCLOAK_URL_QUERY,
      expect.anything()
    );
    expect(response.status).toEqual(200);
    expect(response.body).toEqual(STANDARD_TOKEN_OUTPUT);
  });

  it('rejected when refresh token is expired', async () => {
    const expiredRefreshTokenError = {
      error: 'invalid_grant',
      error_description: 'Token is not active',
    };
    const mockedAxios = mockRefreshWithStatus(400, expiredRefreshTokenError);

    const response = await submitTokenRefreshRequest({
      refreshToken: REFRESH_TOKEN,
    });

    expect(mockedAxios.post).toHaveBeenCalledWith(
      KEYCLOAK_URL,
      KEYCLOAK_URL_QUERY,
      expect.anything()
    );
    expect(response.status).toEqual(401);
  });

  it('rejected when non-existent realm is specified', async () => {
    const incorrectRealm = {
      error: 'Realm does not exist',
    };
    const mockedAxios = mockRefreshWithStatus(404, incorrectRealm);

    const response = await submitTokenRefreshRequest({
      refreshToken: REFRESH_TOKEN,
    });

    expect(mockedAxios.post).toHaveBeenCalledWith(
      KEYCLOAK_URL,
      KEYCLOAK_URL_QUERY,
      expect.anything()
    );
    expect(response.status).toEqual(500);
  });
});
