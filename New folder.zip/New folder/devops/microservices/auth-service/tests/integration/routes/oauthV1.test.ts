import app from '../../../src/app';
import supertest from 'supertest';
import { ENDPOINTS } from '../../../src/constants';
import { Utilities } from '@alcumus/globals';
import { ConfidentialClientApplication } from '@azure/msal-node';
import getUnixTime from 'date-fns/getUnixTime';
import { escape } from 'querystring';
import {
  mockOrganizationLookupByIdentifier,
  mockAxios,
  ENVIRONMENT,
} from './authTestHelpers';
import { getAuthorityUrl } from '@alcumus/auth-plugin';
import axios from 'axios';

const TENANT_IDENTIFIER = 'tenant123';
const TEST_ENVIRONMENT = {
  SERVICE_MESH_HOST: ENVIRONMENT.SERVICE_MESH_HOST,
  SERVICE_MESH_API_KEY: ENVIRONMENT.SERVICE_MESH_API_KEY,
  FEATURE_TOGGLE_USE_LINKERD: 'true',
  AZURE_AD_CLIENT_ID: 'ffeef9a5-a4f4-42fd-84dc-8ad2b5308b29',
  AZURE_AD_REDIRECT_URI: 'https://portal.alcumus.com:3099/authorize',
  AZURE_AD_CLIENT_SECRET: 'V6e7Q~EEo16XeXl.5X4ZBPnUtLsvpmN9SLAlE',
  AZURE_AD_TENANT_NAME: 'tenanty',
  AZURE_AD_COMBINED_SIGNUP_SIGNIN_POLICY_NAME: 'policyWonk',
  DEBUG_INCLUDE_SERVER_ERROR_IN_RESPONSE: 'true',
};

let authorizationEndpoint: string;

beforeEach(() => {
  Utilities.ProcessEnv.overrideEnv(TEST_ENVIRONMENT);
  authorizationEndpoint = `${getAuthorityUrl()}/oauth2/v2.0/authorize`;
});

afterEach(() => {
  jest.clearAllMocks();
});

describe('/api/v1/oauth/url', () => {
  const ENCODED_URI = escape(TEST_ENVIRONMENT.AZURE_AD_REDIRECT_URI);

  const EXPECTED_AUTH_URL =
    `${authorizationEndpoint}` +
    `?client_id=${TEST_ENVIRONMENT.AZURE_AD_CLIENT_ID}` +
    `&scope=openid%20profile%20offline_access` +
    `&redirect_uri=${ENCODED_URI}` +
    `&client-request-id=9081bcc5-20f7-4aca-afe8-5ec0093948cf` +
    `&response_mode=query&response_type=code&x-client-SKU=msal.js.node&x-client-VER=1.3.2&x-client-OS=darwin&x-client-CPU=x64&client_info=1&`;

  describe('GET /url', () => {
    let getAuthCodeUrlSpy: jest.SpyInstance;

    beforeAll(() => {
      getAuthCodeUrlSpy = jest.spyOn(
        ConfidentialClientApplication.prototype,
        'getAuthCodeUrl'
      );
    });

    it('Given missing api key, returns 401 error', async () => {
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.OAUTH}/url?organizationIdentifier=${TENANT_IDENTIFIER}&prompt=login`
        )
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('Given invalid api key, returns 401 error', async () => {
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.OAUTH}/url?organizationIdentifier=${TENANT_IDENTIFIER}&prompt=login`
        )
        .set('x-api-key', 'completely wrong')
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('given api key, returns valid url', async () => {
      getAuthCodeUrlSpy.mockResolvedValueOnce(EXPECTED_AUTH_URL);
      const response = await supertest(app)
        .get(`${ENDPOINTS.OAUTH}/url?prompt=login`)
        .set('x-api-key', TEST_ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        200,
        EXPECTED_AUTH_URL,
      ]);
    });

    it('given valid tenant identifier and api key, returns valid url', async () => {
      const mockLookup = mockOrganizationLookupByIdentifier(TENANT_IDENTIFIER);
      getAuthCodeUrlSpy.mockResolvedValueOnce(EXPECTED_AUTH_URL);
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.OAUTH}/url?organizationIdentifier=${TENANT_IDENTIFIER}&prompt=login`
        )
        .set('x-api-key', TEST_ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        200,
        EXPECTED_AUTH_URL,
      ]);
      expect(mockLookup).toHaveBeenCalledTimes(1);
    });
  });

  describe('GET /authorize', () => {
    const NOW_INSTANT = 1635975408860;

    it('Given missing api key, returns 401 error', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.OAUTH}/authorize`)
        .send({
          code: 'dont care',
          state: 'login',
          organizationIdentifier: TENANT_IDENTIFIER,
        });
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('Given invalid api key, returns 401 error', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.OAUTH}/authorize`)
        .set('x-api-key', 'completely wrong')
        .send({
          code: 'dont care',
          state: 'login',
          organizationIdentifier: TENANT_IDENTIFIER,
        });
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('given valid code, returns valid token from endpoint and msal', async () => {
      axios.interceptors.request.use((config) => {
        console.log(config.url);
        return config;
      });
      const acquireTokenByCodeSpy = jest.spyOn(
        ConfidentialClientApplication.prototype,
        'acquireTokenByCode'
      );
      jest.spyOn(Date, 'now').mockImplementation(() => NOW_INSTANT);

      const OFFSET_IN_MS = 1_000_000;
      const OFFSET_IN_SECONDS = OFFSET_IN_MS / 1000;

      const expiryDate = new Date(NOW_INSTANT + OFFSET_IN_MS);
      const expectedTokenFromMsal = {
        accessToken: 'xyz.123.abc',
        expiresOn: expiryDate,
        extExpiresOn: expiryDate,
        tokenType: 'bearer',
        authority: getAuthorityUrl(),
        state: 'login',
        uniqueId: '123',
        tenantId: '123',
        scopes: [],
        account: null,
        idToken: 'fake',
        idTokenClaims: {},
        fromCache: false,
        correlationId: 'fake',
      };
      const expectedTokenFromEndpoint = {
        refresh_token: 'a213132123123',
        access_token: expectedTokenFromMsal.accessToken,
        expires_on: 1635976408,
      };
      acquireTokenByCodeSpy.mockResolvedValueOnce(expectedTokenFromMsal);

      // mock the hack
      mockAxios
        .onPost(`${getAuthorityUrl()}/oauth2/v2.0/token`)
        .replyOnce(() => [200, expectedTokenFromEndpoint]);

      const response = await supertest(app)
        .post(`${ENDPOINTS.OAUTH}/authorize`)
        .set('x-api-key', TEST_ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send({
          code: 'secret avengers handshake',
          state: 'login',
          organizationIdentifier: TENANT_IDENTIFIER,
        });
      expect([response.status, response.body]).toEqual([
        200,
        {
          accessToken: expectedTokenFromMsal.accessToken,
          expiresAt: getUnixTime(expiryDate),
          expiresIn: OFFSET_IN_SECONDS,
          expiresOn: getUnixTime(expiryDate),
          refreshExpiresIn: OFFSET_IN_SECONDS,
          tokenType: 'bearer',
          refreshToken: expectedTokenFromEndpoint.refresh_token,
        },
      ]);
    });
  });
});
