import { Utilities } from '@alcumus/globals';
import request from 'supertest';
import axios from 'axios';
import { ENDPOINTS } from '../../../src/constants';
import authServiceApp from '../../../src/app';

jest.mock('axios');

const REFRESH_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM4MDIyLCJ1c2VySWQiOiJzb21lLXVzZXItaWQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJoZXN0aWEtdXNlci0xIn0.DEH_Eh041Pyyfp4tphOxYUsmlYQQRBYUX3Yh7aTDSJc';
const LOGOUT_URL =
  'http://keycloak/auth/realms/test/protocol/openid-connect/logout';
const KEYCLOAK_URL_QUERY = `client_id=client&client_secret=sh&refresh_token=${REFRESH_TOKEN}`;

function mockLogoutWithStatus(
  status: number,
  data: object | null
): jest.Mocked<typeof axios> {
  const mockedAxios = axios as jest.Mocked<typeof axios>;
  // mock access token validation
  mockedAxios.get.mockImplementationOnce(() =>
    Promise.resolve({
      status: 200,
      data: {},
    })
  );

  // mock logout
  mockedAxios.post.mockImplementationOnce(() =>
    Promise.resolve({
      status: status,
      data: data,
    })
  );
  return mockedAxios;
}

describe(`Integration Test: ${ENDPOINTS.LOGOUT}`, () => {
  beforeEach(() => {
    Utilities.ProcessEnv.overrideEnv({
      KEYCLOAK_SERVER_URL: 'http://keycloak/auth',
      KEYCLOAK_SERVER_REALM: 'test',
      KEYCLOAK_CLIENT_ID: 'client',
      KEYCLOAK_CLIENT_SECRET: 'sh',
    });
    jest.spyOn(Date, 'now').mockImplementation(() => 10_000_000); // ms
  });

  afterEach(() => {
    jest.clearAllMocks();
    Utilities.ProcessEnv.clearOverrides();
  });

  async function submitLogout(body: {
    refreshToken?: string;
  }): Promise<request.Test> {
    return request(authServiceApp)
      .post(`${ENDPOINTS.LOGOUT}`)
      .set('x-access-token', 'made up')
      .send(body);
  }

  it('returns 400 if body is missing parameters', async () => {
    const response = await submitLogout({});
    expect(response.status).toEqual(400);
  });

  it('succeeds when Keycloak succeeds', async () => {
    const mockedAxios = mockLogoutWithStatus(200, null);

    await submitLogout({ refreshToken: REFRESH_TOKEN });

    expect(mockedAxios.post).toHaveBeenCalledWith(
      LOGOUT_URL,
      KEYCLOAK_URL_QUERY,
      expect.anything()
    );
  });

  it('rejected when refresh token is expired', async () => {
    const expiredRefreshTokenError = {
      error: 'invalid_grant',
      error_description: 'Token is not active',
    };
    const mockedAxios = mockLogoutWithStatus(400, expiredRefreshTokenError);

    const response = await submitLogout({ refreshToken: REFRESH_TOKEN });

    expect(mockedAxios.post).toHaveBeenCalledWith(
      LOGOUT_URL,
      KEYCLOAK_URL_QUERY,
      expect.anything()
    );
    expect(response.status).toEqual(401);
  });

  it('rejected when non-existent realm is specified', async () => {
    const incorrectRealm = {
      error: 'Realm does not exist',
    };
    const mockedAxios = mockLogoutWithStatus(404, incorrectRealm);

    const response = await submitLogout({ refreshToken: REFRESH_TOKEN });

    expect(mockedAxios.post).toHaveBeenCalledWith(
      LOGOUT_URL,
      KEYCLOAK_URL_QUERY,
      expect.anything()
    );
    expect(response.status).toEqual(500);
  });
});
