import {
  API_LOGINS_NOT_ALLOWED,
  ENDPOINTS,
  VAGUE_LOGIN_ERROR_MESSAGE,
} from '../../../src/constants';
import { Utilities } from '@alcumus/globals';
import supertest from 'supertest';
import authServiceApp from '../../../src/app';
import {
  ENVIRONMENT,
  mockAuthProviderLookup,
  mockAxios,
  mockInvalidKeycloakLogin,
  mockUserAccountLookup,
  mockValidKeycloakLogin,
  NOW_INSTANT_MS,
  SUCCESS_TOKEN,
} from './authTestHelpers';
import { toKeycloakEmailOrUsername } from '@alcumus/auth-plugin';
import { OrganizationAuthProviderType } from '../../../src/lib/clients/services/types';

let dateNowSpy: jest.SpyInstance;

beforeEach(() => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
  dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(() => NOW_INSTANT_MS);
});

afterEach(() => {
  dateNowSpy.mockRestore();
  jest.clearAllMocks();
  Utilities.ProcessEnv.clearOverrides();
});

describe(ENDPOINTS.LOGIN, () => {
  describe(`POST /`, () => {
    it('Given valid credentials, Should return 200 and login tokens', async () => {
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
      };
      const mockedUserLookup = mockUserAccountLookup(loginRequest.username);
      const mockedAuthLookup = mockAuthProviderLookup();
      const mockedLoginCall = mockValidKeycloakLogin(
        loginRequest.username,
        loginRequest.password
      );
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(loginRequest);
      expect(mockedLoginCall).toHaveBeenCalledTimes(1);
      expect(mockedUserLookup).toHaveBeenCalledTimes(1);
      expect(mockedAuthLookup).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([200, SUCCESS_TOKEN]);
    });

    it('Given invalid username, Should return 400 and vague error', async () => {
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
      };
      const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/accounts/usernames/${loginRequest.username}`;
      const mockedInvalidLookup = jest.fn(() => [
        404,
        { message: 'not found' },
      ]);
      mockAxios.onGet(serviceMeshUrl).replyOnce(mockedInvalidLookup);
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(loginRequest);
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: VAGUE_LOGIN_ERROR_MESSAGE,
        },
      ]);
    });

    it('Given invalid password, Should return 400 and vague error', async () => {
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
      };
      const mockedUserLookup = mockUserAccountLookup(loginRequest.username);
      const mockedAuthLookup = mockAuthProviderLookup();
      const mockedLoginCall = mockInvalidKeycloakLogin(
        loginRequest.username,
        loginRequest.password
      );
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(loginRequest);
      expect(mockedUserLookup).toHaveBeenCalledTimes(1);
      expect(mockedLoginCall).toHaveBeenCalledTimes(1);
      expect(mockedAuthLookup).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: VAGUE_LOGIN_ERROR_MESSAGE,
        },
      ]);
    });

    it('Given invalid organization identifier, Should return 400 and vague error', async () => {
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
        organizationIdentifier: 'asdasdasd',
      };
      const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/auth/${loginRequest.organizationIdentifier}/authProviders`;
      const mockedAuthProviderLookup = jest.fn(() => [404, {}]);
      mockAxios.onGet(serviceMeshUrl, mockedAuthProviderLookup);

      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(loginRequest);
      expect(mockedAuthProviderLookup).not.toHaveBeenCalled();
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: VAGUE_LOGIN_ERROR_MESSAGE,
        },
      ]);
    });

    it('Given organization identifier and invalid credentials, Should return 400 and vague error', async () => {
      const prefix = '123123fafda_';
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
        organizationIdentifier: 'asdasdasd',
      };
      const mockedUserMigrationCall = mockUserAccountLookup(
        loginRequest.username,
        loginRequest.organizationIdentifier
      );
      const mockedAuthProviderCall = mockAuthProviderLookup(
        prefix,
        loginRequest.organizationIdentifier
      );
      const mockedLoginCall = mockInvalidKeycloakLogin(
        toKeycloakEmailOrUsername(loginRequest.username, prefix) as string,
        loginRequest.password
      );
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(loginRequest);
      expect(mockedLoginCall).toHaveBeenCalledTimes(1);
      expect(mockedAuthProviderCall).toHaveBeenCalledTimes(1);
      expect(mockedUserMigrationCall).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([
        400,
        {
          message: VAGUE_LOGIN_ERROR_MESSAGE,
        },
      ]);
    });

    it('Given organization identifier and valid credentials, Should return 200 and token', async () => {
      const prefix = '123123fafda_';
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
        organizationIdentifier: 'asdasdasd',
      };
      const mockedUserMigrationCall = mockUserAccountLookup(
        loginRequest.username,
        loginRequest.organizationIdentifier
      );
      const mockedAuthProviderCall = mockAuthProviderLookup(
        prefix,
        loginRequest.organizationIdentifier
      );
      const mockedLoginCall = mockValidKeycloakLogin(
        toKeycloakEmailOrUsername(loginRequest.username, prefix) as string,
        loginRequest.password
      );
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(loginRequest);
      expect(mockedLoginCall).toHaveBeenCalledTimes(1);
      expect(mockedAuthProviderCall).toHaveBeenCalledTimes(1);
      expect(mockedUserMigrationCall).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([200, SUCCESS_TOKEN]);
    });

    it('Given organization identifier and external provider type, Should return 403', async () => {
      const prefix = '123123fafda_';
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
        organizationIdentifier: 'asdasdasd',
      };
      const mockedUserMigrationCall = mockUserAccountLookup(
        loginRequest.username,
        loginRequest.organizationIdentifier,
        OrganizationAuthProviderType.EXTERNAL
      );
      const mockedAuthProviderCall = mockAuthProviderLookup(
        prefix,
        loginRequest.organizationIdentifier,
        OrganizationAuthProviderType.EXTERNAL
      );
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(loginRequest);
      expect(mockedAuthProviderCall).toHaveBeenCalledTimes(1);
      expect(mockedUserMigrationCall).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([
        403,
        {
          message: API_LOGINS_NOT_ALLOWED,
        },
      ]);
    });

    it('Given missing api key, returns 401 response', async () => {
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
      };
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .send(loginRequest);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('Given invalid api key, returns 401 response', async () => {
      const loginRequest = {
        username: 'someguy',
        password: 'somepassword123!',
      };
      const response = await supertest(authServiceApp)
        .post(`${ENDPOINTS.LOGIN}`)
        .set('x-api-key', 'clearly wrong')
        .send(loginRequest);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });
  });
});
