import { ENDPOINTS, VAGUE_LOGIN_ERROR_MESSAGE } from '../../../src/constants';
import supertest from 'supertest';
import app from '../../../src/app';
import { Utilities } from '@alcumus/globals';
import {
  ENVIRONMENT,
  mockApiAuthProviderLookup,
  mockAuthProviderLookup,
  mockAxios,
  mockInvalidKeycloakLogin,
  mockUserAccountLookup,
  mockValidKeycloakLogin,
  NOW_INSTANT_MS,
  PROFILE,
} from './authTestHelpers';
import { OrganizationAuthProviderType } from '../../../src/lib/clients/services/types';
import { toKeycloakEmailOrUsername } from '@alcumus/auth-plugin';
import { v4 as uuidV4 } from 'uuid';

let dateNowSpy: jest.SpyInstance;

const AZURE_AD_CALLBACK_API_KEY = 'french toast';

beforeEach(() => {
  Utilities.ProcessEnv.overrideEnv({
    ...ENVIRONMENT,
    FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD: 'true',
    AZURE_AD_CALLBACK_API_KEY,
  });
  dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(() => NOW_INSTANT_MS);
});

afterEach(() => {
  dateNowSpy.mockRestore();
  jest.clearAllMocks();
  Utilities.ProcessEnv.clearOverrides();
});

const ORGANIZATION_IDENTIFIER = 'lionheart';
const PREFIX = 'org_lionheart_';
const LOGIN_IDENTIFIER = 'richard';
const PASSWORD = 'Alcdev01!';

describe('/api/v1/migrate', () => {
  describe('POST /', () => {
    describe('Basic Checks', () => {
      it('When API key is missing, return 401', async () => {
        const result = await supertest(app).post(ENDPOINTS.MIGRATE).send({
          username: 'whatever',
          password: 'dont care',
          organizationIdentifier: 'dont care',
        });
        expect([result.status, result.body]).toEqual([
          401,
          {
            message: "'x-azure-api-key' header required",
          },
        ]);
      });

      it('When API key is invalid, return 401', async () => {
        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', 'something wrong')
          .send({
            username: 'whatever',
            password: 'dont care',
            organizationIdentifier: 'dont care',
          });
        expect([result.status, result.body]).toEqual([
          401,
          {
            message: 'x-azure-api-key header has an incorrect api key',
          },
        ]);
      });

      it('When username and password are missing, return 400 with validation errors', async () => {
        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            organizationIdentifier: 'dont care',
          });
        expect([result.status, result.body]).toEqual([
          400,
          {
            message:
              "request.body should have required property 'username', request.body should have required property 'password'",
          },
        ]);
      });

      it('When user identifier is not real, return 404 indicating problem', async () => {
        const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/accounts/usernames/${LOGIN_IDENTIFIER}?organizationIdentifier=${ORGANIZATION_IDENTIFIER}`;
        const mockedUserLookup = jest.fn(() => [404, {}]);
        mockAxios.onGet(serviceMeshUrl).replyOnce(mockedUserLookup);

        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            organizationIdentifier: ORGANIZATION_IDENTIFIER,
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          404,
          {
            message: `User with identifier ${ORGANIZATION_IDENTIFIER}:${LOGIN_IDENTIFIER} was not found.`,
          },
        ]);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
      });

      it('When tenant identifier is not real, return 404 indicating problem', async () => {
        const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/authProviders/${OrganizationAuthProviderType.KEYCLOAK}?organizationIdentifier=${ORGANIZATION_IDENTIFIER}`;
        const mockedUserLookup = mockUserAccountLookup(
          LOGIN_IDENTIFIER,
          ORGANIZATION_IDENTIFIER
        );
        const mockedAuthProviderLookup = jest.fn(() => [404, {}]);
        mockAxios.onGet(serviceMeshUrl).replyOnce(mockedAuthProviderLookup);

        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            organizationIdentifier: ORGANIZATION_IDENTIFIER,
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          404,
          {
            message: `Authentication provider ${ORGANIZATION_IDENTIFIER}:${OrganizationAuthProviderType.KEYCLOAK} was not found.`,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
      });
    });

    describe('Azure AD Checks', () => {
      it('When migrated user is already on azure ad, return 200 to indicate no migration needed', async () => {
        const authProviderType = OrganizationAuthProviderType.AZURE_AD;
        const mockedAuthProviderLookup = mockAuthProviderLookup(
          PREFIX,
          ORGANIZATION_IDENTIFIER,
          authProviderType
        );
        const mockedUserLookup = mockUserAccountLookup(
          LOGIN_IDENTIFIER,
          ORGANIZATION_IDENTIFIER,
          authProviderType,
          false,
          244
        );
        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            organizationIdentifier: ORGANIZATION_IDENTIFIER,
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          200,
          {
            authProviderName: authProviderType,
            authProviderType,
            username: LOGIN_IDENTIFIER,
            requiresPasswordReset: false,
            ...PROFILE,
            requiresMFA: false,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
      });
    });

    describe('Keycloak Checks', () => {
      it('When username and password are invalid according to keycloak, return 401', async () => {
        const mockedAuthProviderLookup = mockAuthProviderLookup(
          PREFIX,
          ORGANIZATION_IDENTIFIER
        );
        const mockedUserLookup = mockUserAccountLookup(
          LOGIN_IDENTIFIER,
          ORGANIZATION_IDENTIFIER,
          OrganizationAuthProviderType.KEYCLOAK,
          false
        );
        const expectedKeycloakUsername = toKeycloakEmailOrUsername(
          LOGIN_IDENTIFIER,
          PREFIX
        );
        const mockedLogin = mockInvalidKeycloakLogin(
          expectedKeycloakUsername as string,
          PASSWORD
        );
        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            organizationIdentifier: ORGANIZATION_IDENTIFIER,
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          400,
          {
            message:
              'Username, organization identifier, and password combination are not valid',
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
        expect(mockedLogin).toHaveBeenCalledTimes(1);
      });

      it('When login is successful according to keycloak, return 200', async () => {
        const authProviderType = OrganizationAuthProviderType.KEYCLOAK;
        const mockedAuthProviderLookup = mockAuthProviderLookup(
          PREFIX,
          ORGANIZATION_IDENTIFIER,
          authProviderType
        );
        const mockedUserLookup = mockUserAccountLookup(
          LOGIN_IDENTIFIER,
          ORGANIZATION_IDENTIFIER,
          authProviderType,
          false,
          244
        );
        const expectedKeycloakUsername = toKeycloakEmailOrUsername(
          LOGIN_IDENTIFIER,
          PREFIX
        );
        const mockedLogin = mockValidKeycloakLogin(
          expectedKeycloakUsername as string,
          PASSWORD
        );
        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            organizationIdentifier: ORGANIZATION_IDENTIFIER,
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          200,
          {
            authProviderName: authProviderType,
            authProviderType,
            username: LOGIN_IDENTIFIER,
            requiresPasswordReset: false,
            ...PROFILE,
            requiresMFA: false,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
        expect(mockedLogin).toHaveBeenCalledTimes(1);
      });

      it('When login for individual account is successful but needs reset, return 200', async () => {
        const authProviderType = OrganizationAuthProviderType.KEYCLOAK;
        const loginIdentifier = uuidV4();
        const mockedAuthProviderLookup = mockAuthProviderLookup();
        const mockedUserLookup = mockUserAccountLookup(
          loginIdentifier,
          undefined,
          authProviderType,
          true
        );
        const mockedLogin = mockValidKeycloakLogin(loginIdentifier, PASSWORD);
        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            username: loginIdentifier,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          200,
          {
            authProviderName: authProviderType,
            authProviderType,
            username: loginIdentifier,
            requiresPasswordReset: true,
            ...PROFILE,
            requiresMFA: false,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
        expect(mockedLogin).toHaveBeenCalledTimes(1);
      });

      it('When login for individual account is successful, return 200', async () => {
        const authProviderType = OrganizationAuthProviderType.KEYCLOAK;
        const loginIdentifier = uuidV4();
        const mockedAuthProviderLookup = mockAuthProviderLookup();
        const mockedUserLookup = mockUserAccountLookup(
          loginIdentifier,
          undefined,
          authProviderType,
          false
        );
        const mockedLogin = mockValidKeycloakLogin(loginIdentifier, PASSWORD);
        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            username: loginIdentifier,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          200,
          {
            authProviderName: authProviderType,
            authProviderType,
            username: loginIdentifier,
            requiresPasswordReset: false,
            ...PROFILE,
            requiresMFA: false,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
        expect(mockedLogin).toHaveBeenCalledTimes(1);
      });
    });

    describe('API Checks', () => {
      async function shouldReturn200WhenApiReturnsBody(
        body?: any
      ): Promise<void> {
        const providerName = uuidV4();
        const [mockedAuthProviderLookup, callbackUrl] =
          mockApiAuthProviderLookup(providerName);
        const mockedUserLookup = mockUserAccountLookup(
          LOGIN_IDENTIFIER,
          undefined,
          providerName,
          false
        );
        const mockedLogin = jest.fn().mockImplementation(() => [200, body]);
        mockAxios.onPost(callbackUrl).replyOnce(mockedLogin);

        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          200,
          {
            authProviderName: providerName,
            authProviderType: OrganizationAuthProviderType.API,
            username: LOGIN_IDENTIFIER,
            requiresPasswordReset: false,
            ...PROFILE,
            requiresMFA: false,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
        expect(mockedLogin).toHaveBeenCalledTimes(1);
      }

      it('When API returns 200 with empty object, return 200', () =>
        shouldReturn200WhenApiReturnsBody({}));

      it('When API returns 200 with no body, return 200', () =>
        shouldReturn200WhenApiReturnsBody());

      it('When API returns 200 with false in body, return 200', () =>
        shouldReturn200WhenApiReturnsBody({
          isPasswordExpired: false,
        }));

      it('When API returns 200 with true boolean body, return 200', () =>
        shouldReturn200WhenApiReturnsBody(true));
      it('When API returns 200 with true boolean body, return 200', () =>
        shouldReturn200WhenApiReturnsBody(false));

      it('When login is invalid according to API, return 400', async () => {
        const providerName = uuidV4();
        const [mockedAuthProviderLookup, callbackUrl] =
          mockApiAuthProviderLookup(providerName);
        const mockedUserLookup = mockUserAccountLookup(
          LOGIN_IDENTIFIER,
          undefined,
          providerName
        );
        const mockedLogin = jest.fn().mockImplementation(() => [400, {}]);
        mockAxios.onPost(callbackUrl).replyOnce(mockedLogin);

        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          400,
          {
            message: VAGUE_LOGIN_ERROR_MESSAGE,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
        expect(mockedLogin).toHaveBeenCalledTimes(1);
      });

      it('When password is expired according to API, return 200 with requires reset = true', async () => {
        const providerName = uuidV4();
        const [mockedAuthProviderLookup, callbackUrl] =
          mockApiAuthProviderLookup(providerName);
        const mockedUserLookup = mockUserAccountLookup(
          LOGIN_IDENTIFIER,
          undefined,
          providerName,
          false
        );
        const mockedLogin = jest.fn().mockImplementation(() => [
          200,
          {
            isPasswordExpired: true,
          },
        ]);
        mockAxios.onPost(callbackUrl).replyOnce(mockedLogin);

        const result = await supertest(app)
          .post(ENDPOINTS.MIGRATE)
          .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
          .send({
            username: LOGIN_IDENTIFIER,
            password: PASSWORD,
          });
        expect([result.status, result.body]).toEqual([
          200,
          {
            authProviderName: providerName,
            authProviderType: OrganizationAuthProviderType.API,
            username: LOGIN_IDENTIFIER,
            ...PROFILE,
            requiresMFA: false,
            requiresPasswordReset: true,
          },
        ]);
        expect(mockedAuthProviderLookup).toHaveBeenCalledTimes(1);
        expect(mockedUserLookup).toHaveBeenCalledTimes(1);
        expect(mockedLogin).toHaveBeenCalledTimes(1);
      });
    });
  });
});
