import request from 'supertest';
import express, { Application, Request, Response } from 'express';
import {
  requirePassword,
  requireUserName,
} from '../../../src/middlewares/validateLoginRequest';
import { Utilities } from '@alcumus/globals';
import { validationHandler } from '@alcumus/express-app';

describe('Unit Test: validateLoginRequest', () => {
  let app: Application;
  beforeAll(() => {
    app = express();
    app.use(express.json());

    app.post(
      '/',
      requirePassword,
      requireUserName,
      validationHandler(401),
      (request: Request, response: Response) => {
        response.json();
      }
    );
  });

  afterEach(() => {
    Utilities.ProcessEnv.clearOverrides();
  });

  function submitLogin(body: { username?: string; password?: string }) {
    return request(app).post('/').send(body);
  }

  it('rejects request without username and password', (done) => {
    submitLogin({}).expect(
      401,
      {
        errors: {
          password: {
            key: 'auth.login.passwordDoesNotExist',
            message: 'auth.login.passwordDoesNotExist',
          },
          username: {
            key: 'auth.login.userNameDoesNotExist',
            message: 'auth.login.userNameDoesNotExist',
          },
        },
      },
      done
    );
  });

  it('rejects request with empty username and password', (done) => {
    submitLogin({
      username: '',
      password: '',
    }).expect(
      401,
      {
        errors: {
          password: {
            key: 'auth.login.passwordDoesNotExist',
            message: 'auth.login.passwordDoesNotExist',
          },
          username: {
            key: 'auth.login.userNameDoesNotExist',
            message: 'auth.login.userNameDoesNotExist',
          },
        },
      },
      done
    );
  });

  it('accepts username instead of email', (done) => {
    submitLogin({ username: 'hello', password: 'world' }).expect(200, done);
  });

  it('allows request with valid email and password', (done) => {
    submitLogin({ username: 'hello@world.com', password: 'world' }).expect(
      200,
      done
    );
  });
});
