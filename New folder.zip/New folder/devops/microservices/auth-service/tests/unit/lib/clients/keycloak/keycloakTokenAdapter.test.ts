import {
  transformKeycloakToLegacyToken,
  transformLegacyToStandardLoginToken,
} from '../../../../../src/lib/clients/keycloak';
import fromUnixTime from 'date-fns/fromUnixTime';
import {
  KeycloakOAuthGrant,
  LegacyLoginToken,
  StandardLoginToken,
} from '../../../../../src/types';

const REFRESH_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
const ACCESS_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6Ikpvc2VwaCBEb2UiLCJpYXQiOjE1MTYyMzkwMjJ9.P8mirVCmtb6FU0Bj9lrVFM62YUfpSWWVwC4xeaBfN3Y';
const TOKEN_TYPE = 'Bearer';

const NOW = 900;
const REFRESH_EXPIRES_AT = 20000;
const ACCESS_EXPIRES_AT = 1000;

describe('Unit Test: keycloakTokenAdapter', () => {
  describe('transformToken', () => {
    it('calculates expiry and refresh expiry times', () => {
      const date = fromUnixTime(10000);
      const rawKeycloakToken: KeycloakOAuthGrant = {
        refresh_token: REFRESH_TOKEN,
        access_token: ACCESS_TOKEN,
        expires_in: 100,
        refresh_expires_in: 1000,
        token_type: TOKEN_TYPE,
      };
      const transformedToken = transformKeycloakToLegacyToken(
        rawKeycloakToken,
        date
      );
      expect(transformedToken.access_token).toEqual(ACCESS_TOKEN);
      expect(transformedToken.refresh_token).toEqual(REFRESH_TOKEN);
      expect(transformedToken.token_type).toEqual(TOKEN_TYPE);
      expect(transformedToken.expires_at).toEqual(10100);
      expect(transformedToken.refresh_expires_at).toEqual(11000);
    });
  });

  describe('transformLegacyToStandardLoginToken', () => {
    it('changes structure of token', () => {
      const input: LegacyLoginToken = {
        token_type: 'Bearer',
        access_token: ACCESS_TOKEN,
        refresh_token: REFRESH_TOKEN,
        expires_at: ACCESS_EXPIRES_AT,
        expires_in: ACCESS_EXPIRES_AT - NOW,
        refresh_expires_at: REFRESH_EXPIRES_AT,
        refresh_expires_in: REFRESH_EXPIRES_AT - NOW,
      };
      const expected: StandardLoginToken = {
        tokenType: 'Bearer',
        accessToken: ACCESS_TOKEN,
        refreshToken: REFRESH_TOKEN,
        expiresIn: ACCESS_EXPIRES_AT - NOW,
        expiresAt: ACCESS_EXPIRES_AT,
        refreshExpiresAt: REFRESH_EXPIRES_AT,
        refreshExpiresIn: REFRESH_EXPIRES_AT - NOW,
      };
      expect(transformLegacyToStandardLoginToken(input)).toEqual(expected);
    });
  });
});
