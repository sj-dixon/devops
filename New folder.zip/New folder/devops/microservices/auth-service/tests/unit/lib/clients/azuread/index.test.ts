import {
  ConfidentialClientApplication,
  AuthorizationUrlRequest,
  AuthorizationCodeRequest,
} from '@azure/msal-node';
import {
  getScopes,
  getAuthCodeUrl,
  redeemCodeForTokens,
} from '../../../../../src/lib/clients/azuread';
import { Utilities } from '@alcumus/globals';

const CODE = '1231231231543123123123123wdasada34ra';
const EXPECTED_AUTH_URL = `http://microsoftlogin.com/something?code_challenge=123456890`;
const REQUEST_ID = 'xy123xz';

const EXPECTED_TOKEN = { accessToken: 'xyz.asd123.e123' };

const ENVIRONMENT = {
  AZURE_AD_TENANT_NAME: 'fooBarBaz',
  AZURE_AD_COMBINED_SIGNUP_SIGNIN_POLICY_NAME: 'test_policy',
  AZURE_AD_CLIENT_ID: 'Giovanni',
  AZURE_AD_CLIENT_SECRET: 'Not just a gym leader',
  AZURE_AD_REDIRECT_URI: 'http://rocketlair.com:666/redirect',
};

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
});

afterEach(() => {
  jest.clearAllMocks();
});

describe('lib/clients/azureAd', () => {
  describe('getAuthCodeUrl', () => {
    let getAuthCodeUrlSpy: jest.SpyInstance;

    beforeAll(() => {
      getAuthCodeUrlSpy = jest.spyOn(
        ConfidentialClientApplication.prototype,
        'getAuthCodeUrl'
      );
    });
    it('given valid inputs, returns valid url', async () => {
      getAuthCodeUrlSpy.mockImplementation((args: AuthorizationUrlRequest) => {
        expect(args.correlationId).toEqual(REQUEST_ID);
        expect(args.scopes).toEqual(getScopes());
        expect(args.redirectUri).toEqual(ENVIRONMENT.AZURE_AD_REDIRECT_URI);
        return Promise.resolve(EXPECTED_AUTH_URL);
      });
      const url = await getAuthCodeUrl({
        correlationId: REQUEST_ID,
        redirectUri: ENVIRONMENT.AZURE_AD_REDIRECT_URI,
        prompt: 'login',
      });
      expect(url).toEqual(EXPECTED_AUTH_URL);
      expect(getAuthCodeUrlSpy).toHaveBeenCalled();
    });

    // it('given invalid inputs, throws error', async () => {
    //   const error = "Secret is wrong"
    //   getAuthCodeUrlSpy.mockImplementation(() => {
    //     throw new Error(error)
    //   })
    //   await expect(() => getAuthCodeUrl({
    //     redirectUri: REDIRECT_URI,
    //     codeVerifier: CHALLENGE_INPUT,
    //     correlationId: REQUEST_ID
    //   })).toThrowError(error)
    //   expect(getAuthCodeUrlSpy).toHaveBeenCalled()
    // })
  });

  describe('redeemCodeForTokens', () => {
    let acquireTokenByCodeSpy: jest.SpyInstance;

    beforeAll(() => {
      acquireTokenByCodeSpy = jest.spyOn(
        ConfidentialClientApplication.prototype,
        'acquireTokenByCode'
      );
    });

    it('given valid inputs, returns valid code', async () => {
      acquireTokenByCodeSpy.mockImplementation(
        (args: AuthorizationCodeRequest) => {
          expect(args.correlationId).toEqual(REQUEST_ID);
          expect(args.scopes).toEqual(getScopes());
          expect(args.redirectUri).toEqual(ENVIRONMENT.AZURE_AD_REDIRECT_URI);
          expect(args.code).toEqual(CODE);
          return Promise.resolve(EXPECTED_TOKEN);
        }
      );
      const token = await redeemCodeForTokens({
        correlationId: REQUEST_ID,
        redirectUri: ENVIRONMENT.AZURE_AD_REDIRECT_URI,
        code: CODE,
        state: 'login',
      });
      expect(token).toEqual(EXPECTED_TOKEN);
      expect(acquireTokenByCodeSpy).toHaveBeenCalled();
    });
  });
});
