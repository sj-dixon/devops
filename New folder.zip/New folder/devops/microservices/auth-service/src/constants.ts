export const V1_BASE_PATH = '/api/v1';

export const ENDPOINTS = {
  LOGIN: `${V1_BASE_PATH}/login`,
  TOKENS: `${V1_BASE_PATH}/tokens`,
  LOGOUT: `${V1_BASE_PATH}/logout`,
  MIGRATE: `${V1_BASE_PATH}/migrate`,
  OAUTH: `${V1_BASE_PATH}/oauth`,
};

export const VAGUE_LOGIN_ERROR_MESSAGE =
  'Username, organization identifier, and password combination are not valid';

export const API_LOGINS_NOT_ALLOWED =
  'API-based Login not allowed for external accounts. Use impersonation or request a new admin endpoint for creating trusted tokens.';
