import { runApp } from '@alcumus/express-app';
import app from './app';
import process from 'process';

const port = Number(process.env.AUTH_SERVICE_PORT) || 8010;

runApp(app, { port }).catch((reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
});
export { AcquireTokenParameters } from './types/oauth';
