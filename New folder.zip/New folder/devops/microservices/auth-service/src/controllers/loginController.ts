import { Types, Utilities } from '@alcumus/globals';
import { Response } from 'express';
import { LoginRequest, StandardLoginToken } from '../types';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
} from '../lib/clients/services/types';
import { handleKeycloakLogin } from './keycloakLoginController';

export async function handleManagedLogin(
  request: Types.Request,
  response: Response,
  loginRequest: LoginRequest,
  authProvider: OrganizationAuthProvider | null
): Promise<StandardLoginToken | null> {
  const { username, password } = loginRequest;

  if (authProvider === null) {
    if (!Utilities.ProcessEnv.isEnabled('FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD')) {
      return handleKeycloakLogin(request, response, username, password, null);
    } else {
      // if the auth provider is null, it means we don't have enough information to decide
      // whether keycloak or azure ad should validate the credentials.
      // todo prevent null auth provider argument.
      throw new Error(
        "Not supported - we don't know if the user is in Azure AD or Keycloak"
      );
    }
  }

  if (authProvider.authProviderType === OrganizationAuthProviderType.KEYCLOAK) {
    return handleKeycloakLogin(
      request,
      response,
      username,
      password,
      authProvider
    );
  }

  throw new Error(
    `Not supported - cannot handle auth provider ${authProvider.authProviderName} with type ${authProvider.authProviderType}`
  );
}
