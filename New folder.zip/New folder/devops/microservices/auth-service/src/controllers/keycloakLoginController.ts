import { Types } from '@alcumus/globals';
import { Response } from 'express';
import {
  loginWithKeycloak,
  transformKeycloakToken,
} from '../lib/clients/keycloak';
import { StandardLoginToken } from '../types';
import { toKeycloakEmailOrUsername } from '@alcumus/auth-plugin';
import { OrganizationAuthProvider } from '../lib/clients/services/types';
import { VAGUE_LOGIN_ERROR_MESSAGE } from '../constants';

export async function handleKeycloakLogin(
  request: Types.Request,
  response: Response,
  username: string,
  password: string,
  authProvider: OrganizationAuthProvider | null
): Promise<StandardLoginToken | null> {
  const loginIdentifier = toKeycloakEmailOrUsername(
    username,
    authProvider?.userNamePrefix
  ) as string;

  const { status, data } = await loginWithKeycloak(loginIdentifier, password);
  if (status >= 500) {
    console.error(
      `Keycloak failure for user identifier ${loginIdentifier} failed due to ${status} error`,
      data
    );
    response.status(500).json({
      message: 'Could not process login request at this time',
    });
    return null;
  } else if (status >= 400) {
    console.log(
      `Login failure for user identifier ${loginIdentifier} failed due to ${status} response`,
      data
    );
    response.status(400).json({
      message: VAGUE_LOGIN_ERROR_MESSAGE,
    });
    return null;
  } else {
    const now = new Date(Date.now());
    return transformKeycloakToken(data, now);
  }
}
