import { Types } from '@alcumus/globals';
import { Response } from 'express';
import { StandardLoginToken } from '../types';
import {
  getRefreshedToken,
  transformKeycloakToken,
} from '../lib/clients/keycloak';

export async function refreshKeycloakToken(
  request: Types.Request,
  response: Response
): Promise<StandardLoginToken | null> {
  const keycloakResponse = await getRefreshedToken(request.body.refreshToken);
  if (keycloakResponse.status >= 404) {
    console.error(
      `Token Refresh Failed: received response with status code ${
        keycloakResponse.status
      } and error ${JSON.stringify(keycloakResponse.data)}`
    );
    response.status(500).send({
      message: 'Could not refresh token, server error',
    });
    return null;
  }
  if (keycloakResponse.status >= 400) {
    response.status(401).send(keycloakResponse.data);
    return null;
  }

  const now = new Date(Date.now());
  return transformKeycloakToken(keycloakResponse.data, now);
}
