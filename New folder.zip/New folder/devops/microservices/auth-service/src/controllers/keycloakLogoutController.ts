import { Types } from '@alcumus/globals';
import { Response } from 'express';
import { logout } from '../lib/clients/keycloak';

export async function logoutWithKeycloak(
  request: Types.Request,
  response: Response
): Promise<void> {
  const { refreshToken } = request.body;

  const logoutResponse = await logout(refreshToken);

  if (logoutResponse.status >= 404) {
    console.error(
      `Logout Failed: received response with status code ${
        logoutResponse.status
      } and error ${JSON.stringify(logoutResponse.data)}`
    );
    response.sendStatus(500);
  } else if (logoutResponse.status >= 400) {
    response.sendStatus(401);
  } else if (logoutResponse.status >= 300) {
    response.setHeader('Location', logoutResponse.redirect);
    response.sendStatus(302);
  } else {
    response.sendStatus(200);
  }
}
