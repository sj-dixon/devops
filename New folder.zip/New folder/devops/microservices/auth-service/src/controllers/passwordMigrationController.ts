import { LoginRequest } from '../types';
import { Response } from 'express';
import { Types, Utilities } from '@alcumus/globals';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
  UserAccount,
} from '../lib/clients/services/types';
import { updateUserAccount } from '../lib/clients/services';

export async function handlePasswordMigration(
  request: Types.Request,
  response: Response,
  loginRequest: LoginRequest,
  authProvider: OrganizationAuthProvider | null,
  userAccount: UserAccount | null,
  targetProviderType: OrganizationAuthProviderType
): Promise<boolean> {
  if (authProvider === null || userAccount === null) {
    // todo provide a way of migrating users who are in the global user pool
    return true;
  }

  if (userAccount.authProviderName === targetProviderType) {
    // no migration needed
    return true;
  }
  const axiosInstance = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'users'
  );
  const wasMigrated = updateUserAccount({
    axiosInstance,
    userAccount,
    password: loginRequest.password,
    targetProviderType,
  });

  if (!wasMigrated) {
    console.error(
      `Was unable to migrate account with id ${userAccount.id} from ${userAccount.authProviderName} to ${targetProviderType}`
    );
  }
  return wasMigrated;
}
