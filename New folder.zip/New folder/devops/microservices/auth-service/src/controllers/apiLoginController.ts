import { Types, Utilities } from '@alcumus/globals';
import { Response } from 'express';
import { LoginRequest, PasswordValidationResult } from '../types';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
  UserAccount,
} from '../lib/clients/services/types';
import { LoginIdentifierType } from '../types/apiCredentialRequest';
import { VAGUE_LOGIN_ERROR_MESSAGE } from '../constants';
import { handlePasswordMigration } from './passwordMigrationController';
import { handleKeycloakLogin } from './keycloakLoginController';
import { retrieveAuthProvider } from '../lib/clients/services';

export async function handleApiLogin(
  request: Types.Request,
  response: Response,
  loginRequest: LoginRequest,
  authProvider: OrganizationAuthProvider,
  userAccount: UserAccount
): Promise<void> {
  const wasValidationSuccessful = await validateCredentialsAgainstApi(
    request,
    response,
    loginRequest,
    authProvider,
    userAccount
  );
  if (!wasValidationSuccessful.isPasswordValid) {
    return;
  }

  const wasMigrated = await handlePasswordMigration(
    request,
    response,
    loginRequest,
    authProvider,
    userAccount,
    OrganizationAuthProviderType.KEYCLOAK
  );
  if (!wasMigrated) {
    throw new Error(
      `API-Based password validation succeeded for account ${userAccount.id} but migration failed`
    );
  }
  const tenantsClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    Types.ServiceEndpoints.TENANTS
  );
  const keycloakAuthProvider = await retrieveAuthProvider({
    axiosInstance: tenantsClient,
    organizationIdentifier: loginRequest.organizationIdentifier,
    providerName: OrganizationAuthProviderType.KEYCLOAK,
  });

  const loginToken = await handleKeycloakLogin(
    request,
    response,
    loginRequest.username,
    loginRequest.password,
    keycloakAuthProvider
  );
  if (loginToken) {
    response.json(loginToken);
  } else {
    throw new Error(
      `Migration was successful for account ${userAccount.id}, but could not log in with new credentials`
    );
  }
}

export async function validateCredentialsAgainstApi(
  request: Types.Request,
  response: Response,
  loginRequest: LoginRequest,
  authProvider: OrganizationAuthProvider,
  userMigration: UserAccount | null
): Promise<PasswordValidationResult> {
  const { username, password, organizationIdentifier } = loginRequest;

  // todo restore this once unblocked by FieldID
  // const loginIdentifierType = identifyLoginType(username);

  const apiLoginBody: object = {
    organizationId: authProvider?.organizationId || null,
    organizationIdentifier: organizationIdentifier || null,
    loginIdentifier: username || null,
    username: userMigration?.username || null,
    email: userMigration?.email || null,
    // loginIdentifierType,
    password,
  };

  const headers = {
    [authProvider.apiTokenHeaderName as string]:
      authProvider.apiTokenHeaderValue as string,
  };
  populatePropertyIfSet(
    headers,
    'x-api-client-app',
    request.requestedBy?.requestedByApplication
  );
  populatePropertyIfSet(
    headers,
    'x-requested-by',
    request.requestedBy?.requestedForIpAddress || request.socket.remoteAddress,
    (ip) =>
      `for=${ip};proto=https${
        request.requestedBy?.requestedByHost
          ? `;by=${request.requestedBy.requestedByHost}`
          : ''
      }`
  );

  const axiosClient = Utilities.AxiosClient.getAxiosClient(request);

  const loginResponse = await axiosClient.post(
    authProvider.callbackUrl as string,
    apiLoginBody,
    {
      headers,
      validateStatus: null,
    }
  );

  if (loginResponse.status >= 200 && loginResponse.status < 300) {
    return {
      isPasswordValid: true,
      isPasswordExpired: loginResponse.data?.isPasswordExpired === true,
    };
  } else {
    response.status(400).json({
      message: VAGUE_LOGIN_ERROR_MESSAGE,
    });
    return {
      isPasswordValid: false,
      isPasswordExpired: false,
    };
  }
}

function populatePropertyIfSet(
  headers: { [key: string]: string },
  propertyName: string,
  propertyValue: string | undefined,
  transform?: (value: string | undefined) => string
): void {
  if (!propertyValue) {
    return;
  }
  if (!transform) {
    headers[propertyName] = propertyValue;
  } else {
    headers[propertyName] = transform(propertyValue);
  }
}

// todo restore this when we are unblocked by Field
// function identifyLoginType(loginIdentifier: string): LoginIdentifierType {
//   if (loginIdentifier.includes('@')) {
//     return LoginIdentifierType.EMAIL;
//   } else if (loginIdentifier.substr(0, 1).match(/[\d]/)) {
//     return LoginIdentifierType.PHONE;
//   } else {
//     return LoginIdentifierType.USERNAME;
//   }
// }
