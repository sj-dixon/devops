import {
  OrganizationAuthProvider,
  UserAccount,
} from '../lib/clients/services/types';
import { Types, Utilities } from '@alcumus/globals';
import { Response } from 'express';
import { LoginRequest } from '../types';
import {
  retrieveAuthProvider,
  retrieveUserAccount,
} from '../lib/clients/services';
import { VAGUE_LOGIN_ERROR_MESSAGE } from '../constants';

type AuthProviderAndUserAccount = [
  OrganizationAuthProvider | null,
  UserAccount | null
];

export async function handleOrganizationProviderAndUserLookupsForMigrationRequest(
  request: Types.Request,
  response: Response
): Promise<AuthProviderAndUserAccount> {
  return handleOrganizationProviderAndUserLookups(request, response, 404, true);
}

export async function handleOrganizationProviderAndUserLookupsForLoginRequest(
  request: Types.Request,
  response: Response
): Promise<AuthProviderAndUserAccount> {
  return handleOrganizationProviderAndUserLookups(
    request,
    response,
    400,

    false
  );
}

export async function handleOrganizationProviderAndUserLookups(
  request: Types.Request,
  response: Response,
  statusCodeIfNotFound: number,
  provideDescriptiveErrors: boolean
): Promise<AuthProviderAndUserAccount> {
  const { username, organizationIdentifier }: LoginRequest = request.body;

  const usersClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'users'
  );

  const userMigration = await retrieveUserAccount({
    axiosInstance: usersClient,
    organizationIdentifier,
    username,
  });

  if (!userMigration) {
    const identifier = `${
      organizationIdentifier
        ? `${organizationIdentifier}:${username}`
        : username
    }`;
    const message = provideDescriptiveErrors
      ? `User with identifier ${identifier} was not found.`
      : VAGUE_LOGIN_ERROR_MESSAGE;
    logIfErrorIsMeaningful(message, provideDescriptiveErrors, request.id);
    response.status(statusCodeIfNotFound).json({
      message,
    });
    return [null, null];
  }

  const tenantsClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    Types.ServiceEndpoints.TENANTS
  );
  const authProvider = await retrieveAuthProvider({
    providerName: userMigration.authProviderName,
    organizationIdentifier,
    axiosInstance: tenantsClient,
  });
  if (!authProvider) {
    const authIdentifier = `${
      organizationIdentifier
        ? `${organizationIdentifier}:${userMigration.authProviderName}`
        : userMigration.authProviderName
    }`;
    const message = provideDescriptiveErrors
      ? `Authentication provider ${authIdentifier} was not found.`
      : VAGUE_LOGIN_ERROR_MESSAGE;
    logIfErrorIsMeaningful(message, provideDescriptiveErrors, request.id);
    response.status(statusCodeIfNotFound).json({
      message,
    });
    return [null, userMigration];
  }

  return [authProvider, userMigration];
}

function logIfErrorIsMeaningful(
  message: string,
  isDescriptive: boolean,
  requestId?: string
): void {
  if (isDescriptive) {
    console.log(requestId, message);
  }
}
