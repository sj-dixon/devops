import { parseJwt } from '@alcumus/auth-plugin';
import { Types } from '@alcumus/globals';
import { Response } from 'express';
import { getMSGraphClient } from '../lib/clients/msgraph';

export interface LogoutResult {
  data: object;
  status: number;
  redirect: string;
}

export async function logoutWithAzure(
  request: Types.Request,
  response: Response
): Promise<void> {
  const accessToken = request.headers['x-access-token'];
  const parsedToken = parseJwt(accessToken as string);
  if (parsedToken) {
    const client = getMSGraphClient();

    // https://docs.microsoft.com/en-us/graph/api/user-invalidateallrefreshtokens
    await client
      .api(`/users/${parsedToken.sub}/invalidateAllRefreshTokens`)
      .header('Content-Type', 'application/json')
      .post({});

    // for reference: https://docs.microsoft.com/en-us/graph/api/user-revokesigninsessions
    await client
      .api(`/users/${parsedToken.sub}/revokeSignInSessions`)
      .header('Content-Type', 'application/json')
      .post({});

    response.sendStatus(200);
  } else {
    response.status(400).json({ message: 'Could not parse token payload' });
  }
}
