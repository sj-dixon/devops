import { Middlewares, Types, Utilities } from '@alcumus/globals';
import express, { Response, Router } from 'express';
import {
  getAuthCodeUrl,
  transformToken,
  redeemCodeForTokens,
} from '../lib/clients/azuread';
import { requireRealOrganizationIdentifier } from '../middlewares/requireRealOrganizationIdentifier';
import { AuthenticationAppState } from '../types/oauth';
import { getTokensFromAuthorizationCode } from '../lib/clients/azuread/restClient';

const oathRouterV1: Router = express.Router({ mergeParams: true });

oathRouterV1.get(
  '/url',
  Middlewares.requireApiKeyHeader,
  requireRealOrganizationIdentifier,
  async (request: Types.Request, response: Response) => {
    const prompt = request.query.prompt as AuthenticationAppState;
    const url = await getAuthCodeUrl({
      correlationId: request.id,
      redirectUri: Utilities.ProcessEnv.getValueOrThrow(
        'AZURE_AD_REDIRECT_URI'
      ),
      prompt: prompt || 'login',
    });
    response.json(url);
  }
);

oathRouterV1.post(
  '/authorize',
  Middlewares.requireApiKeyHeader,
  requireRealOrganizationIdentifier,
  async (request: Types.Request, response: Response) => {
    const { code, state } = request.body;
    if (!code) {
      return response.status(400).send({
        message: 'code is missing from request',
      });
    }
    const result = await redeemCodeForTokens({
      code,
      redirectUri: Utilities.ProcessEnv.getValueOrThrow(
        'AZURE_AD_REDIRECT_URI'
      ),
      correlationId: request.id,
      state,
    });
    if (result) {
      const now = new Date(Date.now());
      const tokensFromMsalNodeClient = transformToken(result, now);
      // TODO: REMOVE LATER
      // Temporary hack
      // Obtain refresh tokens from REST api through the code as msal-node client does not return refresh token
      const tokensFromRestCall = await getTokensFromAuthorizationCode(code);
      response.send({
        ...tokensFromMsalNodeClient,
        // TODO: REMOVE LATER
        // Temporary hack
        // Injecting access token and refresh token obtained through the rest call
        ...tokensFromRestCall,
      });
    } else {
      response.sendStatus(401);
    }
  }
);

export { oathRouterV1 };
