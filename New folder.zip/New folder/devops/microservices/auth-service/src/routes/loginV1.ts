import express, { Response, Router } from 'express';
import { Types, Utilities } from '@alcumus/globals';
import {
  requirePassword,
  requireUserName,
} from '../middlewares/validateLoginRequest';
import { LoginRequest } from '../types';
import { validationHandler } from '@alcumus/express-app';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
  UserAccount,
} from '../lib/clients/services/types';
import { handleOrganizationProviderAndUserLookupsForLoginRequest } from '../controllers/authProviderLookupController';
import { handleManagedLogin } from '../controllers/loginController';
import { handlePasswordMigration } from '../controllers/passwordMigrationController';
import { handleApiLogin } from '../controllers/apiLoginController';
import { requireApiKeyHeader } from '@alcumus/globals/build/middlewares';
import { API_LOGINS_NOT_ALLOWED } from '../constants';

const loginRouter: Router = express.Router();

loginRouter.post(
  '/',
  requireApiKeyHeader,
  requirePassword,
  requireUserName,
  validationHandler(401),
  async (request: Types.Request, response: Response): Promise<void> => {
    const loginRequest: LoginRequest = request.body;

    let authProvider: OrganizationAuthProvider | null = null;
    let userAccount: UserAccount | null = null;

    [authProvider, userAccount] =
      await handleOrganizationProviderAndUserLookupsForLoginRequest(
        request,
        response
      );

    // lookup did not succeed - controller will have already put errors
    // onto response.
    if (!authProvider || !userAccount) {
      return;
    }

    const shouldMigrateToAzureAd = Utilities.ProcessEnv.isEnabled(
      'FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD'
    );

    if (
      authProvider?.authProviderType === OrganizationAuthProviderType.EXTERNAL
    ) {
      response.status(403).json({
        message: API_LOGINS_NOT_ALLOWED,
      });
      return;
    }

    if (
      authProvider?.authProviderType === OrganizationAuthProviderType.API &&
      !shouldMigrateToAzureAd
    ) {
      await handleApiLogin(
        request,
        response,
        loginRequest,
        authProvider,
        userAccount
      );
      return;
    }

    const loginToken = await handleManagedLogin(
      request,
      response,
      loginRequest,
      authProvider
    );

    if (!loginToken) {
      return;
    }
    if (!shouldMigrateToAzureAd) {
      // if using Azure AD, migration of passwords will happen automatically. so no need to invoke it.
      // if using Keycloak, migration of passwords should be contingent on feature toggle.
      response.json(loginToken);
      return;
    }

    const wasMigrationSuccessful = await handlePasswordMigration(
      request,
      response,
      loginRequest,
      authProvider,
      userAccount,
      OrganizationAuthProviderType.KEYCLOAK
    );

    if (wasMigrationSuccessful) {
      response.json(loginToken);
    } else {
      throw new Error(
        `Was not able to migrate account ${userAccount.id} to ${OrganizationAuthProviderType.KEYCLOAK}`
      );
    }
  }
);

export default loginRouter;
