import express, { Router, Response } from 'express';
import { Types } from '@alcumus/globals';
import { requireValidAccessToken } from '../middlewares/requireValidAccessToken';
import { validationHandler } from '@alcumus/express-app';
import { isAzureAdToken } from '@alcumus/auth-plugin';
import { logoutWithKeycloak } from '../controllers/keycloakLogoutController';
import { validateBodyHasRefreshToken } from '../middlewares/validateBodyHasRefreshToken';
import { logoutWithAzure } from '../controllers/azureadController';

const logoutRouterV1: Router = express.Router();

logoutRouterV1.post(
  '/',
  validateBodyHasRefreshToken,
  validationHandler(401),
  requireValidAccessToken,
  async (request: Types.Request, response: Response): Promise<void> => {
    const accessToken = request.header('x-access-token') as string;
    if (isAzureAdToken(accessToken)) {
      await logoutWithAzure(request, response);
    } else {
      await logoutWithKeycloak(request, response);
    }
  }
);

export default logoutRouterV1;
