import express, { Router, Response } from 'express';
import { Types } from '@alcumus/globals';
// import { validationHandler } from '@alcumus/express-app';
import { requireValidAccessToken } from '../middlewares/requireValidAccessToken';
import { isAzureAdToken } from '@alcumus/auth-plugin';
import { StandardLoginToken } from '../types';
import { refreshKeycloakToken } from '../controllers/keycloakRefreshController';
import { refreshToken } from '../lib/clients/azuread';
// import { validateBodyHasRefreshToken } from '../middlewares/validateBodyHasRefreshToken';

const tokensV1Router: Router = express.Router();

async function refreshAzureAdToken(
  request: Types.Request,
  response: Response
): Promise<StandardLoginToken | null> {
  const result = await refreshToken(
    request.body.refreshToken,
    request.id as string
  );

  if (result === null) {
    console.log('Refresh token not valid');
    response.status(401).json({ message: 'Refresh token was not valid' });
  }

  return result;
}

tokensV1Router.post(
  '/refresh',
  // validateBodyHasRefreshToken,
  // validationHandler(401),
  requireValidAccessToken,
  async (request: Types.Request, response: Response): Promise<void> => {
    let tokens: StandardLoginToken | null;
    const accessToken = request.header('x-access-token') as string;
    if (isAzureAdToken(accessToken)) {
      const accessToken = await refreshAzureAdToken(request, response);
      tokens = {
        ...(accessToken as StandardLoginToken),
        refreshToken: request.body.refreshToken,
      };
    } else {
      console.log('Refreshing keycloak token');
      tokens = await refreshKeycloakToken(request, response);
    }
    if (tokens) {
      response.json(tokens);
    }
  }
);

tokensV1Router.get(
  '/validate',
  requireValidAccessToken,
  (request: Types.Request, response: Response) => {
    response.sendStatus(200);
  }
);

export default tokensV1Router;
