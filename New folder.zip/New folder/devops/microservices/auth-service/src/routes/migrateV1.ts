import { Middlewares, Types } from '@alcumus/globals';
import express, { Response, Router } from 'express';
import { LoginRequest } from '../types';
import { handleOrganizationProviderAndUserLookupsForMigrationRequest } from '../controllers/authProviderLookupController';
import { handleManagedLogin } from '../controllers/loginController';
import {
  MigrationResponse,
  OrganizationAuthProviderType,
} from '../lib/clients/services/types';
import { validateCredentialsAgainstApi } from '../controllers/apiLoginController';

const migrateRouterV1: Router = express.Router();

// this endpoint is intended for use by a managed authentication provider in order
// to migrate passwords off an existing auth provider and into the
// main authentication provider for the services.
migrateRouterV1.post(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    'x-azure-api-key',
    'AZURE_AD_CALLBACK_API_KEY'
  ),
  async (request: Types.Request, response: Response) => {
    const loginRequest: LoginRequest = request.body;

    const [authProvider, userAccount] =
      await handleOrganizationProviderAndUserLookupsForMigrationRequest(
        request,
        response
      );

    if (authProvider === null || userAccount === null) {
      return;
    }

    const migrationResponse: MigrationResponse = {
      firstName: userAccount.firstName,
      lastName: userAccount.lastName,
      authProviderName: userAccount.authProviderName,
      authProviderType: authProvider.authProviderType,
      email: userAccount.email,
      username: userAccount.username,
      requiresPasswordReset: userAccount.requiresPasswordReset,
      requiresMFA: false,
    };

    // if user is already on Azure AD, report success
    if (
      authProvider.authProviderType === OrganizationAuthProviderType.AZURE_AD
    ) {
      return response.status(200).json(migrationResponse);
    }

    if (authProvider.authProviderType === OrganizationAuthProviderType.API) {
      const wasValidationSuccessful = await validateCredentialsAgainstApi(
        request,
        response,
        loginRequest,
        authProvider,
        userAccount
      );
      if (wasValidationSuccessful.isPasswordValid) {
        const requiresPasswordReset =
          migrationResponse.requiresPasswordReset ||
          wasValidationSuccessful.isPasswordExpired;
        return response.status(200).json({
          ...migrationResponse,
          requiresPasswordReset,
        });
      } else {
        // already handled by controller
        return;
      }
    } else if (
      authProvider.authProviderType === OrganizationAuthProviderType.KEYCLOAK
    ) {
      // keycloak
      const loginToken = await handleManagedLogin(
        request,
        response,
        loginRequest,
        authProvider
      );

      if (loginToken) {
        return response.status(200).json(migrationResponse);
      } else {
        return;
      }
    }

    throw new Error(
      'Did not know what to do with auth provider ' +
        authProvider.authProviderName
    );
  }
);

export { migrateRouterV1 };
