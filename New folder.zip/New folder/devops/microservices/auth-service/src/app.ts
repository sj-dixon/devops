import path from 'path';
import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import loginRouter from './routes/loginV1';
import tokensRouter from './routes/tokensV1';
import logoutRouterV1 from './routes/logoutV1';
import { oathRouterV1 } from './routes/oauthV1';
import { migrateRouterV1 } from './routes/migrateV1';

const apiSpec = './api-spec.yaml';

const authServiceApp = configureApp({
  serviceName: 'Authentication Service',
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
  },
  setup: (app) => {
    app.use(ENDPOINTS.LOGIN, loginRouter);
    app.use(ENDPOINTS.TOKENS, tokensRouter);
    app.use(ENDPOINTS.LOGOUT, logoutRouterV1);
    app.use(ENDPOINTS.OAUTH, oathRouterV1);
    app.use(ENDPOINTS.MIGRATE, migrateRouterV1);
  },
});

export default authServiceApp;
