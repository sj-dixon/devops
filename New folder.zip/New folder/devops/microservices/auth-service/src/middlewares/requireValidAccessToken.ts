import { Response, NextFunction } from 'express';
import { Types } from '@alcumus/globals';
import {
  getAuthorityUrl,
  getKeycloakConfig,
  isAzureAdToken,
  parseJwtHeader,
} from '@alcumus/auth-plugin';
import axios from 'axios';

export async function requireValidAccessToken(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const accessToken = request.headers['x-access-token'];
  if (accessToken && isAzureAdToken(accessToken as string)) {
    if (await validateAzureToken(accessToken as string)) {
      next();
    } else {
      response.status(401).json({
        message: 'Azure Access Token not Valid',
      });
    }
    return;
  }

  const keycloakConfig = getKeycloakConfig();
  const url = `${keycloakConfig['auth-server-url']}/realms/${keycloakConfig.realm}/protocol/openid-connect/userinfo`;
  const axiosResponse = await axios.get(url, {
    validateStatus: (status) => status < 500,
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (axiosResponse.status !== 200) {
    response.status(401).json({
      message: 'Access Token not Valid',
    });
  } else {
    next();
  }
}

// azure token validation: https://docs.microsoft.com/en-us/azure/active-directory-b2c/tokens-overview#validation
async function validateAzureToken(accessToken: string) {
  const parsedHeader = parseJwtHeader(accessToken);

  const url = `${getAuthorityUrl()}/discovery/v2.0/keys`;
  const { data } = await axios.get(url);
  if (data.keys[0].kid !== parsedHeader?.kid) return false;
  return true;
}
