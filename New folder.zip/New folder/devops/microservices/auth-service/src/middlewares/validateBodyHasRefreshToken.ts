import { expressValidator } from '@alcumus/express-app';
import { isAzureAdToken } from '@alcumus/auth-plugin';

const JWT_REGEX = /^[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.?[A-Za-z0-9-_.+/=]*$/;

const isKeycloakToken: expressValidator.CustomValidator = (value) =>
  !isAzureAdToken(value);

export const validateBodyHasRefreshToken = expressValidator
  .body('refreshToken', 'auth.token.validJwtRefreshTokenRequired')
  .if(isKeycloakToken)
  .exists()
  .isString()
  .matches(JWT_REGEX)
  .notEmpty();
