import { expressValidator } from '@alcumus/express-app';

export const requireUserName = expressValidator
  .body('username', 'auth.login.userNameDoesNotExist')
  .exists()
  .isString()
  .notEmpty()
  .bail();

export const requirePassword = expressValidator
  .body('password', 'auth.login.passwordDoesNotExist')
  .exists()
  .isString()
  .notEmpty();
