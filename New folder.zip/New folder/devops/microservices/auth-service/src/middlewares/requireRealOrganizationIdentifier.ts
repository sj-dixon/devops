import { Response, NextFunction } from 'express';
import { Types, Utilities } from '@alcumus/globals';

export async function requireRealOrganizationIdentifier(
  request: Types.Request,
  response: Response,
  next: NextFunction
): Promise<void> {
  const organizationIdentifier = request.query.organizationIdentifier;
  if (!organizationIdentifier) {
    next();
    return;
  }

  const axiosInstance = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'tenants'
  );
  const organizationResponse = await axiosInstance.get(
    `/api/v1/auth/${organizationIdentifier}`
  );
  if (organizationResponse.status >= 300) {
    response.status(404).json({
      message: `Organization with identifier "${organizationIdentifier}" was not found`,
    });
    return;
  }
  next();
}
