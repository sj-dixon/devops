export interface LoginRequest {
  username: string;
  password: string;
  organizationIdentifier?: string;
}

export interface StandardLoginToken {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  expiresAt: number;
  refreshExpiresIn?: number;
  refreshExpiresAt?: number;
  tokenType: string;
}

export interface KeycloakTokenResponse {
  data: KeycloakOAuthGrant;
  status: number;
}

export interface PasswordValidationResult {
  isPasswordValid: boolean;
  isPasswordExpired: boolean;
}

/* eslint-disable camelcase */

export interface LegacyLoginToken {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  expires_at: number;
  refresh_expires_in: number;
  refresh_expires_at: number;
  token_type: string;
}

export interface KeycloakOAuthGrant {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  refresh_expires_in: number;
}

/* eslint-enable camelcase */
