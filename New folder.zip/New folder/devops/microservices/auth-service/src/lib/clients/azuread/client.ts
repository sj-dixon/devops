import {
  ConfidentialClientApplication,
  Configuration,
  LogLevel,
  ProtocolMode,
} from '@azure/msal-node';
import { getAuthorityUrl, getAuthorityDomain } from '@alcumus/auth-plugin';
import { Utilities } from '@alcumus/globals';

export function getAzureAdClient(): ConfidentialClientApplication {
  // Configuration reference:
  // https://docs.microsoft.com/en-us/azure/active-directory-b2c/tutorial-authenticate-nodejs-web-app-msal
  // See section where confidentialClientConfig is being initialized

  const clientConfig: Configuration = {
    auth: {
      clientId: Utilities.ProcessEnv.getValueOrThrow('AZURE_AD_CLIENT_ID'),
      authority: getAuthorityUrl(),
      clientSecret: Utilities.ProcessEnv.getValueOrThrow(
        'AZURE_AD_CLIENT_SECRET'
      ),
      knownAuthorities: [getAuthorityDomain()],
      protocolMode: ProtocolMode.AAD,
    },
    system: {
      loggerOptions: {
        logLevel: LogLevel.Trace,
      },
    },
  };
  return new ConfidentialClientApplication(clientConfig);
}
