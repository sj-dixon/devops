import { getAzureAdClient } from './client';
import { StandardLoginToken } from '../../../types';
import { AuthenticationResult } from '@azure/msal-common';
import getUnixTime from 'date-fns/getUnixTime';
import {
  AuthorizationCodeRequest,
  RefreshTokenRequest,
} from '@azure/msal-node';
import { Utilities } from '@alcumus/globals';
import {
  AcquireTokenParameters,
  AcquireUrlParameters,
} from '../../../types/oauth';
import { getAuthorityUrl } from '@alcumus/auth-plugin';

export interface TokenExchangeResult extends AuthenticationResult {
  refreshToken: string;
}

export { getAzureAdClient };

export function getScopes() {
  return [
    Utilities.ProcessEnv.getValueOrThrow('AZURE_AD_CLIENT_ID'),
    'openid',
    'offline_access',
  ];
}

export async function getAuthCodeUrl({
  correlationId,
  redirectUri,
  prompt = 'login',
}: AcquireUrlParameters): Promise<string> {
  const client = getAzureAdClient();
  return client.getAuthCodeUrl({
    correlationId,
    scopes: getScopes(),
    redirectUri,
    prompt,
  });
}

export async function redeemCodeForTokens({
  correlationId,
  code,
  redirectUri,
}: AcquireTokenParameters): Promise<AuthenticationResult | null> {
  const azureAdAuthority = getAuthorityUrl();

  const client = getAzureAdClient();

  // Use acquireTokensByCode to get the access token
  const acquireTokenRequest: AuthorizationCodeRequest = {
    authority: azureAdAuthority,
    correlationId,
    code,
    redirectUri,
    scopes: getScopes(),
  };
  const result = await client.acquireTokenByCode(acquireTokenRequest);
  return result;
}

export async function refreshToken(
  refreshToken: string,
  correlationId: string
) {
  const client = getAzureAdClient();
  const request: RefreshTokenRequest = {
    refreshToken,
    scopes: getScopes(),
    correlationId,
  };
  const authenticationResult = await client.acquireTokenByRefreshToken(request);
  const now = new Date(Date.now());
  return transformToken(authenticationResult, now);
}

export function transformToken(
  input: TokenExchangeResult | AuthenticationResult | null,
  now: Date
): StandardLoginToken | null {
  if (!input) {
    return null;
  }
  if (!input.expiresOn || !input.extExpiresOn) {
    return null;
  }

  return {
    accessToken: input.accessToken,
    refreshToken: (input as TokenExchangeResult).refreshToken as string,
    refreshExpiresIn: getUnixTime(input.extExpiresOn) - getUnixTime(now),
    tokenType: input.tokenType,
    expiresAt: getUnixTime(input.expiresOn),
    expiresIn: getUnixTime(input.expiresOn) - getUnixTime(now),
  };
}
