import axios from 'axios';
import qs from 'querystring';
import { KeycloakOAuthGrant } from '../../../types';
import { Utilities } from '@alcumus/globals';

interface KeycloakResponse {
  status: number;
  data: KeycloakOAuthGrant;
}

export async function loginWithKeycloak(
  username: string,
  password: string
): Promise<KeycloakResponse> {
  const keycloak = Utilities.getKeycloakConstants();
  const url = `${keycloak.URL}/realms/${keycloak.REALM}/protocol/openid-connect/token`;
  const config = {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    validateStatus: null,
  };

  const body = {
    client_id: keycloak.CLIENT_ID,
    client_secret: keycloak.CLIENT_SECRET,
    username,
    password,
    grant_type: 'password',
  };
  const result = await axios.post(url, qs.stringify(body), config);
  return {
    data: result.data,
    status: result.status,
  };
}
