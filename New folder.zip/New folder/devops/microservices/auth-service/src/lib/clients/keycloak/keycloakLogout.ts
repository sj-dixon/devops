import axios, { AxiosRequestConfig } from 'axios';
import { Utilities } from '@alcumus/globals';
import qs from 'querystring';

export interface LogoutResult {
  data: object;
  status: number;
  redirect: string;
}

export async function logout(refreshToken: string): Promise<LogoutResult> {
  const keycloak = Utilities.getKeycloakConstants();
  const redirectUri = Utilities.ProcessEnv.getValue(
    'AUTH_SERVICE_LOGOUT_REDIRECT_URL'
  );
  const redirectQueryString = Utilities.ProcessEnv.isEnabled(
    'AUTH_SERVICE_LOGOUT_REDIRECT_URL'
  )
    ? `?redirect_uri=${redirectUri}`
    : '';
  const url = `${keycloak.URL}/realms/${keycloak.REALM}/protocol/openid-connect/logout${redirectQueryString}`;
  const config: AxiosRequestConfig = {
    validateStatus: (status) => status < 500,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  };
  const body = {
    client_id: keycloak.CLIENT_ID,
    client_secret: keycloak.CLIENT_SECRET,
    refresh_token: refreshToken,
  };
  const result = await axios.post(url, qs.stringify(body), config);
  return {
    data: result.data,
    status: result.status,
    redirect: result.headers?.Location,
  };
}
