export enum OrganizationAuthProviderType {
  KEYCLOAK = 'KEYCLOAK',
  AZURE_AD = 'AZURE_AD',
  API = 'API',
  EXTERNAL = 'EXTERNAL',
}

export interface OrganizationAuthProvider {
  id: number;
  organizationId: number;
  userNamePrefix: string;
  authProviderName: string;
  authProviderType: OrganizationAuthProviderType;
  apiTokenHeaderName?: string;
  apiTokenHeaderValue?: string;
  callbackUrl?: string;
}

export interface UserAccount {
  id: number;
  userId: number;
  scopedToOrganizationId: number | null;
  email: string | null;
  username: string | null;
  isEnabled: boolean;
  internalAccountId: string | null;
  authProviderName: OrganizationAuthProviderType | string;
  authProviderType: OrganizationAuthProviderType;
  requiresPasswordReset: boolean;
  firstName: string;
  lastName: string;
}

export interface MigrationResponse {
  email: string | null;
  username: string | null;
  authProviderName: OrganizationAuthProviderType | string;
  authProviderType: OrganizationAuthProviderType;
  firstName: string;
  lastName: string;
  requiresPasswordReset: boolean;
  requiresMFA: boolean;
}
