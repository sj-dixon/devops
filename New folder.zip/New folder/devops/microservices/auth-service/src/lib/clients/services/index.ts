import { AxiosInstance } from 'axios';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
  UserAccount,
} from './types';

export async function retrieveAuthProvider({
  axiosInstance,
  organizationIdentifier,
  providerName,
}: {
  axiosInstance: AxiosInstance;
  organizationIdentifier?: string;
  providerName: OrganizationAuthProviderType | string;
}): Promise<OrganizationAuthProvider | null> {
  const url = `/api/v1/authProviders/${providerName}${
    organizationIdentifier
      ? `?organizationIdentifier=${organizationIdentifier}`
      : ''
  }`;
  const result = await axiosInstance.get(url);
  if (result.status === 404) {
    return null;
  } else {
    return result.data as OrganizationAuthProvider;
  }
}

export async function retrieveUserAccount({
  axiosInstance,
  organizationIdentifier,
  username,
}: {
  axiosInstance: AxiosInstance;
  organizationIdentifier?: string;
  username: string;
}): Promise<UserAccount | null> {
  const url = `/api/v1/accounts/usernames/${username}${
    organizationIdentifier
      ? `?organizationIdentifier=${organizationIdentifier}`
      : ''
  }`;
  const result = await axiosInstance.get(url);
  if (result.status === 404) {
    return null;
  } else {
    return result.data as UserAccount;
  }
}

export async function updateUserAccount({
  axiosInstance,
  userAccount,
  password,
  targetProviderType,
}: {
  axiosInstance: AxiosInstance;
  userAccount: UserAccount;
  password: string;
  targetProviderType: OrganizationAuthProviderType;
}): Promise<boolean> {
  const url = `/api/v1/accounts/migrate/${userAccount.id}`;
  const response = await axiosInstance.patch(url, {
    authProviderType: targetProviderType,
    password,
  });

  return response.status >= 200 && response.status < 300;
}
