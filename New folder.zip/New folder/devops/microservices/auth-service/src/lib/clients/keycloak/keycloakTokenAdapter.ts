import add from 'date-fns/add';
import getUnixTime from 'date-fns/getUnixTime';
import {
  LegacyLoginToken,
  StandardLoginToken,
  KeycloakOAuthGrant,
} from '../../../types';

export function transformKeycloakToLegacyToken(
  token: KeycloakOAuthGrant,
  now: Date
): LegacyLoginToken {
  const expiresAt = getUnixTime(
    add(now, {
      seconds: token.expires_in,
    })
  );
  const refreshExpiresAt = getUnixTime(
    add(now, {
      seconds: token.refresh_expires_in,
    })
  );
  return {
    access_token: token.access_token,
    refresh_token: token.refresh_token,
    expires_in: token.expires_in,
    expires_at: expiresAt,
    refresh_expires_at: refreshExpiresAt,
    refresh_expires_in: token.refresh_expires_in,
    token_type: token.token_type,
  };
}

export function transformLegacyToStandardLoginToken(
  token: LegacyLoginToken
): StandardLoginToken {
  return {
    accessToken: token.access_token,
    refreshToken: token.refresh_token,
    expiresIn: token.expires_in,
    expiresAt: token.expires_at,
    refreshExpiresAt: token.refresh_expires_at,
    refreshExpiresIn: token.refresh_expires_in,
    tokenType: token.token_type,
  };
}

export function transformKeycloakToken(
  data: KeycloakOAuthGrant,
  now: Date
): StandardLoginToken {
  const legacyToken = transformKeycloakToLegacyToken(data, now);
  return transformLegacyToStandardLoginToken(legacyToken);
}
