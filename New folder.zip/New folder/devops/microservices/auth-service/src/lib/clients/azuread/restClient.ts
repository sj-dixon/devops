import { Utilities } from '@alcumus/globals';
import axios, { AxiosResponse } from 'axios';
import { getAuthorityUrl } from '@alcumus/auth-plugin';

// TODO: REMOVE LATER
// This isnt a standard part of the msal code, but something supported by Azure AD B2C to obtain tokens
// https://docs.microsoft.com/en-us/azure/active-directory-b2c/authorization-code-flow
export function getTokenEndpoint() {
  const parts = [getAuthorityUrl(), `oauth2/v2.0/token`];
  return parts.join('/');
}

export async function getTokensFromAuthorizationCode(code: string) {
  const azureAdClientId = Utilities.ProcessEnv.getValueOrThrow(
    'AZURE_AD_CLIENT_ID'
  ) as string;
  const azureAdClientSecret = Utilities.ProcessEnv.getValueOrThrow(
    'AZURE_AD_CLIENT_SECRET'
  );

  // TODO: REMOVE LATER
  // Until we've a proper way to obtain refresh tokens, this is a temporary hack
  // Obtain tokens through AzureAD B2C tokens endpoint
  const formData = new URLSearchParams({
    client_id: azureAdClientId,
    client_secret: azureAdClientSecret,
    grant_type: 'authorization_code',
    code,
    scope: `${azureAdClientId} openid offline_access`,
    response_type: 'token',
  });
  const tokenEndpoint = getTokenEndpoint();
  const result: AxiosResponse = await axios.post(tokenEndpoint, formData, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  });

  if (axios.isAxiosError(result)) {
    console.error('Error obtaining tokens from AzureAD B2C', result.data);
    throw new Error('Error obtaining tokens from AzureAD B2C');
  }

  const { data: tokenResponse } = result;
  return {
    accessToken: tokenResponse.access_token as string,
    refreshToken: tokenResponse.refresh_token as string,
    expiresOn: tokenResponse.expires_on, // Expiry in seconds
  };
}
