import 'isomorphic-fetch';
import { Client } from '@microsoft/microsoft-graph-client';
import { TokenCredentialAuthenticationProvider } from '@microsoft/microsoft-graph-client/authProviders/azureTokenCredentials';
import { ClientSecretCredential } from '@azure/identity';
import { Utilities } from '@alcumus/globals';

export function getMSGraphClient() {
  const credential = new ClientSecretCredential(
    Utilities.ProcessEnv.getValueOrThrow('AZURE_AD_TENANT_ID'),
    Utilities.ProcessEnv.getValueOrThrow('AZURE_AD_CLIENT_ID'),
    Utilities.ProcessEnv.getValueOrThrow('AZURE_AD_CLIENT_SECRET')
  );

  const authProvider = new TokenCredentialAuthenticationProvider(credential, {
    scopes: ['https://graph.microsoft.com/.default'],
  });
  return Client.initWithMiddleware({
    debugLogging: Boolean(
      Utilities.ProcessEnv.getValueOrDefault('DEBUG_MS_GRAPH_CALLS', 'false')
    ),
    authProvider,
  });
}
