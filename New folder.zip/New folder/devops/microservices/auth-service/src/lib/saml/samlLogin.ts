// import axios from 'axios'
import axios, { AxiosResponse } from 'axios';
import qs from 'querystring';
import { Utilities } from '@alcumus/globals';
import {
  getSamlLoginContext,
  getSsoLoginSessionToken,
  SsoLoginContext,
} from './htmlParsers';

function cleanCookies(cookies: string[]): string[] {
  return cookies.map((cookie) => {
    return cookie.split('; ')[0];
  });
}

export async function loginWithSaml(
  ssoExchange: string,
  username: string,
  password: string
): Promise<string | undefined> {
  try {
    const ssoLoginPageResponse = await getSsoLoginPage(ssoExchange);
    const ssoLoginContext = getSsoLoginSessionToken(ssoLoginPageResponse.data);
    const ssoLoginResponse = await postCredentialsToIdpAuthenticate(
      ssoLoginContext,
      username,
      password,
      cleanCookies(ssoLoginPageResponse.headers['set-cookie'])
    );

    const samlLoginContext = getSamlLoginContext(ssoLoginResponse.data);
    return samlLoginContext.samlResponse;
  } catch (err) {
    console.log(`Could not log into SAML with user ${username}, err: \n`, err);
    return undefined;
  }
}

async function getSsoLoginPage(ssoExchange: string): Promise<AxiosResponse> {
  const keycloak = Utilities.getKeycloakConstants();
  const url = `${keycloak.URL}/realms/${keycloak.REALM}/protocol/saml/clients/${ssoExchange}`;
  return axios.get(url);
}

async function postCredentialsToIdpAuthenticate(
  context: SsoLoginContext,
  username: string,
  password: string,
  cookies: string[]
): Promise<AxiosResponse> {
  const body = qs.stringify({
    username,
    password,
    credentialId: '',
  });
  const config = {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Cookie: cookies.join('; '),
    },
  };
  console.log(`POST ${context.actionUrl}`);
  const result = await axios.post(context.actionUrl, body, config);
  console.log('===>\n', result.headers, result.status);
  return result;
}
