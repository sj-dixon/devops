import qs from 'querystring';
import { parse } from 'node-html-parser';

export interface SsoLoginContext {
  sessionCode: string;
  actionUrl: string;
}

export interface SsoRedirectContext {
  actionUrl: string;
  samlResponse: string;
}

function parseHtmlUsingRegex(
  htmlPage: string,
  regex: RegExp,
  error: string
): string {
  const matches = regex.exec(htmlPage);
  if (!matches || matches.length < 2) {
    throw new Error(error);
  }
  return matches[1];
}

export function getSsoLoginSessionToken(ssoLoginPage: string): SsoLoginContext {
  const regex = /<form([\w\s\d="-:?;]+)>/;
  const match = parseHtmlUsingRegex(
    ssoLoginPage,
    regex,
    'Could not parse login page for form element'
  );
  const element = parse(`<form ${match} />`);
  const form = element.querySelector('#kc-form-login');
  const action = form.getAttribute('action');
  if (!action) {
    throw new Error('Could not SSO login page form action');
  }
  const actionQuery = qs.parse(action.substring(action.indexOf('?') + 1));
  return {
    actionUrl: action,
    sessionCode: actionQuery.session_code as string,
  };
}

export function getSamlLoginContext(
  ssoSuccessPage: string
): SsoRedirectContext {
  const samlResponseRegex = /value="([\w\d+/=]+)"/;
  const samlResponse = parseHtmlUsingRegex(
    ssoSuccessPage,
    samlResponseRegex,
    'Could not parse SSO Success page HTML for SAML Response'
  );

  const actionUrlRegex = /action="(.+)"/;
  const actionUrl = parseHtmlUsingRegex(
    ssoSuccessPage,
    actionUrlRegex,
    'Could not parse SSO Success page HTML for authenticate endpoint'
  );

  return {
    actionUrl,
    samlResponse,
  };
}
