export interface ApiCredentialRequest {
  organizationId: number | null;
  organizationIdentifier: string | null;
  loginIdentifier: string | null;
  username: string | null;
  email: string | null;
  password: string | null;
  loginIdentifierType: LoginIdentifierType;
}

export enum LoginIdentifierType {
  EMAIL = 'EMAIL',
  USERNAME = 'USERNAME',
  PHONE = 'PHONE',
}
