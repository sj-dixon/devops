export interface AcquireTokenParameters {
  correlationId?: string;
  code: string;
  redirectUri: string;
  state: string;
}

// Reference: https://docs.microsoft.com/en-us/azure/active-directory-b2c/tutorial-authenticate-nodejs-web-app-msal
// See section where APP_STATES is declared
export type AuthenticationAppState =
  | 'login'
  | 'logout'
  | 'password_reset'
  | 'update_profile';

export interface AcquireUrlParameters {
  correlationId?: string;
  redirectUri: string;
  prompt?: AuthenticationAppState;
}
