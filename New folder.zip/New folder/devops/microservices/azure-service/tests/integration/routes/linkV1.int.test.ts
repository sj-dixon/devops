import supertest from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { Utilities } from '@alcumus/globals';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { AzureLinkRequest, UserAccount } from '../../../src/types';
import { getErrorMessage } from '../../../src/lib/errorMessages';

const requestBody: AzureLinkRequest = {
  signInName: 'twasbrillig@mahegrabe.com',
  objectId: 'asdfjkalsdfjasdflsdjf',
};

const expectedUser: UserAccount = {
  userId: 123,
  email: requestBody.signInName as string,
  username: null,
  firstName: 'Twas',
  lastName: 'Brill',
};

const AZURE_AD_CALLBACK_API_KEY = 'friendship';
const SERVICE_MESH_HOST = 'http://secretlair:8000';

const mockAxios = new MockAdapter(axios);

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv({
    AZURE_AD_CALLBACK_API_KEY,
    SERVICE_MESH_HOST,
    SERVICE_MESH_API_KEY: 'secret mesh api key',
  });
});

describe(ENDPOINTS.LINK, () => {
  describe('POST /', () => {
    it('returns 401 if azure api key is not specified', async () => {
      const response = await supertest(app)
        .post(ENDPOINTS.LINK)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        401,
        { message: "'x-azure-api-key' header required" },
      ]);
    });

    it('returns 401 if azure api key is wrong', async () => {
      const response = await supertest(app)
        .post(ENDPOINTS.LINK)
        .set('x-azure-api-key', 'wrong value')
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        401,
        { message: 'x-azure-api-key header has an incorrect api key' },
      ]);
    });

    it('when submitting email and users service returns 200, returns 200 ', async () => {
      const mockedUserService = mockPatchUserBasedOnUsername(200, expectedUser);
      const response = await supertest(app)
        .post(ENDPOINTS.LINK)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect(mockedUserService).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([200, expectedUser]);
    });

    it('when users service returns 404, returns 404 ', async () => {
      const mockedUserService = mockPatchUserBasedOnUsername(404);
      const response = await supertest(app)
        .post(ENDPOINTS.LINK)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect(mockedUserService).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([
        404,
        getErrorMessage({
          requestId: expect.any(String),
          key: 'DOES_NOT_EXIST',
        }),
      ]);
    });

    it('when users service returns 400, returns 500 response ', async () => {
      const mockedUserService = mockPatchUserBasedOnUsername(400);
      const response = await supertest(app)
        .post(ENDPOINTS.LINK)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect(mockedUserService).toHaveBeenCalledTimes(1);
      expect([response.status, response.body]).toEqual([
        500,
        {
          message: expect.any(String),
        },
      ]);
    });
  });
});

function mockPatchUserBasedOnUsername(
  statusCode: number,
  body = {}
): jest.Mock {
  const patchResult = jest.fn().mockImplementation(() => [statusCode, body]);
  const url = `${SERVICE_MESH_HOST}/users/api/v1/accounts/usernames/${requestBody.signInName}`;
  mockAxios.onPatch(url).replyOnce(patchResult);
  return patchResult;
}
