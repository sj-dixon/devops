import supertest from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { Utilities } from '@alcumus/globals';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import { AuthMigrationResult, AzureValidateResponse } from '../../../src/types';
import { getErrorMessage } from '../../../src/lib/errorMessages';

const AZURE_AD_CALLBACK_API_KEY = 'friendship';
const SERVICE_MESH_HOST = 'http://secretlair:8000';
const requestBody = {
  username: 'danny@boy.com',
  password: 'the pipes are calling',
};

const mockAxios = new MockAdapter(axios);

beforeAll(() => {
  Utilities.ProcessEnv.overrideEnv({
    AZURE_AD_CALLBACK_API_KEY,
    SERVICE_MESH_HOST,
    SERVICE_MESH_API_KEY: 'secret mesh api key',
  });
});

describe('/api/v1/validate', () => {
  describe('POST /', () => {
    it('returns 401 if azure api key is not specified', async () => {
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        401,
        { message: "'x-azure-api-key' header required" },
      ]);
    });

    it('returns 401 if azure api key is wrong', async () => {
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', 'wrong value')
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        401,
        { message: 'x-azure-api-key header has an incorrect api key' },
      ]);
    });

    it('when auth service returns AD record, returns 200 with needsMigration=false', async () => {
      const mockedUser: AuthMigrationResult =
        getAuthMigrationResult('AZURE_AD');
      const mockedAuthService = mockAuthService(200, mockedUser);
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedValidationResult(mockedUser, false, false),
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
    });

    it('when auth service returns API account, returns 200 with needsMigration=true', async () => {
      const mockedUser: AuthMigrationResult = getAuthMigrationResult('API');
      const mockedAuthService = mockAuthService(200, mockedUser);
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedValidationResult(mockedUser, true, false),
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
    });

    it('when auth service returns resettable KEYCLOAK account, returns 200 with needsMigration=true and requiresPasswordReset=true', async () => {
      const mockedUser: AuthMigrationResult = getAuthMigrationResult(
        'KEYCLOAK',
        true
      );
      const mockedAuthService = mockAuthService(200, mockedUser);
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedValidationResult(mockedUser, true, true),
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
    });

    it('when auth service returns non-resettable KEYCLOAK account, returns 200 with needsMigration=true and requiresPasswordReset=false', async () => {
      const mockedUser: AuthMigrationResult = getAuthMigrationResult(
        'KEYCLOAK',
        false
      );
      const mockedAuthService = mockAuthService(200, mockedUser);
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedValidationResult(mockedUser, true, false),
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
    });

    it('when auth service returns 400, returns 400 response', async () => {
      const message = 'Something was wrong';
      const mockedAuthService = mockAuthService(400, { message });
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        400,
        getErrorMessage({
          key: 'LOGIN_INVALID',
          requestId: expect.any(String),
        }),
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
    });

    it('when auth service returns 401, returns 500 response', async () => {
      const message = 'api key was wrong';
      const mockedAuthService = mockAuthService(401, { message });
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);

      expect([response.status, response.body]).toEqual([
        500,
        { message: expect.any(String) },
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
      expect(response.body.message).not.toEqual({ message });
    });

    it('when auth service returns 409, returns 409 response', async () => {
      const message = 'this case might not be real but handle it anyways';
      const mockedAuthService = mockAuthService(409, { message });
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        400,
        getErrorMessage({
          key: 'LOGIN_INVALID',
          requestId: expect.any(String),
        }),
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
    });

    it('when auth service returns 500, returns 500 response', async () => {
      const message = 'auth service doesnt know how to talk to keycloak';
      const mockedAuthService = mockAuthService(500, { message });
      const response = await supertest(app)
        .post(ENDPOINTS.VALIDATE_CREDENTIALS)
        .set('x-azure-api-key', AZURE_AD_CALLBACK_API_KEY)
        .send(requestBody);
      expect([response.status, response.body]).toEqual([
        500,
        { message: expect.any(String) },
      ]);
      expect(mockedAuthService).toHaveBeenCalledTimes(1);
      expect(response.body.message).not.toEqual({ message });
    });
  });
});

function mockAuthService(
  statusCode: number,
  body: object | AuthMigrationResult = {}
): jest.Mock {
  const authServiceFn = jest.fn().mockImplementation(() => [statusCode, body]);
  const url = `${SERVICE_MESH_HOST}/auth/api/v1/migrate`;
  mockAxios.onPost(url).replyOnce(authServiceFn);
  return authServiceFn;
}

function getAuthMigrationResult(
  authProviderName: string,
  requiresPasswordReset = false
): AuthMigrationResult {
  return {
    email: requestBody.username,
    firstName: 'Danny',
    lastName: 'Boy',
    username: null,
    authProviderName,
    authProviderType:
      authProviderName === 'AZURE_AD' ? authProviderName : 'API',
    requiresPasswordReset,
    requiresMFA: true,
  };
}

function getExpectedValidationResult(
  authMigrationResult: AuthMigrationResult,
  needsMigration: boolean,
  requiresPasswordReset: boolean
): AzureValidateResponse {
  return {
    needsMigration,
    newPassword: requestBody.password,
    displayName: authMigrationResult.firstName,
    givenName: authMigrationResult.firstName,
    surName: authMigrationResult.lastName,
    email: authMigrationResult.email as string,
    requiresPasswordReset,
    requiresMFA: true,
  };
}
