import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import path from 'path';
import { validateV1 } from './routes/validateV1';
import { doesNotExist } from './routes/doesNotExist';
import { doesExistV1 } from './routes/doesExistV1';
import { linkV1 } from './routes/linkV1';

const apiSpec = './api-spec.yaml';

const app = configureApp({
  serviceName: 'Azure Callback Service',
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
    validateResponse: true,
  },
  setup: (theApp) => {
    theApp.use(ENDPOINTS.VALIDATE_CREDENTIALS, validateV1);
    theApp.use(ENDPOINTS.DOES_NOT_EXIST, doesNotExist);
    theApp.use(ENDPOINTS.DOES_EXIST, doesExistV1);
    theApp.use(ENDPOINTS.LINK, linkV1);
  },
});

export default app;
