import { runApp } from '@alcumus/express-app';
import app from './app';
import process from 'process';
import { PORT_NUMBER } from './constants';

runApp(app, {
  port: PORT_NUMBER,
}).catch(async (reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
  process.exit(1);
});
