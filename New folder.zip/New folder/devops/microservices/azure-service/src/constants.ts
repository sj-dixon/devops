import { Utilities } from '@alcumus/globals';

export const PORT_NUMBER =
  Number(Utilities.ProcessEnv.getValue('AZURE_SERVICE_PORT')) || 8015;

export const ENDPOINTS = {
  VALIDATE_CREDENTIALS: `/api/v1/accounts/validate`,
  DOES_NOT_EXIST: '/api/v1/accounts/doesNotExist',
  DOES_EXIST: '/api/v1/accounts/exists',
  LINK: '/api/v1/accounts/link',
};
