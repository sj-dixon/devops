import { Types } from '@alcumus/globals';

export const ERROR_MESSAGES: Types.Dictionary<string, Types.StringDictionary> =
  {
    en: {
      DOES_NOT_EXIST: 'User does not exist',
      DOES_EXIST: 'Email is already in use by another user',
      LOGIN_INVALID: 'Credentials were not valid.',
    },
  };
