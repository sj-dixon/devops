import express, { Response, Router } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { getAuthServiceClient } from '../lib/clients';
import { AuthMigrationResult, AzureValidateResponse } from '../types';
import { getErrorMessage } from '../lib/errorMessages';

const validateV1: Router = express.Router();

validateV1.post(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    'x-azure-api-key',
    'AZURE_AD_CALLBACK_API_KEY'
  ),
  async (request: Types.Request, response: Response) => {
    const { signInName: username, password } = request.body;
    const axiosInstance = getAuthServiceClient(request);
    const axiosResponse = await axiosInstance.post(`/api/v1/migrate`, {
      username,
      password,
    });

    if (
      axiosResponse.status >= 400 &&
      axiosResponse.status < 500 &&
      axiosResponse.status !== 401
    ) {
      return response.status(400).send(
        getErrorMessage({
          requestId: request.id,
          key: 'LOGIN_INVALID',
        })
      );
    } else if (axiosResponse.status >= 200 && axiosResponse.status < 300) {
      const authMigrationResponse: AuthMigrationResult = axiosResponse.data;

      const needsMigration =
        authMigrationResponse.authProviderType !== 'AZURE_AD';

      const accountDetails: AzureValidateResponse = {
        email: authMigrationResponse.email as string,
        surName: authMigrationResponse.lastName,
        givenName: authMigrationResponse.firstName,
        displayName: authMigrationResponse.firstName,
        newPassword: password,
        requiresPasswordReset: authMigrationResponse.requiresPasswordReset,
        needsMigration,
        requiresMFA: authMigrationResponse.requiresMFA,
      };
      return response.status(200).send(accountDetails);
    } else {
      throw new Error(axiosResponse.data.message);
    }
  }
);

export { validateV1 };
