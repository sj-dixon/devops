import express, { Response, Router } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { getUsersServiceClient } from '../lib/clients';
import { getErrorMessage } from '../lib/errorMessages';

const doesNotExist: Router = express.Router();

doesNotExist.post(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    'x-azure-api-key',
    'AZURE_AD_CALLBACK_API_KEY'
  ),
  async (request: Types.Request, response: Response) => {
    const { signInName: username } = request.body;
    const axiosInstance = getUsersServiceClient(request);
    const axiosResponse = await axiosInstance.get(
      `/api/v1/accounts/usernames/${username}`
    );
    if (axiosResponse.status === 200) {
      response.status(409).json(
        getErrorMessage({
          requestId: request.id,
          key: 'DOES_EXIST',
        })
      );
    } else if (axiosResponse.status === 404) {
      response.status(200).json({});
    } else {
      throw new Error(axiosResponse.data.message);
    }
  }
);

export { doesNotExist };
