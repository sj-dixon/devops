import express, { Response, Router } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { getUsersServiceClient } from '../lib/clients';
import { AzureLinkRequest } from '../types';
import { getErrorMessage } from '../lib/errorMessages';

const linkV1: Router = express.Router();

linkV1.post(
  '/',
  Middlewares.requireCustomApiKeyHeader(
    'x-azure-api-key',
    'AZURE_AD_CALLBACK_API_KEY'
  ),
  async (request: Types.Request, response: Response) => {
    const linkRequest: AzureLinkRequest = request.body;
    const axiosInstance = getUsersServiceClient(request);
    const axiosResponse = await axiosInstance.patch(
      `/api/v1/accounts/usernames/${linkRequest.signInName}`,
      {
        authProviderType: 'AZURE_AD',
        objectId: linkRequest.objectId,
      }
    );
    if (axiosResponse.status === 200) {
      response.status(200).json(axiosResponse.data);
    } else if (axiosResponse.status === 404) {
      response.status(404).json(
        getErrorMessage({
          requestId: request.id,
          key: 'DOES_NOT_EXIST',
        })
      );
    } else {
      throw new Error(axiosResponse.data.message);
    }
  }
);

export { linkV1 };
