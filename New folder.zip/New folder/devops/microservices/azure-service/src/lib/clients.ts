import { AxiosInstance } from 'axios';
import { Types, Utilities } from '@alcumus/globals';

export function getUsersServiceClient(request: Types.Request): AxiosInstance {
  const axiosInstance = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'users'
  );
  axiosInstance.defaults.headers['x-azure-api-key'] =
    Utilities.ProcessEnv.getValueOrThrow('AZURE_AD_CALLBACK_API_KEY');
  return axiosInstance;
}

export function getAuthServiceClient(request: Types.Request): AxiosInstance {
  const axiosInstance = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    'auth'
  );
  axiosInstance.defaults.headers['x-azure-api-key'] =
    Utilities.ProcessEnv.getValueOrThrow('AZURE_AD_CALLBACK_API_KEY');
  return axiosInstance;
}
