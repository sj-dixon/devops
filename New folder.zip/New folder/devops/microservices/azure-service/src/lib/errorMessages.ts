import { AzureErrorResponse } from '../types';
import { ERROR_MESSAGES } from '../i18nMessages';

export function getErrorMessage({
  requestId,
  key,
}: {
  requestId?: string;
  key: string;
}): AzureErrorResponse {
  const userMessage = ERROR_MESSAGES.en[key];
  if (!userMessage) {
    throw new Error('Could not find message');
  }
  return {
    version: '1.0.1',
    status: 409,
    code: null,
    requestId: requestId || null,
    userMessage,
    developerMessage: null,
    moreInfo: null,
  };
}
