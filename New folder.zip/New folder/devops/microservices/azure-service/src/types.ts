export interface AzureValidateRequest {
  signInName: string;
  password?: string;
  organizationIdentifier?: string;
}

export interface AzureEmailRequest {
  signInName: string;
}

export interface AzureLinkRequest {
  objectId: string;
  signInName?: string;
}

export interface AzureValidateResponse {
  email: string;
  newPassword: string;
  displayName: string;
  givenName: string;
  surName: string;
  requiresPasswordReset: boolean;
  needsMigration: boolean;
  requiresMFA: boolean;
}

export interface UserAccount {
  email: string;
  username: string | null;
  userId: number;
  firstName: string;
  lastName: string;
}

export interface AuthMigrationResult {
  username?: string | null;
  email?: string | null;
  authProviderType: string;
  authProviderName: string;
  firstName: string;
  lastName: string;
  requiresPasswordReset: boolean;
  requiresMFA: boolean;
}

/**
 * Changing this interface is restricted as Azure
 * requires errors to be in this format in order
 * to be displayed properly on the UI.  If translating,
 * set the userMessage based on the language-specific string.
 */
export interface AzureErrorResponse {
  version: string;
  status: number;
  userMessage: string;

  requestId: string | null;
  code: string | null;
  developerMessage: string | null;
  moreInfo: string | null;
}
