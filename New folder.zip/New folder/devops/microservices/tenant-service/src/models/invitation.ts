import { JsonSchemaBuilder, toJavascriptDate } from '@alcumus/objection-lib';
import { v4 as uuidV4 } from 'uuid';
import { Model, Transaction } from 'objection';
import { isBefore } from 'date-fns';
import getInvitationExpiration from '../lib/utils/getInvitationExpiration';

export class InvitationEntity extends Model {
  id!: number;
  inviteCode!: string;
  email!: string;
  organizationId!: number;
  expiresAt!: string;
  used!: boolean;
  deleted!: boolean;

  static tableName = 'invitations';

  // static relationMappings = {
  //   organizationId: {
  //     relation: Model.HasManyRelation,
  //     modelClass: InvitationEntity,
  //     join: {
  //       from: 'tenants.id',
  //       to: 'invitations.organizationId',
  //     },
  //   },
  // };

  static jsonSchema = JsonSchemaBuilder.newBuilder().build();

  static async getInvitations(
    organizationId: number,
    offset?: number,
    limit?: number
  ): Promise<InvitationEntity[]> {
    return InvitationEntity.query()
      .where({
        organizationId,
        deleted: false,
      })
      .offset(offset || 0)
      .limit(limit || 10)
      .orderBy('id', 'DESC');
  }

  static async find(
    organizationId: number,
    inviteCode: string
  ): Promise<InvitationEntity> {
    return InvitationEntity.query().findOne({
      organizationId,
      inviteCode,
      deleted: false,
    });
  }

  static isValid(invitation: InvitationEntity) {
    return (
      !invitation.deleted &&
      !invitation.used &&
      isBefore(new Date(), toJavascriptDate(invitation.expiresAt))
    );
  }

  static async create(
    trx: Transaction | null,
    organizationId: number,
    email: string
  ): Promise<InvitationEntity> {
    return InvitationEntity.query(trx).insert({
      inviteCode: uuidV4(),
      organizationId,
      email,
      expiresAt: getInvitationExpiration(),
    });
  }

  static async createBatch(
    trx: Transaction | null,
    organizationId: number,
    emails: string[]
  ): Promise<InvitationEntity[]> {
    return Promise.all(
      emails.map((email) => InvitationEntity.create(trx, organizationId, email))
    );
  }

  static async update(
    trx: Transaction | null,
    organizationId: number,
    inviteCode: string,
    bumpExpiration: boolean,
    markAsUsed: boolean
  ): Promise<void> {
    await InvitationEntity.query(trx)
      .update({
        used: markAsUsed,
        ...(bumpExpiration && { expiresAt: getInvitationExpiration() }),
      })
      .where({ inviteCode, organizationId, deleted: false });
  }

  static async delete(
    organizationId: number,
    inviteCode: string
  ): Promise<void> {
    await InvitationEntity.query()
      .update({
        deleted: true,
      })
      .where({ inviteCode, organizationId });
  }
}
