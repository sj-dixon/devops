import {
  getMySqlCurrentTimestamp,
  JsonSchemaBuilder,
  SoftDeletableKnexEntity,
} from '@alcumus/objection-lib';
import { TenantSpecifier, TenantTypeCode } from '../types';
import { Model, Transaction } from 'objection';
import { Utilities } from '@alcumus/globals';

export class Tenant extends Model implements SoftDeletableKnexEntity {
  id!: number;
  createdAt!: string;
  modifiedAt!: string;
  deletedAt?: Date;

  tenantTypeCode!: TenantTypeCode;
  tenantName!: string;
  tenantIdentifier!: string;

  parentTenantId?: number;

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeInsert() {
    const now = getMySqlCurrentTimestamp();
    this.createdAt = now;
    this.modifiedAt = now;
  }

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeUpdate() {
    this.modifiedAt = getMySqlCurrentTimestamp();
  }

  static tableName = 'tenants';

  static relationMappings = {
    parentTenant: {
      relation: Model.BelongsToOneRelation,
      modelClass: Tenant,
      join: {
        from: 'tenants.parentTenantId',
        to: 'tenants.id',
      },
    },
  };

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withTimestampField('createdAt', true)
    .withTimestampField('modifiedAt', true)
    .withTimestampField('deletedAt', true)
    .withStringField('tenantName', true)
    .withStringField('tenantIdentifier', true)
    .withStringField('tenantTypeCode', true)
    .withIntegerField('parentTenantId', false)
    .build();

  static getRootTenantIdentifer(): string {
    return Utilities.ProcessEnv.getValueOrDefault(
      'TENANT_SERVICE_ROOT_TENANT_IDENTIFIER',
      'alcumus'
    );
  }

  static async getRootTenant(): Promise<Tenant> {
    const identifier = Tenant.getRootTenantIdentifer();
    return await Tenant.query().findOne({
      tenantTypeCode: TenantTypeCode.ADMIN_ORGANIZATION,
      parentTenantId: null,
      tenantIdentifier: identifier,
    });
  }

  static async getOrganizationById(
    organizationId: number
  ): Promise<Tenant | null> {
    return Tenant.query().findOne({
      tenantTypeCode: TenantTypeCode.ORGANIZATION,
      id: organizationId,
    });
  }

  static async getOrganizationByIdentifier(
    organizationIdentifier: string
  ): Promise<Tenant | null> {
    return Tenant.query().findOne({
      tenantTypeCode: TenantTypeCode.ORGANIZATION,
      tenantIdentifier: organizationIdentifier,
    });
  }

  static async createOrganization(
    { tenantName, tenantIdentifier }: TenantSpecifier,
    parentTenantId: number | null,
    transaction?: Transaction
  ): Promise<Tenant> {
    return Tenant.query(transaction).insertAndFetch({
      tenantTypeCode: TenantTypeCode.ORGANIZATION,
      tenantName,
      tenantIdentifier,
      parentTenantId,
      deletedAt: null,
    });
  }
}
