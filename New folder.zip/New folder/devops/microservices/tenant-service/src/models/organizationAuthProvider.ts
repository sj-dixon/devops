import {
  getMySqlCurrentTimestamp,
  JsonSchemaBuilder,
  SoftDeletableKnexEntity,
} from '@alcumus/objection-lib';
import { Model, Transaction } from 'objection';
import {
  CreateCustomApiAuthProviderRequest,
  OrganizationAuthProviderType,
} from '../types';
import { getOrganizationUserNamePrefix } from '../provisioning/provisionTenant';

// todo consider renaming this entity since it can also be detached from an organization
export class OrganizationAuthProvider
  extends Model
  implements SoftDeletableKnexEntity
{
  id!: number;
  createdAt!: string;
  modifiedAt!: string;

  deletedAt?: Date;
  organizationId!: number;
  authProviderName!: string;
  authProviderType!: OrganizationAuthProviderType;

  callbackUrl?: string;
  apiTokenHeaderName?: string;
  apiTokenHeaderValue?: string;
  userNamePrefix?: string;

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withTimestampField('createdAt', true)
    .withTimestampField('modifiedAt', true)
    .withTimestampField('deletedAt', true)
    .withCompanyId(true)
    .withStringField('authProviderName', true)
    .withStringField('authProviderType', true)
    .withStringField('userNamePrefix')
    .withStringField('callbackUrl')
    .withStringField('apiTokenHeaderName')
    .withStringField('apiTokenHeaderValue')
    .build();

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeInsert() {
    const now = getMySqlCurrentTimestamp();
    this.createdAt = now;
    this.modifiedAt = now;
  }

  // this hook ensures that we set the timestamp in javascript instead
  // of relying on MySQL to set it.  This ensures that the object you get
  // after YourModel.query().insert actually has the timestamps.
  // noinspection JSUnusedGlobalSymbols
  $beforeUpdate() {
    this.modifiedAt = getMySqlCurrentTimestamp();
  }

  static tableName = 'organization_auth_providers';

  static async findByOrganizationId(
    organizationId: number
  ): Promise<OrganizationAuthProvider[]> {
    return OrganizationAuthProvider.query().select('*').where({
      organizationId,
      deletedAt: null,
    });
  }

  static async findByOrganizationIdAndProviderName(
    providerName: string,
    organizationId: number | null
  ): Promise<OrganizationAuthProvider | null> {
    return OrganizationAuthProvider.query().select('*').findOne({
      organizationId,
      authProviderName: providerName,
      deletedAt: null,
    });
  }

  static async createManagedAuthProvider(
    organizationId: number,
    userNamePrefix: string,
    providerType: OrganizationAuthProviderType,
    transaction?: Transaction
  ): Promise<OrganizationAuthProvider> {
    const provider = {
      organizationId,
      authProviderName: providerType,
      authProviderType: providerType,
      userNamePrefix: getOrganizationUserNamePrefix(organizationId),
      deletedAt: null,
    };
    return OrganizationAuthProvider.query(transaction).insertAndFetch(provider);
  }

  static async createCustomAuthProvider(
    organizationId: number,
    {
      authProviderType = OrganizationAuthProviderType.API,
      authProviderName,
      callbackUrl,
      apiTokenHeaderValue,
      apiTokenHeaderName,
    }: CreateCustomApiAuthProviderRequest
  ): Promise<OrganizationAuthProvider> {
    const provider = {
      organizationId,
      authProviderType,
      authProviderName,
      callbackUrl,
      apiTokenHeaderValue,
      apiTokenHeaderName,
      userNamePrefix: null,
      deletedAt: null,
    };
    return OrganizationAuthProvider.query().insertAndFetch(provider);
  }

  static async upsertCustomAuthProvider(
    organizationId: number,
    originalProviderName: string,
    {
      authProviderName,
      authProviderType = OrganizationAuthProviderType.API,
      apiTokenHeaderName,
      apiTokenHeaderValue,
      callbackUrl,
    }: CreateCustomApiAuthProviderRequest
  ): Promise<OrganizationAuthProvider> {
    const provider = {
      organizationId,
      authProviderType,
      authProviderName,
      callbackUrl,
      apiTokenHeaderName,
      apiTokenHeaderValue,
      userNamePrefix: null,
      deletedAt: null,
    };

    let wasUpdated = false;

    const result = await OrganizationAuthProvider.transaction(
      async (trx: Transaction) => {
        const existing = await OrganizationAuthProvider.query(trx).findOne({
          organizationId,
          authProviderName: originalProviderName,
        });
        if (existing) {
          wasUpdated = true;
          return existing
            .$query(trx)
            .updateAndFetch(provider)
            .onConflict('auth_provider_name')
            .merge();
        } else {
          return OrganizationAuthProvider.query(trx)
            .insertAndFetch(provider)
            .onConflict('auth_provider_name')
            .merge();
        }
      }
    );
    return result;
  }
}
