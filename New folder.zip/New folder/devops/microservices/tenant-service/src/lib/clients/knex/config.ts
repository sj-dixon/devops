import { Knex } from 'knex';
import { Utilities } from '@alcumus/globals';
import { getKnexConfig } from '@alcumus/objection-lib';

const databaseName = Utilities.ProcessEnv.getValueOrDefault(
  'TENANT_SERVICE_DATABASE_NAME',
  'tenants_db'
);
const config: Knex.Config = getKnexConfig(databaseName);

export default config;
