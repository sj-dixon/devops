import KcAdminClient from 'keycloak-admin';
import { Utilities } from '@alcumus/globals';
import {
  KeycloakGroupRepresentation,
  KeycloakCredentials,
  KeycloakClientRepresentation,
  KeycloakConstants,
} from '../../../types';

export function getAdminKeycloakClient(): AdminKeycloakClient {
  const constants = Utilities.getKeycloakConstants();
  const configs = {
    baseUrl: constants.URL,
    realmName: constants.REALM,
  };
  const client = new KcAdminClient(configs);
  return new AdminKeycloakClient(client, constants);
}

export class AdminKeycloakClient {
  private _client: KcAdminClient;
  private _constants: KeycloakConstants;

  constructor(client: KcAdminClient, constants: KeycloakConstants) {
    this._client = client;
    this._constants = constants;
  }

  async authenticateAsAdmin(): Promise<void> {
    const credentials: KeycloakCredentials = {
      grantType: 'client_credentials',
      clientId: this._constants.ADMIN_ID,
      clientSecret: this._constants.ADMIN_SECRET,
    };
    await this._client.auth(credentials);
  }

  async createGroupIfNotExists(groupName: string): Promise<string> {
    const groups: KeycloakGroupRepresentation[] =
      await this._client.groups.find({
        search: groupName,
        max: 1,
      });
    if (groups && groups[0]) {
      return groups[0].id as string;
    }

    const created: KeycloakGroupRepresentation =
      await this._client.groups.create({
        name: groupName,
      });
    return created.id as string;
  }

  async getClientIfExists(clientId?: string): Promise<string | null> {
    if (!clientId) {
      return null;
    }
    const clients: KeycloakClientRepresentation[] =
      await this._client.clients.find({ clientId, max: 1 });
    if (clients && clients[0]) {
      return clients[0].id as string;
    }
    return null;
  }
}
