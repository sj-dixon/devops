import { toMySqlDateTimeString } from '@alcumus/objection-lib';
import { addDays } from 'date-fns';

export default function getInvitationExpiration(): string {
  return toMySqlDateTimeString(addDays(new Date(), 7));
}
