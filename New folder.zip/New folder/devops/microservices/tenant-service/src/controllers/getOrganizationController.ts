import { Tenant } from '../models/tenant';
import { Response } from 'express';
import { OrganizationAuthProvider } from '../models/organizationAuthProvider';

export async function getOrganizationByIdentifier(
  response: Response,
  organizationIdentifier: string
): Promise<Tenant | null> {
  const organization = await Tenant.getOrganizationByIdentifier(
    organizationIdentifier
  );
  if (!organization) {
    response.status(404).json({
      message: `Could not find organization with identifier ${organizationIdentifier}.`,
    });
    return null;
  }
  return organization;
}

export async function getOrganizationById(
  response: Response,
  organizationId: number
): Promise<Tenant | null> {
  const organization = await Tenant.getOrganizationById(organizationId);
  if (!organization) {
    response.status(404).json({
      message: `Could not find organization with id ${organizationId}.`,
    });
    return null;
  }
  return organization;
}

export async function getOrganizationAuthProvider(
  response: Response,
  organization: Tenant,
  providerName: string
): Promise<OrganizationAuthProvider | null> {
  const authProvider =
    await OrganizationAuthProvider.findByOrganizationIdAndProviderName(
      providerName,
      organization.id
    );
  if (!authProvider) {
    const message =
      organization.tenantIdentifier === Tenant.getRootTenantIdentifer()
        ? `Could not find global auth provider ${providerName}.`
        : `Could not find auth provider for organization identified by ${organization.tenantIdentifier} and provider name ${providerName}.`;
    response.status(404).json({
      message,
    });
  }
  return authProvider;
}
