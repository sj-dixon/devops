import { Types } from '@alcumus/globals';
import { Response } from 'express';
import {
  getOrganizationAuthProvider,
  getOrganizationById,
  getOrganizationByIdentifier,
} from './getOrganizationController';
import { OrganizationAuthProviderType } from '../types';
import { Tenant } from '../models/tenant';

export async function handleOrganizationAuthProviderRetrieval(
  request: Types.Request,
  response: Response,
  organizationIdentifier?: string,
  organizationId?: number
): Promise<void> {
  const authProviderName = request.params.authProviderName;
  let organization: Tenant | null;

  if (organizationId) {
    organization = await getOrganizationById(response, organizationId);
  } else if (organizationIdentifier) {
    organization = await getOrganizationByIdentifier(
      response,
      organizationIdentifier
    );
  } else {
    throw new Error('This code path should be unreachable');
  }

  if (!organization) {
    return;
  }

  const authProvider = await getOrganizationAuthProvider(
    response,
    organization,
    authProviderName
  );

  if (authProvider) {
    response.json(authProvider);
  }
}

export async function handleGlobalAuthProviderRetrieval(
  request: Types.Request,
  response: Response
): Promise<void> {
  const authProviderName = request.params.authProviderName;

  if (authProviderName === OrganizationAuthProviderType.KEYCLOAK) {
    response.status(200).json(STUB_KEYCLOAK_PROVIDER);
    return;
  }
  if (authProviderName === OrganizationAuthProviderType.AZURE_AD) {
    response.status(200).json(STUB_AZURE_AD_PROVIDER);
    return;
  }

  // todo - separate global auth providers from the alcumus tenant.
  const rootOrganization = await Tenant.getRootTenant();

  const authProvider = await getOrganizationAuthProvider(
    response,
    rootOrganization,
    authProviderName
  );

  if (authProvider) {
    response.json(authProvider);
  }
}

export const STUB_KEYCLOAK_PROVIDER = {
  authProviderName: OrganizationAuthProviderType.KEYCLOAK,
  authProviderType: OrganizationAuthProviderType.KEYCLOAK,
  callbackUrl: null,
  apiTokenHeaderName: null,
  apiTokenHeaderValue: null,
  userNamePrefix: null,
};

export const STUB_AZURE_AD_PROVIDER = {
  authProviderName: OrganizationAuthProviderType.AZURE_AD,
  authProviderType: OrganizationAuthProviderType.AZURE_AD,
  callbackUrl: null,
  apiTokenHeaderName: null,
  apiTokenHeaderValue: null,
  userNamePrefix: null,
};
