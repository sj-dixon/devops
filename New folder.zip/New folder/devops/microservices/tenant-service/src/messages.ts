export const Messages = {
  ManagedGlobalAuthProviderRetrievalNotSupported:
    "We don't currently persist the global auth providers and therefore this method has nothing to return",
  CannotModifyManagedAuthProviders:
    'This endpoint forbids modifying and/or overloading auth providers for managed auth solutions.',
};
