import { runApp } from '@alcumus/express-app';
import app from './app';
import process from 'process';
import { TENANT_SERVICE_PORT } from './constants';
import getKnexClient from './lib/clients/knex';

const knexClient = getKnexClient();

runApp(app, {
  port: TENANT_SERVICE_PORT,
}).catch(async (reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
  await knexClient.destroy();
  process.exit(1);
});
