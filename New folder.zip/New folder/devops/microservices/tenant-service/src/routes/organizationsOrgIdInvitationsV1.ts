import express, { Router, Response } from 'express';
import { Types, Middlewares } from '@alcumus/globals';
import { Model, Transaction } from 'objection';
import { InvitationEntity } from '../models/invitation';
import { Invitation } from '../types';

function transformInvitation(invitation: InvitationEntity): Invitation {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { used, deleted, ...invitationDetails } = invitation;
  return {
    ...invitationDetails,
    isValid: InvitationEntity.isValid(invitation),
  };
}

const router: Router = express.Router({
  mergeParams: true,
});

router.get(
  '/',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    const { orgId } = req.params;
    const { offset, limit } = req.query;
    const invitations = await InvitationEntity.getInvitations(
      Number(orgId),
      Number(offset),
      Number(limit)
    );
    res.json(invitations.map(transformInvitation));
  }
);

router.post(
  '/',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    try {
      const { orgId } = req.params;
      const { email } = req.body;
      if (!email) {
        res.status(400).json({ message: 'Bad request' });
      } else {
        const record = await InvitationEntity.create(
          null,
          Number(orgId),
          email
        );
        res.json(transformInvitation(record));
      }
    } catch (err) {
      console.error('Failed to create invitation', err);
      res.status(500).json({ message: 'Failed to create invitation' });
    }
  }
);

router.post(
  '/batch',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    try {
      const { orgId } = req.params;
      const { emails } = req.body;
      if (!emails?.length) {
        res.status(400).json({ message: 'Bad request' });
      } else {
        await Model.transaction((trx: Transaction) =>
          InvitationEntity.createBatch(trx, Number(orgId), emails)
        );
        res.sendStatus(201);
      }
    } catch (err) {
      console.error('Batch invitation creation failed', err);
      res
        .status(500)
        .json({ message: 'Failed to process invitation batch request' });
    }
  }
);

router.get(
  '/:code',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    const { orgId, code } = req.params;
    const match = await InvitationEntity.find(Number(orgId), code);
    if (!match) {
      res.status(404).json({ message: 'Invitation not found' });
    } else {
      res.json(transformInvitation(match));
    }
  }
);

router.patch(
  '/:code',
  Middlewares.requireApiKeyHeader,
  async (req: Types.Request, res: Response) => {
    try {
      const { orgId, code } = req.params;
      const { bumpExpiration = false, markAsUsed = false } = req.body;
      if (!bumpExpiration && !markAsUsed) {
        res.status(400).json('Bad request');
      } else {
        const match = await InvitationEntity.find(Number(orgId), code);
        if (!match) {
          res.status(404).json({ message: 'Invitation not found' });
        } else {
          await InvitationEntity.update(
            null,
            Number(orgId),
            code,
            bumpExpiration,
            markAsUsed
          );
          const record = await InvitationEntity.find(Number(orgId), code);
          res.status(200).json(transformInvitation(record));
        }
      }
    } catch (err) {
      console.error('Failed to update invitation record', err);
      res.status(500).json({ message: 'Failed to update invitation record' });
    }
  }
);

router.delete('/:code', async (req: Types.Request, res: Response) => {
  const { orgId: organizationId, code: inviteCode } = req.params;
  await InvitationEntity.delete(Number(organizationId), inviteCode);
  res.sendStatus(204);
});

export default router;
