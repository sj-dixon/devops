import express, { Response, Router } from 'express';
import { Tenant } from '../models/tenant';
import { Middlewares, Types } from '@alcumus/globals';
import { CreateOrganizationRequest, TenantTypeCode } from '../types';
import {
  provisionTenant,
  provisionTenantAuthProviders,
} from '../provisioning/provisionTenant';
import { getAdminKeycloakClient } from '../lib/clients/keycloak';
import { createRootUser } from '../provisioning/createRootUser';
import { Transaction, Model } from 'objection';
import organizationsOrgInvitationsRouterV1 from './organizationsOrgIdInvitationsV1';
import {
  requireEmailIfCreatingAccount,
  requireFirstNameIfCreatingAccount,
  requireLastNameIfCreatingAccount,
  requirePasswordIfCreatingAccount,
} from '../middleware/requireRootFieldsWhenCreatingAccount';
import { validationHandler } from '@alcumus/express-app';
import { InvitationEntity } from '../models/invitation';
import {
  requireTenantIdentifier,
  requireTenantName,
} from '../middleware/requireTenantFields';
import { authProvidersV1 } from './organizationsOrgIdAuthProvidersV1';
import { requireApiKeyHeader } from '@alcumus/globals/build/middlewares';

const organizationRouterV1: Router = express.Router();

organizationRouterV1.post(
  '/',
  requireApiKeyHeader,
  requireTenantIdentifier,
  requireTenantName,
  requireFirstNameIfCreatingAccount,
  requireLastNameIfCreatingAccount,
  requireEmailIfCreatingAccount,
  requirePasswordIfCreatingAccount,
  validationHandler(),
  async (request: Types.Request, response: Response) => {
    const requestBody = request.body as CreateOrganizationRequest;

    const adminClient = getAdminKeycloakClient();

    const result = await Model.transaction(async (transaction: Transaction) => {
      const organization: Tenant = await provisionTenant(
        transaction,
        requestBody
      );
      await provisionTenantAuthProviders(
        transaction,
        adminClient,
        requestBody.tenantIdentifier,
        organization.id
      );

      let rootUserId: number | null = null;
      if (requestBody.createAccount) {
        await InvitationEntity.create(
          transaction,
          organization.id,
          requestBody.rootEmail as string
        );
        const rootUser = await createRootUser(request, organization.id);
        rootUserId = rootUser.data.id;
      }

      return {
        ...organization,
        userId: rootUserId,
      };
    });

    response.status(201).json(result);
  }
);

organizationRouterV1.get(
  '/',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const rootOrganization = await Tenant.getRootTenant();
    const organizations = await Tenant.query().where({
      parentTenantId: rootOrganization.id,
      tenantTypeCode: TenantTypeCode.ORGANIZATION,
      deletedAt: null,
    });
    response.json(organizations);
  }
);

organizationRouterV1.get(
  '/:organizationId',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationId = parseInt(request.params.organizationId);
    const result = await Tenant.query().findById(organizationId);
    if (result) {
      response.json(result);
    } else {
      response.sendStatus(404);
    }
  }
);

organizationRouterV1.use(
  '/:orgId/invitations',
  organizationsOrgInvitationsRouterV1
);

organizationRouterV1.use('/:organizationId/authProviders', authProvidersV1);

export default organizationRouterV1;
