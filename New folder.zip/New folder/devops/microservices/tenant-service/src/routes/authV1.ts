import express, { Response } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import { OrganizationAuthProvider } from '../models/organizationAuthProvider';
import {
  getOrganizationAuthProvider,
  getOrganizationByIdentifier,
} from '../controllers/getOrganizationController';

const authRouterV1 = express.Router();

authRouterV1.get(
  '/:organizationIdentifier',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationIdentifier = request.params.organizationIdentifier;

    const organization = await getOrganizationByIdentifier(
      response,
      organizationIdentifier
    );
    if (organization) {
      response.json(organization);
    }
  }
);

authRouterV1.get(
  '/:organizationIdentifier/authProviders',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationIdentifier = request.params.organizationIdentifier;

    const organization = await getOrganizationByIdentifier(
      response,
      organizationIdentifier
    );
    if (organization) {
      const authProviders = await OrganizationAuthProvider.findByOrganizationId(
        organization.id
      );
      response.json(authProviders);
    }
  }
);

authRouterV1.get(
  '/:organizationIdentifier/authProviders/:providerName',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationIdentifier = request.params.organizationIdentifier;
    const providerName = request.params.providerName;

    const organization = await getOrganizationByIdentifier(
      response,
      organizationIdentifier
    );
    if (!organization) {
      return;
    }

    const authProvider = await getOrganizationAuthProvider(
      response,
      organization,
      providerName
    );
    if (authProvider) {
      response.json(authProvider);
    }
  }
);

export { authRouterV1 };
