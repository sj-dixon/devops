import express, { Response } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import {
  handleGlobalAuthProviderRetrieval,
  handleOrganizationAuthProviderRetrieval,
} from '../controllers/authProviderController';
import { preventManagedAuthProviderChanges } from '../middleware/preventManagedAuthProviderChanges';
import {
  requireApiTokenHeaderName,
  requireApiTokenHeaderValue,
  requireAuthProviderName,
  requireCallbackUrl,
} from '../middleware/requireCustomApiProviderFields';
import { validationHandler } from '@alcumus/express-app';
import { OrganizationAuthProvider } from '../models/organizationAuthProvider';
import { Tenant } from '../models/tenant';
import { CreateCustomApiAuthProviderRequest } from '../types';
import { getOrganizationById } from '../controllers/getOrganizationController';

const authProvidersV1 = express.Router();

authProvidersV1.post(
  '/',
  Middlewares.requireApiKeyHeader,
  preventManagedAuthProviderChanges,
  requireCallbackUrl,
  requireApiTokenHeaderValue,
  requireApiTokenHeaderName,
  requireAuthProviderName,
  validationHandler(),
  async (request: Types.Request, response: Response) => {
    const providerRequest: CreateCustomApiAuthProviderRequest = request.body;
    const organization = await Tenant.getRootTenant();
    const organizationId = organization.id;

    const existingAuthProvider =
      await OrganizationAuthProvider.findByOrganizationIdAndProviderName(
        providerRequest.authProviderName,
        organizationId
      );
    if (existingAuthProvider) {
      return response
        .status(409)
        .json({ message: 'Already have auth provider by that name' });
    }

    const result = await OrganizationAuthProvider.createCustomAuthProvider(
      organizationId,
      providerRequest
    );

    response.status(201).json(result);
  }
);

authProvidersV1.put(
  '/:providerName',
  Middlewares.requireApiKeyHeader,
  requireAuthProviderName,
  requireCallbackUrl,
  requireApiTokenHeaderName,
  requireApiTokenHeaderValue,
  validationHandler(),
  preventManagedAuthProviderChanges,
  async (request: Types.Request, response: Response) => {
    let organizationId = Number(request.query.organizationId);
    if (!organizationId) {
      const organization = await Tenant.getRootTenant();
      organizationId = organization.id;
    } else {
      const organization = await getOrganizationById(response, organizationId);
      if (!organization) {
        return;
      }
    }

    const providerRequest: CreateCustomApiAuthProviderRequest = request.body;
    const result = await OrganizationAuthProvider.upsertCustomAuthProvider(
      organizationId,
      request.params.providerName,
      providerRequest
    );
    response.status(200).json(result);
  }
);

authProvidersV1.get(
  '/:authProviderName',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationIdentifier = request.query.organizationIdentifier as
      | string
      | undefined;
    const organizationId = Number(request.query.organizationId);

    if (organizationIdentifier || organizationId) {
      await handleOrganizationAuthProviderRetrieval(
        request,
        response,
        organizationIdentifier,
        organizationId
      );
      return;
    }

    await handleGlobalAuthProviderRetrieval(request, response);
  }
);

export { authProvidersV1 };
