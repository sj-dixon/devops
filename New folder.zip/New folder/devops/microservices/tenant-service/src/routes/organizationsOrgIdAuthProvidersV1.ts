import express, { Response, Router } from 'express';
import { Types, Middlewares } from '@alcumus/globals';
import {
  getOrganizationAuthProvider,
  getOrganizationById,
} from '../controllers/getOrganizationController';
import { OrganizationAuthProvider } from '../models/organizationAuthProvider';
import { preventManagedAuthProviderChanges } from '../middleware/preventManagedAuthProviderChanges';
import { validationHandler } from '@alcumus/express-app';
import {
  requireApiTokenHeaderName,
  requireApiTokenHeaderValue,
  requireCallbackUrl,
  requireAuthProviderName,
} from '../middleware/requireCustomApiProviderFields';
import { CreateCustomApiAuthProviderRequest } from '../types';

const authProvidersV1: Router = express.Router({ mergeParams: true });

authProvidersV1.get(
  '/',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationId = parseInt(request.params.organizationId);
    const organization = await getOrganizationById(response, organizationId);
    if (!organization) {
      return;
    }

    const result = await OrganizationAuthProvider.findByOrganizationId(
      organizationId
    );
    if (result) {
      response.json(result);
    }
  }
);

authProvidersV1.get(
  '/:providerName',
  Middlewares.requireApiKeyHeader,
  async (request: Types.Request, response: Response) => {
    const organizationId = parseInt(request.params.organizationId);
    const organization = await getOrganizationById(response, organizationId);
    if (!organization) {
      return;
    }

    const providerName = request.params.providerName;
    const result = await getOrganizationAuthProvider(
      response,
      organization,
      providerName
    );
    if (result) {
      response.json(result);
    }
  }
);

authProvidersV1.post(
  '/',
  Middlewares.requireApiKeyHeader,
  requireAuthProviderName,
  requireCallbackUrl,
  requireApiTokenHeaderName,
  requireApiTokenHeaderValue,
  validationHandler(),
  preventManagedAuthProviderChanges,
  async (request: Types.Request, response: Response) => {
    const organizationId = Number(request.params.organizationId);
    const providerRequest: CreateCustomApiAuthProviderRequest = request.body;
    const organization = await getOrganizationById(response, organizationId);
    if (!organization) {
      return;
    }
    const existingAuthProvider =
      await OrganizationAuthProvider.findByOrganizationIdAndProviderName(
        providerRequest.authProviderName,
        organizationId
      );
    if (existingAuthProvider) {
      return response
        .status(409)
        .json({ message: 'Already have auth provider by that name' });
    }

    const result = await OrganizationAuthProvider.createCustomAuthProvider(
      organizationId,
      providerRequest
    );
    response.status(201).json(result);
  }
);

authProvidersV1.put(
  '/:providerName',
  Middlewares.requireApiKeyHeader,
  requireAuthProviderName,
  requireCallbackUrl,
  requireApiTokenHeaderName,
  requireApiTokenHeaderValue,
  validationHandler(),
  preventManagedAuthProviderChanges,
  async (request: Types.Request, response: Response) => {
    const organizationId = Number(request.params.organizationId);
    const organization = await getOrganizationById(response, organizationId);
    const providerRequest: CreateCustomApiAuthProviderRequest = request.body;
    if (!organization) {
      return;
    }

    const result = await OrganizationAuthProvider.upsertCustomAuthProvider(
      organizationId,
      request.params.providerName,
      providerRequest
    );
    response.status(200).json(result);
  }
);

export { authProvidersV1 };
