import KeycloakUserRepresentation from 'keycloak-admin/lib/defs/userRepresentation';
import { Credentials } from 'keycloak-admin/lib/utils/auth';
import KeycloakGroupRepresentation from 'keycloak-admin/lib/defs/groupRepresentation';
import KeycloakClientRepresentation from 'keycloak-admin/lib/defs/clientRepresentation';

export {
  KeycloakUserRepresentation,
  Credentials as KeycloakCredentials,
  KeycloakGroupRepresentation,
  KeycloakClientRepresentation,
};

export interface KeycloakConstants {
  URL: string;
  REALM: string;
  CLIENT_ID: string;
  ADMIN_ID: string;
  CLIENT_SECRET: string;
  ADMIN_SECRET: string;
}

export enum OrganizationAuthProviderType {
  KEYCLOAK = 'KEYCLOAK', // keycloak credential store - temporary measure
  AZURE_AD = 'AZURE_AD', // azure ad credential store - accounts are managed as local to our tenant
  EXTERNAL = 'EXTERNAL', // azure ad credential store - but organization has their own tenant
  API = 'API', // this provider has a callback url that we can use to validate credentials
}

export enum TenantTypeCode {
  ADMIN_ORGANIZATION = 'ADMIN_ORGANIZATION',
  ORGANIZATION = 'ORGANIZATION',
}

export type TenantSpecifier = {
  tenantIdentifier: string;
  tenantName: string;
};

export interface CreateOrganizationRequest {
  tenantIdentifier: string;
  tenantName: string;

  rootEmail?: string;
  rootUsername?: string;
  rootPassword?: string;
  rootFirstName?: string;
  rootLastName?: string;
  createAccount: boolean;
}

export interface CreateCustomApiAuthProviderRequest {
  authProviderName: string;
  callbackUrl: string;
  apiTokenHeaderName: string;
  apiTokenHeaderValue: string;
  authProviderType?: OrganizationAuthProviderType;
}

export interface Invitation {
  id?: number;
  inviteCode: string;
  email: string;
  organizationId: number;
  expiresAt: string;
  isValid: boolean;
}
