import path from 'path';
import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import organizationRouterV1 from './routes/organizationV1';
import { authRouterV1 } from './routes/authV1';
import { authProvidersV1 } from './routes/authProvidersV1';

const apiSpec = 'api-spec.yaml';

const tenantServiceApp = configureApp({
  serviceName: 'Tenant Service',
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
    validateResponse: true,
  },
  setup: (app) => {
    app.use(ENDPOINTS.ORGANIZATIONS, organizationRouterV1);
    app.use(ENDPOINTS.AUTH, authRouterV1);
    app.use(ENDPOINTS.AUTH_PROVIDERS, authProvidersV1);
  },
});

export default tenantServiceApp;
