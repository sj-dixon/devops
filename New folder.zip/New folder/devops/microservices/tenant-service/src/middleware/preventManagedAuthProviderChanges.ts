import { Response, NextFunction } from 'express';
import { Types } from '@alcumus/globals';
import { OrganizationAuthProviderType } from '../types';
import { Messages } from '../messages';

export async function preventManagedAuthProviderChanges(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  if (
    isProviderNameIllegal(request.params.providerName) ||
    isProviderNameIllegal(request.body.authProviderName)
  ) {
    response.status(403).json({
      message: Messages.CannotModifyManagedAuthProviders,
    });
  } else {
    next();
  }
}

function isProviderNameIllegal(providerName?: string): boolean {
  return (
    providerName === OrganizationAuthProviderType.KEYCLOAK ||
    providerName === OrganizationAuthProviderType.AZURE_AD
  );
}
