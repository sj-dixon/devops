import { expressValidator } from '@alcumus/express-app';

export const requireTenantIdentifier = expressValidator
  .body('tenantIdentifier', 'organization.post.tenantIdentifierRequired')
  .trim()
  .escape()
  .not()
  .isEmpty();

export const requireTenantName = expressValidator
  .body('tenantName', 'organization.post.tenantNameRequired')
  .trim()
  .escape()
  .not()
  .isEmpty();
