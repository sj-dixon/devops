import { expressValidator } from '@alcumus/express-app';

const isCreatingAccount: expressValidator.CustomValidator = (value, { req }) =>
  req.body.createAccount;

export const requireFirstNameIfCreatingAccount = expressValidator
  .body('rootFirstName', 'organization.post.firstNameRequiredIfCreatingAccount')
  .if(isCreatingAccount)
  .trim()
  .escape()
  .not()
  .isEmpty();

export const requireLastNameIfCreatingAccount = expressValidator
  .body('rootLastName', 'organization.post.lastNameRequiredIfCreatingAccount')
  .if(isCreatingAccount)
  .trim()
  .escape()
  .not()
  .isEmpty();

export const requireEmailIfCreatingAccount = expressValidator
  .body('rootEmail', 'organization.post.emailRequiredIfCreatingAccount')
  .if(isCreatingAccount)
  .trim()
  .escape()
  .isEmail()
  .not()
  .isEmpty();

export const requirePasswordIfCreatingAccount = expressValidator
  .body('rootPassword', 'organization.post.passwordRequiredIfCreatingAccount')
  .if(isCreatingAccount)
  .trim()
  .escape()
  .not()
  .isEmpty();
