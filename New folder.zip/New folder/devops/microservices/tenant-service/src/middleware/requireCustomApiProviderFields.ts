import { expressValidator } from '@alcumus/express-app';

const isCreatingApiProvider: expressValidator.CustomValidator = (
  value,
  { req }
) => !req.body.authProviderType || req.body.authProviderType === 'API';

export const requireAuthProviderName = expressValidator
  .body(
    'authProviderName',
    'organization.authProvider.put.requireAuthProviderName'
  )
  .trim()
  .escape()
  .not()
  .isEmpty();

export const requireCallbackUrl = expressValidator
  .body('callbackUrl', 'organization.authProvider.put.requireCallbackUrl')
  .if(isCreatingApiProvider)
  .trim()
  .not()
  .isEmpty();

export const requireApiTokenHeaderName = expressValidator
  .body(
    'apiTokenHeaderName',
    'organization.authProvider.put.requireApiTokenHeaderName'
  )
  .if(isCreatingApiProvider)
  .not()
  .isEmpty();

export const requireApiTokenHeaderValue = expressValidator
  .body(
    'apiTokenHeaderValue',
    'organization.authProvider.put.requireApiTokenHeaderValue'
  )
  .if(isCreatingApiProvider)
  .not()
  .isEmpty();
