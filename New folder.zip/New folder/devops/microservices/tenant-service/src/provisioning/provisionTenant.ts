import { OrganizationAuthProvider } from '../models/organizationAuthProvider';
import { OrganizationAuthProviderType, TenantSpecifier } from '../types';
import { Tenant } from '../models/tenant';
import { AdminKeycloakClient } from '../lib/clients/keycloak';
import { Transaction } from 'objection';

export async function provisionTenant(
  transaction: Transaction,
  request: TenantSpecifier
): Promise<Tenant> {
  const rootTenant = await Tenant.getRootTenant();
  return Tenant.createOrganization(request, rootTenant.id, transaction);
}

export async function provisionTenantAuthProviders(
  transaction: Transaction,
  authenticatedAdminClient: AdminKeycloakClient,
  tenantIdentifier: string,
  organizationId: number
): Promise<void> {
  const usernamePrefix = getOrganizationUserNamePrefix(organizationId);

  await Promise.all([
    OrganizationAuthProvider.createManagedAuthProvider(
      organizationId,
      usernamePrefix,
      OrganizationAuthProviderType.KEYCLOAK,
      transaction
    ),
    OrganizationAuthProvider.createManagedAuthProvider(
      organizationId,
      usernamePrefix,
      OrganizationAuthProviderType.AZURE_AD,
      transaction
    ),
  ]);
}

export function getOrganizationUserNamePrefix(organizationId: number) {
  return `Org${organizationId}_`;
}
