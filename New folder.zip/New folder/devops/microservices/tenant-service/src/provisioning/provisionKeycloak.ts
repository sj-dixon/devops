import { AdminKeycloakClient } from '../lib/clients/keycloak';

export async function provisionKeycloakClients(
  adminClient: AdminKeycloakClient,
  fieldIdEntityId?: string,
  ecomplianceEntityId?: string
): Promise<(string | null)[]> {
  return Promise.all([
    adminClient.getClientIfExists(fieldIdEntityId),
    adminClient.getClientIfExists(ecomplianceEntityId),
  ]);
}
