import { CreateOrganizationRequest } from '../types';
import { Types } from '@alcumus/globals';
import {
  postEntity,
  ServiceMeshRequestResult,
} from '@alcumus/service-mesh-plugin';

interface UserAccountRequest {
  firstName: string;
  lastName: string;
  username: string;
  password: string;
  email: string;
  createAccount: boolean;
}

interface UserAccountResponse {
  id: number;
  firstName: string;
  lastName: string;
}

export async function createRootUser(
  request: Types.Request,
  // eslint-disable-next-line
  organizationId: number
): Promise<ServiceMeshRequestResult<UserAccountResponse>> {
  const createRequest = request.body as CreateOrganizationRequest;
  const data: UserAccountRequest = {
    firstName: createRequest.rootFirstName as string,
    lastName: createRequest.rootLastName as string,
    createAccount: true,
    email: createRequest.rootEmail as string,
    password: createRequest.rootPassword as string,
    username: (createRequest.rootUsername || createRequest.rootEmail) as string,
  };
  // todo root user should be added to organization
  return await postEntity<UserAccountRequest, UserAccountResponse>(data, {
    endpoint: Types.ServiceEndpoints.USERS,
    routePath: '/v1/users',
  });
}
