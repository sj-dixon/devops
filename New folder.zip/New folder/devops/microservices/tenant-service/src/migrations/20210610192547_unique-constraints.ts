import { Knex } from 'knex';

const TENANTS_TABLE = 'tenants';

export async function up(knex: Knex): Promise<void> {
  knex.schema.alterTable(TENANTS_TABLE, (tableBuilder) => {
    tableBuilder.unique(['tenant_identifier']);
    tableBuilder.unique(['tenant_name']);
  });
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  if (await knex.schema.hasTable(TENANTS_TABLE)) {
    knex.schema.alterTable(TENANTS_TABLE, (tableBuilder) => {
      tableBuilder.dropUnique(['tenant_identifier']);
      tableBuilder.dropUnique(['tenant_name']);
    });
  }
}
