import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.renameTable(
    'tenant_auth_provider',
    'organization_auth_provider'
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.renameTable(
    'organization_auth_provider',
    'tenant_auth_provider'
  );
}
