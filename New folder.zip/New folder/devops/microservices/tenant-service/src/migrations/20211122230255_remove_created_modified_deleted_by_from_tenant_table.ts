import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable('tenants', (builder: Knex.AlterTableBuilder) => {
    builder.dropColumn('created_by');
    builder.dropColumn('modified_by');
    builder.dropColumn('deleted_by');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable('tenants', (builder: Knex.AlterTableBuilder) => {
    builder.integer('created_by').nullable().defaultTo(null).unsigned();
    builder.integer('modified_by').nullable().defaultTo(null).unsigned();
    builder.integer('deleted_by').nullable().defaultTo(null).unsigned();
  });
}
