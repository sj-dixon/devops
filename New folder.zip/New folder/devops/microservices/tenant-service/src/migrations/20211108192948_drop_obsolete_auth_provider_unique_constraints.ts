import { Knex } from 'knex';

const TABLE_NAME = 'organization_auth_providers';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // we have to drop the foreign constraint in order to remove the unique constraint
      tableBuilder.dropForeign(
        ['organization_id'],
        'FK_tenant_auth_provider_organization_id'
      );
      tableBuilder.dropUnique(
        ['organization_id'],
        'tenant_auth_provider_organization_id_unique'
      );
      tableBuilder.dropUnique(
        ['user_name_prefix'],
        'tenant_auth_provider_keycloak_user_name_prefix_unique'
      );

      tableBuilder
        .foreign('organization_id', 'FK_tenant_auth_provider_organization_id')
        .references('id')
        .inTable('tenants')
        .onDelete('CASCADE');

      tableBuilder.unique(
        ['user_name_prefix', 'auth_provider_name'],
        'FK_org_auth_provider_prefix_name_unique'
      );
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropForeign(
        ['organization_id'],
        'FK_tenant_auth_provider_organization_id'
      );

      tableBuilder.dropUnique(
        ['user_name_prefix', 'auth_provider_name'],
        'FK_org_auth_provider_prefix_name_unique'
      );

      tableBuilder.unique(
        ['organization_id'],
        'FK_tenant_auth_provider_organization_id'
      );
      tableBuilder.unique(
        ['organization_id'],
        'tenant_auth_provider_organization_id_unique'
      );
      tableBuilder.unique(
        ['user_name_prefix'],
        'tenant_auth_provider_keycloak_user_name_prefix_unique'
      );

      tableBuilder
        .foreign('organization_id', 'FK_tenant_auth_provider_organization_id')
        .references('id')
        .inTable('tenants')
        .onDelete('CASCADE');
    }
  );
}
