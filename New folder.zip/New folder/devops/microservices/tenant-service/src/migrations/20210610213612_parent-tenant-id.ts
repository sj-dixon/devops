import { Knex } from 'knex';

const TENANT_TABLE = 'tenants';
export async function up(knex: Knex): Promise<void> {
  knex.schema.alterTable(TENANT_TABLE, (tableBuilder) => {
    tableBuilder
      .foreign('parent_tenant_id', 'FK_parent_tenant_id')
      .references('id')
      .inTable(TENANT_TABLE)
      .onDelete('CASCADE');
  });
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  if (await knex.schema.hasTable(TENANT_TABLE)) {
    knex.schema.alterTable(TENANT_TABLE, (tableBuilder) => {
      tableBuilder.dropForeign('parent_tenant_id', 'FK_parent_tenant_id');
    });
  }
}
