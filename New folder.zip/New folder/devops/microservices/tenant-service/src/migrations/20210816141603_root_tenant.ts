import { Knex } from 'knex';
import { TenantTypeCode } from '../types';
import { Utilities } from '@alcumus/globals';

export async function up(knex: Knex): Promise<void> {
  const adminTenantIdentifier = Utilities.ProcessEnv.getValueOrDefault(
    'TENANT_SERVICE_ROOT_TENANT_IDENTIFIER',
    'alcumus'
  );

  // clear any seeded tenants (for development environments)
  await knex('tenants')
    .where({
      tenantTypeCode: TenantTypeCode.ADMIN_ORGANIZATION,
      tenantIdentifier: adminTenantIdentifier,
    })
    .delete();
  await knex('tenants').insert({
    tenantName: 'Alcumus Inc',
    tenantTypeCode: TenantTypeCode.ADMIN_ORGANIZATION,
    tenantIdentifier: adminTenantIdentifier,
  });
}

export async function down(knex: Knex): Promise<void> {
  const adminTenantIdentifier = Utilities.ProcessEnv.getValueOrDefault(
    'TENANT_SERVICE_ROOT_TENANT_IDENTIFIER',
    'alcumus'
  );
  await knex('users')
    .where({
      tenantTypeCode: TenantTypeCode.ADMIN_ORGANIZATION,
      tenantIdentifier: adminTenantIdentifier,
    })
    .delete();
}
