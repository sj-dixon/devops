import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.renameTable(
    'organization_auth_provider',
    'organization_auth_providers'
  );
  await knex.schema.alterTable(
    'organization_auth_providers',
    (table: Knex.CreateTableBuilder) => {
      table.dropColumn('keycloak_tenant_group_id');
      table.dropColumn('keycloak_field_id_group_id');
      table.dropColumn('keycloak_field_id_sso_client_id');
      table.dropColumn('keycloak_ecompliance_group_id');
      table.dropColumn('keycloak_ecompliance_sso_client_id');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.renameTable(
    'organization_auth_providers',
    'organization_auth_provider'
  );
  await knex.schema.alterTable(
    'organization_auth_providers',
    (table: Knex.CreateTableBuilder) => {
      table.string('keycloak_tenant_group_id', 255).unique().defaultTo(null);
      table.string('keycloak_field_id_group_id', 255).unique().defaultTo(null);
      table
        .string('keycloak_field_id_sso_client_id', 255)
        .unique()
        .defaultTo(null);
      table
        .string('keycloak_ecompliance_group_id', 255)
        .unique()
        .defaultTo(null);
      table
        .string('keycloak_ecompliance_sso_client_id', 255)
        .unique()
        .defaultTo(null);
    }
  );
}
