import { Knex } from 'knex';

const TENANTS_TABLE = 'tenants';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(TENANTS_TABLE);
  await knex.schema.createTable(TENANTS_TABLE, (tableBuilder) => {
    tableBuilder.uuid('id').primary();
    tableBuilder.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
    tableBuilder
      .timestamp('modified_at')
      .notNullable()
      .defaultTo(knex.fn.now());
    tableBuilder.string('created_by').notNullable();
    tableBuilder.string('modified_by').notNullable();

    // soft deletion
    tableBuilder.boolean('is_deleted').notNullable().defaultTo(false);
    tableBuilder.timestamp('deleted_at').nullable();
    tableBuilder.string('deleted_by').nullable();

    // entity specific columns
    tableBuilder
      .uuid('parent_tenant_id')
      .references('id')
      .inTable(TENANTS_TABLE);

    tableBuilder.string('tenant_type_code').notNullable();
    tableBuilder.string('tenant_name').notNullable();
    tableBuilder.string('tenant_identifier').unique().notNullable();
  });
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  if (await knex.schema.hasTable(TENANTS_TABLE)) {
    await knex.schema.dropTableIfExists(TENANTS_TABLE);
  }
}
