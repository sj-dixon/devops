import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'organization_auth_providers',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.string('callback_url', 150);
      tableBuilder.string('api_token_header_name', 50);
      tableBuilder.string('api_token_header_value', 50);
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'organization_auth_providers',
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('callback_url');
      tableBuilder.dropColumn('api_token_header_name');
      tableBuilder.dropColumn('api_token_header_value');
    }
  );
}
