import { Knex } from 'knex';

const TABLE_NAME = 'organization_auth_providers';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.renameColumn(
        'keycloak_user_name_prefix',
        'user_name_prefix'
      );
      tableBuilder
        .string('auth_provider_name', 50)
        .notNullable()
        .defaultTo('KEYCLOAK');
      tableBuilder.unique(
        ['auth_provider_name', 'organization_id'],
        'UK_org_id_auth_provider_name'
      );
      tableBuilder.dropColumn('auth_provider_type');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.renameColumn(
        'user_name_prefix',
        'keycloak_user_name_prefix'
      );
      tableBuilder.dropUnique(
        ['auth_provider_name', 'organization_id'],
        'UK_org_id_auth_provider_name'
      );
      tableBuilder.dropColumn('auth_provider_name');

      tableBuilder
        .enum('auth_provider_type', ['KEYCLOAK', 'EXTERNAL'])
        .notNullable()
        .defaultTo('KEYCLOAK');
    }
  );
}
