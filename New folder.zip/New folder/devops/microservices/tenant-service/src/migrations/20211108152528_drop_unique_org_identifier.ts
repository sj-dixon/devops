import { Knex } from 'knex';

const TABLE_NAME = 'organization_auth_providers';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('organization_identifier');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      // don't add not-null and unique constraints back because after this point we are no longer guaranteed
      // to have a unique organization identifier per auth provider.
      tableBuilder.string('organization_identifier', 50).nullable();
    }
  );
}
