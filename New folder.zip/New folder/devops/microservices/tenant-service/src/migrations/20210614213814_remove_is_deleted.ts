import { Knex } from 'knex';

const TENANTS_TABLE = 'tenants';
export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TENANTS_TABLE,
    (tableBuilder: Knex.TableBuilder) => {
      tableBuilder.dropColumn('is_deleted');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TENANTS_TABLE,
    (tableBuilder: Knex.TableBuilder) => {
      tableBuilder.boolean('is_deleted');
    }
  );
  await knex.raw(
    `UPDATE ${TENANTS_TABLE} SET is_deleted = (deleted_at is not null)`
  );
}
