import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'tenant_auth_provider',
    (alterTableBuilder: Knex.AlterTableBuilder) => {
      alterTableBuilder.renameColumn(
        'keycloak_e_compliance_group_id',
        'keycloak_ecompliance_group_id'
      );
      alterTableBuilder.renameColumn(
        'keycloak_e_compliance_sso_client_id',
        'keycloak_ecompliance_sso_client_id'
      );
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    'tenant_auth_provider',
    (alterTableBuilder: Knex.AlterTableBuilder) => {
      alterTableBuilder.renameColumn(
        'keycloak_ecompliance_group_id',
        'keycloak_e_compliance_group_id'
      );
      alterTableBuilder.renameColumn(
        'keycloak_ecompliance_sso_client_id',
        'keycloak_e_compliance_sso_client_id'
      );
    }
  );
}
