import { Knex } from 'knex';

const TABLE_NAME = 'invitations';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (t: Knex.CreateTableBuilder) => {
    t.boolean('used').defaultTo(false);
    t.boolean('deleted').defaultTo(false);
    t.dropColumn('created_by');
    t.dropColumn('created_at');
    t.dropColumn('modified_by');
    t.dropColumn('modified_at');
    t.dropColumn('deleted_by');
    t.dropColumn('deleted_at');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(TABLE_NAME, (t: Knex.CreateTableBuilder) => {
    t.dropColumn('used');
    t.dropColumn('deleted');
    // metadata
    t.integer('created_by').nullable().unsigned();
    t.integer('modified_by').nullable().unsigned();
    t.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
    t.timestamp('modified_at').notNullable().defaultTo(knex.fn.now());

    // soft deletion
    t.timestamp('deleted_at').nullable();
    t.integer('deleted_by').nullable().unsigned();
  });
}
