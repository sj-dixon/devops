import { Knex } from 'knex';

const TABLE_NAME = 'tenant_auth_provider';

export async function up(knex: Knex): Promise<void> {
  // noinspection DuplicatedCode
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.increments('id').primary();

      // metadata
      tableBuilder.integer('created_by').nullable().unsigned();
      tableBuilder.integer('modified_by').nullable().unsigned();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      // soft deletion
      tableBuilder.timestamp('deleted_at').nullable();
      tableBuilder.integer('deleted_by').nullable().unsigned();

      // foreign key to parent table
      tableBuilder.integer('organization_id').unsigned().notNullable().unique();
      tableBuilder
        .foreign('organization_id', 'FK_tenant_auth_provider_organization_id')
        .references('id')
        .inTable('tenants')
        .onDelete('CASCADE');

      // main properties
      tableBuilder.enum('auth_provider_type', ['KEYCLOAK', 'EXTERNAL']);
      tableBuilder.string('organization_identifier').notNullable().unique();
      tableBuilder.string('keycloak_user_name_prefix').nullable().unique();
      tableBuilder.string('keycloak_tenant_group_id').nullable().unique();
      tableBuilder.string('keycloak_field_id_group_id').nullable();
      tableBuilder
        .string('keycloak_field_id_sso_client_id')
        .nullable()
        .unique();
      tableBuilder.string('keycloak_e_compliance_group_id').nullable();
      tableBuilder
        .string('keycloak_e_compliance_sso_client_id')
        .nullable()
        .unique();
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  knex.schema.dropTable(TABLE_NAME);
}
