import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  const tableNameAndColumns = knex.raw('?? (??, ??, ??, ??) ', [
    'organization_auth_providers',
    'organization_id',
    'user_name_prefix',
    'auth_provider_name',
    'auth_provider_type',
  ]);

  await knex
    .from(tableNameAndColumns)
    .insert(function (this: Knex.QueryBuilder) {
      this.from('organization_auth_providers').select(
        'organization_id',
        'user_name_prefix',
        knex.raw('? as ??', ['AZURE_AD', 'auth_provider_name']),
        knex.raw('? as ??', ['AZURE_AD', 'auth_provider_type'])
      );
    });
}

export async function down(knex: Knex): Promise<void> {
  await knex
    .from('organization_auth_providers')
    .where({
      authProviderType: 'AZURE_AD',
    })
    .del();
}
