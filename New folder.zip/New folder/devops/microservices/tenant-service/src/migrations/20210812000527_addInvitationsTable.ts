import { Knex } from 'knex';

const TABLE_NAME = 'invitations';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    TABLE_NAME,
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.increments('id').primary();
      tableBuilder.string('invite_code', 36).notNullable().unique();
      tableBuilder.integer('organization_id').nullable().unsigned();
      // We want to allow same user to be sent an email for multiple organizations
      tableBuilder.string('email', 50).notNullable();
      tableBuilder.dateTime('expires_at').notNullable();

      // metadata
      tableBuilder.integer('created_by').nullable().unsigned();
      tableBuilder.integer('modified_by').nullable().unsigned();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      // soft deletion
      tableBuilder.timestamp('deleted_at').nullable();
      tableBuilder.integer('deleted_by').nullable().unsigned();

      // A user can be sent invitation for once. If invitation needs to be resent, we would bump the expiration.
      tableBuilder.unique(
        ['organization_id', 'email'],
        'UK_invitations_organization_id_email'
      );

      tableBuilder
        .foreign('organization_id', 'FK_invitations_organization_id')
        .references('id')
        .inTable('tenants')
        .onDelete('CASCADE');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable(TABLE_NAME);
}
