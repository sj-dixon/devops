import { Knex } from 'knex';

const TENANTS_TABLE = 'tenants';
export async function up(knex: Knex): Promise<void> {
  await knex.schema.dropTable(TENANTS_TABLE);

  await knex.schema.createTable(TENANTS_TABLE, (tableBuilder) => {
    tableBuilder.increments('id').primary();

    // metadata
    tableBuilder.string('created_by').notNullable();
    tableBuilder.string('modified_by').notNullable();
    tableBuilder.timestamp('created_at').notNullable().defaultTo(knex.fn.now());
    tableBuilder
      .timestamp('modified_at')
      .notNullable()
      .defaultTo(knex.fn.now());

    // soft deletion
    tableBuilder.boolean('is_deleted').notNullable().defaultTo(false);
    tableBuilder.timestamp('deleted_at').nullable();
    tableBuilder.string('deleted_by').nullable();

    // self-reference
    tableBuilder.integer('parent_tenant_id').unsigned().nullable();
    tableBuilder
      .foreign('parent_tenant_id', 'FK_parent_tenant_id')
      .references('id')
      .inTable(TENANTS_TABLE)
      .onDelete('CASCADE');

    // simple attributes
    tableBuilder.string('tenant_type_code').notNullable();
    tableBuilder.string('tenant_name').unique().notNullable();
    tableBuilder.string('tenant_identifier').unique().notNullable();
  });
}

export async function down(knex: Knex): Promise<void> {
  knex.schema.dropTable(TENANTS_TABLE);
}
