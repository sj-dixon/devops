import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await applyMetadataChange(knex, 'tenants');
}

export async function down(knex: Knex): Promise<void> {
  await revertMetadataChange(knex, 'tenants');
}

// noinspection DuplicatedCode
async function applyMetadataChange(knex: Knex, tableName: string) {
  await knex.schema.alterTable(
    tableName,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
      tableBuilder.dropColumn('deleted_by');
    }
  );
  await knex.schema.alterTable(
    tableName,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.integer('created_by').nullable().defaultTo(null).unsigned();
      tableBuilder.integer('modified_by').nullable().defaultTo(null).unsigned();
      tableBuilder.integer('deleted_by').nullable().defaultTo(null).unsigned();
    }
  );
}

// noinspection DuplicatedCode
async function revertMetadataChange(
  knex: Knex,
  tableName: string
): Promise<void> {
  await knex.schema.alterTable(
    tableName,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('created_by');
      tableBuilder.dropColumn('modified_by');
      tableBuilder.dropColumn('deleted_by');
    }
  );

  await knex.schema.alterTable(
    tableName,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.string('created_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('modified_by', 50).notNullable().defaultTo('@SYSTEM');
      tableBuilder.string('deleted_by', 50).nullable().defaultTo(null);
    }
  );
}
