import { Knex } from 'knex';

const TABLE_NAME = 'organization_auth_providers';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder
        .enum(
          'auth_provider_type',
          ['KEYCLOAK', 'AZURE_AD', 'API', 'EXTERNAL'],
          {
            existingType: true,
            enumName: 'ENUM_auth_provider_type',
            useNative: true,
          }
        )
        .notNullable()
        .defaultTo('KEYCLOAK');
    }
  );
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    TABLE_NAME,
    (tableBuilder: Knex.AlterTableBuilder) => {
      tableBuilder.dropColumn('auth_provider_type');
    }
  );
}
