import { Knex } from 'knex';

const TENANTS_TABLE = 'tenants';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    TENANTS_TABLE,
    (tableBuilder: Knex.CreateTableBuilder) => {
      // id and metadata
      tableBuilder.uuid('id').primary();
      tableBuilder
        .timestamp('_createdOn')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('_modifiedOn')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder.string('_createdBy').notNullable();
      tableBuilder.string('_modifiedBy').notNullable();

      // soft deletion
      tableBuilder.timestamp('_deletedOn').nullable();
      tableBuilder.string('_deletedBy').nullable();

      // entity specific columns
      tableBuilder
        .uuid('parentTenantId')
        .references('id')
        .inTable(TENANTS_TABLE);

      tableBuilder.string('tenantTypeCode').notNullable();
      tableBuilder.string('tenantDisplayName').notNullable();
      tableBuilder.string('tenantCode').unique().notNullable();
    }
  );
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  if (await knex.schema.hasTable(TENANTS_TABLE)) {
    await knex.schema.dropTableIfExists(TENANTS_TABLE);
  }
}
