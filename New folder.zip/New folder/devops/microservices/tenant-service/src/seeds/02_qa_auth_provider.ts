import { Knex } from 'knex';
import { OrganizationAuthProvider } from '../models/organizationAuthProvider';
import { TenantTypeCode } from '../types';
import { Tenant } from '../models/tenant';
import {
  AdminKeycloakClient,
  getAdminKeycloakClient,
} from '../lib/clients/keycloak';
import { FIRST_ORGANIZATION_IDENTIFIER } from './01-root-tenant';
import { provisionTenantAuthProviders } from '../provisioning/provisionTenant';
import { Model, Transaction } from 'objection';

export async function seed(knex: Knex): Promise<void> {
  Model.knex(knex);

  // Deletes ALL existing entries
  console.log('\nStarting Seed: 02_qa_auth_provider');
  console.log('Removing all tenant auth providers');

  await knex(OrganizationAuthProvider.tableName).del();

  const rootTenant = await Tenant.getRootTenant();
  const qaTenant = await Tenant.query()
    .where({
      tenantIdentifier: FIRST_ORGANIZATION_IDENTIFIER,
      tenantTypeCode: TenantTypeCode.ORGANIZATION,
      parentTenantId: rootTenant.id,
    })
    .first();

  await Model.transaction(async (transaction: Transaction) => {
    const adminClient: AdminKeycloakClient = getAdminKeycloakClient();
    await adminClient.authenticateAsAdmin();
    await provisionTenantAuthProviders(
      transaction,
      adminClient,
      FIRST_ORGANIZATION_IDENTIFIER,
      qaTenant.id
    );
  });
}
