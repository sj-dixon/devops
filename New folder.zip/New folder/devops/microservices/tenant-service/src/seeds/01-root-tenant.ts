import { Knex } from 'knex';
import { Tenant } from '../models/tenant';
import { TenantTypeCode } from '../types';
import { Utilities } from '@alcumus/globals';

const ADMIN_TENANT_IDENTIFIER = Utilities.ProcessEnv.getValueOrThrow(
  'TENANT_SERVICE_ROOT_TENANT_IDENTIFIER'
);

export const FIRST_ORGANIZATION_IDENTIFIER = 'acme-test';

export async function seed(knex: Knex): Promise<void> {
  Tenant.knex(knex);

  await knex(Tenant.tableName).del().whereNot({
    tenantIdentifier: ADMIN_TENANT_IDENTIFIER,
  });

  const adminTenant = await Tenant.query().findOne({
    tenantIdentifier: ADMIN_TENANT_IDENTIFIER,
  });

  await Tenant.query().insert({
    tenantName: 'Test Company for QA Purposes',
    tenantTypeCode: TenantTypeCode.ORGANIZATION,
    tenantIdentifier: FIRST_ORGANIZATION_IDENTIFIER,
    parentTenantId: adminTenant.id,
  });
}
