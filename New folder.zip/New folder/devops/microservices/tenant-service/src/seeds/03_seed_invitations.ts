import { Knex } from 'knex';
import { v4 as uuidV4 } from 'uuid';
import getInvitationExpiration from '../lib/utils/getInvitationExpiration';
import { Tenant } from '../models/tenant';

export async function seed(knex: Knex): Promise<void> {
  Tenant.knex(knex);

  const tenant = await Tenant.query()
    .where({
      tenantName: 'Test Company for QA Purposes',
    })
    .first();

  await knex('invitations').insert([
    {
      invite_code: uuidV4(),
      email: 'demouser@alcumus.com',
      organizationId: Number(tenant.id),
      expires_at: getInvitationExpiration(),
    },
  ]);
}
