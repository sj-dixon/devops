import { Utilities } from '@alcumus/globals';

const BASE_PATH_V1 = '/api/v1';

export const ENDPOINTS = {
  ORGANIZATIONS: `${BASE_PATH_V1}/organizations`,
  AUTH: `${BASE_PATH_V1}/auth`,
  AUTH_PROVIDERS: `${BASE_PATH_V1}/authProviders`,
};

export const TENANT_SERVICE_PORT = Number(
  Utilities.ProcessEnv.getValueOrDefault('TENANT_SERVICE_PORT', '8016')
);
