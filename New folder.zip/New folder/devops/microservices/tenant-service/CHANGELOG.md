# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.4.0](https://github.com/Alcumus/services/compare/tenant-service@0.3.0...tenant-service@0.4.0) (2021-12-06)


### Bug Fixes

* Removed created/modified/deleted by from tenant and organization auth provider. ([522ed62](https://github.com/Alcumus/services/commit/522ed62fbd9c63dcaacda721eca218ede3332770))
* Removed tenant source type enum from api contracts and code. ([bf38606](https://github.com/Alcumus/services/commit/bf386062d4e946cc8adfdf5ea995927660c651cd))


### Features

* Created endpoint to create api auth providers, which validate credentials against an endpoint. ([ca9ba2c](https://github.com/Alcumus/services/commit/ca9ba2cb05e1a8eca0cf2f0e5cfa9448af82bfb2))
* implemented PUT /tenants/api/v1/organizations/:id/authProviders/:providerName ([e2adf29](https://github.com/Alcumus/services/commit/e2adf29c89d2b6bfb412b62c062bb11343e0696d))


* feat!: Added endpoint that retrieves an organization based on organization identifier. ([a239198](https://github.com/Alcumus/services/commit/a239198179ffdef5a4c4c2c5da9009c630872142))


### BREAKING CHANGES

* moved auth provider urls.





# 0.3.0 (2021-11-11)


### Bug Fixes

* **tenant-service:** fix tests, new endpoints ([0e48d4e](https://github.com/Alcumus/services/commit/0e48d4e5ba87eefd5f35496371840f4e25dba6c5))
* **tenant-service:** migrate timestamp columns to datetime columns ([c8c0a98](https://github.com/Alcumus/services/commit/c8c0a98f2846bcec9ee262294ed223d5f75ee5b1))
* Run syncpack:fix to resolve dependency issues ([3dbedf9](https://github.com/Alcumus/services/commit/3dbedf9696f6fb46febb311ec3856347f4c8a8c1))
* **tenant-service:** add guards before destructuring data ([e1b8500](https://github.com/Alcumus/services/commit/e1b8500cd4bccada3edea49daa24f21885c03aff))
* **tenant-service:** Fix invitation seeds failing due to duplicate record ([d968d2b](https://github.com/Alcumus/services/commit/d968d2b2de5f26111c231e896b19c55fbf3c851b))
* **tenant-service:** Rename seed_invitations file and use objection for querying ([54f3107](https://github.com/Alcumus/services/commit/54f31076fa30a4e85bd5e1f7205c9548d5093334))
* add missing param for tenant by id api ([1c9166c](https://github.com/Alcumus/services/commit/1c9166c5f47e4889e451039f6515ba7fda3767ac))
* createdBy, deletedBy, and modifiedBy are now nullable, unsigned integer columns in the database. ([d72b9c8](https://github.com/Alcumus/services/commit/d72b9c8a2ee41c91687effbbc4f4577943043ec3))
* eliminated uses of x-userinfo header and middleware. ([e9e181e](https://github.com/Alcumus/services/commit/e9e181e6fc0fa37a5618e80a2fb24d0b4e7dcb29))
* Fix seed script issue with environment variable ([e72c1e6](https://github.com/Alcumus/services/commit/e72c1e699310d19d5f483e1bf9288f10653db548))
* fixed assertion to match contract. ([1f39d5b](https://github.com/Alcumus/services/commit/1f39d5ba3f5948c7644e95acb7e6567c343de6a3))
* fixed down scripts. ([d7f2d57](https://github.com/Alcumus/services/commit/d7f2d577dd2d1d6521af86d7f3e0f6b2e4a5a5a6))
* fixed inconsistencies with seed; also fixed volatile test. ([a05526b](https://github.com/Alcumus/services/commit/a05526b469195b0a5e4fd02d831ea64236a0db1c))
* fixed tests. ([0fc0df4](https://github.com/Alcumus/services/commit/0fc0df4ef1a515cf57fd1797e1b10fac52f5485e))
* Implemented getter endpoint for auth provider, + test and fixes. ([fe05d9a](https://github.com/Alcumus/services/commit/fe05d9a69d9d6cfaa6266f1472f978290ce1ccc7))
* Made dockerfiles consistent and removed npm run bootstrap since its a postinstall step and ran anyways. ([9bd3f40](https://github.com/Alcumus/services/commit/9bd3f4011bc5250623a5d0c8bea5ee01c41b9563))
* made route public and updated contract security. ([863f812](https://github.com/Alcumus/services/commit/863f812846fd769dba2bc5dd079946128f85e0de))
* now using lowercase header name in all contracts. ([1e0afa6](https://github.com/Alcumus/services/commit/1e0afa6618236359a7fe91f90ef449e65aa7ea12))
* PR feedback addressed ([a93a8f4](https://github.com/Alcumus/services/commit/a93a8f401f4071e3b9b34ed4e45425cb0c73f28c))
* quick fix for seed command. ([f84341b](https://github.com/Alcumus/services/commit/f84341be44a9bff15de17cc01d75c4a9e527bf06))
* removed KEYCLOAK_IMPORT because it will prevent keycloak from starting up if it stops. ([711b2f1](https://github.com/Alcumus/services/commit/711b2f19ca9d791e23a51dc52a36744463318f71))
* removed x-userinfo from remaining api contracts. ([c23ef4c](https://github.com/Alcumus/services/commit/c23ef4c5c4d33a25d1bcc62664ff5b7f4d4e493a))
* reverted Bearer -> bearer overshoot. ([f82122c](https://github.com/Alcumus/services/commit/f82122c5b355c6116b83097440a514eb72e61bbd))
* status -> sendStatus ([6973f93](https://github.com/Alcumus/services/commit/6973f93ccf8abe947691cef5e53d32dc53934d26))
* updated package reference ([2f4d702](https://github.com/Alcumus/services/commit/2f4d70223953d1fbe7587ea369688c071b558e00))
* **tenant-service:** minor updates to get API working with db entity ([838e95c](https://github.com/Alcumus/services/commit/838e95c6be83a6e6d8dc2db1c593ffdd22eab67e))
* **tenant-service:** Use extended Request instead of express Request ([113cfef](https://github.com/Alcumus/services/commit/113cfef8429d05b8346e3012b2ce4c6cc4bdb054))
* undid requiring the given and family names. ([4dadbe4](https://github.com/Alcumus/services/commit/4dadbe47a0ec469db750dbc93e6eda6e206c2e0a))


### db

* **Password Migration:** Added authProviderName column to auth provider, and removed organizationIdentifier. ([aff82c5](https://github.com/Alcumus/services/commit/aff82c5e5ed3e1036433bc82c9b729d0e69258c9))


### Features

* **BI-138:** added test to check auth providers are created on organization creation. ([43afc67](https://github.com/Alcumus/services/commit/43afc67ccf3b7167154e1f700f89a81a24e9229e))
* **BI-138:** introduced new route for retrieving auth provider by organization identifier. ([76f9d5c](https://github.com/Alcumus/services/commit/76f9d5c2d45919d353363a7774d31ac8d7b594fd))
* **BI-138:** refactored integration test and added new one. ([2b3e739](https://github.com/Alcumus/services/commit/2b3e7391dc50de28b778cb4cdd7a7bcb4ed2ce22))
* **Password Migration:** Introduced GET /tenants/api/v1/auth/{orgId}/{providerName} endpoint ([1576fc8](https://github.com/Alcumus/services/commit/1576fc8c37809d9cb1f7d0c9fa8e6bc777b4f05c))
* **Password Migration:** split GET /tenants/api/v1/organization/:id/authProvider -> /tenants/api/v1/organizations/:id/authProviders(/:providerName) ([a015681](https://github.com/Alcumus/services/commit/a01568194f5605c25ccc06325cce9a6b29d9bea6))
* added /rootAdmin route to tenant service. ([41ff84c](https://github.com/Alcumus/services/commit/41ff84c5adabfc209abca504d016505559a046d2))
* added api key to tenant service contract ([c13ba3c](https://github.com/Alcumus/services/commit/c13ba3cf80edd5b569bf9c93428caeaea8396e80))
* Added basic api routes for tenant. ([e39c04c](https://github.com/Alcumus/services/commit/e39c04ceeba1a62daf1735ef6ab38c78b1b91e66))
* added middleware and tests for validating tenant specific fields. ([98d700f](https://github.com/Alcumus/services/commit/98d700fadd2f30fd6a2ddf1cd45baff21dba1be1))
* added password checker to post endpoint. ([4e9866d](https://github.com/Alcumus/services/commit/4e9866d55d9aec67e215873f8bb4e5236f8ce7e3))
* added root tenant to migration; no longer setting groups. ([e669822](https://github.com/Alcumus/services/commit/e66982297db2043e19e47fb264ecd3aa27a04423))
* auth provider creation with passing test. ([c083200](https://github.com/Alcumus/services/commit/c0832005598e32c1125b4b06d14711faa3d9627c))
* Auth Provider now connects your tenant to the groups and clients from Keycloak if they exist. ([4369d28](https://github.com/Alcumus/services/commit/4369d28c3400a63619703b5dbc838b2552d200fc))
* designed model classes for auth provider. ([14219d0](https://github.com/Alcumus/services/commit/14219d02cabd7ee0ceb99c167bd4ee0647c1777b))
* formatter fixes. ([de36d89](https://github.com/Alcumus/services/commit/de36d89c5163fdcbadd41fbfde755ee1a0fd1e24))
* implemented api for registering a new company using the api key. ([d43748e](https://github.com/Alcumus/services/commit/d43748e59c2f3a57ec99c5b4f054d647ecd74f73))
* Implemented endpoint for looking up organizations for manual org mapping use case. ([04cea9c](https://github.com/Alcumus/services/commit/04cea9cff6c276e37c910913c920d87a2c756565))
* improved middlewares and added unit tests. ([195b8a3](https://github.com/Alcumus/services/commit/195b8a3a16b64b5da76465e47ffa20f87edef882))
* made service mesh plugin use feature toggle to decide to use linkerd. ([cdf97b9](https://github.com/Alcumus/services/commit/cdf97b90b1e2223ad9234dd62204d525b27ff2da))
* made service mesh plugin use feature toggle to decide to use linkerd. ([c9e1d00](https://github.com/Alcumus/services/commit/c9e1d00ac9b0fca47741b7f3edd4d9b0577c67f1))
* now validating responses that come back. ([1848821](https://github.com/Alcumus/services/commit/1848821a4f7aa6cb9f91046eb67b83362d48043a))
* Primary key now uses number rather than guid. ([66e80aa](https://github.com/Alcumus/services/commit/66e80aac92afea0224f508d90575160164ea2097))
* queue-lib has an adapter for Azure service bus, ([3044973](https://github.com/Alcumus/services/commit/3044973cdc13f03f92b36587034840f25acd37c1))
* renamed middleware file. ([bcbab76](https://github.com/Alcumus/services/commit/bcbab76dc26b878ae916cfb3520e97067c33cb69))
* renamed tenantAuthProvider -> organizationAuthProvider for consistency. ([9c14e4c](https://github.com/Alcumus/services/commit/9c14e4cdc677474c50087c89b8634d6e069abb78))
* sketch of creating root user from tenant service and inviting them to the org. ([d45c232](https://github.com/Alcumus/services/commit/d45c23209729b8c61c46fd6a85bb14b2e79bffbb))
* wrote test for posting new root user. ([ea23e29](https://github.com/Alcumus/services/commit/ea23e291e04cf5f45f8b9f5806353869e83ee92e))
* **BI-33:** createAccounts -> createAccount ([30fce33](https://github.com/Alcumus/services/commit/30fce33ecde3b602c1ae943959da345252be71fc))
* **BI-33:** credentials -> accounts ([bc1e971](https://github.com/Alcumus/services/commit/bc1e97120797fd7132e6b6fb0c1ae018f19b12a4))
* **BI-5:** built out working credential storage route. ([7235f7a](https://github.com/Alcumus/services/commit/7235f7a3d58e9d9caf08ac1cd3e1772d79b906d6))
* **BI-57:** givenNames -> firstName and familyName -> lastName ([f071555](https://github.com/Alcumus/services/commit/f071555312a1e4fdd8dc991b46e709895a66953e))
* **tenant-service:** Add barebones route handlers for invitation endpoints ([8eaecdf](https://github.com/Alcumus/services/commit/8eaecdf4b60db6c398e4ea5ba1e5551f43e3acb2))
* **tenant-service:** add migration to create invitations table ([18ee25e](https://github.com/Alcumus/services/commit/18ee25ed1d50ff1217b50e1a074bcab394b9a50d))
* **tenant-service:** Create API specs for tenant invitations endpoints ([b7fbb57](https://github.com/Alcumus/services/commit/b7fbb571111ef5a631003cdbaf165aba3bdbbecb))
* **tenant-service:** define database model entity for Invitation ([9cc708e](https://github.com/Alcumus/services/commit/9cc708e86bf7efa3be63818de95a2c8fbce7ac6c))
* **tenant-service:** Update invitation route handlers to work with db updates ([8591d49](https://github.com/Alcumus/services/commit/8591d497685009658a8f958a6bc88eac5f225323))
* **tenant-service:** write seed to create a test invitation record ([4e3e59e](https://github.com/Alcumus/services/commit/4e3e59edcf147603aa663ae04de38c7160a5d565))
* removed is_deleted column in favour of deleted_at; wrote test. ([fe326ad](https://github.com/Alcumus/services/commit/fe326ad7eea50bd891930d9d33f1ef692420a767))
* restructured request body. ([2808004](https://github.com/Alcumus/services/commit/2808004cc94a95b031cbc23c505c159be98a670a))
* Sketch of retrieving auth provider from tenant service. ([e018c96](https://github.com/Alcumus/services/commit/e018c96b7fdf4c18d296775d5db0133472941d75))
* sketch of tenant service dockerfile and charts. ([f5a7b72](https://github.com/Alcumus/services/commit/f5a7b72a71a629db016bfb7963df7948b5794854))
* Sketched API for new entity + companies. ([d995d0f](https://github.com/Alcumus/services/commit/d995d0f436d41709aa312ffd33fa8d5ec98b840e))
* updated api contract. ([366b373](https://github.com/Alcumus/services/commit/366b373e4b10d3e8131b0739b505234cdf844de7))


### Reverts

* **@alcumus/globals:** remove added serialize function ([14d7c89](https://github.com/Alcumus/services/commit/14d7c892f78c4df5da72492c0d62396241de5980))
* **tenant-service:** reset package.json to develop ([ce91347](https://github.com/Alcumus/services/commit/ce913475dc5760268d97adbedbe02763120cbd71))


### BREAKING CHANGES

* **Password Migration:** the endpoint for retrieving auth providers using the organization id has changed to reflect the one to many relationship they now have.
* **Password Migration:** keycloakUserNamePrefix -> userNamePrefix
* **Password Migration:** GET /tenants/api/v1/auth/{orgId} now returns a list.





# 0.2.0 (2021-11-02)


### Bug Fixes

* Run syncpack:fix to resolve dependency issues ([3dbedf9](https://github.com/Alcumus/services/commit/3dbedf9696f6fb46febb311ec3856347f4c8a8c1))
* **tenant-service:** add guards before destructuring data ([e1b8500](https://github.com/Alcumus/services/commit/e1b8500cd4bccada3edea49daa24f21885c03aff))
* **tenant-service:** Fix invitation seeds failing due to duplicate record ([d968d2b](https://github.com/Alcumus/services/commit/d968d2b2de5f26111c231e896b19c55fbf3c851b))
* **tenant-service:** Rename seed_invitations file and use objection for querying ([54f3107](https://github.com/Alcumus/services/commit/54f31076fa30a4e85bd5e1f7205c9548d5093334))
* add missing param for tenant by id api ([1c9166c](https://github.com/Alcumus/services/commit/1c9166c5f47e4889e451039f6515ba7fda3767ac))
* createdBy, deletedBy, and modifiedBy are now nullable, unsigned integer columns in the database. ([d72b9c8](https://github.com/Alcumus/services/commit/d72b9c8a2ee41c91687effbbc4f4577943043ec3))
* eliminated uses of x-userinfo header and middleware. ([e9e181e](https://github.com/Alcumus/services/commit/e9e181e6fc0fa37a5618e80a2fb24d0b4e7dcb29))
* Fix seed script issue with environment variable ([e72c1e6](https://github.com/Alcumus/services/commit/e72c1e699310d19d5f483e1bf9288f10653db548))
* fixed assertion to match contract. ([1f39d5b](https://github.com/Alcumus/services/commit/1f39d5ba3f5948c7644e95acb7e6567c343de6a3))
* fixed down scripts. ([d7f2d57](https://github.com/Alcumus/services/commit/d7f2d577dd2d1d6521af86d7f3e0f6b2e4a5a5a6))
* fixed inconsistencies with seed; also fixed volatile test. ([a05526b](https://github.com/Alcumus/services/commit/a05526b469195b0a5e4fd02d831ea64236a0db1c))
* fixed tests. ([0fc0df4](https://github.com/Alcumus/services/commit/0fc0df4ef1a515cf57fd1797e1b10fac52f5485e))
* Implemented getter endpoint for auth provider, + test and fixes. ([fe05d9a](https://github.com/Alcumus/services/commit/fe05d9a69d9d6cfaa6266f1472f978290ce1ccc7))
* Made dockerfiles consistent and removed npm run bootstrap since its a postinstall step and ran anyways. ([9bd3f40](https://github.com/Alcumus/services/commit/9bd3f4011bc5250623a5d0c8bea5ee01c41b9563))
* made route public and updated contract security. ([863f812](https://github.com/Alcumus/services/commit/863f812846fd769dba2bc5dd079946128f85e0de))
* now using lowercase header name in all contracts. ([1e0afa6](https://github.com/Alcumus/services/commit/1e0afa6618236359a7fe91f90ef449e65aa7ea12))
* PR feedback addressed ([a93a8f4](https://github.com/Alcumus/services/commit/a93a8f401f4071e3b9b34ed4e45425cb0c73f28c))
* quick fix for seed command. ([f84341b](https://github.com/Alcumus/services/commit/f84341be44a9bff15de17cc01d75c4a9e527bf06))
* removed KEYCLOAK_IMPORT because it will prevent keycloak from starting up if it stops. ([711b2f1](https://github.com/Alcumus/services/commit/711b2f19ca9d791e23a51dc52a36744463318f71))
* removed x-userinfo from remaining api contracts. ([c23ef4c](https://github.com/Alcumus/services/commit/c23ef4c5c4d33a25d1bcc62664ff5b7f4d4e493a))
* reverted Bearer -> bearer overshoot. ([f82122c](https://github.com/Alcumus/services/commit/f82122c5b355c6116b83097440a514eb72e61bbd))
* status -> sendStatus ([6973f93](https://github.com/Alcumus/services/commit/6973f93ccf8abe947691cef5e53d32dc53934d26))
* updated package reference ([2f4d702](https://github.com/Alcumus/services/commit/2f4d70223953d1fbe7587ea369688c071b558e00))
* **tenant-service:** minor updates to get API working with db entity ([838e95c](https://github.com/Alcumus/services/commit/838e95c6be83a6e6d8dc2db1c593ffdd22eab67e))
* **tenant-service:** Use extended Request instead of express Request ([113cfef](https://github.com/Alcumus/services/commit/113cfef8429d05b8346e3012b2ce4c6cc4bdb054))
* undid requiring the given and family names. ([4dadbe4](https://github.com/Alcumus/services/commit/4dadbe47a0ec469db750dbc93e6eda6e206c2e0a))


### Features

* Implemented endpoint for looking up organizations for manual org mapping use case. ([04cea9c](https://github.com/Alcumus/services/commit/04cea9cff6c276e37c910913c920d87a2c756565))
* **BI-138:** added test to check auth providers are created on organization creation. ([43afc67](https://github.com/Alcumus/services/commit/43afc67ccf3b7167154e1f700f89a81a24e9229e))
* **BI-138:** introduced new route for retrieving auth provider by organization identifier. ([76f9d5c](https://github.com/Alcumus/services/commit/76f9d5c2d45919d353363a7774d31ac8d7b594fd))
* **BI-138:** refactored integration test and added new one. ([2b3e739](https://github.com/Alcumus/services/commit/2b3e7391dc50de28b778cb4cdd7a7bcb4ed2ce22))
* added /rootAdmin route to tenant service. ([41ff84c](https://github.com/Alcumus/services/commit/41ff84c5adabfc209abca504d016505559a046d2))
* added api key to tenant service contract ([c13ba3c](https://github.com/Alcumus/services/commit/c13ba3cf80edd5b569bf9c93428caeaea8396e80))
* Added basic api routes for tenant. ([e39c04c](https://github.com/Alcumus/services/commit/e39c04ceeba1a62daf1735ef6ab38c78b1b91e66))
* added middleware and tests for validating tenant specific fields. ([98d700f](https://github.com/Alcumus/services/commit/98d700fadd2f30fd6a2ddf1cd45baff21dba1be1))
* added password checker to post endpoint. ([4e9866d](https://github.com/Alcumus/services/commit/4e9866d55d9aec67e215873f8bb4e5236f8ce7e3))
* added root tenant to migration; no longer setting groups. ([e669822](https://github.com/Alcumus/services/commit/e66982297db2043e19e47fb264ecd3aa27a04423))
* auth provider creation with passing test. ([c083200](https://github.com/Alcumus/services/commit/c0832005598e32c1125b4b06d14711faa3d9627c))
* Auth Provider now connects your tenant to the groups and clients from Keycloak if they exist. ([4369d28](https://github.com/Alcumus/services/commit/4369d28c3400a63619703b5dbc838b2552d200fc))
* designed model classes for auth provider. ([14219d0](https://github.com/Alcumus/services/commit/14219d02cabd7ee0ceb99c167bd4ee0647c1777b))
* formatter fixes. ([de36d89](https://github.com/Alcumus/services/commit/de36d89c5163fdcbadd41fbfde755ee1a0fd1e24))
* implemented api for registering a new company using the api key. ([d43748e](https://github.com/Alcumus/services/commit/d43748e59c2f3a57ec99c5b4f054d647ecd74f73))
* improved middlewares and added unit tests. ([195b8a3](https://github.com/Alcumus/services/commit/195b8a3a16b64b5da76465e47ffa20f87edef882))
* made service mesh plugin use feature toggle to decide to use linkerd. ([cdf97b9](https://github.com/Alcumus/services/commit/cdf97b90b1e2223ad9234dd62204d525b27ff2da))
* made service mesh plugin use feature toggle to decide to use linkerd. ([c9e1d00](https://github.com/Alcumus/services/commit/c9e1d00ac9b0fca47741b7f3edd4d9b0577c67f1))
* now validating responses that come back. ([1848821](https://github.com/Alcumus/services/commit/1848821a4f7aa6cb9f91046eb67b83362d48043a))
* Primary key now uses number rather than guid. ([66e80aa](https://github.com/Alcumus/services/commit/66e80aac92afea0224f508d90575160164ea2097))
* queue-lib has an adapter for Azure service bus, ([3044973](https://github.com/Alcumus/services/commit/3044973cdc13f03f92b36587034840f25acd37c1))
* removed is_deleted column in favour of deleted_at; wrote test. ([fe326ad](https://github.com/Alcumus/services/commit/fe326ad7eea50bd891930d9d33f1ef692420a767))
* renamed middleware file. ([bcbab76](https://github.com/Alcumus/services/commit/bcbab76dc26b878ae916cfb3520e97067c33cb69))
* renamed tenantAuthProvider -> organizationAuthProvider for consistency. ([9c14e4c](https://github.com/Alcumus/services/commit/9c14e4cdc677474c50087c89b8634d6e069abb78))
* sketch of creating root user from tenant service and inviting them to the org. ([d45c232](https://github.com/Alcumus/services/commit/d45c23209729b8c61c46fd6a85bb14b2e79bffbb))
* wrote test for posting new root user. ([ea23e29](https://github.com/Alcumus/services/commit/ea23e291e04cf5f45f8b9f5806353869e83ee92e))
* **BI-33:** createAccounts -> createAccount ([30fce33](https://github.com/Alcumus/services/commit/30fce33ecde3b602c1ae943959da345252be71fc))
* **BI-33:** credentials -> accounts ([bc1e971](https://github.com/Alcumus/services/commit/bc1e97120797fd7132e6b6fb0c1ae018f19b12a4))
* **BI-5:** built out working credential storage route. ([7235f7a](https://github.com/Alcumus/services/commit/7235f7a3d58e9d9caf08ac1cd3e1772d79b906d6))
* **BI-57:** givenNames -> firstName and familyName -> lastName ([f071555](https://github.com/Alcumus/services/commit/f071555312a1e4fdd8dc991b46e709895a66953e))
* **tenant-service:** Add barebones route handlers for invitation endpoints ([8eaecdf](https://github.com/Alcumus/services/commit/8eaecdf4b60db6c398e4ea5ba1e5551f43e3acb2))
* **tenant-service:** add migration to create invitations table ([18ee25e](https://github.com/Alcumus/services/commit/18ee25ed1d50ff1217b50e1a074bcab394b9a50d))
* **tenant-service:** Create API specs for tenant invitations endpoints ([b7fbb57](https://github.com/Alcumus/services/commit/b7fbb571111ef5a631003cdbaf165aba3bdbbecb))
* **tenant-service:** define database model entity for Invitation ([9cc708e](https://github.com/Alcumus/services/commit/9cc708e86bf7efa3be63818de95a2c8fbce7ac6c))
* **tenant-service:** Update invitation route handlers to work with db updates ([8591d49](https://github.com/Alcumus/services/commit/8591d497685009658a8f958a6bc88eac5f225323))
* **tenant-service:** write seed to create a test invitation record ([4e3e59e](https://github.com/Alcumus/services/commit/4e3e59edcf147603aa663ae04de38c7160a5d565))
* restructured request body. ([2808004](https://github.com/Alcumus/services/commit/2808004cc94a95b031cbc23c505c159be98a670a))
* Sketch of retrieving auth provider from tenant service. ([e018c96](https://github.com/Alcumus/services/commit/e018c96b7fdf4c18d296775d5db0133472941d75))
* sketch of tenant service dockerfile and charts. ([f5a7b72](https://github.com/Alcumus/services/commit/f5a7b72a71a629db016bfb7963df7948b5794854))
* Sketched API for new entity + companies. ([d995d0f](https://github.com/Alcumus/services/commit/d995d0f436d41709aa312ffd33fa8d5ec98b840e))
* updated api contract. ([366b373](https://github.com/Alcumus/services/commit/366b373e4b10d3e8131b0739b505234cdf844de7))





# 0.1.0 (2021-11-02)


### Bug Fixes

* Run syncpack:fix to resolve dependency issues ([3dbedf9](https://github.com/Alcumus/services/commit/3dbedf9696f6fb46febb311ec3856347f4c8a8c1))
* **tenant-service:** add guards before destructuring data ([e1b8500](https://github.com/Alcumus/services/commit/e1b8500cd4bccada3edea49daa24f21885c03aff))
* **tenant-service:** Fix invitation seeds failing due to duplicate record ([d968d2b](https://github.com/Alcumus/services/commit/d968d2b2de5f26111c231e896b19c55fbf3c851b))
* **tenant-service:** Rename seed_invitations file and use objection for querying ([54f3107](https://github.com/Alcumus/services/commit/54f31076fa30a4e85bd5e1f7205c9548d5093334))
* add missing param for tenant by id api ([1c9166c](https://github.com/Alcumus/services/commit/1c9166c5f47e4889e451039f6515ba7fda3767ac))
* createdBy, deletedBy, and modifiedBy are now nullable, unsigned integer columns in the database. ([d72b9c8](https://github.com/Alcumus/services/commit/d72b9c8a2ee41c91687effbbc4f4577943043ec3))
* eliminated uses of x-userinfo header and middleware. ([e9e181e](https://github.com/Alcumus/services/commit/e9e181e6fc0fa37a5618e80a2fb24d0b4e7dcb29))
* Fix seed script issue with environment variable ([e72c1e6](https://github.com/Alcumus/services/commit/e72c1e699310d19d5f483e1bf9288f10653db548))
* fixed assertion to match contract. ([1f39d5b](https://github.com/Alcumus/services/commit/1f39d5ba3f5948c7644e95acb7e6567c343de6a3))
* fixed down scripts. ([d7f2d57](https://github.com/Alcumus/services/commit/d7f2d577dd2d1d6521af86d7f3e0f6b2e4a5a5a6))
* fixed inconsistencies with seed; also fixed volatile test. ([a05526b](https://github.com/Alcumus/services/commit/a05526b469195b0a5e4fd02d831ea64236a0db1c))
* fixed tests. ([0fc0df4](https://github.com/Alcumus/services/commit/0fc0df4ef1a515cf57fd1797e1b10fac52f5485e))
* Implemented getter endpoint for auth provider, + test and fixes. ([fe05d9a](https://github.com/Alcumus/services/commit/fe05d9a69d9d6cfaa6266f1472f978290ce1ccc7))
* Made dockerfiles consistent and removed npm run bootstrap since its a postinstall step and ran anyways. ([9bd3f40](https://github.com/Alcumus/services/commit/9bd3f4011bc5250623a5d0c8bea5ee01c41b9563))
* made route public and updated contract security. ([863f812](https://github.com/Alcumus/services/commit/863f812846fd769dba2bc5dd079946128f85e0de))
* now using lowercase header name in all contracts. ([1e0afa6](https://github.com/Alcumus/services/commit/1e0afa6618236359a7fe91f90ef449e65aa7ea12))
* PR feedback addressed ([a93a8f4](https://github.com/Alcumus/services/commit/a93a8f401f4071e3b9b34ed4e45425cb0c73f28c))
* quick fix for seed command. ([f84341b](https://github.com/Alcumus/services/commit/f84341be44a9bff15de17cc01d75c4a9e527bf06))
* removed KEYCLOAK_IMPORT because it will prevent keycloak from starting up if it stops. ([711b2f1](https://github.com/Alcumus/services/commit/711b2f19ca9d791e23a51dc52a36744463318f71))
* removed x-userinfo from remaining api contracts. ([c23ef4c](https://github.com/Alcumus/services/commit/c23ef4c5c4d33a25d1bcc62664ff5b7f4d4e493a))
* reverted Bearer -> bearer overshoot. ([f82122c](https://github.com/Alcumus/services/commit/f82122c5b355c6116b83097440a514eb72e61bbd))
* status -> sendStatus ([6973f93](https://github.com/Alcumus/services/commit/6973f93ccf8abe947691cef5e53d32dc53934d26))
* updated package reference ([2f4d702](https://github.com/Alcumus/services/commit/2f4d70223953d1fbe7587ea369688c071b558e00))
* **tenant-service:** minor updates to get API working with db entity ([838e95c](https://github.com/Alcumus/services/commit/838e95c6be83a6e6d8dc2db1c593ffdd22eab67e))
* **tenant-service:** Use extended Request instead of express Request ([113cfef](https://github.com/Alcumus/services/commit/113cfef8429d05b8346e3012b2ce4c6cc4bdb054))
* undid requiring the given and family names. ([4dadbe4](https://github.com/Alcumus/services/commit/4dadbe47a0ec469db750dbc93e6eda6e206c2e0a))


### Features

* Implemented endpoint for looking up organizations for manual org mapping use case. ([04cea9c](https://github.com/Alcumus/services/commit/04cea9cff6c276e37c910913c920d87a2c756565))
* **BI-138:** added test to check auth providers are created on organization creation. ([43afc67](https://github.com/Alcumus/services/commit/43afc67ccf3b7167154e1f700f89a81a24e9229e))
* **BI-138:** introduced new route for retrieving auth provider by organization identifier. ([76f9d5c](https://github.com/Alcumus/services/commit/76f9d5c2d45919d353363a7774d31ac8d7b594fd))
* **BI-138:** refactored integration test and added new one. ([2b3e739](https://github.com/Alcumus/services/commit/2b3e7391dc50de28b778cb4cdd7a7bcb4ed2ce22))
* added /rootAdmin route to tenant service. ([41ff84c](https://github.com/Alcumus/services/commit/41ff84c5adabfc209abca504d016505559a046d2))
* added api key to tenant service contract ([c13ba3c](https://github.com/Alcumus/services/commit/c13ba3cf80edd5b569bf9c93428caeaea8396e80))
* Added basic api routes for tenant. ([e39c04c](https://github.com/Alcumus/services/commit/e39c04ceeba1a62daf1735ef6ab38c78b1b91e66))
* added middleware and tests for validating tenant specific fields. ([98d700f](https://github.com/Alcumus/services/commit/98d700fadd2f30fd6a2ddf1cd45baff21dba1be1))
* added password checker to post endpoint. ([4e9866d](https://github.com/Alcumus/services/commit/4e9866d55d9aec67e215873f8bb4e5236f8ce7e3))
* added root tenant to migration; no longer setting groups. ([e669822](https://github.com/Alcumus/services/commit/e66982297db2043e19e47fb264ecd3aa27a04423))
* auth provider creation with passing test. ([c083200](https://github.com/Alcumus/services/commit/c0832005598e32c1125b4b06d14711faa3d9627c))
* Auth Provider now connects your tenant to the groups and clients from Keycloak if they exist. ([4369d28](https://github.com/Alcumus/services/commit/4369d28c3400a63619703b5dbc838b2552d200fc))
* designed model classes for auth provider. ([14219d0](https://github.com/Alcumus/services/commit/14219d02cabd7ee0ceb99c167bd4ee0647c1777b))
* formatter fixes. ([de36d89](https://github.com/Alcumus/services/commit/de36d89c5163fdcbadd41fbfde755ee1a0fd1e24))
* implemented api for registering a new company using the api key. ([d43748e](https://github.com/Alcumus/services/commit/d43748e59c2f3a57ec99c5b4f054d647ecd74f73))
* improved middlewares and added unit tests. ([195b8a3](https://github.com/Alcumus/services/commit/195b8a3a16b64b5da76465e47ffa20f87edef882))
* made service mesh plugin use feature toggle to decide to use linkerd. ([cdf97b9](https://github.com/Alcumus/services/commit/cdf97b90b1e2223ad9234dd62204d525b27ff2da))
* made service mesh plugin use feature toggle to decide to use linkerd. ([c9e1d00](https://github.com/Alcumus/services/commit/c9e1d00ac9b0fca47741b7f3edd4d9b0577c67f1))
* now validating responses that come back. ([1848821](https://github.com/Alcumus/services/commit/1848821a4f7aa6cb9f91046eb67b83362d48043a))
* Primary key now uses number rather than guid. ([66e80aa](https://github.com/Alcumus/services/commit/66e80aac92afea0224f508d90575160164ea2097))
* queue-lib has an adapter for Azure service bus, ([3044973](https://github.com/Alcumus/services/commit/3044973cdc13f03f92b36587034840f25acd37c1))
* removed is_deleted column in favour of deleted_at; wrote test. ([fe326ad](https://github.com/Alcumus/services/commit/fe326ad7eea50bd891930d9d33f1ef692420a767))
* renamed middleware file. ([bcbab76](https://github.com/Alcumus/services/commit/bcbab76dc26b878ae916cfb3520e97067c33cb69))
* renamed tenantAuthProvider -> organizationAuthProvider for consistency. ([9c14e4c](https://github.com/Alcumus/services/commit/9c14e4cdc677474c50087c89b8634d6e069abb78))
* sketch of creating root user from tenant service and inviting them to the org. ([d45c232](https://github.com/Alcumus/services/commit/d45c23209729b8c61c46fd6a85bb14b2e79bffbb))
* wrote test for posting new root user. ([ea23e29](https://github.com/Alcumus/services/commit/ea23e291e04cf5f45f8b9f5806353869e83ee92e))
* **BI-33:** createAccounts -> createAccount ([30fce33](https://github.com/Alcumus/services/commit/30fce33ecde3b602c1ae943959da345252be71fc))
* **BI-33:** credentials -> accounts ([bc1e971](https://github.com/Alcumus/services/commit/bc1e97120797fd7132e6b6fb0c1ae018f19b12a4))
* **BI-5:** built out working credential storage route. ([7235f7a](https://github.com/Alcumus/services/commit/7235f7a3d58e9d9caf08ac1cd3e1772d79b906d6))
* **BI-57:** givenNames -> firstName and familyName -> lastName ([f071555](https://github.com/Alcumus/services/commit/f071555312a1e4fdd8dc991b46e709895a66953e))
* **tenant-service:** Add barebones route handlers for invitation endpoints ([8eaecdf](https://github.com/Alcumus/services/commit/8eaecdf4b60db6c398e4ea5ba1e5551f43e3acb2))
* **tenant-service:** add migration to create invitations table ([18ee25e](https://github.com/Alcumus/services/commit/18ee25ed1d50ff1217b50e1a074bcab394b9a50d))
* **tenant-service:** Create API specs for tenant invitations endpoints ([b7fbb57](https://github.com/Alcumus/services/commit/b7fbb571111ef5a631003cdbaf165aba3bdbbecb))
* **tenant-service:** define database model entity for Invitation ([9cc708e](https://github.com/Alcumus/services/commit/9cc708e86bf7efa3be63818de95a2c8fbce7ac6c))
* **tenant-service:** Update invitation route handlers to work with db updates ([8591d49](https://github.com/Alcumus/services/commit/8591d497685009658a8f958a6bc88eac5f225323))
* **tenant-service:** write seed to create a test invitation record ([4e3e59e](https://github.com/Alcumus/services/commit/4e3e59edcf147603aa663ae04de38c7160a5d565))
* restructured request body. ([2808004](https://github.com/Alcumus/services/commit/2808004cc94a95b031cbc23c505c159be98a670a))
* Sketch of retrieving auth provider from tenant service. ([e018c96](https://github.com/Alcumus/services/commit/e018c96b7fdf4c18d296775d5db0133472941d75))
* sketch of tenant service dockerfile and charts. ([f5a7b72](https://github.com/Alcumus/services/commit/f5a7b72a71a629db016bfb7963df7948b5794854))
* Sketched API for new entity + companies. ([d995d0f](https://github.com/Alcumus/services/commit/d995d0f436d41709aa312ffd33fa8d5ec98b840e))
* updated api contract. ([366b373](https://github.com/Alcumus/services/commit/366b373e4b10d3e8131b0739b505234cdf844de7))
