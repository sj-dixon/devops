import express from 'express';
import supertest from 'supertest';
import { requireTenantIdentifier } from '../../../src/middleware/requireTenantFields';
import { getMiddlewareTestApp } from './middlewareHelpers';

describe('Tenant Service / middlewares / tenantIdentifier', () => {
  let app: express.Application;

  beforeEach(() => {
    app = getMiddlewareTestApp(requireTenantIdentifier);
  });

  it('reject unspecified tenantIdentifier', (done) => {
    const expectedErrors = {
      errors: {
        tenantIdentifier: {
          key: 'organization.post.tenantIdentifierRequired',
          message: 'organization.post.tenantIdentifierRequired',
        },
      },
    };
    const body = {};
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('reject blank tenantIdentifier', (done) => {
    const expectedErrors = {
      errors: {
        tenantIdentifier: {
          key: 'organization.post.tenantIdentifierRequired',
          message: 'organization.post.tenantIdentifierRequired',
        },
      },
    };
    const body = { tenantIdentifier: '' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('reject whitespace-only tenantIdentifier', (done) => {
    const expectedErrors = {
      errors: {
        tenantIdentifier: {
          key: 'organization.post.tenantIdentifierRequired',
          message: 'organization.post.tenantIdentifierRequired',
        },
      },
    };
    const body = { tenantIdentifier: ' \t\n' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('accept non-blank valid tenantIdentifier', (done) => {
    const body = { tenantIdentifier: 'stark-inc' };
    supertest(app).post('/').send(body).expect(200, body, done);
  });
});
