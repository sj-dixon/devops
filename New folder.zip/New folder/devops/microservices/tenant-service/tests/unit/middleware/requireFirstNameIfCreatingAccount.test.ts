import express from 'express';
import supertest from 'supertest';
import { requireFirstNameIfCreatingAccount } from '../../../src/middleware/requireRootFieldsWhenCreatingAccount';
import { getMiddlewareTestApp } from './middlewareHelpers';

describe('Tenant Service / middlewares / requireFirstNameIfCreatingAccount', () => {
  let app: express.Application;

  beforeEach(() => {
    app = getMiddlewareTestApp(requireFirstNameIfCreatingAccount);
  });

  it('When createAccount=false, do not require rootFirstName', (done) => {
    const body = { createAccount: false };
    supertest(app).post('/').send(body).expect(200, body, done);
  });

  it('When createAccount=true, reject unspecified rootFirstName', (done) => {
    const expectedErrors = {
      errors: {
        rootFirstName: {
          key: 'organization.post.firstNameRequiredIfCreatingAccount',
          message: 'organization.post.firstNameRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject blank rootFirstName', (done) => {
    const expectedErrors = {
      errors: {
        rootFirstName: {
          key: 'organization.post.firstNameRequiredIfCreatingAccount',
          message: 'organization.post.firstNameRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootFirstName: '' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject whitespace-only rootFirstName', (done) => {
    const expectedErrors = {
      errors: {
        rootFirstName: {
          key: 'organization.post.firstNameRequiredIfCreatingAccount',
          message: 'organization.post.firstNameRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootFirstName: ' \t\n' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, accept non-blank rootFirstName', (done) => {
    const body = { createAccount: true, rootFirstName: 'Tony' };
    supertest(app).post('/').send(body).expect(200, body, done);
  });
});
