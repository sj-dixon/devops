import express, { Response, Application, NextFunction } from 'express';
import { Types } from '@alcumus/globals';
import { validationHandler } from '@alcumus/express-app';

type ExpressMiddleware = (
  request: Types.Request,
  response: Response,
  next: NextFunction
) => void | Promise<void>;

export function getMiddlewareTestApp(
  middlewareUnderTest: ExpressMiddleware
): Application {
  const app = express();
  app.use(express.json());
  app.use(middlewareUnderTest);
  app.use(validationHandler());
  app.post('/', (request: Types.Request, response: Response) => {
    response.json(request.body);
  });
  return app;
}
