import express from 'express';
import supertest from 'supertest';
import { requireTenantName } from '../../../src/middleware/requireTenantFields';
import { getMiddlewareTestApp } from './middlewareHelpers';

describe('Tenant Service / middlewares / tenantName', () => {
  let app: express.Application;

  beforeEach(() => {
    app = getMiddlewareTestApp(requireTenantName);
  });

  it('reject unspecified tenantName', (done) => {
    const expectedErrors = {
      errors: {
        tenantName: {
          key: 'organization.post.tenantNameRequired',
          message: 'organization.post.tenantNameRequired',
        },
      },
    };
    const body = {};
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('reject blank tenantName', (done) => {
    const expectedErrors = {
      errors: {
        tenantName: {
          key: 'organization.post.tenantNameRequired',
          message: 'organization.post.tenantNameRequired',
        },
      },
    };
    const body = { tenantName: '' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('reject whitespace-only tenantName', (done) => {
    const expectedErrors = {
      errors: {
        tenantName: {
          key: 'organization.post.tenantNameRequired',
          message: 'organization.post.tenantNameRequired',
        },
      },
    };
    const body = { tenantName: ' \t\n' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('accept non-blank valid tenantName', (done) => {
    const body = { tenantName: 'Stark Industries' };
    supertest(app).post('/').send(body).expect(200, body, done);
  });
});
