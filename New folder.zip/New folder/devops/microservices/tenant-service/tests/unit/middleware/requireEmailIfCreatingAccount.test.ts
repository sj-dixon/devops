import express from 'express';
import supertest from 'supertest';
import { requireEmailIfCreatingAccount } from '../../../src/middleware/requireRootFieldsWhenCreatingAccount';
import { getMiddlewareTestApp } from './middlewareHelpers';

describe('Tenant Service / middlewares / requireEmailIfCreatingAccount', () => {
  let app: express.Application;

  beforeEach(() => {
    app = getMiddlewareTestApp(requireEmailIfCreatingAccount);
  });

  it('When createAccount=false, do not require rootEmail', (done) => {
    const body = { createAccount: false };
    supertest(app).post('/').send(body).expect(200, body, done);
  });

  it('When createAccount=true, reject unspecified rootEmail', (done) => {
    const expectedErrors = {
      errors: {
        rootEmail: {
          key: 'organization.post.emailRequiredIfCreatingAccount',
          message: 'organization.post.emailRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject blank rootEmail', (done) => {
    const expectedErrors = {
      errors: {
        rootEmail: {
          key: 'organization.post.emailRequiredIfCreatingAccount',
          message: 'organization.post.emailRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootEmail: '' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject whitespace-only rootEmail', (done) => {
    const expectedErrors = {
      errors: {
        rootEmail: {
          key: 'organization.post.emailRequiredIfCreatingAccount',
          message: 'organization.post.emailRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootEmail: ' \t\n' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject non-blank invalid rootEmail', (done) => {
    const expectedErrors = {
      errors: {
        rootEmail: {
          key: 'organization.post.emailRequiredIfCreatingAccount',
          message: 'organization.post.emailRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootEmail: 'tony.stark' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, accept non-blank valid rootEmail', (done) => {
    const body = {
      createAccount: true,
      rootEmail: 'tony.stark@starkindustries.com',
    };
    supertest(app).post('/').send(body).expect(200, body, done);
  });
});
