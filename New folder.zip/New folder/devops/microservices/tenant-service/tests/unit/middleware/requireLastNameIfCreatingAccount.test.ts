import express from 'express';
import supertest from 'supertest';
import { requireLastNameIfCreatingAccount } from '../../../src/middleware/requireRootFieldsWhenCreatingAccount';
import { getMiddlewareTestApp } from './middlewareHelpers';

describe('Tenant Service / middlewares / requireLastNameIfCreatingAccount', () => {
  let app: express.Application;

  beforeEach(() => {
    app = getMiddlewareTestApp(requireLastNameIfCreatingAccount);
  });

  it('When createAccount=false, do not require rootLastName', (done) => {
    const body = { createAccount: false };
    supertest(app).post('/').send(body).expect(200, body, done);
  });

  it('When createAccount=true, reject unspecified rootLastName', (done) => {
    const expectedErrors = {
      errors: {
        rootLastName: {
          key: 'organization.post.lastNameRequiredIfCreatingAccount',
          message: 'organization.post.lastNameRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject blank rootLastName', (done) => {
    const expectedErrors = {
      errors: {
        rootLastName: {
          key: 'organization.post.lastNameRequiredIfCreatingAccount',
          message: 'organization.post.lastNameRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootLastName: '' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject whitespace-only rootLastName', (done) => {
    const expectedErrors = {
      errors: {
        rootLastName: {
          key: 'organization.post.lastNameRequiredIfCreatingAccount',
          message: 'organization.post.lastNameRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootLastName: ' \t\n' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, accept non-blank rootLastName', (done) => {
    const body = { createAccount: true, rootLastName: 'Stark' };
    supertest(app).post('/').send(body).expect(200, body, done);
  });
});
