import express from 'express';
import supertest from 'supertest';
import { requirePasswordIfCreatingAccount } from '../../../src/middleware/requireRootFieldsWhenCreatingAccount';
import { getMiddlewareTestApp } from './middlewareHelpers';

describe('Tenant Service / middlewares / requirePasswordIfCreatingAccount', () => {
  let app: express.Application;

  beforeEach(() => {
    app = getMiddlewareTestApp(requirePasswordIfCreatingAccount);
  });

  it('When createAccount=false, do not require rootPassword', (done) => {
    const body = { createAccount: false };
    supertest(app).post('/').send(body).expect(200, body, done);
  });

  it('When createAccount=true, reject unspecified rootPassword', (done) => {
    const expectedErrors = {
      errors: {
        rootPassword: {
          key: 'organization.post.passwordRequiredIfCreatingAccount',
          message: 'organization.post.passwordRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject blank rootPassword', (done) => {
    const expectedErrors = {
      errors: {
        rootPassword: {
          key: 'organization.post.passwordRequiredIfCreatingAccount',
          message: 'organization.post.passwordRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootPassword: '' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, reject whitespace-only rootPassword', (done) => {
    const expectedErrors = {
      errors: {
        rootPassword: {
          key: 'organization.post.passwordRequiredIfCreatingAccount',
          message: 'organization.post.passwordRequiredIfCreatingAccount',
        },
      },
    };
    const body = { createAccount: true, rootPassword: ' \t\n' };
    supertest(app).post('/').send(body).expect(400, expectedErrors, done);
  });

  it('When createAccount=true, accept non-blank rootPassword', (done) => {
    const body = { createAccount: true, rootPassword: 'Stark' };
    supertest(app).post('/').send(body).expect(200, body, done);
  });
});
