import { Tenant } from '../../../src/models/tenant';
import { v4 as uuidV4 } from 'uuid';
import {
  CreateCustomApiAuthProviderRequest,
  TenantTypeCode,
} from '../../../src/types';
import config from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Utilities } from '@alcumus/globals';
import { Model } from 'objection';
import { ENVIRONMENT } from '../routes/keycloakTestHelpers';
import { OrganizationAuthProvider } from '../../../src/models/organizationAuthProvider';

const TENANT_SERVICE_ROOT_TENANT_IDENTIFIER = uuidV4();

describe('Models: organizationAuthProvider', () => {
  let adminOrganizationId: number;
  let knex: Knex;

  beforeAll(async () => {
    knex = connectToKnex(config);
    Model.knex(knex);
    Utilities.ProcessEnv.overrideEnv({
      TENANT_SERVICE_ROOT_TENANT_IDENTIFIER,
      ...ENVIRONMENT,
    });
    const adminTenant = await Tenant.query().insert({
      tenantName: `TestAdmin-${TENANT_SERVICE_ROOT_TENANT_IDENTIFIER}`,
      tenantTypeCode: TenantTypeCode.ADMIN_ORGANIZATION,
      tenantIdentifier: TENANT_SERVICE_ROOT_TENANT_IDENTIFIER,
      parentTenantId: null,
    });
    adminOrganizationId = adminTenant.id;
  });

  afterAll(async () => {
    await knex.destroy();
    Utilities.ProcessEnv.clearOverrides();
  });

  describe('upsertCustomAuthProvider', () => {
    it('inserts and updates one auth provider if done at same time', async () => {
      const organization = await Tenant.createOrganization(
        {
          tenantName: uuidV4(),
          tenantIdentifier: uuidV4(),
        },
        adminOrganizationId
      );

      const authProviderName = 'OTHELLO';

      const provider1: CreateCustomApiAuthProviderRequest = {
        authProviderName,
        apiTokenHeaderValue: 'secret1',
        apiTokenHeaderName: 'x-secret',
        callbackUrl: 'http://secret-castle:8000',
      };
      const provider2: CreateCustomApiAuthProviderRequest = {
        authProviderName,
        apiTokenHeaderValue: 'secret2',
        apiTokenHeaderName: 'x-secret',
        callbackUrl: 'http://secret-palace:8000',
      };

      await Promise.all([
        OrganizationAuthProvider.upsertCustomAuthProvider(
          organization.id,
          authProviderName,
          provider1
        ),
        OrganizationAuthProvider.upsertCustomAuthProvider(
          organization.id,
          authProviderName,
          provider2
        ),
      ]);
      const actual =
        await OrganizationAuthProvider.findByOrganizationIdAndProviderName(
          authProviderName,
          organization.id
        );

      expect(actual).not.toBeNull();
      expect(actual).toEqual(
        expect.objectContaining({
          apiTokenHeaderName: 'x-secret',
          apiTokenHeaderValue: expect.stringMatching(
            `${provider1.apiTokenHeaderValue}|${provider2.apiTokenHeaderValue}`
          ),
          authProviderName,
          callbackUrl: expect.stringMatching(
            `${provider1.callbackUrl}|${provider2.callbackUrl}`
          ),
        })
      );
      expect(
        isSubset(provider1, actual) || isSubset(provider2, actual)
      ).toBeTruthy();
    });
  });

  it('update after two inserts results in known state', async () => {
    const organization = await Tenant.createOrganization(
      {
        tenantName: uuidV4(),
        tenantIdentifier: uuidV4(),
      },
      adminOrganizationId
    );

    const authProviderName = 'OTHELLO';

    const provider1: CreateCustomApiAuthProviderRequest = {
      authProviderName,
      apiTokenHeaderValue: 'secret1',
      apiTokenHeaderName: 'x-secret',
      callbackUrl: 'http://secret-castle:8000',
    };
    const provider2: CreateCustomApiAuthProviderRequest = {
      authProviderName,
      apiTokenHeaderValue: 'secret2',
      apiTokenHeaderName: 'x-secret',
      callbackUrl: 'http://secret-palace:8000',
    };
    const provider3: CreateCustomApiAuthProviderRequest = {
      authProviderName: 'NEW_PROVIDER',
      apiTokenHeaderValue: 'secret3',
      apiTokenHeaderName: 'x-secret',
      callbackUrl: 'http://secret-lair:8000',
    };

    await Promise.all([
      OrganizationAuthProvider.upsertCustomAuthProvider(
        organization.id,
        authProviderName,
        provider1
      ),
      OrganizationAuthProvider.upsertCustomAuthProvider(
        organization.id,
        authProviderName,
        provider2
      ),
    ]);
    await OrganizationAuthProvider.upsertCustomAuthProvider(
      organization.id,
      authProviderName,
      provider3
    );

    const actual =
      await OrganizationAuthProvider.findByOrganizationIdAndProviderName(
        provider3.authProviderName,
        organization.id
      );

    expect(actual).toEqual(expect.objectContaining(provider3));
  });

  it('concurrent updates results in one of two states', async () => {
    const organization = await Tenant.createOrganization(
      {
        tenantName: uuidV4(),
        tenantIdentifier: uuidV4(),
      },
      adminOrganizationId
    );

    const authProviderName = 'OTHELLO';

    const provider1: CreateCustomApiAuthProviderRequest = {
      authProviderName,
      apiTokenHeaderValue: 'secret1',
      apiTokenHeaderName: 'x-secret',
      callbackUrl: 'http://secret-castle:8000',
    };
    const provider2: CreateCustomApiAuthProviderRequest = {
      authProviderName,
      apiTokenHeaderValue: 'secret2',
      apiTokenHeaderName: 'x-secret',
      callbackUrl: 'http://secret-palace:8000',
    };
    const provider3: CreateCustomApiAuthProviderRequest = {
      authProviderName,
      apiTokenHeaderValue: 'secret3',
      apiTokenHeaderName: 'x-secret',
      callbackUrl: 'http://secret-lair:8000',
    };

    await OrganizationAuthProvider.upsertCustomAuthProvider(
      organization.id,
      authProviderName,
      provider1
    );

    await Promise.all([
      OrganizationAuthProvider.upsertCustomAuthProvider(
        organization.id,
        authProviderName,
        provider2
      ),
      OrganizationAuthProvider.upsertCustomAuthProvider(
        organization.id,
        authProviderName,
        provider3
      ),
    ]);
    const actual =
      await OrganizationAuthProvider.findByOrganizationIdAndProviderName(
        authProviderName,
        organization.id
      );

    expect(actual).not.toBeNull();
    expect(actual).toEqual(
      expect.objectContaining({
        apiTokenHeaderName: 'x-secret',
        apiTokenHeaderValue: expect.stringMatching(
          `${provider2.apiTokenHeaderValue}|${provider3.apiTokenHeaderValue}`
        ),
        authProviderName,
        callbackUrl: expect.stringMatching(
          `${provider2.callbackUrl}|${provider3.callbackUrl}`
        ),
      })
    );
    expect(
      isSubset(provider1, actual) || isSubset(provider2, actual)
    ).toBeTruthy();
  });
});

function isSubset(obj1: object, obj2: object | null) {
  for (const key in obj2) {
    // @ts-ignore
    if (JSON.stringify(obj2[key]) === JSON.stringify(obj1[key])) {
      return true;
    }
  }
  return false;
}
