import { Tenant } from '../../../src/models/tenant';
import {
  CreateCustomApiAuthProviderRequest,
  OrganizationAuthProviderType,
  TenantTypeCode,
} from '../../../src/types';

export function generateRandomNumber(): number {
  return Math.floor(Math.random() * 100000);
}

export function getExpectedApiAuthProvider(
  organizationId: number,
  authProviderDetails: CreateCustomApiAuthProviderRequest
) {
  return {
    authProviderType: OrganizationAuthProviderType.API,
    ...authProviderDetails,
    userNamePrefix: null,
    createdAt: expect.any(String),
    modifiedAt: expect.any(String),
    deletedAt: null,
    id: expect.any(Number),
    organizationId: organizationId,
  };
}

export async function createOrganization(
  tenantIdentifier: string,
  tenantTypeCode = TenantTypeCode.ORGANIZATION
): Promise<Tenant> {
  return await Tenant.query().insertAndFetch({
    tenantIdentifier,
    tenantName: tenantIdentifier,
    tenantTypeCode,
    parentTenantId: null,
    deletedAt: null,
  });
}
