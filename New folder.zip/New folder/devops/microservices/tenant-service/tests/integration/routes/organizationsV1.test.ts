import { Model } from 'objection';
import connectToKnex, { Knex } from 'knex';
import { v4 as uuidV4 } from 'uuid';
import supertest from 'supertest';
import { Utilities } from '@alcumus/globals';
import { Tenant } from '../../../src/models/tenant';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import config from '../../../src/knexfile';
import {
  CreateOrganizationRequest,
  OrganizationAuthProviderType,
  TenantTypeCode,
} from '../../../src/types';
import { ENVIRONMENT, mockAxios } from './keycloakTestHelpers';
import { OrganizationAuthProvider } from '../../../src/models/organizationAuthProvider';
import { toMySqlDateTimeString } from '@alcumus/objection-lib';

export const FAKE_TIME_FN = () => 1487076707000;
const CREATED_USER_ID = 789;
const NOW = '2017-02-14T12:51:47.000Z';

describe('/tenants/api/v1/organizations', () => {
  let knex: Knex;
  let dateNowSpy: jest.SpyInstance;

  beforeAll(async () => {
    knex = connectToKnex(config);
    Model.knex(knex);
    dateNowSpy = jest.spyOn(Date, 'now').mockImplementation(FAKE_TIME_FN);
  });

  afterAll(async () => {
    await knex.destroy();
    Utilities.ProcessEnv.clearOverrides();
    dateNowSpy.mockClear();
  });

  describe('POST /', () => {
    const TENANT_SERVICE_ROOT_TENANT_IDENTIFIER = uuidV4();

    let adminTenant: Tenant;
    let organizationIdentifier: string;

    beforeAll(async () => {
      Utilities.ProcessEnv.overrideEnv({
        TENANT_SERVICE_ROOT_TENANT_IDENTIFIER,
        ...ENVIRONMENT,
      });
      adminTenant = await Tenant.query().insert({
        tenantName: `TestAdmin-${TENANT_SERVICE_ROOT_TENANT_IDENTIFIER}`,
        tenantTypeCode: TenantTypeCode.ADMIN_ORGANIZATION,
        tenantIdentifier: TENANT_SERVICE_ROOT_TENANT_IDENTIFIER,
        parentTenantId: null,
      });
    });

    beforeEach(() => {
      organizationIdentifier = uuidV4();
    });

    function getRequestBody(): CreateOrganizationRequest {
      return {
        tenantName: `TestOrganization-${organizationIdentifier}`,
        tenantIdentifier: organizationIdentifier,
        createAccount: false,

        rootFirstName: 'Root',
        rootLastName: 'User',
      };
    }

    it('returns newly created organization if api key valid and no groups specified', async () => {
      const simpleRequest = {
        tenantName: `TestOrganization-${organizationIdentifier}`,
        tenantIdentifier: organizationIdentifier,
        createAccount: false,
      };

      const expectedTenant = getExpectedTenant(
        simpleRequest.tenantIdentifier,
        simpleRequest.tenantName,
        adminTenant.id
      );

      await createOrganizationAndExpectResponse(simpleRequest, expectedTenant);
    });

    it('returns newly created organization and user id', async () => {
      const request = {
        tenantName: `TestOrganization-${organizationIdentifier}`,
        tenantIdentifier: organizationIdentifier,
        createAccount: true,

        rootFirstName: 'Root',
        rootLastName: 'User',
        rootEmail: 'root.user@example.org',
        rootPassword: 'Safety123!@',
        rootUsername: 'root',
      };

      const mockUserCreate = mockUserCreation(request);
      const expectedTenant = getExpectedTenant(
        request.tenantIdentifier,
        request.tenantName,
        adminTenant.id,
        CREATED_USER_ID
      );

      const result = await postOrganizationWithApiKey(request);
      expect([result.status, result.body]).toEqual([201, expectedTenant]);
      expect(mockUserCreate).toHaveBeenCalled();
    });

    it('also creates auth provider for organization', async () => {
      const request = getRequestBody();
      const result = await postOrganizationWithApiKey(request);
      const expectedTenant = getExpectedTenant(
        request.tenantIdentifier,
        request.tenantName,
        adminTenant.id,
        undefined
      );

      const actualOrganizationId = result.body.id;
      const authProviders = await OrganizationAuthProvider.findByOrganizationId(
        actualOrganizationId
      );
      const expectedProviders =
        getExpectedTenantAuthProviders(actualOrganizationId);
      expect([result.status, result.body]).toEqual([201, expectedTenant]);
      expect(authProviders).toEqual(expectedProviders);
    });
  });

  describe('GET /organizations', () => {
    const TENANT_SERVICE_ROOT_TENANT_IDENTIFIER = uuidV4();
    let adminTenant: Tenant;

    beforeAll(async () => {
      Utilities.ProcessEnv.overrideEnv({
        TENANT_SERVICE_ROOT_TENANT_IDENTIFIER,
        ...ENVIRONMENT,
      });
      adminTenant = await Tenant.query().insert({
        tenantName: `TestAdmin-${TENANT_SERVICE_ROOT_TENANT_IDENTIFIER}`,
        tenantTypeCode: TenantTypeCode.ADMIN_ORGANIZATION,
        tenantIdentifier: TENANT_SERVICE_ROOT_TENANT_IDENTIFIER,
        parentTenantId: null,
      });
    });

    async function createSubtenant(
      subtenantNumber: number,
      deletedBy?: number
    ): Promise<Tenant> {
      return Tenant.query().insertAndFetch({
        tenantName: `${adminTenant.tenantName}-Subtenant-${subtenantNumber}`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        tenantIdentifier: `${TENANT_SERVICE_ROOT_TENANT_IDENTIFIER}-${subtenantNumber}`,
        parentTenantId: adminTenant.id,
        deletedAt: deletedBy
          ? toMySqlDateTimeString(new Date(FAKE_TIME_FN()))
          : null,
      });
    }

    it('given missing api key, should return 401 response', async () => {
      const response = await supertest(app).get(ENDPOINTS.ORGANIZATIONS).send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('given invalid api key, should return 401 response', async () => {
      const response = await supertest(app)
        .get(ENDPOINTS.ORGANIZATIONS)
        .set('x-api-key', 'something invalid')
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('Given valid api key, should retrieve all organizations created under a root tenant', async () => {
      const organization1 = await createSubtenant(1);
      const organization2 = await createSubtenant(2);
      await createSubtenant(3, 1);
      const response = await supertest(app)
        .get(ENDPOINTS.ORGANIZATIONS)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        200,
        [organization1, organization2],
      ]);
    });
  });
});

function mockUserCreation({
  rootFirstName: firstName,
  rootLastName: lastName,
  rootPassword: password,
  rootUsername: username,
  rootEmail: email,
}: CreateOrganizationRequest) {
  const url = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/users`;
  const callback = jest.fn(() => [
    200,
    {
      id: CREATED_USER_ID,
      firstName,
      lastName,
    },
  ]);
  mockAxios.onPost(url).replyOnce((config) => {
    expect(JSON.parse(config.data)).toEqual({
      firstName,
      lastName,
      password,
      email,
      username,
      createAccount: true,
    });
    return callback();
  });
  return callback;
}

function getExpectedTenant(
  tenantIdentifier: string,
  tenantName: string,
  adminTenantId: number,
  userId?: number
): object {
  return {
    createdAt: NOW,
    deletedAt: null,
    id: expect.any(Number),
    modifiedAt: NOW,
    parentTenantId: adminTenantId,
    tenantIdentifier: tenantIdentifier,
    tenantName: tenantName,
    tenantTypeCode: TenantTypeCode.ORGANIZATION,
    userId: userId || null,
  };
}

function getExpectedTenantAuthProviders(organizationId: number): object[] {
  const generateProvider = (providerType: OrganizationAuthProviderType) => ({
    authProviderName: providerType,
    authProviderType: providerType,
    createdAt: NOW,
    deletedAt: null,
    id: expect.any(Number),
    userNamePrefix: expect.any(String),
    modifiedAt: NOW,
    organizationId: organizationId,
    callbackUrl: null,
    apiTokenHeaderName: null,
    apiTokenHeaderValue: null,
  });
  return [
    generateProvider(OrganizationAuthProviderType.KEYCLOAK),
    generateProvider(OrganizationAuthProviderType.AZURE_AD),
  ];
}

async function postOrganizationWithApiKey(body: CreateOrganizationRequest) {
  return supertest(app)
    .post(ENDPOINTS.ORGANIZATIONS)
    .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
    .send(body);
}

async function createOrganizationAndExpectResponse(
  createRequest: CreateOrganizationRequest,
  expectedTenant: object
) {
  const result = await supertest(app)
    .post(ENDPOINTS.ORGANIZATIONS)
    .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
    .send(createRequest);
  expect([result.status, result.body]).toEqual([201, expectedTenant]);

  // note: technically this is a violation of Arrange Act Assert
  const organizationId = result.body.id;
  const actualProviders = await OrganizationAuthProvider.findByOrganizationId(
    organizationId
  );
  const expectedProvider = getExpectedTenantAuthProviders(organizationId);
  expect(actualProviders).toEqual(expectedProvider);
}
