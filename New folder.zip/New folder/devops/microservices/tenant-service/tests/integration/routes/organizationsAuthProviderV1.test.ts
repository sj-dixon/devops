import config from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities } from '@alcumus/globals';
import { ENVIRONMENT } from './keycloakTestHelpers';
import supertest from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { Tenant } from '../../../src/models/tenant';
import {
  CreateCustomApiAuthProviderRequest,
  OrganizationAuthProviderType,
  TenantTypeCode,
} from '../../../src/types';
import { OrganizationAuthProvider } from '../../../src/models/organizationAuthProvider';
import {
  createOrganization,
  generateRandomNumber,
  getExpectedApiAuthProvider,
} from './testHelpers';

describe('/api/v1/organizations/:organizationIdentifier/authProviders', () => {
  let knex: Knex;
  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(config);
    Model.knex(knex);
  });
  afterAll(async () => {
    await knex.destroy();
  });

  describe('GET /', () => {
    it('When given no API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders`)
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });
    it('When given non-existent identifier, Should return 404 response with empty body', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with id 999999.`,
        },
      ]);
    });

    it('When given real identifier, Should return 200 with auth provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const authProvider =
        await OrganizationAuthProvider.createManagedAuthProvider(
          organization.id,
          `Prefix.${tenantIdentifier}_`,
          OrganizationAuthProviderType.KEYCLOAK
        );
      const response = await supertest(app)
        .get(`${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, [authProvider]]);
    });
  });

  describe('GET /:providerName', () => {
    it('When given no API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.ORGANIZATIONS}/9999999/authProviders/somethingMadeUp`)
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });
    it('When given non-existent identifier, Should return 404 response with empty body', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.ORGANIZATIONS}/9999999/authProviders/somethingMadeUp`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with id 9999999.`,
        },
      ]);
    });

    it('When given invalid provider name, Should return 404 with descriptive error', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders/somethingMadeUp`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find auth provider for organization identified by ${tenantIdentifier} and provider name somethingMadeUp.`,
        },
      ]);
    });

    it('When given real identifier, Should return 200 with auth provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const authProvider =
        await OrganizationAuthProvider.createManagedAuthProvider(
          organization.id,
          `Prefix.${tenantIdentifier}_`,
          OrganizationAuthProviderType.KEYCLOAK
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders/${OrganizationAuthProviderType.KEYCLOAK}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });

    it('when given custom api provider name, should return custom api provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: tenantIdentifier,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const authProviderDetails = {
        callbackUrl: 'http://chaos.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'CHAOS',
      };
      const authProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          authProviderDetails
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders/${authProviderDetails.authProviderName}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });
  });

  describe('POST /', () => {
    it('When given no API key, Should return 401 response', async () => {
      const authProviderDetails = {
        callbackUrl: 'dont care',
        apiTokenHeaderValue: 'dont care',
        apiTokenHeaderName: 'dont care',
        authProviderName: 'dont care',
      };
      const response = await supertest(app)
        .post(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders`)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When given invalid API key, Should return 401 response', async () => {
      const authProviderDetails = {
        callbackUrl: 'dont care',
        apiTokenHeaderValue: 'dont care',
        apiTokenHeaderName: 'dont care',
        authProviderName: 'dont care',
      };
      const response = await supertest(app)
        .post(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders`)
        .set('x-api-key', 'dont care')
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });
    it('When given empty body, Should return 400 response', async () => {
      const response = await supertest(app)
        .post(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send({});
      expect([response.status, response.body]).toEqual([
        400,
        {
          errors: {
            apiTokenHeaderName: {
              key: 'organization.authProvider.put.requireApiTokenHeaderName',
              message:
                'organization.authProvider.put.requireApiTokenHeaderName',
            },
            apiTokenHeaderValue: {
              key: 'organization.authProvider.put.requireApiTokenHeaderValue',
              message:
                'organization.authProvider.put.requireApiTokenHeaderValue',
            },
            authProviderName: {
              key: 'organization.authProvider.put.requireAuthProviderName',
              message: 'organization.authProvider.put.requireAuthProviderName',
            },
            callbackUrl: {
              key: 'organization.authProvider.put.requireCallbackUrl',
              message: 'organization.authProvider.put.requireCallbackUrl',
            },
          },
        },
      ]);
    });

    it('When given non-existent id, Should return 404 response with empty body', async () => {
      const authProviderDetails = {
        callbackUrl: 'http://dontcare.com',
        apiTokenHeaderValue: 'dont care',
        apiTokenHeaderName: 'dont care',
        authProviderName: 'dont care',
      };
      const response = await supertest(app)
        .post(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with id 999999.`,
        },
      ]);
    });

    it('When given api key and valid request body, Should return 201 response with created entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
      };
      const organization = await createOrganization(tenantIdentifier);
      const response = await postAuthProvider(
        organization,
        authProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        201,
        getExpectedApiAuthProvider(organization.id, authProviderDetails),
      ]);
    });

    it('When given api key and valid request body and api provider type, Should return 201 response with created entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
        authProviderType: OrganizationAuthProviderType.API,
      };
      const organization = await createOrganization(tenantIdentifier);
      const response = await postAuthProvider(
        organization,
        authProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        201,
        getExpectedApiAuthProvider(organization.id, authProviderDetails),
      ]);
    });

    it('When you create the same auth provider twice, Should return 409 response', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
        authProviderType: OrganizationAuthProviderType.API,
      };
      const organization = await createOrganization(tenantIdentifier);
      await postAuthProvider(organization, authProviderDetails);
      const shouldBeConflict = await postAuthProvider(
        organization,
        authProviderDetails
      );
      expect([shouldBeConflict.status, shouldBeConflict.body]).toEqual([
        409,
        {
          message: 'Already have auth provider by that name',
        },
      ]);
    });

    it('When given api key and valid request body and sso provider type, Should return 201 response with created entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
        authProviderType: OrganizationAuthProviderType.EXTERNAL,
      };
      const organization = await createOrganization(tenantIdentifier);
      const response = await postAuthProvider(
        organization,
        authProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        201,
        getExpectedApiAuthProvider(organization.id, authProviderDetails),
      ]);
    });
  });

  describe('PUT /:providerName', () => {
    it('When given empty body, Should return 400 response', async () => {
      const response = await supertest(app)
        .put(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders/madeUp`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send({});
      expect([response.status, response.body]).toEqual([
        400,
        {
          errors: {
            apiTokenHeaderName: {
              key: 'organization.authProvider.put.requireApiTokenHeaderName',
              message:
                'organization.authProvider.put.requireApiTokenHeaderName',
            },
            apiTokenHeaderValue: {
              key: 'organization.authProvider.put.requireApiTokenHeaderValue',
              message:
                'organization.authProvider.put.requireApiTokenHeaderValue',
            },
            callbackUrl: {
              key: 'organization.authProvider.put.requireCallbackUrl',
              message: 'organization.authProvider.put.requireCallbackUrl',
            },
            authProviderName: {
              key: 'organization.authProvider.put.requireAuthProviderName',
              message: 'organization.authProvider.put.requireAuthProviderName',
            },
          },
        },
      ]);
    });

    it('When given no API key, Should return 401 response', async () => {
      const authProviderDetails = {
        callbackUrl: 'dont care',
        apiTokenHeaderValue: 'dont care',
        apiTokenHeaderName: 'dont care',
        authProviderName: 'dont care',
      };
      const response = await supertest(app)
        .put(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders/madeUp`)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When given invalid api key, Should return 400 response', async () => {
      const response = await supertest(app)
        .put(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders/madeUp`)
        .set('x-api-key', 'dont care')
        .send({});
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('When given non-existent id, Should return 404 response with empty body', async () => {
      const authProviderDetails = {
        callbackUrl: 'http://dontcare.com',
        apiTokenHeaderValue: 'dont care',
        apiTokenHeaderName: 'dont care',
        authProviderName: 'dont care',
      };
      const response = await supertest(app)
        .put(`${ENDPOINTS.ORGANIZATIONS}/999999/authProviders/madeUp`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with id 999999.`,
        },
      ]);
    });

    it('When asking to modify KEYCLOAK, Should return 403 response', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
      };
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const response = await supertest(app)
        .put(
          `${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders/${OrganizationAuthProviderType.KEYCLOAK}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        403,
        {
          message:
            'This endpoint forbids modifying and/or overloading auth providers for managed auth solutions.',
        },
      ]);
    });

    it('When given api key and valid request body, Should return 200 response with created entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
      };
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const response = await putAuthProvider(organization, authProviderDetails);
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(organization.id, authProviderDetails),
      ]);
    });

    it('When given api key and valid request body with api type, Returns 200 response with created entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
        authProviderType: OrganizationAuthProviderType.EXTERNAL,
      };
      const organization = await createOrganization(tenantIdentifier);
      const response = await putAuthProvider(organization, authProviderDetails);
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(organization.id, authProviderDetails),
      ]);
    });

    it('When attempting to overload AZURE AD, Should return 403 response', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const originalAuthProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          {
            callbackUrl: 'http://secretlair.inc/validate?q=something',
            apiTokenHeaderName: 'x-secret-header2',
            apiTokenHeaderValue: 'x-secret-val2',
            authProviderName: 'THANOS',
          }
        );
      const updatedAuthProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: OrganizationAuthProviderType.AZURE_AD,
      };
      const response = await supertest(app)
        .put(
          `${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders/${originalAuthProvider.authProviderName}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(updatedAuthProviderDetails);
      expect([response.status, response.body]).toEqual([
        403,
        {
          message:
            'This endpoint forbids modifying and/or overloading auth providers for managed auth solutions.',
        },
      ]);
    });

    it('When given api key and valid request body, Should return 200 response with updated entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const originalAuthProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          {
            callbackUrl: 'http://secretlair.inc/validate?q=something',
            apiTokenHeaderName: 'x-secret-header2',
            apiTokenHeaderValue: 'x-secret-val2',
            authProviderName: 'THANOS',
          }
        );
      const updatedAuthProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'AVENGERS',
      };
      const response = await supertest(app)
        .put(
          `${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders/${originalAuthProvider.authProviderName}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(updatedAuthProviderDetails);
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(organization.id, updatedAuthProviderDetails),
      ]);
    });
  });
});

async function postAuthProvider(
  organization: Tenant,
  authProviderDetails: CreateCustomApiAuthProviderRequest
) {
  return supertest(app)
    .post(`${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders`)
    .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
    .send(authProviderDetails);
}

async function putAuthProvider(
  organization: Tenant,
  authProviderDetails: CreateCustomApiAuthProviderRequest
) {
  return supertest(app)
    .put(
      `${ENDPOINTS.ORGANIZATIONS}/${organization.id}/authProviders/${authProviderDetails.authProviderName}`
    )
    .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
    .send(authProviderDetails);
}
