import config from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities } from '@alcumus/globals';
import { ENVIRONMENT } from './keycloakTestHelpers';
import supertest from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { Tenant } from '../../../src/models/tenant';
import {
  OrganizationAuthProviderType,
  TenantTypeCode,
} from '../../../src/types';
import { OrganizationAuthProvider } from '../../../src/models/organizationAuthProvider';

describe('/api/v1/auth', () => {
  let knex: Knex;
  beforeAll(() => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    knex = connectToKnex(config);
    Model.knex(knex);
  });
  afterAll(async () => {
    await knex.destroy();
  });

  describe('GET /:organizationIdentifier/authProviders', () => {
    it('When given no API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/somethingMadeUp/authProviders`)
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });
    it('When given non-existent identifier, Should return 404 response with empty body', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/somethingMadeUp/authProviders`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with identifier somethingMadeUp.`,
        },
      ]);
    });

    it('When given real identifier, Should return 200 with auth provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const authProvider =
        await OrganizationAuthProvider.createManagedAuthProvider(
          organization.id,
          `Prefix.${tenantIdentifier}_`,
          OrganizationAuthProviderType.KEYCLOAK
        );
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/${tenantIdentifier}/authProviders`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, [authProvider]]);
    });
  });

  describe('GET /:organizationIdentifier/:providerName', () => {
    it('When given no API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/somethingMadeUp/authProviders/alsoMadeUp`)
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });
    it('When given non-existent identifier, Should return 404 response with empty body', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/somethingMadeUp/authProviders/alsoMadeUp`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with identifier somethingMadeUp.`,
        },
      ]);
    });

    it('When given invalid provider name, Should return 404 with descriptive error', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH}/${tenantIdentifier}/authProviders/somethingMadeUp`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find auth provider for organization identified by ${tenantIdentifier} and provider name somethingMadeUp.`,
        },
      ]);
    });

    it('When given real identifier, Should return 200 with auth provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const authProvider =
        await OrganizationAuthProvider.createManagedAuthProvider(
          organization.id,
          `Prefix.${tenantIdentifier}_`,
          OrganizationAuthProviderType.KEYCLOAK
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH}/${tenantIdentifier}/authProviders/${OrganizationAuthProviderType.KEYCLOAK}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });

    it('when given custom api provider name, should return custom api provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantName: tenantIdentifier,
          tenantIdentifier,
        },
        null
      );
      const authProviderDetails = {
        callbackUrl: 'http://chaos.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'CHAOS',
      };
      const authProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          authProviderDetails
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH}/${tenantIdentifier}/authProviders/${authProviderDetails.authProviderName}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });
  });

  describe('GET /:organizationIdentifier', () => {
    it('When given no API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/somethingMadeUp`)
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });
    it('When given non-existent identifier, Should return 404 response with empty body', async () => {
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/somethingMadeUp`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with identifier somethingMadeUp.`,
        },
      ]);
    });

    it('When given real identifier, Should return 200 with organization', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: `${tenantIdentifier} Inc`,
        },
        null,
        undefined
      );
      const response = await supertest(app)
        .get(`${ENDPOINTS.AUTH}/${tenantIdentifier}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, organization]);
    });
  });
});

function generateRandomNumber(): number {
  return Math.floor(Math.random() * 100000);
}
