import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

export const mockAxios = new MockAdapter(axios);

export const ENVIRONMENT = {
  KEYCLOAK_SERVER_URL: 'http://secret-lair:8080/auth',
  KEYCLOAK_SERVER_REALM: 'secret-realm',
  KEYCLOAK_ADMIN_ID: 'secret-cli',
  KEYCLOAK_ADMIN_SECRET: '9012cf7e-e4d3-4e38-9186-93973f5c5326',
  KEYCLOAK_CLIENT_ID: 'regular-cli',
  KEYCLOAK_CLIENT_SECRET: 'banana split',
  SERVICE_MESH_HOST: 'https://secret-cloud:5000/api',
  SERVICE_MESH_API_KEY: 'carbonated ice cream',
  FEATURE_TOGGLE_USE_LINKERD: 'true',
};

export function setupAxiosInterceptors(): void {
  axios.interceptors.request.use((config) => {
    console.log(
      `${config.method} ${config.url} ${JSON.stringify(
        config.params || config.data
      )}`
    );
    return config;
  });
}
