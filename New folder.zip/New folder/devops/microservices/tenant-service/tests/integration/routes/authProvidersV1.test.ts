import config from '../../../src/lib/clients/knex/config';
import connectToKnex, { Knex } from 'knex';
import { Model } from 'objection';
import { Utilities } from '@alcumus/globals';
import { ENVIRONMENT } from './keycloakTestHelpers';
import supertest from 'supertest';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { Tenant } from '../../../src/models/tenant';
import {
  CreateCustomApiAuthProviderRequest,
  OrganizationAuthProviderType,
  TenantTypeCode,
} from '../../../src/types';
import { OrganizationAuthProvider } from '../../../src/models/organizationAuthProvider';
import { Messages } from '../../../src/messages';
import {
  createOrganization,
  generateRandomNumber,
  getExpectedApiAuthProvider,
} from './testHelpers';
import { v4 as uuidV4 } from 'uuid';
import {
  STUB_AZURE_AD_PROVIDER,
  STUB_KEYCLOAK_PROVIDER,
} from '../../../src/controllers/authProviderController';

let knex: Knex;
let rootOrganization: Tenant;
let rootTenantIdentifier: string;

beforeAll(() => {
  knex = connectToKnex(config);
  Model.knex(knex);
});

afterAll(async () => {
  await knex.destroy();
});

describe('/api/v1/authProviders', () => {
  beforeEach(async () => {
    rootTenantIdentifier = uuidV4();
    Utilities.ProcessEnv.overrideEnv({
      ...ENVIRONMENT,
      TENANT_SERVICE_ROOT_TENANT_IDENTIFIER: rootTenantIdentifier,
    });

    rootOrganization = await createOrganization(
      rootTenantIdentifier,
      TenantTypeCode.ADMIN_ORGANIZATION
    );
  });

  describe('POST /', () => {
    it('When given no API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .post(ENDPOINTS.AUTH_PROVIDERS)
        .send({});
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When given invalid API key, Should return 401 response', async () => {
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: uuidV4(),
        authProviderType: OrganizationAuthProviderType.API,
      };
      const response = await supertest(app)
        .post(ENDPOINTS.AUTH_PROVIDERS)
        .set('x-api-key', 'somethingMadeUp')
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('When given empty body, Should return 400 response', async () => {
      const response = await supertest(app)
        .post(ENDPOINTS.AUTH_PROVIDERS)
        .set('x-api-key', 'dont care')
        .send({});
      expect([response.status, response.body]).toEqual([
        400,
        {
          message:
            "request.body should have required property 'callbackUrl', request.body should have required property 'authProviderName', request.body should have required property 'apiTokenHeaderName', request.body should have required property 'apiTokenHeaderValue'",
        },
      ]);
    });

    it('Returns 403 when creating global managed provider', async () => {
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: OrganizationAuthProviderType.KEYCLOAK,
      };
      const response = await supertest(app)
        .post(ENDPOINTS.AUTH_PROVIDERS)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        403,
        {
          message: Messages.CannotModifyManagedAuthProviders,
        },
      ]);
    });

    it('When given api key and valid request body and api provider type, Should return 201 response with created entity', async () => {
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: uuidV4(),
        authProviderType: OrganizationAuthProviderType.API,
      };
      const response = await supertest(app)
        .post(ENDPOINTS.AUTH_PROVIDERS)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        201,
        getExpectedApiAuthProvider(rootOrganization.id, authProviderDetails),
      ]);
    });

    it('When api provider is created twice, Should return 409 response', async () => {
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: uuidV4(),
        authProviderType: OrganizationAuthProviderType.API,
      };
      // create once
      await supertest(app)
        .post(ENDPOINTS.AUTH_PROVIDERS)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      // create same thing a second time
      const conflictingResponse = await supertest(app)
        .post(ENDPOINTS.AUTH_PROVIDERS)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([conflictingResponse.status, conflictingResponse.body]).toEqual([
        409,
        { message: 'Already have auth provider by that name' },
      ]);
    });
  });

  describe('GET /:providerName', () => {
    it('When given no API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/somethingMadeUp?organizationIdentifier=alsoMadeUp`
        )
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When given invalid API key, Should return 401 response', async () => {
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/somethingMadeUp?organizationIdentifier=alsoMadeUp`
        )
        .set('x-api-key', 'somethingMadeUp')
        .send();
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('Returns 200 stub when querying global keycloak provider', async () => {
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/${OrganizationAuthProviderType.KEYCLOAK}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        200,
        STUB_KEYCLOAK_PROVIDER,
      ]);
    });

    it('Returns 200 stub when querying global azuread provider', async () => {
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/${OrganizationAuthProviderType.AZURE_AD}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        200,
        STUB_AZURE_AD_PROVIDER,
      ]);
    });
  });

  describe('GET /:providerName?organizationIdentifier=:identifier', () => {
    it('When given non-existent identifier, Should return 404 response with empty body', async () => {
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/fakeName?organizationIdentifier=somethingMadeUp`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with identifier somethingMadeUp.`,
        },
      ]);
    });

    it('When given invalid provider name, Should return 404 with descriptive error', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/somethingMadeUp?organizationIdentifier=${tenantIdentifier}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find auth provider for organization identified by ${tenantIdentifier} and provider name somethingMadeUp.`,
        },
      ]);
    });

    it('When given real identifier, Should return 200 with auth provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const providerName = OrganizationAuthProviderType.KEYCLOAK;
      const authProvider =
        await OrganizationAuthProvider.createManagedAuthProvider(
          organization.id,
          `Prefix.${tenantIdentifier}_`,
          providerName
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/${providerName}?organizationIdentifier=${tenantIdentifier}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });

    it('when given custom api provider name, should return custom api provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantName: tenantIdentifier,
          tenantIdentifier,
        },
        null
      );
      const authProviderDetails = {
        callbackUrl: 'http://chaos.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'CHAOS',
      };
      const authProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          authProviderDetails
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/${authProviderDetails.authProviderName}?organizationIdentifier=${tenantIdentifier}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });
  });

  describe('GET /:providerName?organizationId=:id', () => {
    it('When given non-existent identifier, Should return 404 response with empty body', async () => {
      const organizationId = generateRandomNumber();
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/fakeName?organizationId=${organizationId}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with id ${organizationId}.`,
        },
      ]);
    });

    it('When given invalid provider name, Should return 404 with descriptive error', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const providerName = 'somethingMadeUp';
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/${providerName}?organizationId=${organization.id}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find auth provider for organization identified by ${tenantIdentifier} and provider name ${providerName}.`,
        },
      ]);
    });

    it('When given real identifier, Should return 200 with auth provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.query().insert({
        tenantIdentifier,
        tenantName: `${tenantIdentifier} Inc`,
        tenantTypeCode: TenantTypeCode.ORGANIZATION,
        parentTenantId: null,
      });
      const providerName = OrganizationAuthProviderType.KEYCLOAK;
      const authProvider =
        await OrganizationAuthProvider.createManagedAuthProvider(
          organization.id,
          `Prefix.${tenantIdentifier}_`,
          providerName
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/${providerName}?organizationId=${organization.id}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });

    it('when given custom api provider name, should return custom api provider', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantName: tenantIdentifier,
          tenantIdentifier,
        },
        null
      );
      const authProviderDetails = {
        callbackUrl: 'http://chaos.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'CHAOS',
      };
      const authProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          authProviderDetails
        );
      const response = await supertest(app)
        .get(
          `${ENDPOINTS.AUTH_PROVIDERS}/${authProviderDetails.authProviderName}?organizationId=${organization.id}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send();
      expect([response.status, response.body]).toEqual([200, authProvider]);
    });
  });

  describe('PUT /:providerName', () => {
    it('When given empty body, Should return 400 response', async () => {
      const response = await supertest(app)
        .put(`${ENDPOINTS.AUTH_PROVIDERS}/neverRead`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send({});
      expect([response.status, response.body]).toEqual([
        400,
        {
          errors: {
            apiTokenHeaderName: {
              key: 'organization.authProvider.put.requireApiTokenHeaderName',
              message:
                'organization.authProvider.put.requireApiTokenHeaderName',
            },
            apiTokenHeaderValue: {
              key: 'organization.authProvider.put.requireApiTokenHeaderValue',
              message:
                'organization.authProvider.put.requireApiTokenHeaderValue',
            },
            callbackUrl: {
              key: 'organization.authProvider.put.requireCallbackUrl',
              message: 'organization.authProvider.put.requireCallbackUrl',
            },
            authProviderName: {
              key: 'organization.authProvider.put.requireAuthProviderName',
              message: 'organization.authProvider.put.requireAuthProviderName',
            },
          },
        },
      ]);
    });

    it('When given no API key, Should return 401 response', async () => {
      const authProviderDetails = {
        callbackUrl: 'dont care',
        apiTokenHeaderValue: 'dont care',
        apiTokenHeaderName: 'dont care',
        authProviderName: 'dont care',
      };
      const response = await supertest(app)
        .put(`${ENDPOINTS.AUTH_PROVIDERS}/neverRead`)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: "'x-api-key' header required",
        },
      ]);
    });

    it('When given invalid api key, Should return 400 response', async () => {
      const response = await supertest(app)
        .put(`${ENDPOINTS.AUTH_PROVIDERS}/neverRead`)
        .set('x-api-key', 'dont care')
        .send({});
      expect([response.status, response.body]).toEqual([
        401,
        {
          message: 'x-api-key header has an incorrect api key',
        },
      ]);
    });

    it('When given non-existent id, Should return 404 response with empty body', async () => {
      const authProviderDetails = {
        callbackUrl: 'http://dontcare.com',
        apiTokenHeaderValue: 'dont care',
        apiTokenHeaderName: 'dont care',
        authProviderName: 'dont care',
      };
      const response = await supertest(app)
        .put(`${ENDPOINTS.AUTH_PROVIDERS}/neverRead?organizationId=999999`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        404,
        {
          message: `Could not find organization with id 999999.`,
        },
      ]);
    });

    it('When asking to modify KEYCLOAK, Should return 403 response', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
      };
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const response = await supertest(app)
        .put(
          `${ENDPOINTS.AUTH_PROVIDERS}/${OrganizationAuthProviderType.KEYCLOAK}?organizationId=${organization.id}`
        )
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .send(authProviderDetails);
      expect([response.status, response.body]).toEqual([
        403,
        {
          message:
            'This endpoint forbids modifying and/or overloading auth providers for managed auth solutions.',
        },
      ]);
    });

    it('When given api key and valid request body, Should return 200 response with created entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
      };
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const response = await updateOrganizationAuthProvider(
        organization,
        authProviderDetails.authProviderName,
        authProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(organization.id, authProviderDetails),
      ]);
    });

    it('When given api key and valid request body with external type, Returns 200 response with created entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const authProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'THANOS',
        authProviderType: OrganizationAuthProviderType.EXTERNAL,
      };
      const organization = await createOrganization(tenantIdentifier);
      const response = await updateOrganizationAuthProvider(
        organization,
        authProviderDetails.authProviderName,
        authProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(organization.id, authProviderDetails),
      ]);
    });

    it('When attempting to overload AZURE AD, Should return 403 response', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const originalAuthProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          {
            callbackUrl: 'http://secretlair.inc/validate?q=something',
            apiTokenHeaderName: 'x-secret-header2',
            apiTokenHeaderValue: 'x-secret-val2',
            authProviderName: 'THANOS',
          }
        );
      const updatedAuthProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: OrganizationAuthProviderType.AZURE_AD,
      };
      const response = await updateOrganizationAuthProvider(
        organization,
        originalAuthProvider.authProviderName,
        updatedAuthProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        403,
        {
          message:
            'This endpoint forbids modifying and/or overloading auth providers for managed auth solutions.',
        },
      ]);
    });

    it('When given api key and valid request body, Should return 200 response with updated entity', async () => {
      const tenantIdentifier = `AuthV1Test.${generateRandomNumber()}`;
      const organization = await Tenant.createOrganization(
        {
          tenantIdentifier,
          tenantName: tenantIdentifier,
        },
        null
      );
      const originalAuthProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          organization.id,
          {
            callbackUrl: 'http://secretlair.inc/validate?q=something',
            apiTokenHeaderName: 'x-secret-header2',
            apiTokenHeaderValue: 'x-secret-val2',
            authProviderName: 'THANOS',
          }
        );
      const updatedAuthProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'AVENGERS',
      };
      const response = await updateOrganizationAuthProvider(
        organization,
        originalAuthProvider.authProviderName,
        updatedAuthProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(organization.id, updatedAuthProviderDetails),
      ]);
    });

    it('When given api key and global auth provider, Should return 200 response with inserted entity', async () => {
      const providerDetails = {
        callbackUrl: 'http://secretlair.inc/validate?q=something',
        apiTokenHeaderName: 'x-secret-header2',
        apiTokenHeaderValue: 'x-secret-val2',
        authProviderName: 'THANOS',
      };
      const response = await updateOrganizationAuthProvider(
        null,
        providerDetails.authProviderName,
        providerDetails
      );
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(rootOrganization.id, providerDetails),
      ]);
    });

    it('When given api key and global auth provider, Should return 200 response with updated entity', async () => {
      const originalAuthProvider =
        await OrganizationAuthProvider.createCustomAuthProvider(
          rootOrganization.id,
          {
            callbackUrl: 'http://secretlair.inc/validate?q=something',
            apiTokenHeaderName: 'x-secret-header2',
            apiTokenHeaderValue: 'x-secret-val2',
            authProviderName: 'THANOS',
          }
        );
      const updatedAuthProviderDetails = {
        callbackUrl: 'http://avengers.inc/validate?q=something',
        apiTokenHeaderValue: 'my top secret value',
        apiTokenHeaderName: 'x-secret-header',
        authProviderName: 'AVENGERS',
      };
      const response = await updateOrganizationAuthProvider(
        null,
        originalAuthProvider.authProviderName,
        updatedAuthProviderDetails
      );
      expect([response.status, response.body]).toEqual([
        200,
        getExpectedApiAuthProvider(
          rootOrganization.id,
          updatedAuthProviderDetails
        ),
      ]);
    });
  });
});

async function updateOrganizationAuthProvider(
  organization: Tenant | null,
  authProviderName: string,
  authProviderDetails: CreateCustomApiAuthProviderRequest
) {
  const organizationId = organization?.id;
  const url = organizationId
    ? `${ENDPOINTS.AUTH_PROVIDERS}/${authProviderName}?organizationId=${organizationId}`
    : `${ENDPOINTS.AUTH_PROVIDERS}/${authProviderName}`;

  return supertest(app)
    .put(url)
    .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
    .send(authProviderDetails);
}
