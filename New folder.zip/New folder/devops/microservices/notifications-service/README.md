# Notifications Service

## REST Endpoints
Please refer to the API Spec for detailed description about endpoints.

## General Architecture & important components

The notifications service has the following components, and all of them need to be running for the service to work:

- Admin API: Allows you to provision notifications service so that you can create Senders and Consumers
- REST API: Allows you to queue notifications
- Worker: Listens on the queue and sends notification using the underlying transport mechanism 

## How to run the service

Admin API and REST API: `npm run start`
Worker: `npm run start-worker`

All emails sent currently are sent to a mailhog instance by default, which is accessible at 
`http://localhost:8000/mailhog` OR
`https://wildbreeze-qa01.ecompliance.com/mailhog`
