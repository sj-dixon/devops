import {
  BaseKnexEntityModel,
  JsonSchemaBuilder,
  SoftDeletableKnexEntity,
} from '@alcumus/objection-lib';
import { Model, Pojo } from 'objection';
import { simpleCipher } from '../singletons/simpleCipher';
import Consumer from './consumer';
import { ChannelConfig } from '../types';
export default class Sender
  extends BaseKnexEntityModel
  implements SoftDeletableKnexEntity
{
  name!: string;

  deletedAt?: Date;
  deletedBy?: number;

  channelConfigs?: Buffer;

  static tableName = 'senders';

  static relationMappings = () => ({
    apps: {
      relation: Model.HasManyRelation,
      modelClass: Consumer,
      join: {
        from: 'senders.id',
        to: 'consumers.senderId',
      },
    },
  });

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withCreatedByAtFields()
    .withModifiedByAtFields()
    .isSoftDeletable()
    .build();

  getChannelConfigs(): ChannelConfig[] {
    if (!this.channelConfigs) {
      throw new Error('channelConfigs is empty');
    }
    return JSON.parse(
      simpleCipher.decrypt(this.channelConfigs).toString('utf8')
    );
  }

  static encryptChannelConfigs(channelConfigs: ChannelConfig[]) {
    return simpleCipher.encrypt(
      Buffer.from(JSON.stringify(channelConfigs), 'utf8')
    );
  }

  $formatJson(json: Pojo): Pojo {
    json = super.$formatJson(json);
    delete json.channelConfigs;
    return json;
  }
}
