import {
  BaseKnexEntityModel,
  JsonSchemaBuilder,
  SoftDeletableKnexEntity,
} from '@alcumus/objection-lib';
import { Model, Pojo } from 'objection';
import Sender from './sender';

export default class Consumer
  extends BaseKnexEntityModel
  implements SoftDeletableKnexEntity
{
  name!: string;

  deletedAt?: Date;
  deletedBy?: number;

  senderId?: string;
  apiKey?: string;

  static tableName = 'consumers';

  static relationMappings = () => ({
    sender: {
      relation: Model.HasOneRelation,
      modelClass: Sender,
      join: {
        from: 'consumers.senderId',
        to: 'senders.id',
      },
    },
  });

  $formatJson(json: Pojo): Pojo {
    json = super.$formatJson(json);
    delete json.apiKey;
    return json;
  }

  static jsonSchema = JsonSchemaBuilder.newBuilder()
    .withCreatedByAtFields()
    .withModifiedByAtFields()
    .isSoftDeletable()
    .build();
}
