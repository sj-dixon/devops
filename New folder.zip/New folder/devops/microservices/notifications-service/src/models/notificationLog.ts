import { Model } from 'objection';
import Consumer from './consumer';

export class NotificationLog extends Model {
  static STATUS_QUEUED = 'queued';
  static STATUS_SENT = 'sent';
  static STATUS_FAILED = 'failed';

  id!: string;

  createdAt?: Date;
  createdBy?: string;

  modifiedAt?: Date;
  modifiedBy?: string;

  deletedAt?: Date;
  deletedBy?: string;

  payload?: Object;
  channel?: string;

  status?: string;

  consumerId?: number;

  static tableName = 'notification_logs';

  static get jsonAttributes() {
    return ['payload'];
  }

  static relationMappings = {
    consumer: {
      relation: Model.HasOneRelation,
      modelClass: Consumer,
      join: {
        from: 'notification_logs.consumer_id',
        to: 'consumers.id',
      },
    },
  };

  // static jsonSchema = JsonSchemaBuilder.newBuilder()
  //   .withCreatedByAtFields()
  //   .withModifiedByAtFields()
  //   .isSoftDeletable()
  //   .build();
}
