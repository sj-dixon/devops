import { Knex } from 'knex';

export const SENDERS_TABLE = 'senders';

const COLUMN = 'channel_configs';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    SENDERS_TABLE,
    (tableBuilder: Knex.TableBuilder) => {
      tableBuilder.dropColumn(COLUMN);
    }
  );
  await knex.schema.alterTable(
    SENDERS_TABLE,
    (tableBuilder: Knex.TableBuilder) => {
      tableBuilder.binary(COLUMN);
    }
  );
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  await knex.schema.alterTable(
    SENDERS_TABLE,
    (tableBuilder: Knex.TableBuilder) => {
      tableBuilder.dropColumn(COLUMN);
    }
  );
  await knex.schema.alterTable(
    SENDERS_TABLE,
    (tableBuilder: Knex.TableBuilder) => {
      tableBuilder.json(COLUMN);
    }
  );
}
