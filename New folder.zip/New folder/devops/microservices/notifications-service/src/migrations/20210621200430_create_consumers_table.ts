import { Knex } from 'knex';
import { SENDERS_TABLE } from './20210621200421_create_senders_table';

export const CONSUMERS_TABLE = 'consumers';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    CONSUMERS_TABLE,
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.increments('id').primary();

      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      tableBuilder.string('name');
      tableBuilder.string('api_key').unique();

      tableBuilder.string('created_by');
      tableBuilder.string('modified_by');

      tableBuilder
        .integer('sender_id')
        .unsigned()
        .notNullable()
        .references('id')
        .inTable(SENDERS_TABLE);

      // soft deletion
      tableBuilder.timestamp('deleted_at').nullable();
      tableBuilder.string('deleted_by').nullable();
    }
  );
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(CONSUMERS_TABLE);
}
