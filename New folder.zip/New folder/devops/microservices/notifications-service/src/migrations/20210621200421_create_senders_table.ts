import { Knex } from 'knex';

export const SENDERS_TABLE = 'senders';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    SENDERS_TABLE,
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.increments('id').primary();

      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      tableBuilder.string('name');

      tableBuilder.string('created_by');
      tableBuilder.string('modified_by');

      tableBuilder.json('channel_configs');

      // soft deletion
      tableBuilder.timestamp('deleted_at').nullable();
      tableBuilder.string('deleted_by').nullable();
    }
  );
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(SENDERS_TABLE);
}
