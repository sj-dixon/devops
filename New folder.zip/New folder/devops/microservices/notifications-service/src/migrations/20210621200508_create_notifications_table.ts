import { Knex } from 'knex';
import { CONSUMERS_TABLE } from './20210621200430_create_consumers_table';

const NOTIFICATION_LOGS_TABLE = 'notification_logs';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(
    NOTIFICATION_LOGS_TABLE,
    (tableBuilder: Knex.CreateTableBuilder) => {
      tableBuilder.uuid('id').primary();
      tableBuilder
        .timestamp('created_at')
        .notNullable()
        .defaultTo(knex.fn.now());
      tableBuilder
        .timestamp('modified_at')
        .notNullable()
        .defaultTo(knex.fn.now());

      tableBuilder.string('channel').notNullable();
      tableBuilder.json('payload').notNullable();

      tableBuilder.string('status').defaultTo('queued').notNullable();
      tableBuilder.timestamp('sent_at');

      tableBuilder
        .integer('consumer_id')
        .unsigned()
        .notNullable()
        .references('id')
        .inTable(CONSUMERS_TABLE);
    }
  );
}

// noinspection JSUnusedGlobalSymbols
export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTableIfExists(NOTIFICATION_LOGS_TABLE);
}
