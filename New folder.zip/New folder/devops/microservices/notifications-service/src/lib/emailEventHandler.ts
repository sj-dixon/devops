import { IQueue, IQueueMessage } from '@alcumus/queue-lib';
import { EmailQueueMessage } from '../types';
import { NodeMailerTransport, sendEmail } from './clients/nodemailer';

type EmailListener = (
  message: IQueueMessage<EmailQueueMessage>
) => Promise<void>;

export function getEmailEventHandler(
  queue: IQueue<EmailQueueMessage>,
  transport: NodeMailerTransport
): EmailListener {
  return async (message: IQueueMessage<EmailQueueMessage>) => {
    console.info(
      `${message.content.subject}, to: '${message.content.recipients?.join(
        ','
      )}'`
    );
    if (message.lastRetryAt) {
      console.log(`Attempt #: ${message.retryCount + 1}`);
      console.log(
        `Last retry: ${((Date.now() - message.lastRetryAt) / 1000).toFixed(
          2
        )}s ago`
      );
    }

    const email = message.content;
    try {
      await sendEmail(transport, email);
      await queue.ack(message);
      console.log(`Acked ${message.content.id}!`);
    } catch (e) {
      console.error(`Nacking ${message.content.id}`, e);
      await queue.nack(message);
    }
  };
}
