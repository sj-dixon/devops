import Knex from 'knex';
import { Model } from 'objection';
import config from '../../../knexfile';

export default function getKnexClient() {
  const knex = Knex(config);
  Model.knex(knex);
  return knex;
}
