import nodemailer, { Transporter } from 'nodemailer';
import SMTPTransport from 'nodemailer/lib/smtp-transport';
import { Utilities } from '@alcumus/globals';
import { EmailQueueMessage } from '../../../types';

function getSmtpOptions(): SMTPTransport.Options {
  const user = Utilities.ProcessEnv.getValueOrDefault(
    'NOTIFICATIONS_SERVICE_SMTP_USER',
    ''
  );
  const hasAuth = user !== '';
  return {
    host: Utilities.ProcessEnv.getValueOrDefault(
      'NOTIFICATIONS_SERVICE_SMTP_HOST',
      'localhost'
    ),
    port: Number(
      Utilities.ProcessEnv.getValueOrDefault(
        'NOTIFICATIONS_SERVICE_SMTP_PORT',
        '1025'
      )
    ),
    auth: hasAuth
      ? {
          user,
          pass: Utilities.ProcessEnv.getValueOrDefault(
            'NOTIFICATIONS_SERVICE_SMTP_PASS',
            ''
          ),
        }
      : undefined,
    secure: Utilities.ProcessEnv.isEnabled(
      'NOTIFICATIONS_SERVICE_SMTP_ENABLE_SECURE'
    ),
  };
}

export type NodeMailerTransport = Transporter<SMTPTransport.SentMessageInfo>;

export async function createTransport(): Promise<NodeMailerTransport> {
  return nodemailer.createTransport(getSmtpOptions());
}

export async function sendEmail(
  transport: NodeMailerTransport,
  email: EmailQueueMessage
): Promise<void> {
  await transport.sendMail({
    from: `"${email.from.name}" <${email.from.email}>`,
    to: email.recipients.join(', '),
    subject: email.subject,
    text: email.text,
    html: email.html,
  });
}
