import { Knex } from 'knex';
import { Utilities } from '@alcumus/globals';
import { getKnexConfig } from '@alcumus/objection-lib';

const databaseName = Utilities.ProcessEnv.getValueOrDefault(
  'NOTIFICATIONS_SERVICE_DATABASE_NAME',
  'notifications_db'
);
const config: Knex.Config = getKnexConfig(databaseName);

export default config;
