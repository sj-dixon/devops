import { Utilities } from '@alcumus/globals';
import { IQueue, QueueFactory } from '@alcumus/queue-lib';
import { EmailQueueMessage } from '../../../types';
import {
  ASB_CONNECTION_STRING,
  EMAIL_QUEUE_NAME,
  QUEUE_CONNECTION_STRING,
} from '../../../constants';

export const emailQueue: IQueue<EmailQueueMessage> = QueueFactory('rabbitmq', {
  connectionString: QUEUE_CONNECTION_STRING,
  name: EMAIL_QUEUE_NAME,
});

export const emailQueueAzure: IQueue<EmailQueueMessage> = QueueFactory(
  'azure-service-bus',
  {
    connectionString: ASB_CONNECTION_STRING,
    name: EMAIL_QUEUE_NAME,
  }
);

export function getQueue(): IQueue<EmailQueueMessage> {
  const queueType = Utilities.ProcessEnv.getValueOrDefault(
    'NOTIFICATIONS_SERVICE_QUEUE_DRIVER',
    'rabbitmq'
  );

  let queue: IQueue<EmailQueueMessage>;
  switch (queueType) {
    case 'azure':
      queue = emailQueueAzure;
      break;
    default:
      queue = emailQueue;
      break;
  }

  return queue;
}
