import crypto, { randomBytes } from 'crypto';

function md5(data: string): string {
  const cipher = crypto.createHash('md5');
  cipher.update(data);
  return cipher.digest('hex');
}

export class SimpleCipher {
  static ALGORITHM = 'aes-128-cbc';
  static ALGORITHM_IV_SIZE = 16;

  private readonly secretKey: Buffer;

  constructor(secretKey: string) {
    this.secretKey = Buffer.from(md5(secretKey), 'hex');
  }

  encrypt(data: Buffer): Buffer {
    const initVector = randomBytes(SimpleCipher.ALGORITHM_IV_SIZE);
    const cipher = crypto.createCipheriv(
      SimpleCipher.ALGORITHM,
      this.secretKey,
      initVector
    );
    return Buffer.concat([initVector, cipher.update(data), cipher.final()]);
  }

  decrypt(data: Buffer): Buffer {
    const [initVector, encrypted] = [
      data.subarray(0, SimpleCipher.ALGORITHM_IV_SIZE),
      data.subarray(SimpleCipher.ALGORITHM_IV_SIZE),
    ];
    const cipher = crypto.createDecipheriv(
      SimpleCipher.ALGORITHM,
      this.secretKey,
      initVector
    );
    return Buffer.concat([cipher.update(encrypted), cipher.final()]);
  }
}
