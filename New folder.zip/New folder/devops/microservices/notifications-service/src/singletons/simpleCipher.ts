import { SECRET_KEY } from '../constants';
import { SimpleCipher } from '../lib/simpleCipher';

export const simpleCipher: SimpleCipher = new SimpleCipher(SECRET_KEY);
