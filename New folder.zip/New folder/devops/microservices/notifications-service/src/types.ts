export interface EmailQueueMessage {
  id: string;
  subject: string;
  recipients: [string];
  html: string;
  text: string;
  from: {
    email: string;
    name: string;
  };
}

export interface SMSQueueMessage {
  id: string;
  recipient: string;
  message: string;
}

export interface ChannelConfig {
  channel: 'email'; // | 'text' | 'push'
  driver: SMTPDriverConfig; // | TextDriverConfig
}

export interface SMTPDriverConfig {
  name: 'smtp';
  host: string;
  port: string;
  username: string;
  password: string;
}
