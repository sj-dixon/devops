import { validationHandler, expressValidator } from '@alcumus/express-app';
import Sender from '../models/sender';

export default function () {
  return [
    expressValidator.body('name').exists().isString().notEmpty(),
    expressValidator
      .body('senderId')
      .exists()
      .notEmpty()
      .custom(async (senderId) => {
        if (!(await Sender.query().findById(senderId))) {
          throw new Error();
        }
      })
      .withMessage('Invalid Sender ID'),
    validationHandler(),
  ];
}
