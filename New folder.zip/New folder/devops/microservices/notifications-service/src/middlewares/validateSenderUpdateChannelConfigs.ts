import { validationHandler, expressValidator } from '@alcumus/express-app';

export default function () {
  return [
    expressValidator.body().exists().isArray().notEmpty(),
    validationHandler(),
  ];
}
