import { Request, Response, NextFunction } from 'express';
import { MESSAGES } from '../constants';
import Consumer from '../models/consumer';

export default async function (
  req: Request,
  res: Response,
  next: NextFunction
) {
  const consumerKey: string = req.header('X-Consumer-Key') || '';

  if (!consumerKey) {
    res.status(401).send({ message: MESSAGES.CONSUMER_KEY_HEADERS_REQUIRED });
    return;
  }

  const consumer = await Consumer.query().where('apiKey', consumerKey).first();

  if (!consumer) {
    res.status(401).send({ message: MESSAGES.CONSUMER_KEY_INVALID });
    return;
  }

  res.locals.consumer = consumer;

  next();
}
