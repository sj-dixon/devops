import { validationHandler, expressValidator } from '@alcumus/express-app';

export default function () {
  return [
    expressValidator.body('name').exists().isString().notEmpty(),
    expressValidator.body('channelConfigs').exists().isArray().notEmpty(),
    validationHandler(),
  ];
}
