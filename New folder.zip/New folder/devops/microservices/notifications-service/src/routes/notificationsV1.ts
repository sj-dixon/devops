import express, { Router, Request, Response } from 'express';
import validateRequestHasValidConsumerKey from '../middlewares/validateRequestHasValidConsumerKey';
import Consumer from '../models/consumer';
import { NotificationLog } from '../models/notificationLog';
import * as uuid from 'uuid';
import { EmailQueueMessage } from '../types';
import {
  buildMetaData,
  buildResponse,
  getPaginationQueryParams,
} from '@alcumus/response-utils';
import { getQueue } from '../lib/clients/queue';

const notificationsRouterV1: Router = express.Router();
const emailQueue = getQueue();

interface CreateNotificationRequest {
  channel: string;
  payload: Object;
}

notificationsRouterV1.post(
  '/',
  validateRequestHasValidConsumerKey,
  async (request: Request, response: Response) => {
    const consumer: Consumer = response.locals.consumer;
    const notificationReq: CreateNotificationRequest = request.body;

    const id = uuid.v4();

    const notificationLogEntry = {
      id,
      payload: notificationReq.payload,
      channel: notificationReq.channel,
      status: NotificationLog.STATUS_QUEUED,
      consumerId: consumer.id,
    };

    const notification = await NotificationLog.query().insert(
      notificationLogEntry
    );
    await emailQueue.send({
      id,
      ...notificationReq.payload,
    } as EmailQueueMessage);

    response.json(notification);
  }
);

notificationsRouterV1.get(
  '/',
  validateRequestHasValidConsumerKey,
  async (request: Request, response: Response) => {
    const consumer: Consumer = response.locals.consumer;

    const {
      page = 1,
      pageSize = 10,
      skip = 0,
    } = getPaginationQueryParams(request.query);

    const baseQuery = NotificationLog.query().where('consumerId', consumer.id);

    const count = await baseQuery.resultSize();
    const result = await baseQuery.offset(skip).limit(pageSize);

    const metadata = buildMetaData({
      count,
      page,
      pageSize,
      currentPageSize: result.length,
    });
    response.status(200).json(
      buildResponse({
        response: result,
        metadata,
      })
    );
  }
);

notificationsRouterV1.get(
  '/:id',
  validateRequestHasValidConsumerKey,
  async (request: Request, response: Response) => {
    const consumer: Consumer = response.locals.consumer;

    const notification = await NotificationLog.query()
      .where('consumerId', consumer.id)
      .where('id', request.params.id)
      .first();

    if (!notification) {
      response.status(404).json({ message: 'not found' });
    } else {
      response.status(200).json(notification);
    }
  }
);

export default notificationsRouterV1;
