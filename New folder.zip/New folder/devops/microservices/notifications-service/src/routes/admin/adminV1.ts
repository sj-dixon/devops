import express, { Router } from 'express';
import { ENDPOINTS } from '../../constants';
import sendersRouterV1 from './sendersV1';
import consumersRouterV1 from './consumerV1';

const adminRouterV1: Router = express.Router();

adminRouterV1.use(ENDPOINTS.ADMIN_SENDERS, sendersRouterV1);
adminRouterV1.use(ENDPOINTS.ADMIN_CONSUMERS, consumersRouterV1);

export default adminRouterV1;
