import {
  buildMetaData,
  buildResponse,
  getPaginationQueryParams,
} from '@alcumus/response-utils';
import { randomBytes } from 'crypto';
import express, { Request, Response, Router } from 'express';
import { GENERATED_API_KEY_SIZE_BYTES } from '../../constants';
import validateConsumerCreateRequest from '../../middlewares/validateConsumerCreateRequest';
import Consumer from '../../models/consumer';

const consumersRouterV1: Router = express.Router();

interface CreateConsumerRequest {
  name: string;
  senderId: string;
}

// TODO: Protect these routes using tenant service
consumersRouterV1.post(
  '/',
  validateConsumerCreateRequest(),
  async (request: Request, response: Response) => {
    const createConsumerRequest: CreateConsumerRequest = request.body;

    // Create an API Key for our use
    const apiKey = randomBytes(GENERATED_API_KEY_SIZE_BYTES).toString('hex');

    const consumer = await Consumer.query().withGraphFetched('sender').insert({
      createdBy: 0,
      modifiedBy: 0,
      name: createConsumerRequest.name,
      senderId: createConsumerRequest.senderId,
      apiKey,
    });

    response.json({ ...consumer.toJSON(), apiKey });
  }
);

consumersRouterV1.get('/', async (request: Request, response: Response) => {
  const {
    page = 1,
    pageSize = 10,
    skip = 0,
  } = getPaginationQueryParams(request.query);

  const baseQuery = Consumer.query().withGraphFetched('sender');

  const count = await baseQuery.resultSize();
  const result = await baseQuery.offset(skip).limit(pageSize);

  const metadata = buildMetaData({
    count,
    page,
    pageSize,
    currentPageSize: result.length,
  });
  response.status(200).json(
    buildResponse({
      response: result,
      metadata,
    })
  );
});

consumersRouterV1.get('/:id', async (request: Request, response: Response) => {
  const consumer = await Consumer.query()
    .findById(request.params.id)
    .withGraphFetched('sender');

  if (!consumer) {
    response.status(404).json({ message: 'not found' });
  } else {
    response.status(200).json(consumer);
  }
});

consumersRouterV1.put(
  '/:id',
  validateConsumerCreateRequest(),
  async (request: Request, response: Response) => {
    const consumer = await Consumer.query()
      .patchAndFetchById(request.params.id, request.body)
      .withGraphFetched('sender');

    if (!consumer) {
      response.status(404).json({ message: 'not found' });
    } else {
      response.status(200).json(consumer);
    }
  }
);

consumersRouterV1.delete(
  '/:id',
  async (request: Request, response: Response) => {
    const deleted = await Consumer.query().deleteById(request.params.id);

    if (!deleted) {
      response.status(404).json({ message: 'not found' });
    } else {
      response.status(200).json({ deleted });
    }
  }
);

export default consumersRouterV1;
