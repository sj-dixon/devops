import {
  buildMetaData,
  buildResponse,
  getPaginationQueryParams,
} from '@alcumus/response-utils';
import express, { Request, Response, Router } from 'express';
import validateSenderCreateRequest from '../../middlewares/validateSenderCreateRequest';
import validateSenderUpdateChannelConfigs from '../../middlewares/validateSenderUpdateChannelConfigs';
import Sender from '../../models/sender';
import { simpleCipher } from '../../singletons/simpleCipher';
import { ChannelConfig } from '../../types';

const sendersRouterV1: Router = express.Router();

interface CreateSenderRequest {
  name: string;
  channelConfigs: [ChannelConfig];
}

// TODO: Protect these routes using tenant service
sendersRouterV1.post(
  '/',
  validateSenderCreateRequest(),
  async (request: Request, response: Response) => {
    const createSenderRequest: CreateSenderRequest = request.body;

    const encodedConfigs = simpleCipher.encrypt(
      Buffer.from(JSON.stringify(createSenderRequest.channelConfigs), 'utf8')
    );

    const sender = await Sender.query().insert({
      name: createSenderRequest.name,
      channelConfigs: encodedConfigs,
      createdBy: 0,
      modifiedBy: 0,
    });

    response.json(sender);
  }
);

sendersRouterV1.get('/', async (request: Request, response: Response) => {
  const {
    page = 1,
    pageSize = 10,
    skip = 0,
  } = getPaginationQueryParams(request.query);

  const baseQuery = Sender.query();

  const count = await baseQuery.resultSize();
  const result = await baseQuery.offset(skip).limit(pageSize);

  const metadata = buildMetaData({
    count,
    page,
    pageSize,
    currentPageSize: result.length,
  });
  response.status(200).json(
    buildResponse({
      response: result,
      metadata,
    })
  );
});

sendersRouterV1.get('/:id', async (request: Request, response: Response) => {
  const sender = await Sender.query().findById(request.params.id);

  if (!sender) {
    response.status(404).json({ message: 'not found' });
  } else {
    response.status(200).json(sender);
  }
});

sendersRouterV1.get(
  '/:id/channel-configs',
  async (request: Request, response: Response) => {
    const sender = await Sender.query().findById(request.params.id);

    if (!sender) {
      response.status(404).json({ message: 'not found' });
    } else {
      try {
        const decryptedConfigs = sender.getChannelConfigs();
        response.status(200).json(decryptedConfigs);
      } catch {
        response.status(400).json({
          error: 'Could not decrypt channel configs',
        });
      }
    }
  }
);

sendersRouterV1.put(
  '/:id/channel-configs',
  validateSenderUpdateChannelConfigs(),
  async (request: Request, response: Response) => {
    const sender = await Sender.query().patchAndFetchById(request.params.id, {
      channelConfigs: Sender.encryptChannelConfigs(request.body),
    });

    if (!sender) {
      response.status(404).json({ message: 'not found' });
    } else {
      response.status(200).json(sender.getChannelConfigs());
    }
  }
);

sendersRouterV1.delete('/:id', async (request: Request, response: Response) => {
  const deleted = await Sender.query().deleteById(request.params.id);

  if (!deleted) {
    response.status(404).json({ message: 'not found' });
  } else {
    response.status(200).json({ deleted });
  }
});

export default sendersRouterV1;
