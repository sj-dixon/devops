import { Utilities } from '@alcumus/globals';

const BASE_PATH_V1 = '/api/v1';

export const ENDPOINTS = {
  ADMIN: `${BASE_PATH_V1}/admin`,
  ADMIN_SENDERS: `/senders`,
  ADMIN_CONSUMERS: `/consumers`,
  NOTIFICATIONS: `${BASE_PATH_V1}/notifications`,
};

export const MESSAGES = {
  CONSUMER_KEY_HEADERS_REQUIRED: 'X-Consumer-Key headers is required',
  CONSUMER_KEY_INVALID: 'X-Consumer-Key is invalid',
};

export const QUEUE_CONNECTION_STRING = Utilities.ProcessEnv.getValueOrDefault(
  'NOTIFICATIONS_SERVICE_QUEUE_CONNECTION_STRING',
  'amqp://localhost'
);

export const ASB_CONNECTION_STRING = Utilities.ProcessEnv.getValue(
  'NOTIFICATIONS_SERVICE_ASB_CONNECTION_STRING'
) as string;

export const EMAIL_QUEUE_NAME = Utilities.ProcessEnv.getValueOrDefault(
  'NOTIFICATIONS_SERVICE_EMAIL_QUEUE_NAME',
  'notifications-email-queue'
);

export const SECRET_KEY = String(
  Utilities.ProcessEnv.getValueOrDefault(
    'NOTIFICATIONS_SERVICE_SECRET_KEY',
    'secret'
  )
);

export const GENERATED_API_KEY_SIZE_BYTES = Number(
  Utilities.ProcessEnv.getValueOrDefault(
    'NOTIFICATIONS_SERVICE_GENERATED_API_KEY_SIZE_BYTES',
    '16'
  )
);

export const NOTIFICATIONS_SERVICE_PORT = Number(
  Utilities.ProcessEnv.getValueOrDefault('NOTIFICATIONS_SERVICE_PORT', '8018')
);
