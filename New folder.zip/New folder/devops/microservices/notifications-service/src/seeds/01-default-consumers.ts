import { Knex } from 'knex';
import Consumer from '../models/consumer';
import { NotificationLog } from '../models/notificationLog';
import Sender from '../models/sender';

export async function seed(knex: Knex): Promise<void> {
  Consumer.knex(knex);
  Sender.knex(knex);
  NotificationLog.knex(knex);

  console.log('Removing all notifications');
  await knex(NotificationLog.tableName).del();

  console.log('Removing all consumers & senders');
  await knex(Consumer.tableName).del();
  await knex(Sender.tableName).del();

  console.log('Creating default consumer & sender');

  const defaultSender = await Sender.query().insert({
    createdBy: 999,
    modifiedBy: 999,
    name: 'default',
    channelConfigs: Sender.encryptChannelConfigs([]),
  });

  const defaultConsumer = await Consumer.query().insert({
    createdBy: 999,
    modifiedBy: 999,
    name: 'default',
    senderId: defaultSender.id,
    apiKey: 'default-consumer-api-key',
  });

  console.log(
    `Default consumer created, ID = ${defaultConsumer.id}, Api Key = '${defaultConsumer.apiKey}'`
  );

  const consumer2 = await Consumer.query().insert({
    createdBy: 999,
    modifiedBy: 999,
    name: 'second',
    senderId: defaultSender.id,
    apiKey: 'second-consumer-api-key',
  });

  console.log(
    `Second consumer created, ID = ${consumer2.id}, Api Key = '${consumer2.apiKey}'`
  );
}
