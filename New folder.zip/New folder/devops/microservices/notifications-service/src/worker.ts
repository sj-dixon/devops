import { createTransport } from './lib/clients/nodemailer';
import { getQueue } from './lib/clients/queue';
import { getEmailEventHandler } from './lib/emailEventHandler';

(async () => {
  const queue = getQueue();
  const transport = await createTransport();
  console.log(`Using queue: ${queue.constructor.name}`);
  await queue.initialize();
  console.log('Queue initialized');
  const handler = getEmailEventHandler(queue, transport);
  queue.listen(handler);
})();
