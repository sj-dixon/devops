import path from 'path';
import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import adminRouterV1 from './routes/admin/adminV1';
import notificationsRouterV1 from './routes/notificationsV1';

const apiSpec = './api-spec.yaml';

const notificationsServiceApp = configureApp({
  serviceName: 'Notifications Service',
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
  },
  setup: (app) => {
    app.use(ENDPOINTS.ADMIN, adminRouterV1);
    app.use(ENDPOINTS.NOTIFICATIONS, notificationsRouterV1);
  },
});

export default notificationsServiceApp;
