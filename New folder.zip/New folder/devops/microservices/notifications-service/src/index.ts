import { runApp } from '@alcumus/express-app';
import app from './app';
import process from 'process';
import { NOTIFICATIONS_SERVICE_PORT } from './constants';
import getKnexClient from './lib/clients/knex';
import { getQueue } from './lib/clients/queue';

const emailQueue = getQueue();
const knexClient = getKnexClient();

runApp(app, {
  port: NOTIFICATIONS_SERVICE_PORT,
  setup: async () => await emailQueue.initialize(),
}).catch(async (reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
  await knexClient.destroy();
  await emailQueue.destroy();
  process.exit(1);
});
