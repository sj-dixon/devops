import { Utilities } from '@alcumus/globals';
import connectToKnex, { Knex } from 'knex';
import request, { Response } from 'supertest';
import config from '../../src/knexfile';
import app from '../../src/app';
import { ENDPOINTS } from '../../src/constants';
import { Model } from 'objection';
import Consumer from '../../src/models/consumer';
import Sender from '../../src/models/sender';
import randomstring from 'randomstring';
import { emailQueue } from '../../src/lib/clients/queue';

const VALID_EMAIL_NOTIFICATION_REQUEST_BODY = {
  channel: 'email',
  payload: {
    recipients: ['test@test.com'],
    from: {
      email: 'no-reply@example.com',
      name: 'No Reply',
    },
    subject: 'Welcome to Example.com',
    text: 'Welcome to Example.com, your password is "TEST"',
    html: '<p>Welcome to Example.com, your password is <b>"TEST"</b><p>',
  },
};

const VALID_EMAIL_NOTIFICATION_REQUEST_BODY_2 = {
  channel: 'email',
  payload: {
    recipients: ['second@test.com'],
    from: {
      email: 'no-reply@example.com',
      name: 'No Reply',
    },
    subject: 'Welcome to Example.com',
    text: 'Welcome to Example.com, your password is "TEST"',
    html: '<p>Welcome to Example.com, your password is <b>"TEST"</b><p>',
  },
};

async function createConsumer(sender: Sender) {
  return Consumer.query().insert({
    createdBy: 123,
    modifiedBy: 123,
    name: 'test-consumer',
    senderId: sender.id,
    apiKey: randomstring.generate(),
  });
}

describe('Notifications Service: Create and Read Endpoints', () => {
  let knex: Knex;
  let sender: Sender;

  beforeAll(async () => {
    Utilities.ProcessEnv.overrideEnv({
      NOTIFICATIONS_SERVICE_EMAIL_QUEUE_NAME: 'notifications-queue-email-test',
    });
    knex = connectToKnex(config);
    Model.knex(knex);
    sender = await Sender.query().insert({
      createdBy: 0,
      modifiedBy: 0,
      name: 'test-sender',
      channelConfigs: Sender.encryptChannelConfigs([]),
    });
    await emailQueue.initialize();
  });

  afterAll(async () => {
    await emailQueue.destroy();
    await knex.destroy();
    Utilities.ProcessEnv.clearOverrides();
  });

  it('POST /api/v1/notifications', async () => {
    const consumer = await createConsumer(sender);
    await request(app)
      .post(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer.apiKey })
      .send(VALID_EMAIL_NOTIFICATION_REQUEST_BODY)
      .expect(200);
  });

  it('GET /api/v1/notifications - Before created any notifications', async () => {
    const consumer = await createConsumer(sender);
    await request(app)
      .get(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer.apiKey })
      .expect(200, {
        documents: [],
        metadata: {
          total_documents_count: 0,
          page_number: 1,
          page_size: 10,
          current_page_size: 0,
          total_pages: 0,
        },
      });
  });

  it('GET /api/v1/notifications - After creating a notification', async () => {
    const consumer = await createConsumer(sender);
    const consumer2 = await createConsumer(sender);

    // Create using default consumer
    await request(app)
      .post(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer.apiKey })
      .send(VALID_EMAIL_NOTIFICATION_REQUEST_BODY)
      .expect(200);

    // Create using second consumer
    await request(app)
      .post(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer2.apiKey })
      .send(VALID_EMAIL_NOTIFICATION_REQUEST_BODY_2)
      .expect(200);

    // Query as default consumer
    await request(app)
      .get(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer.apiKey })
      .expect(200)
      .expect((res: Response) => {
        expect(res.body.metadata).toStrictEqual({
          total_documents_count: 1,
          page_number: 1,
          page_size: 10,
          current_page_size: 1,
          total_pages: 1,
        });
        expect(res.body.documents).toHaveLength(1);
        expect(res.body.documents[0].id).not.toBeNull();
        expect(res.body.documents[0].channel).toBe('email');
        expect(res.body.documents[0].payload.recipients[0]).toBe(
          'test@test.com'
        );
        expect(res.body.documents[0].payload.from.email).toBe(
          'no-reply@example.com'
        );
      });

    // Query as second consumer
    await request(app)
      .get(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer2.apiKey })
      .expect(200)
      .expect((res: Response) => {
        expect(res.body.metadata).toStrictEqual({
          total_documents_count: 1,
          page_number: 1,
          page_size: 10,
          current_page_size: 1,
          total_pages: 1,
        });
        expect(res.body.documents).toHaveLength(1);
        expect(res.body.documents[0].id).not.toBeNull();
        expect(res.body.documents[0].channel).toBe('email');
        expect(res.body.documents[0].payload.recipients[0]).toBe(
          'second@test.com'
        );
      });
  });

  it('GET /api/v1/notifications/{id}', async () => {
    const consumer = await createConsumer(sender);
    const consumer2 = await createConsumer(sender);

    // Create using default consumer
    const notification1 = await request(app)
      .post(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer.apiKey })
      .send(VALID_EMAIL_NOTIFICATION_REQUEST_BODY)
      .expect(200);

    // Create using second consumer
    const notification2 = await request(app)
      .post(ENDPOINTS.NOTIFICATIONS)
      .set({ 'X-Consumer-Key': consumer2.apiKey })
      .send(VALID_EMAIL_NOTIFICATION_REQUEST_BODY_2)
      .expect(200);

    // Query as default consumer
    await request(app)
      .get(`${ENDPOINTS.NOTIFICATIONS}/${notification1.body.id}`)
      .set({ 'X-Consumer-Key': consumer.apiKey })
      .expect(200)
      .expect((res: Response) => {
        expect(res.body.id).toBe(notification1.body.id);
        expect(res.body.channel).toBe('email');
        expect(res.body.payload.recipients[0]).toBe('test@test.com');
        expect(res.body.payload.from.email).toBe('no-reply@example.com');
      });
    await request(app)
      .get(`${ENDPOINTS.NOTIFICATIONS}/${notification2.body.id}`)
      .set({ 'X-Consumer-Key': consumer.apiKey })
      .expect(404);

    // Query as second consumer
    await request(app)
      .get(`${ENDPOINTS.NOTIFICATIONS}/${notification2.body.id}`)
      .set({ 'X-Consumer-Key': consumer2.apiKey })
      .expect(200)
      .expect((res: Response) => {
        expect(res.body.id).toBe(notification2.body.id);
        expect(res.body.channel).toBe('email');
        expect(res.body.payload.recipients[0]).toBe('second@test.com');
        expect(res.body.payload.from.email).toBe('no-reply@example.com');
      });
    await request(app)
      .get(`${ENDPOINTS.NOTIFICATIONS}/${notification1.body.id}`)
      .set({ 'X-Consumer-Key': consumer2.apiKey })
      .expect(404);
  });
});
