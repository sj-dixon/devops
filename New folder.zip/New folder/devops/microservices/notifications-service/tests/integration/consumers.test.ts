import connectToKnex, { Knex } from 'knex';
import config from '../../src/knexfile';
import request from 'supertest';

import app from '../../src/app';
import { ENDPOINTS } from '../../src/constants';
import { Model } from 'objection';
import Sender from '../../src/models/sender';

describe('Notifications Service: Consumer Endpoints', () => {
  let knex: Knex;
  let senderId: number;

  beforeAll(async () => {
    knex = connectToKnex(config);
    Model.knex(knex);
    const sender = await Sender.query().insert({
      name: 'default',
      channelConfigs: Sender.encryptChannelConfigs([]),
      createdBy: 0,
      modifiedBy: 0,
    });
    senderId = sender.id;
  });

  afterAll(async () => {
    await knex.destroy();
  });

  it('Create Consumers', async () => {
    const { body: consumerA } = await request(app)
      .post(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_CONSUMERS)
      .send({ name: 'consumer A', senderId })
      .expect((response) => expect(response.body.apiKey).toBeDefined())
      .expect(200);

    const { body: consumerB } = await request(app)
      .post(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_CONSUMERS)
      .send({ name: 'consumer B', senderId })
      .expect((response) => expect(response.body.apiKey).toBeDefined())
      .expect(200);

    expect(consumerA.id).not.toBe(consumerB.id);
    expect(consumerA.apiKey).not.toBe(consumerB.apiKey);
  });

  it('Consumer API Keys are hidden', async () => {
    const { body: consumer } = await request(app)
      .post(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_CONSUMERS)
      .send({ name: 'consumer A', senderId })
      .expect((response) => expect(response.body.apiKey).toBeDefined())
      .expect(200);

    const { body: consumerInfo } = await request(app)
      .get(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_CONSUMERS + `/${consumer.id}`)
      .expect((response) => expect(response.body.apiKey).toBeUndefined())
      .expect(200);
  });
});
