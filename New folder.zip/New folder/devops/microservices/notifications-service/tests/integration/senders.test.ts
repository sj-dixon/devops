import connectToKnex, { Knex } from 'knex';
import config from '../../src/knexfile';
import request from 'supertest';

import app from '../../src/app';
import { ENDPOINTS } from '../../src/constants';
import { Model } from 'objection';

const VALID_SENDER_REQUEST_A = {
  name: 'sender A',
  channelConfigs: [
    {
      channel: 'email',
      driver: {
        name: 'smtp',
        host: 'localhost',
        port: '1025',
      },
    },
  ],
};

const VALID_SENDER_REQUEST_B = {
  name: 'sender B',
  channelConfigs: [
    {
      channel: 'text',
      driver: {
        name: 'onesignal',
        accountId: 'test',
        apiKey: 'test',
      },
    },
  ],
};

describe('Notifications Service: Admin Endpoints', () => {
  let knex: Knex;

  beforeAll(async () => {
    knex = connectToKnex(config);
    Model.knex(knex);
  });

  afterAll(async () => {
    await knex.destroy();
  });

  it('Create Senders', async () => {
    const { body: senderA } = await request(app)
      .post(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_SENDERS)
      .send(VALID_SENDER_REQUEST_A)
      .expect((response) =>
        expect(response.body.channelConfigs).toBeUndefined()
      )
      .expect(200);

    const { body: senderB } = await request(app)
      .post(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_SENDERS)
      .send(VALID_SENDER_REQUEST_B)
      .expect((response) =>
        expect(response.body.channelConfigs).toBeUndefined()
      )
      .expect(200);

    expect(senderA.id).not.toBe(senderB.id);
  });

  it('Channel configs are stored as blob in database', async () => {
    const { body: sender } = await request(app)
      .post(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_SENDERS)
      .send(VALID_SENDER_REQUEST_A)
      .expect(200);

    const { body: senderChannelConfigs } = await request(app)
      .get(
        ENDPOINTS.ADMIN +
          ENDPOINTS.ADMIN_SENDERS +
          `/${sender.id}/channel-configs`
      )
      .expect(200);

    expect(senderChannelConfigs).toEqual(VALID_SENDER_REQUEST_A.channelConfigs);

    const senderInDb = await knex('senders').where('id', sender.id).first();
    expect(senderInDb.channelConfigs instanceof Buffer).toBeTruthy();
  });

  it('Update Sender channelConfigs', async () => {
    const { body: sender } = await request(app)
      .post(ENDPOINTS.ADMIN + ENDPOINTS.ADMIN_SENDERS)
      .send(VALID_SENDER_REQUEST_A)
      .expect(200);

    const { body: updatedSenderChannelConfigs } = await request(app)
      .put(
        ENDPOINTS.ADMIN +
          ENDPOINTS.ADMIN_SENDERS +
          `/${sender.id}/channel-configs`
      )
      .send(VALID_SENDER_REQUEST_B.channelConfigs)
      .expect(200);

    expect(updatedSenderChannelConfigs).toEqual(
      VALID_SENDER_REQUEST_B.channelConfigs
    );
  });
});
