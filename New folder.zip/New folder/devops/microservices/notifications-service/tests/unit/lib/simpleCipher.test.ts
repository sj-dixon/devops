import { SimpleCipher } from '../../../src/lib/simpleCipher';

// Encoding used for String to Buffer conversion
const ENCODING = 'utf-8';

const DUMMY_DATA = {
  random: 'json object',
  test: 123,
};

describe('SimpleCipher', () => {
  it('encrypts and decrypts any object', () => {
    // The longer the key the better, although there is no lower or upper limit
    // We use the md5 hash of this key as a secret key (so that it always is 128 bits)
    const secret = 'my secret key';
    const simpleCipher = new SimpleCipher(secret);

    const dataAsBuffer = Buffer.from(JSON.stringify(DUMMY_DATA), ENCODING);
    const encrypted = simpleCipher.encrypt(dataAsBuffer);

    expect(encrypted instanceof Buffer).toBe(true);
    // Assert buffers are different
    expect(encrypted.compare(dataAsBuffer)).not.toBe(0);

    const decrypted = simpleCipher.decrypt(encrypted);
    // Assert decrypted buffer is identical to source
    expect(decrypted.compare(dataAsBuffer)).toBe(0);

    const decryptedData = JSON.parse(decrypted.toString(ENCODING));
    expect(decryptedData).toEqual(DUMMY_DATA);
  });

  it('cannot decrypt with new key', () => {
    const secret = 'my secret key';
    const simpleCipher = new SimpleCipher(secret);

    const secretNew = 'my other key';
    const simpleCipherNew = new SimpleCipher(secretNew);

    const dataAsBuffer = Buffer.from(JSON.stringify(DUMMY_DATA), ENCODING);
    const encrypted = simpleCipher.encrypt(dataAsBuffer);

    expect(() => {
      const decrypted = simpleCipherNew.decrypt(encrypted);
    }).toThrow();
  });
});
