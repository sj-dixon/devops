import { Utilities } from '@alcumus/globals';

export const V1_BASE_PATH = '/api/v1';
export const ADMIN_SERVICE_PORT =
  Number(Utilities.ProcessEnv.getValue('ADMIN_SERVICE_PORT')) || 8014;

export const ENDPOINTS = {
  IMPERSONATE: `${V1_BASE_PATH}/impersonate`,
};
