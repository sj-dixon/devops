import { Types } from '@alcumus/globals';
import { NextFunction, Response } from 'express';
import { doesUserHaveUsername } from '../lib/users';

export async function requireUserHasUsername(
  request: Types.Request,
  response: Response,
  next: NextFunction
) {
  const username = request.body.username;
  const alcumusUserId = Number(request.body.alcumusUserId);
  const userAccountType = request.body.userAccountType;
  if (!alcumusUserId || Number.isNaN(alcumusUserId) || !username) {
    response.sendStatus(400);
    return;
  }

  const user = await doesUserHaveUsername(
    request,
    alcumusUserId,
    username,
    userAccountType
  );
  if (!user) {
    response.status(404).json({
      message: `User ${alcumusUserId} does not have username ${username}`,
    });
  } else {
    next();
  }
}
