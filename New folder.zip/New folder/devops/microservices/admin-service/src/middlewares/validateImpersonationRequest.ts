import { expressValidator } from '@alcumus/express-app';

export const requireUserName = expressValidator
  .body('username', 'admin.impersonate.userNameDoesNotExist')
  .exists()
  .isString()
  .notEmpty()
  .bail();

export const requireUserAccountType = expressValidator
  .body('userAccountType', 'admin.impersonate.userAccountTypeIsInvalid')
  .exists()
  .isString()
  .notEmpty()
  .bail();

export const requireUserId = expressValidator
  .body('alcumusUserId', 'admin.impersonate.alcumusUserIdDoesNotExist')
  .exists()
  .isNumeric()
  .notEmpty()
  .bail();
