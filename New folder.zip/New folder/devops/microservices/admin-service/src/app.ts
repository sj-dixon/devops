import { configureApp } from '@alcumus/express-app';
import { ENDPOINTS } from './constants';
import path from 'path';
import impersonationRouter from './routes/impersonateV1';

const apiSpec = './api-spec.yaml';

const app = configureApp({
  serviceName: 'Admin Service',
  cwd: path.join(__dirname, '../build/api'),
  apiOptions: {
    apiSpec,
    specType: 'openapi',
    validateResponse: true,
  },
  setup: (theApp) => {
    theApp.use(ENDPOINTS.IMPERSONATE, impersonationRouter);
  },
});

export default app;
