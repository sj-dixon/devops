export interface ImpersonationRequest {
  username: string;
  alcumusUserId: number;
  userAccountType: string;
}

export interface StandardLoginToken {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  expiresAt: number;
  refreshExpiresIn: number;
  refreshExpiresAt: number;
  tokenType: string;
}

/* eslint-disable camelcase */

export interface KeycloakOAuthGrant {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  refresh_expires_in: number;
}

/* eslint-enable camelcase */
