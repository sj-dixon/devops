import express, { Response, Router } from 'express';
import { Middlewares, Types } from '@alcumus/globals';
import {
  requireUserName,
  requireUserId,
  requireUserAccountType,
} from '../middlewares/validateImpersonationRequest';
import { ImpersonationRequest } from '../types';
import { validationHandler } from '@alcumus/express-app';
import { handleImpersonation } from '../controllers/impersonationController';
import { requireUserHasUsername } from '../middlewares/requireValidUsernameAndUserId';

const impersonationRouter: Router = express.Router();

impersonationRouter.post(
  '/',
  Middlewares.requireApiKeyHeader,
  requireUserId,
  requireUserName,
  requireUserAccountType,
  requireUserHasUsername,
  Middlewares.decodeRequestedBy,
  Middlewares.requireApiClientAppHeader,
  validationHandler(401),
  async (request: Types.Request, response: Response): Promise<void> => {
    const impersonationRequest: ImpersonationRequest = request.body;
    const impersonationResponse = await handleImpersonation(
      request,
      response,
      impersonationRequest
    );

    response.json(impersonationResponse);
  }
);

export default impersonationRouter;
