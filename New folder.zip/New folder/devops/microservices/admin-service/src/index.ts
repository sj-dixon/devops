import { runApp } from '@alcumus/express-app';
import app from './app';
import process from 'process';
import { ADMIN_SERVICE_PORT } from './constants';

runApp(app, {
  port: ADMIN_SERVICE_PORT,
}).catch(async (reason) => {
  console.error(`Process ${process.pid} failed due to: ${reason}`);
  process.exit(1);
});
