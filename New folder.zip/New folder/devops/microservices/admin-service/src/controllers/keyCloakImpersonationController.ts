import { Types } from '@alcumus/globals';
import { Response } from 'express';
import { impersonateWithKeycloak } from '../lib/utils/keycloak/impersonation';
import { transformKeycloakToken } from '../lib/utils/keycloakTokenAdapter';
import { StandardLoginToken, ImpersonationRequest } from '../types';

export async function handleKeycloakImpersonation(
  request: Types.Request,
  response: Response,
  impersonationRequest: ImpersonationRequest
): Promise<StandardLoginToken | null> {
  const { username } = impersonationRequest;
  const { status, data } = await impersonateWithKeycloak(
    request,
    impersonationRequest
  );
  if (status >= 500) {
    console.error(
      `Keycloak failure for user identifier ${username} failed due to ${status} error`,
      data
    );
    response.status(500).json({
      message: 'Could not process login request at this time',
    });
    return null;
  } else if (status >= 400) {
    console.log(
      `Login failure for user identifier ${username} failed due to ${status} response`,
      data
    );
    response.status(status).json({
      // @ts-expect-error - ts doesnt like dot nation with keys containing underscores
      message: data.error_description,
    });
    return null;
  } else {
    const now = new Date(Date.now());
    return transformKeycloakToken(data, now);
  }
}
