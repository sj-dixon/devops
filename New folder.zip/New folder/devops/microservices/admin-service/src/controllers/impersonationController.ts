import { Types } from '@alcumus/globals';
import { Response } from 'express';
import { ImpersonationRequest, StandardLoginToken } from '../types';
import { handleKeycloakImpersonation } from './keyCloakImpersonationController';

export async function handleImpersonation(
  request: Types.Request,
  response: Response,
  impersonationRequest: ImpersonationRequest
): Promise<StandardLoginToken | null> {
  return handleKeycloakImpersonation(request, response, impersonationRequest);
}
