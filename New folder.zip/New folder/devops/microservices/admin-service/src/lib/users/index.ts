import { Types, Utilities } from '@alcumus/globals';

export enum UserAccountType {
  PERSONAL_ACCOUNT = 'PERSONAL_ACCOUNT',
  ORGANIZATION_ACCOUNT = 'ORGANIZATION_ACCOUNT',
  EXTERNAL_ACCOUNT = 'EXTERNAL_ACCOUNT',
}

export async function doesUserHaveUsername(
  request: Types.Request,
  alcumusUserId: number,
  username: string,
  userAccountType: UserAccountType
): Promise<boolean> {
  const axiosClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    Types.ServiceEndpoints.USERS
  );

  const user = await axiosClient.get(`/api/v1/employees/${alcumusUserId}`);
  if (user.status === 404) return false;

  const accounts = await axiosClient.get(
    `/api/v1/users/${user.data.id}/accounts`
  );
  return accounts.data.some(
    (r: { username: string; userAccountType: string }) =>
      r.username === username && r.userAccountType === userAccountType
  );
}
