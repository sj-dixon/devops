export interface Tenant {
  id: number;
  tenantName: string;
  tenantIdentifier: string;
}

export interface CreatedUser {
  id: number;
  firstName: string;
  lastName: string;
}
