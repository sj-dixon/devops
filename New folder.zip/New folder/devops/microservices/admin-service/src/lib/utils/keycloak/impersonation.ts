import axios from 'axios';
import qs from 'querystring';
import { ImpersonationRequest, KeycloakOAuthGrant } from '../../../types';
import { Utilities, Types } from '@alcumus/globals';
import { toKeycloakEmailOrUsername } from '@alcumus/auth-plugin';
import { retrieveAuthProvider } from '../../tenants';
import { OrganizationAuthProviderType } from '../../tenants/types';

interface KeycloakResponse {
  status: number;
  data: KeycloakOAuthGrant;
}

export async function impersonateWithKeycloak(
  request: Types.Request,
  impersonationRequest: ImpersonationRequest
): Promise<KeycloakResponse> {
  const keycloak = Utilities.getKeycloakConstants();
  const { username, alcumusUserId } = impersonationRequest;
  const url = `${keycloak.URL}/realms/${keycloak.REALM}/protocol/openid-connect/token`;
  const config = {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    validateStatus: null,
  };

  await populatePropertyIfSet(
    config.headers,
    'x-api-client-app',
    request.requestedBy?.requestedByApplication
  );
  await populatePropertyIfSet(
    config.headers,
    'x-requested-by',
    request.requestedBy?.requestedForIpAddress || request.socket.remoteAddress,
    (ip) =>
      `for=${ip};proto=https${
        request.requestedBy?.requestedByHost
          ? `;by=${request.requestedBy.requestedByHost}`
          : ''
      }`
  );

  const authProvider = await retrieveAuthProvider(
    request,
    alcumusUserId,
    OrganizationAuthProviderType.KEYCLOAK
  );
  const keycloakUserName = toKeycloakEmailOrUsername(
    username,
    authProvider?.userNamePrefix
  );

  const body = {
    client_id: keycloak.ADMIN_ID,
    client_secret: keycloak.ADMIN_SECRET,
    requested_subject: keycloakUserName,
    grant_type: 'urn:ietf:params:oauth:grant-type:token-exchange',
  };
  const result = await axios.post(url, qs.stringify(body), config);
  console.log(
    `Admin with id ${request.headers['x-admin-identifier']} received token alcumusUserId ${alcumusUserId} for organization ${authProvider?.organizationId}`
  );
  return {
    data: result.data,
    status: result.status,
  };
}

function populatePropertyIfSet(
  headers: { [key: string]: string },
  propertyName: string,
  propertyValue: string | undefined,
  transform?: (value: string | undefined) => string
): void {
  if (!propertyValue) {
    return;
  }
  if (!transform) {
    headers[propertyName] = propertyValue;
  } else {
    headers[propertyName] = transform(propertyValue);
  }
}
