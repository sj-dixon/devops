import add from 'date-fns/add';
import getUnixTime from 'date-fns/getUnixTime';
import { StandardLoginToken, KeycloakOAuthGrant } from '../../types';

export function transformKeycloakToken(
  data: KeycloakOAuthGrant,
  now: Date
): StandardLoginToken {
  const expiresAt = getUnixTime(
    add(now, {
      seconds: data.expires_in,
    })
  );
  const refreshExpiresAt = getUnixTime(
    add(now, {
      seconds: data.refresh_expires_in,
    })
  );
  const transformedToken = {
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    expiresIn: data.expires_in,
    expiresAt: expiresAt,
    refreshExpiresAt: refreshExpiresAt,
    refreshExpiresIn: data.refresh_expires_in,
    tokenType: data.token_type,
  };

  return transformedToken;
}
