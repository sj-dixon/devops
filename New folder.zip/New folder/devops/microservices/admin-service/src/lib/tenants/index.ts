import { Types, Utilities } from '@alcumus/globals';
import {
  OrganizationAuthProvider,
  OrganizationAuthProviderType,
} from './types';

export async function retrieveAuthProvider(
  request: Types.Request,
  alcumusUserId: number,
  providerType: OrganizationAuthProviderType
): Promise<OrganizationAuthProvider | null> {
  const usersAxiosClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    Types.ServiceEndpoints.USERS
  );

  const organizationResult = await usersAxiosClient.get(
    `/api/v1/employees/${alcumusUserId}/organization`
  );
  if (organizationResult.status === 404) return null;

  const tenantsAxiosClient = Utilities.AxiosClient.getServiceMeshAxiosClient(
    request,
    Types.ServiceEndpoints.TENANTS
  );

  const result = await tenantsAxiosClient.get(
    `/api/v1/organizations/${organizationResult.data.organizationId}/authProviders/${providerType}`
  );

  if (result.status === 404) {
    return null;
  } else {
    return result.data as OrganizationAuthProvider;
  }
}
