import { v4 as uuidV4 } from 'uuid';
import { Utilities } from '@alcumus/globals';
import supertest from 'supertest';
import {
  ENVIRONMENT,
  generateRandomNumber,
  mockRetrieveAuthProvider,
  mockRetrievegetOrganizationByAlcumusUserId,
  mockUserIdLookup,
  mockUserNameLookup,
  mockValidKeycloakImpersonateLogin,
  SUCCESS_TOKEN,
} from './testHelpers';
import app from '../../../src/app';
import { ENDPOINTS } from '../../../src/constants';
import { CreatedUser } from '../../../src/lib/users/types';

describe('api/v1/impersonate', () => {
  let username: string;
  let alcumusUserId: number;
  let userAccountType: string;
  let email: string;
  let internalAccountId: string;
  let dateNowSpy: jest.SpyInstance;
  let user: CreatedUser;
  let userIdLookup: jest.Mock;
  let usernameLookup: jest.Mock;
  let retrieveAuthProvider: jest.Mock;
  let organizationLookup: jest.Mock;
  beforeAll(async () => {
    Utilities.ProcessEnv.overrideEnv(ENVIRONMENT);
    dateNowSpy = jest
      .spyOn(Date, 'now')
      .mockImplementation(() => 1487076708000);
    const randomId = generateRandomNumber();
    internalAccountId = uuidV4();
    username = `meV1-${randomId}`;
    email = `meV1-${randomId}@mev1.ts`;
    user = {
      id: 911031,
      firstName: 'Ted',
      lastName: 'Mosby',
    };
    alcumusUserId = 2000;
    userAccountType = 'PERSONAL_ACCOUNT';
  });

  beforeEach(async () => {
    userIdLookup = mockUserIdLookup(user.id, alcumusUserId);
    usernameLookup = mockUserNameLookup(user.id, username, userAccountType);
    organizationLookup = mockRetrievegetOrganizationByAlcumusUserId(
      alcumusUserId,
      123
    );
    retrieveAuthProvider = mockRetrieveAuthProvider(123, 'prefix');
  });

  afterAll(async () => {
    dateNowSpy.mockRestore();
  });

  describe('POST /', () => {
    it('retrieves user account credentials', async () => {
      const mockedImpersonationCall =
        mockValidKeycloakImpersonateLogin(username);

      const result = await supertest(app)
        .post(`${ENDPOINTS.IMPERSONATE}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', 'FIELD_ID')
        .set('x-admin-identifier', 'fieldid@admin.com')
        .send({ username, alcumusUserId, userAccountType });
      expect(mockedImpersonationCall).toHaveBeenCalledTimes(1);
      expect([result.status, result.body]).toEqual([200, SUCCESS_TOKEN]);
    });

    it("errors when user doesn't have account type", async () => {
      const result = await supertest(app)
        .post(`${ENDPOINTS.IMPERSONATE}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', 'FIELD_ID')
        .set('x-admin-identifier', 'fieldid@admin.com')
        .send({ username, alcumusUserId, userAccountType: 'EXTERNAL_ACCOUNT' });
      expect(result.body).toMatchObject({
        message: expect.stringContaining(`does not have username ${username}`),
      });
    });

    it("errors when alcumusUserId and username don't match", async () => {
      const result = await supertest(app)
        .post(`${ENDPOINTS.IMPERSONATE}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', 'FIELD_ID')
        .set('x-admin-identifier', 'fieldid@admin.com')
        .send({
          username: 'testName',
          alcumusUserId,
          userAccountType,
        });
      expect(result.status).toEqual(404);
      expect(result.body).toMatchObject({
        message: expect.stringContaining('does not have username testName'),
      });
    });

    it('Errors when api key header not sent', async () => {
      const result = await supertest(app)
        .post(`${ENDPOINTS.IMPERSONATE}`)
        .set('x-api-client-app', 'FIELD_ID')
        .set('x-admin-identifier', 'fieldid@admin.com')
        .send({ username, alcumusUserId, userAccountType });
      expect([result.status, result.body]).toEqual([
        401,
        { message: "'x-api-key' header required" },
      ]);
    });

    it('Errors when client app header not sent', async () => {
      const result = await supertest(app)
        .post(`${ENDPOINTS.IMPERSONATE}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-admin-identifier', 'fieldid@admin.com')
        .send({ username, alcumusUserId, userAccountType });
      expect([result.status, result.body]).toEqual([
        400,
        {
          message:
            "request.headers should have required property 'x-api-client-app'",
        },
      ]);
    });

    it('Errors when admin identifier header not sent', async () => {
      const result = await supertest(app)
        .post(`${ENDPOINTS.IMPERSONATE}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', 'FIELD_ID')
        .send({ username, alcumusUserId, userAccountType });
      expect([result.status, result.body]).toEqual([
        400,
        {
          message:
            "request.headers should have required property 'x-admin-identifier'",
        },
      ]);
    });

    it('Errors when invalid account type', async () => {
      const result = await supertest(app)
        .post(`${ENDPOINTS.IMPERSONATE}`)
        .set('x-api-key', ENVIRONMENT.SERVICE_MESH_API_KEY)
        .set('x-api-client-app', 'FIELD_ID')
        .set('x-admin-identifier', 'fieldid@admin.com')
        .send({ username, alcumusUserId, userAccountType: 'DOES_NOT_EXIST' });
      expect(result.status).toEqual(400);
      expect(result.body).toMatchObject({
        message: expect.stringContaining(
          'should be equal to one of the allowed values: PERSONAL_ACCOUNT, EXTERNAL_ACCOUNT, ORGANIZATION_ACCOUNT'
        ),
      });
    });
  });
});
