import axios, { AxiosRequestConfig } from 'axios';
import MockAdapter from 'axios-mock-adapter';
import * as queryString from 'querystring';
import { NextFunction, Response } from 'express';
import { Types } from '@alcumus/globals';
import { KeycloakOAuthGrant } from '../../../src/types';
import { OrganizationAuthProviderType } from '../../../src/lib/tenants/types';

jest.mock('@alcumus/auth-plugin', () => {
  const nextMiddleware = (
    request: Request,
    response: Response,
    next: NextFunction
  ) => {
    next();
  };

  // noinspection JSUnusedGlobalSymbols
  return {
    keycloakSessions: () => nextMiddleware,
    keycloakMiddleware: () => nextMiddleware,
    toKeycloakEmailOrUsername: (val?: string, prefix?: string) =>
      val ? `${prefix}${val}` : val,
    requireAuthentication:
      () =>
      (request: Types.Request, response: Response, next: NextFunction) => {
        if (request.headers.authorization?.endsWith('fakeSignature')) {
          next();
        } else {
          response.sendStatus(403);
        }
      },
  };
});

export const mockAxios = new MockAdapter(axios);
export const ACCESS_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJ1c2VySWQiOiJzb21lLXVzZXItaWQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJoZXN0aWEtdXNlci0xIn0.__2MxnL55c4XIe2JbrLsedQgrTnefdLJ56YpIxFkJzM';
export const REFRESH_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM4MDIyLCJ1c2VySWQiOiJzb21lLXVzZXItaWQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJoZXN0aWEtdXNlci0xIn0.DEH_Eh041Pyyfp4tphOxYUsmlYQQRBYUX3Yh7aTDSJc';
export const NOW_INSTANT_MS = 1487076708000;
export const NOW_INSTANT_SECONDS = NOW_INSTANT_MS / 1000;

export const KEYCLOAK_TOKEN: KeycloakOAuthGrant = {
  access_token: ACCESS_TOKEN,
  refresh_token: REFRESH_TOKEN,
  expires_in: 100,
  refresh_expires_in: 1000,
  token_type: 'Bearer',
};

export const SUCCESS_TOKEN = {
  accessToken: ACCESS_TOKEN,
  refreshToken: REFRESH_TOKEN,
  expiresIn: KEYCLOAK_TOKEN.expires_in,
  expiresAt: NOW_INSTANT_SECONDS + KEYCLOAK_TOKEN.expires_in,
  refreshExpiresIn: KEYCLOAK_TOKEN.refresh_expires_in,
  refreshExpiresAt: NOW_INSTANT_SECONDS + KEYCLOAK_TOKEN.refresh_expires_in,
  tokenType: KEYCLOAK_TOKEN.token_type,
};

export const ENVIRONMENT = {
  KEYCLOAK_SERVER_URL: 'http://secret-lair:8080/auth',
  KEYCLOAK_SERVER_REALM: 'secret-realm',
  KEYCLOAK_ADMIN_ID: 'secret-cli',
  KEYCLOAK_ADMIN_SECRET: '9012cf7e-e4d3-4e38-9186-93973f5c5326',
  KEYCLOAK_CLIENT_ID: 'regular-cli',
  KEYCLOAK_CLIENT_SECRET: 'banana split',
  SERVICE_MESH_HOST: 'https://secret-cloud:5000/api',
  SERVICE_MESH_API_KEY: 'carbonated ice cream',
  FEATURE_TOGGLE_USE_LINKERD: 'true',
  FEATURE_TOGGLE_MIGRATE_TO_AZURE_AD: 'false',
};

export const FAKE_TIME_FN = () => 1487076708000;

export function generateRandomNumber(): number {
  return Math.floor(Math.random() * 10000000) + 10000;
}

export function setupAxiosInterceptors(): void {
  axios.interceptors.response.use((response) => {
    console.log(
      `${response.config.method} ${response.config.url} -> ${response.status}`
    );
    return response;
  });
  axios.interceptors.request.use((request) => {
    console.log(
      `${request.method} ${request.url} with ${JSON.stringify(request.data)}`
    );
    return request;
  });
}

export function mockUserIdLookup(
  userId: number,
  alcumusUserId: number
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/employees/${alcumusUserId}`;
  const onReply = jest.fn(() => [
    200,
    {
      id: userId,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockUserNameLookup(
  userId: number,
  username: string,
  accountType: string
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/users/${userId}/accounts`;
  const onReply = jest.fn(() => [
    200,
    [
      {
        id: userId,
        username,
        userAccountType: accountType,
      },
    ],
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockValidKeycloakImpersonateLogin(username: string): jest.Mock {
  const url = `${ENVIRONMENT.KEYCLOAK_SERVER_URL}/realms/${ENVIRONMENT.KEYCLOAK_SERVER_REALM}/protocol/openid-connect/token`;
  const onReply = jest.fn((axiosRequestConfig: AxiosRequestConfig) => {
    const data = queryString.decode(axiosRequestConfig.data);
    expect(data).toEqual({
      requested_subject: `prefix${username}`,
      client_id: ENVIRONMENT.KEYCLOAK_ADMIN_ID,
      client_secret: ENVIRONMENT.KEYCLOAK_ADMIN_SECRET,
      grant_type: 'urn:ietf:params:oauth:grant-type:token-exchange',
    });
    return [200, KEYCLOAK_TOKEN];
  });
  mockAxios.onPost(url).replyOnce(onReply);
  return onReply;
}

export function mockRetrieveAuthProvider(
  organizationId: number,
  prefix: string
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/organizations/${organizationId}/authProviders/${OrganizationAuthProviderType.KEYCLOAK}`;
  const onReply = jest.fn(() => [
    200,
    {
      organizationId,
      userNamePrefix: prefix,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}

export function mockRetrievegetOrganizationByAlcumusUserId(
  alcumusUserId: number,
  organizationId: number
): jest.Mock {
  const serviceMeshUrl = `${ENVIRONMENT.SERVICE_MESH_HOST}/v1/employees/${alcumusUserId}/organization`;
  const onReply = jest.fn(() => [
    200,
    {
      organizationId,
    },
  ]);
  mockAxios.onGet(serviceMeshUrl).replyOnce(onReply);
  return onReply;
}
