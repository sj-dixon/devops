# admin-service

You can use this service to perform admin operations such as impersonation.

### Steps to run this service
- Run `npm ci && npm run clean && npm run bootstrap && npm run build`
- Run `npm run start-dev`
- Run this command in your terminal to see service health endpoint responding: `curl -i http://localhost:8014/api/health`
