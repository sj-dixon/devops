ROOT_DIR=$(git rev-parse --show-toplevel)
cd "${ROOT_DIR}/microservices" || exit

echo "========================================================================"
echo "Synchronizing dockerfiles and .dockerignore"
echo "========================================================================"

for directory in * ; do
  if [[ -d "$directory" && ! -L "$directory" ]]; then
    echo "Synchronizing files in $directory"
    sed "s/%SERVICE_NAME%/$directory/g" ../docker/Dockerfile > "$directory/Dockerfile"
    cat ../docker/.dockerignore > "$directory/.dockerignore"
  fi
done

echo "Done"
