#!/bin/bash

# this script is intended to ensure that all databases have been created on
# the docker mysql instance.

# The MySQL container initializes the DB using .sql files, but only on the first run.
# This script is run on successive runs of the mysql container, therefore ensuring we have the lastest set of DBs

MIGRATION_ROOT="$(git rev-parse --show-toplevel)/docker/mysql/migrations"
# We must ensure we use the right version of mysql
MYSQL_BIN="docker run --network host --rm mysql:8.0.25"

runDatabaseScript(){
  SCRIPT_PATH="${MIGRATION_ROOT}/$1"
  echo "Running ${SCRIPT_PATH}"
  $MYSQL_BIN mysql --host=127.0.0.1 --port=3311 --user=root --password='Safety123!!!' < "${SCRIPT_PATH}"
  MYSQL_RESULT=$?

  if [ $MYSQL_RESULT -eq 0 ]; then
    echo "Script successful."
  else
    echo "Could not ensure that databases are up to date."
    exit 2;
  fi;
}

runDatabaseScript "01-databases.sql"
runDatabaseScript "02-grant-privileges.sql"
runDatabaseScript "03-test-databases.sql"
