-- TODO: Get rid of this file, and create / drop DBs during test setup
CREATE DATABASE IF NOT EXISTS `billing_service_test_db`;
CREATE DATABASE IF NOT EXISTS `objection_lib_test_db`;